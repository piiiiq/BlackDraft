/**
 * �����ṩblack�༭�����п����ɵ��õĲ���
 */
package yang.app.black;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFRun.FontCharRange;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Slider;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.wb.swt.SWTResourceManager;

import qt.hellow;
import yang.app.black.starter.blackMain;
import yang.demo.allPurpose.cfg_read_write;
import yang.demo.allPurpose.io;
import yang.demo.allPurpose.stringAction;
import yang.demo.allPurpose.time;

public class blackAction implements Serializable{
	static final long serialVersionUID = 42L;
	black b;
	Point caretSize;
	static int RENAME = 0, SETNAME = 1;
	KeyListener numberlist;
	int listindex = 1;
	public findinfo findi;
	findinfo_result findinfoResult;
	boolean includeRecycle;
	public Listener sliderListener;
	public blackAction(black b) {
		this.b = b;
	}

	/**
	 * �½��ļ�
	 */
	public void newFile(File f) {
		b.getIO().New(f);
	}

	/**
	 * ���浱ǰ�༭���ļ� �÷��������black���saveCurrentFile����
	 */
	public void saveFile(boolean saveFileView, boolean saveCharCount) {
		b.saveCurrentFile(saveFileView, saveCharCount);
		b.changeSaveLabelState();
	}

	/**
	 * ��ʾ����
	 */
	public void showSettings() {
		new settings(b, SWT.None).open();
	}

	/**
	 * �������滻
	 * 
	 */
	public void findReplaceWord() {
		if (b.getEditer() != null) {
			new findWord(b, SWT.None).open();
			b.blackTextArea.clearSelection();
		}
	}

	/**
	 * ��С�༭������
	 */
	public void zoomIn() {
		if (b.getEditorZoomFromCFG() > 8)
			b.setEditorZoom(b.getEditorZoomFromCFG() - 10);
	}

	/**
	 * �Ŵ�༭������
	 */
	public void zoomOut() {
		if (b.getEditorZoomFromCFG() < 400)
			b.setEditorZoom(b.getEditorZoomFromCFG() + 10);
	}

	/**
	 * ѡ��༭�����е��ı�
	 */
	public void selectAllText(StyledText text) {
		if (text != null) {
			int oldTopPixes = text.getTopPixel();
			text.selectAll();
			text.setTopPixel(oldTopPixes);
		}
	}
	public void openWritingView(){
		if(b.wv == null || b.wv.isDisposed()){
			if(b.getCurrentEditFile() != null && b.text != null)
				b.wv = new writingView(b);
		}
	}
	public void restoreWritingView(){
		openWritingView();
		b.wv.resetView();
	}
	public boolean isWritingView(){
		if(b.getAppProperties("isWritingView") != null && b.getAppProperties("isWritingView").equals("true")) 
			return true;
		else return false;
	}
	public void getSystemInfo(){
		StringBuffer sb = new StringBuffer();
		Properties syspro = System.getProperties();
		Enumeration<Object> en = syspro.keys();
		while(en.hasMoreElements()){
			String key = (String)en.nextElement();
			sb.append(key+": "+ syspro.getProperty(key, "null")+"\n");
		}
		bMessageBox bmb = new bMessageBox(b, SWT.ICON_INFORMATION);
		bmb.setTitle("ϵͳ��Ϣ");
		bmb.setText(sb.toString());
		bmb.open();
	}
	/**
	 * 
	 * @param title �ı���Ϣ�Ի���ı���
	 * @param text Ҫ��ʾ���ı�
	 * @param readOnly �Ƿ�Ϊֻ��ģʽ
	 */
	public void getBMessageBox(String title,String text,boolean readOnly){
		bMessageBox bmb = new bMessageBox(b, SWT.None);
		bmb.setTitle(title);
		bmb.setText(text);
		bmb.readOnly(readOnly);
		bmb.open();
	}
	
	/**
	 * �˳�����
	 */
	public void exitProgram() {
		b.dispose();
	}

	/**
	 * ��ʾ���ڶԻ���
	 */
	public void aboutBlack() {
		new aboutBlack(b, SWT.None).open();
	}

//	/**
//	 * �༭������
//	 */
//	public void editerSettings() {
//		new editerSettings(b, SWT.None).open();
//	}

	/**
	 * ��ʾ�˵���
	 * 
	 * @param isShow
	 */
	public void showMenuBar(boolean isShow) {
		if (!isShow) {
			if (b.getMenuBar() != null)
				b.getMenuBar().dispose();
		} else
			b.createMenuBar();
		b.appProperties.setProperty("MenuBar", String.valueOf(isShow));
	}

	/**
	 * �Ƿ���ʾ�˵���
	 * 
	 * @return
	 */
	public boolean isShowMenuBar() {
		return Boolean.valueOf(b.appProperties.getProperty("MenuBar", "true"));
	}

	/**
	 * ��ʾ����ͳ�ƶԻ���
	 */
	public void wordCountStat(Shell shell) {
		int allChar;
		int chineseChar;
		if (b.getEditer() != null) {
			allChar = b.getEditer().getCharCount();
			chineseChar = wordCountStat.chineseWordCount(b.getEditer());
			MessageBox mb = new MessageBox(shell);
			mb.setText("����ͳ��");
			mb.setMessage("�ַ��������ƻ��з��Ϳո񣩣�" + getCharsCount()
					+ "\n-----------------\n"
					+ "���պ�������" + chineseChar
					 + "\n-----------------\n"
					+"�ַ�������" + allChar);
			mb.open();
		}
	}

	/**
	 * ����������������ʹ�õ��ļ�
	 * 
	 * @param isreopen
	 */
	public void setReOpenLastFileOnStarted(boolean isreopen) {
		b.appProperties
				.setProperty("ReOpenOnStarted", String.valueOf(isreopen));
	}

	/**
	 * �������Ƿ�����ʹ�õ��ļ�
	 * 
	 * @return
	 */
	public boolean IsReOpenLastProjectOnStarted() {
		return Boolean.valueOf(b.appProperties.getProperty("ReOpenOnStarted",
				"true"));
	}

	
	public void simpleMode(){
		if(b.wv != null && !b.wv.isDisposed())
			b.wv.exit();
		
		if (b.text != null && !b.text.isDisposed()){
			if(Boolean.valueOf(b.appProperties.getProperty("SimpleMode", "false"))){
				b.blackTextArea.simpleMode(false);
				b.appProperties.setProperty("SimpleMode", "false");
			}else{
				b.blackTextArea.simpleMode(true);
				b.appProperties.setProperty("SimpleMode", "true");
			}
		}
	}
	public boolean isSimpleMode(){
		return Boolean.valueOf(b.appProperties.getProperty("SimpleMode", "false"));
	}
	public void setColorForLabel(final Label label){
		label.addMouseTrackListener(new MouseTrackListener() {
			
			@Override
			public void mouseHover(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExit(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setBackground(b.color_label_exit);
			}
			
			@Override
			public void mouseEnter(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setBackground(b.color_labelDown);
			}
		});
	}

	/**
	 * �����༭�������ĸ���
	 */
	public void Undo() {
		if (b.tv != null) {
			b.tv.doOperation(b.tv.UNDO);
		}
	}

	/**
	 * �����༭�������ĸ���
	 */
	public void Redo() {
		if (b.tv != null)
			b.tv.doOperation(b.tv.REDO);

	}

	/**
	 * ����־�Ի���������־
	 * 
	 * @param log
	 */
	public void addLog(Object log,Point location,boolean clearlog) {
		if (b.log == null)
			b.log = new logShell(b);
		if (log != null) {
			b.log.appendLog(log.toString(),location,clearlog);
			b.log.setVisible(true);
		}
	}
	public MenuItem getMenuItem(Menu menu, String text, int style){
		MenuItem mi = new MenuItem(menu, style);
		mi.setText(text);
		return mi;
	}

	public void cutText(StyledText text) {
		if (text != null)
			text.cut();
	}

	public void pasteText(StyledText text) {
		if(text != null)
			text.paste();
	}

	public void copyText(StyledText text) {
		if (text != null)
			text.copy();
		;
	}

	/**
	 * Ϊ��ǰѡ����ı����ö��뷽ʽ
	 * 
	 * @param alignment
	 */
	public void setCurrentSelectedTextAlignment(int alignment) {
		Point range = b.getEditer().getSelectionRange();
		if (range != null) {
			int startline = b.getEditer().getLineAtOffset(range.x);
			int endline = b.getEditer().getLineAtOffset(range.x + range.y);
			if (startline != endline)
				b.getEditer().setLineAlignment(startline,
						endline - startline + 1, alignment);
			else
				b.getEditer().setLineAlignment(startline, 1, alignment);
		} else {
			b.getEditer().setLineAlignment(
					b.getEditer().getLineAtOffset(
							b.getEditer().getCaretOffset()), 1, alignment);
		}
		b.setFileIsSave(0);
	}

//	public void setTextUnderlineAndStrikeout(boolean strikeout,boolean underline) {
//		StyleRange sr = new StyleRange();
//		TextStyle ts = new TextStyle();
//		ts.strikeout = strikeout;
//		ts.underline = underline;
//		if (b.text.getSelectionCount() > 0) {
//			sr.start = b.text.getSelectionRange().x;
//			sr.length = b.text.getSelectionRange().y;
//			b.text.setStyleRange();
//		} else if (b.text.getCaretOffset() == b.text.getCharCount()) {
//			b.blackTextArea.defaultStyle = ts;
//		}
//	}

	/**
	 * Ϊ��ǰѡ����ı�������������
	 * 
	 * @param fontName
	 * @param size
	 * @param style
	 * 
	 */
	public void setTextFontStyle(String fontname, int fontsize, int fontstyle, int strikeout, int underline) {
		StyleRange[] sr = b.text.getStyleRanges(b.text.getSelectionRange().x,
				b.text.getSelectionRange().y);
		StyleRange newstyle = null;
		TextStyle ts = null;
		if(fontname != null && fontsize != -1 && fontstyle != -1){
			Font newfont = SWTResourceManager.getFont(fontname,
					b.getZoomedFontSize(fontsize), fontstyle);
			ts = new TextStyle(newfont, null, null);
			
		} else if (fontname != null) {
			int oldstyle = SWT.None;
			int oldfontsize = getEditerDefaultFontSize();
			Font newfont = SWTResourceManager.getFont(fontname,
					b.getZoomedFontSize(oldfontsize), oldstyle);
			ts = new TextStyle(newfont, null, null);
		} else if (fontsize != -1) {
			int oldstyle = SWT.None;
			String oldfontname = b.getEditorDefaultFontFromCFG();
			Font newfont = SWTResourceManager.getFont(oldfontname,
					b.getZoomedFontSize(fontsize), oldstyle);
			ts = new TextStyle(newfont, null, null);
		} else if (fontstyle != -1) {
			int oldfontsize = getEditerDefaultFontSize();
			String oldfontname = b.getEditorDefaultFontFromCFG();
			Font newfont = SWTResourceManager.getFont(oldfontname,
					b.getZoomedFontSize(oldfontsize), fontstyle);
			ts = new TextStyle(newfont, null, null);
		}else if (strikeout != -1){
			int oldfontsize = getEditerDefaultFontSize();
			String oldfontname = b.getEditorDefaultFontFromCFG();
			Font newfont = SWTResourceManager.getFont(oldfontname,
					b.getZoomedFontSize(oldfontsize), SWT.None);
			ts = new TextStyle(newfont,null,null);
			if(strikeout == 0) ts.strikeout = false;
			else ts.strikeout = true;
		}else if(underline != -1){
			int oldfontsize = getEditerDefaultFontSize();
			String oldfontname = b.getEditorDefaultFontFromCFG();
			Font newfont = SWTResourceManager.getFont(oldfontname,
					b.getZoomedFontSize(oldfontsize), SWT.None);
			ts = new TextStyle(newfont,null,null);
			if(underline == 0) ts.underline = false;
			else ts.underline = true;
		}
		
		if (ts != null) {
			if (b.text.getSelectionCount() > 0) {
				newstyle = new StyleRange(ts);
				newstyle.start = b.text.getSelectionRange().x;
				newstyle.length = b.text.getSelectionRange().y;
				b.text.setStyleRange(newstyle);
			} else if (b.text.getCaretOffset() == b.text.getCharCount()) {
				b.blackTextArea.defaultStyle = ts;
			}
		}

		for (StyleRange s : sr) {
			if (s.font != null) {
				if(fontname != null && fontsize != -1 && fontstyle != -1){
					Font newfont = SWTResourceManager.getFont(fontname,
							b.getZoomedFontSize(fontsize), fontstyle);
					s.font = newfont;
				}else if (fontname != null) {
					int oldstyle = s.font.getFontData()[0].getStyle();
					int oldfontsize = s.font.getFontData()[0].getHeight();
					Font newfont = SWTResourceManager.getFont(fontname,
							oldfontsize, oldstyle);
					s.font = newfont;
				} else if (fontsize != -1) {
					int oldstyle = s.font.getFontData()[0].getStyle();
					String oldfontname = s.font.getFontData()[0].getName();
					Font newfont = SWTResourceManager.getFont(oldfontname,
							b.getZoomedFontSize(fontsize), oldstyle);
					s.font = newfont;
				} else if (fontstyle != -1) {
					int oldfontsize = s.font.getFontData()[0].getHeight();
					String oldfontname = s.font.getFontData()[0].getName();
					Font newfont = SWTResourceManager.getFont(oldfontname,
							oldfontsize, fontstyle);
					s.font = newfont;
				} else if(strikeout != -1){
					if(strikeout == 0) s.strikeout = false;
					else s.strikeout = true;
				} else if(underline != -1){
					if(underline == 0) s.underline = false;
					else s.underline = true;
				}
			} else {
				if(fontname != null && fontsize != -1 && fontstyle != -1){
					Font newfont = SWTResourceManager.getFont(fontname,
							b.getZoomedFontSize(fontsize), fontstyle);
					s.font = newfont;
				}else if (fontname != null) {
					int oldstyle = SWT.None;
					int oldfontsize = getEditerDefaultFontSize();
					Font newfont = SWTResourceManager.getFont(fontname,
							b.getZoomedFontSize(oldfontsize), oldstyle);
					s.font = newfont;
				} else if (fontsize != -1) {
					int oldstyle = SWT.None;
					String oldfontname = b.getEditorDefaultFontFromCFG();
					Font newfont = SWTResourceManager.getFont(oldfontname,
							b.getZoomedFontSize(fontsize), oldstyle);
					s.font = newfont;
				} else if (fontstyle != -1) {
					int oldfontsize = getEditerDefaultFontSize();
					String oldfontname = b.getEditorDefaultFontFromCFG();
					Font newfont = SWTResourceManager.getFont(oldfontname,
							b.getZoomedFontSize(oldfontsize), fontstyle);
					s.font = newfont;
				} else if(strikeout != -1){
					if(strikeout == 0) s.strikeout = false;
					else s.strikeout = true;
				} else if(underline != -1){
					if(underline == 0) s.underline = false;
					else s.underline = true;
				}
			}
			b.text.setStyleRange(s);
		}
		// b.text.setStyleRanges(sr);

		b.setFileIsSave(0);
	}

	/**
	 * ��������ѡ��Ի���
	 * 
	 * @return
	 */
	public FontData getMoreFont() {
		FontDialog fd = new FontDialog(b);
		FontData font = fd.open();
		return font;
	}

	/**
	 * ��ȡ��ǰѡ����ı����������ơ��ֺš�������
	 * 
	 * @return textInfo,����װ�������ԣ������ѡ����ı�����������壬�򷵻�null�����򷵻�ĳ���������ƣ�
	 *         �����ѡ����ı���������ֺţ����ֺŷ���-1�������ѡ����ı��������������ʽ���򷵻�-1
	 */
	public textInfo getCurrentSelectTextFontStyle() {
		StyleRange[] sr = b.getEditer().getStyleRanges(
				b.getEditer().getSelectionRange().x,
				b.getEditer().getSelectionRange().y);
		String fontname = null;
		int fontsize = 0, fontstyle = 0, alignments = 0;
		textInfo info = null;
		boolean scrikeout = false, underline = false;
		// ������صķ���������鳤��Ϊ0���򷵻ر༭��Ĭ�����������
		if (sr.length == 0) {
			info = new textInfo(getEditerDefaultFontName(),
					getEditerDefaultFontSize(), -1, false, false, b.getEditer()
							.getAlignment());
		} else {
			// �����������
			for (StyleRange s : sr) {
				if (s.font != null) {
					FontData[] fd = s.font.getFontData();
					for (FontData f : fd) {
						if (fontname == null)
							fontname = f.getName();
						else {
							if (!fontname.equals(f.getName()))
								fontname = null;
						}
						if (fontsize == 0) {
							fontsize = b.getFontRealSize(f.getHeight());
						} else {
							if (fontsize != f.getHeight())
								fontsize = -1;
						}
						if (fontstyle == 0)
							fontstyle = f.getStyle();
						else {
							if (fontstyle != f.getStyle())
								fontstyle = -1;
						}
					}
					scrikeout = s.strikeout;
					underline = s.underline;
				} else {
					fontname = b.getEditorDefaultFontFromCFG();
					fontsize = getEditerDefaultFontSize();
					fontstyle = SWT.None;
					scrikeout = false;
					underline = false;
				}
			}
			// �ж���ѡ����ж��뷽ʽ�Ƿ���ͬ�������ͬ��alignments����Ϊ-1
			Point range = b.getEditer().getSelectionRange();
			int startline = b.getEditer().getLineAtOffset(range.x);
			int endline = b.getEditer().getLineAtOffset(range.x + range.y);
			if (startline != endline) {
				for (int i = startline; i <= endline; ++i) {
					if (alignments == 0)
						alignments = b.getEditer().getLineAlignment(i);
					else if (alignments != b.getEditer().getLineAlignment(i)) {
						alignments = -1;
					}
				}
			} else
				alignments = b.getEditer().getLineAlignment(startline);
		}
		if (info == null)
			info = new textInfo(fontname, fontsize, fontstyle, scrikeout,
					underline, alignments);
		return info;
	}

	/**
	 * ��StyledText�����������ʽ�����������ļ�
	 * 
	 * @param text����������ʽ��StyledText���
	 * @return ����������ʽ�������ļ�
	 */
	public Properties getAllStyleRange(StyledText text) {
		StyleRange[] sr = text.getStyleRanges();
		Properties styles = new Properties();
		for (int i = 0; i < sr.length; i++) {
			styles.setProperty(i + "start", String.valueOf(sr[i].start));
			styles.setProperty(i + "length", String.valueOf(sr[i].length));
			// styles.setProperty(i + "background",
			// String.valueOf(sr[i].background));
			// styles.setProperty(i + "foreground",
			// String.valueOf(sr[i].foreground));
			if (sr[i].font != null) {
				styles.setProperty(i + "font",
						String.valueOf(sr[i].font.getFontData()[0].getName()));
				styles.setProperty(i + "fontheight", String.valueOf(b
						.getFontRealSize(sr[i].font.getFontData()[0]
								.getHeight())));
				styles.setProperty(i + "fontstyle",
						String.valueOf(sr[i].font.getFontData()[0].getStyle()));
			} else {
				styles.setProperty(i + "font", String.valueOf(text.getFont()
						.getFontData()[0].getName()));
				styles.setProperty(i + "fontheight", String.valueOf(b
						.getFontRealSize(text.getFont().getFontData()[0]
								.getHeight())));
				styles.setProperty(i + "fontstyle", String.valueOf(b
						.getFontRealSize(text.getFont().getFontData()[0]
								.getStyle())));
			}
			styles.setProperty(i + "strikeout", String.valueOf(sr[i].strikeout));
			styles.setProperty(i + "underline", String.valueOf(sr[i].underline));
		}
		int count = 0;
		for (int a = 0; a < text.getLineCount(); ++a) {
			int align = text.getLineAlignment(a);
			if (align != text.getAlignment()) {
				styles.setProperty(count + "alignmentstartline",
						String.valueOf(a));
				styles.setProperty(count + "alignment", String.valueOf(align));
				++count;
			}
		}
		return styles;
	}

	/**
	 * �������ļ���ԭ������ʽ��text
	 * 
	 * @param p����������ʽ�������ļ�
	 * @param text
	 *            ҪӦ��������ʽ��StyledText���
	 */
	public void getStylesFromProperties(Properties p, StyledText text) {
		String start, length, font, fontstyle, strikeout, underline, fontheight;
		for (int i = 0; i > -1; i++) {
			start = p.getProperty(i + "start");
			if (start != null) {
				length = p.getProperty(i + "length");
				font = p.getProperty(i + "font");
				fontheight = p.getProperty(i + "fontheight");
				fontstyle = p.getProperty(i + "fontstyle");
				strikeout = p.getProperty(i + "strikeout");
				underline = p.getProperty(i + "underline");

				Font f = SWTResourceManager.getFont(font,
						b.getZoomedFontSize(Integer.valueOf(fontheight)),
						Integer.valueOf(fontstyle));
				TextStyle ts = new TextStyle(f, null, null);
				ts.strikeout = Boolean.valueOf(strikeout);
				ts.underline = Boolean.valueOf(underline);
				StyleRange sr = new StyleRange(ts);
				sr.start = Integer.valueOf(start);
				sr.length = Integer.valueOf(length);
				if(sr.start >= 0 && sr.length+sr.start <= text.getCharCount())
					text.setStyleRange(sr);
			} else
				break;
		}
		for (int a = 0; a > -1; ++a) {
			String startline = p.getProperty(a + "alignmentstartline");
			if (startline != null) {
				text.setLineAlignment(Integer.valueOf(startline), 1,
						Integer.valueOf(p.getProperty(a + "alignment")));
			} else
				break;
		}
	}

	/**
	 * ����text��������ʽ��docx��ʽ�ļ�
	 */
	@SuppressWarnings("deprecation")
	public void saveStylesToDocxFile(StyledText text, XWPFDocument document) {

		for (int i = 0; i < text.getLineCount(); ++i) {
			int lineOffset = text.getOffsetAtLine(i);
			String lineText = text.getLine(i);
			XWPFParagraph paragraph = document.createParagraph();
			paragraph.setFirstLineIndent(text.getIndent());
			int lineAlignment = text.getLineAlignment(i);
			switch (lineAlignment) {
			case SWT.RIGHT:
				paragraph.setAlignment(ParagraphAlignment.RIGHT);
				break;
			case SWT.CENTER:
				paragraph.setAlignment(ParagraphAlignment.CENTER);
				break;
			}
			// ����ÿһ�����ÿ���ַ�
			for (int a = lineOffset; a < lineOffset + lineText.length(); ++a) {
				StyleRange charStyle = text.getStyleRangeAtOffset(a);
				String charText = text.getText(a, a);
				XWPFRun run = paragraph.createRun();
				run.setText(charText);
				String fontname = null;
				int fontsize = 0;
				if (charStyle != null) {
					// Color background = charStyle.background;
					// Color foreground = charStyle.foreground;
					if (charStyle.font != null) {
						fontname = charStyle.font.getFontData()[0].getName();
						if (b.text != null && text.equals(b.text))
							fontsize = b.getFontRealSize(charStyle.font
									.getFontData()[0].getHeight());
						else
							fontsize = text.getFont().getFontData()[0]
									.getHeight();
					}
					int fontstyle = charStyle.fontStyle;
					switch (fontstyle) {
					case SWT.BOLD:
						run.setBold(true);
						break;
					case SWT.ITALIC:
						run.setItalic(true);
						break;
					case SWT.BOLD | SWT.ITALIC:
						run.setBold(true);
						run.setItalic(true);
						break;
					}
					run.setStrike(charStyle.strikeout);
					if (charStyle.underline)
						run.setUnderline(UnderlinePatterns.SINGLE);

					run.setFontFamily(fontname, FontCharRange.eastAsia);
					run.setFontSize(fontsize);
				}

			}

		}

	}

	public void getContentFromDocxFile(XWPFDocument document, StyledText text,
			TextViewer tv) {
		StringBuilder sb = new StringBuilder();
		List<XWPFParagraph> paragraphs = document.getParagraphs();
		Iterator<XWPFParagraph> itp = paragraphs.iterator();
		List<StyleRange> styles = new ArrayList<StyleRange>();
		List<alignmentInfo> aligInfo = new ArrayList<alignmentInfo>();
		alignmentInfo info = null;
		while (itp.hasNext()) {
			XWPFParagraph paragraph = itp.next();
			ParagraphAlignment pa = paragraph.getAlignment();
			if (pa != ParagraphAlignment.LEFT) {
				if (pa == ParagraphAlignment.CENTER)
					info = new alignmentInfo(sb.length(), SWT.CENTER);
				else if (pa == ParagraphAlignment.RIGHT)
					info = new alignmentInfo(sb.length(), SWT.RIGHT);
				aligInfo.add(info);
			}

			List<XWPFRun> runs = paragraph.getRuns();
			Iterator<XWPFRun> itr = runs.iterator();
			while (itr.hasNext()) {
				XWPFRun run = itr.next();

				String runText = run.getText(0);
				if (runText != null) {
					StyleRange sr = null;
					int fontstyle = 0;
					boolean underline = false, strikeout = false;
					Font font = null;

					if (run.isBold())
						fontstyle = SWT.BOLD;
					if (run.isItalic())
						fontstyle = SWT.ITALIC;
					if (run.isBold() && run.isItalic())
						fontstyle = SWT.BOLD | SWT.ITALIC;
					if (run.getUnderline() != UnderlinePatterns.NONE)
						underline = true;
					if (run.isStrike())
						strikeout = true;

					if (run.getFontFamily(FontCharRange.eastAsia) != null) {
						if (run.getFontSize() > 0) {
							if (b.text != null && text.equals(b.text))
								font = SWTResourceManager.getFont(run
										.getFontFamily(FontCharRange.eastAsia),
										b.getZoomedFontSize(run.getFontSize()),
										fontstyle);
							else
								font = SWTResourceManager.getFont(run
										.getFontFamily(FontCharRange.eastAsia),
										run.getFontSize(), fontstyle);
						} else {
							if (b.text != null && text.equals(b.text))
								font = SWTResourceManager
										.getFont(
												run.getFontFamily(FontCharRange.eastAsia),
												b.getZoomedFontSize(getEditerDefaultFontSize()),
												fontstyle);
							else
								font = SWTResourceManager.getFont(run
										.getFontFamily(FontCharRange.eastAsia),
										text.getFont().getFontData()[0]
												.getHeight(), fontstyle);
						}

					}
					if (fontstyle != 0 || underline || strikeout
							|| font != null) {
						sr = new StyleRange();
						sr.start = sb.length();
						sr.length = runText.length();
						if (font != null)
							sr.font = font;
						sr.underline = underline;
						sr.strikeout = strikeout;
						if (styles.size() > 0) {
							if (!sr.similarTo(styles.get(styles.size() - 1)))
								styles.add(sr);
							else {
								styles.get(styles.size() - 1).length += run
										.getText(0).length();
							}
						} else
							styles.add(sr);
					}
					sb.append(run.getText(0));
				}

			}
			sb.append("\n");
		}
		tv.setDocument(new Document(sb.toString()));
		Iterator<StyleRange> itstyle = styles.iterator();
		while (itstyle.hasNext()) {
			StyleRange sr = itstyle.next();
			text.setStyleRange(sr);
		}
		Iterator<alignmentInfo> italign = aligInfo.iterator();
		while (italign.hasNext()) {
			alignmentInfo aligninfo = italign.next();
			if (aligninfo != null)
				text.setLineAlignment(
						text.getLineAtOffset(aligninfo.linestartoffset), 1,
						aligninfo.alignment);
		}
	}

	public void setEditerDefaultFontSize(int size) {
		b.appProperties.setProperty("EditerDefaultFontSize",
				String.valueOf(size));
	}

	public int getEditerDefaultFontSize() {
		return Integer.valueOf(b.appProperties.getProperty(
				"EditerDefaultFontSize", "10"));
	}

	public String getEditerDefaultFontName() {
		return b.getEditorDefaultFontFromCFG();
	}

	public void setEditerDefaultFontName(String fontname) {
		b.setEditorFont(fontname);
	}

	/**
	 * ������Ϣ�Ի���
	 * 
	 * @param message
	 */
	public void getMessageBox(String title, String message) {
		MessageBox mb = new MessageBox(b);
		mb.setText(title);
		mb.setMessage(message);
		mb.open();
	}

	public void createProject(String projectname, String dir) {

		File projectdir = new File(dir + "\\" + projectname);
		if (projectdir.exists()) {
			getMessageBox("", "�������ѱ�ʹ�ã���ָ����������");
		} else {
			projectdir.mkdir();
			new File(projectdir + "\\Files").mkdir();
			new File(projectdir + "\\Settings").mkdir();
			Properties pro = new Properties();
			pro.setProperty("blackVersion", black.getAppVersion());
			pro.setProperty("createDate",
					time.getCurrentDate("") + " " + time.getCurrentTime());
			pro.setProperty("projectName", projectname);
			pro.setProperty("fileCount", "0");
			
			File projectFile = new File(projectdir + "\\project.bpro");
			File fileinfoFile = new File(projectdir+"\\Settings\\fileinfo");
			File recyclefile = new File(projectdir+"\\Settings\\recycle");
			File indexfile = new File(projectdir
					+ "\\Settings\\fileindex.blaobj");
			Properties fileinfo = new Properties();
			Properties recycle = new Properties();
			

			ArrayList<String> al = new ArrayList<String>();
			ioThread io = new ioThread(b, al, indexfile, 1);
			b.getDisplay().syncExec(io);
			cfg_read_write.cfg_write(pro, projectFile);
			cfg_read_write.cfg_write(fileinfo, fileinfoFile);
			cfg_read_write.cfg_write(recycle, recyclefile);
			b.setProject(pro, projectFile);
		}
	}

	public void openProject(File projectProperties) {
		if (projectProperties.exists()) {
			Properties project;
			project = cfg_read_write.cfg_read(projectProperties);
			b.setProject(project, projectProperties);
		} else {
			getMessageBox("", "��Ŀ������");
			//b.tree.setEnabled(false);
			newProject np = new newProject(b, SWT.None);
			boolean result = (boolean) np.open();
			if(!result) b.dispose();
		}
	}

	/**
	 * ����Ŀ����ѡ����ļ� �˷���֧���ⲿ����
	 */
	public void openFile() {
		if (b.tree.getSelectionCount() == 1) {
			TreeItem[] tis = b.tree.getSelection();
			for (TreeItem ti : tis) {
				if (!ti.equals(b.draft) && !ti.equals(b.treeItem_1)) {
					File f = new File(b.projectFile.getParent() + "\\Files\\"
							+ ti.getData("realname"));
					openFile(f,true);
				}
				if (b.findresult != null && ti.getParentItem() != null)
					if (ti.getParentItem().equals(b.findresult)) {
						showFindResult(ti);
					}
			}

		}
	}

	/**
	 * ����Ŀ���������ļ� �˷���֧���ⲿ����
	 */
	public void addFileToProject() {
		File newfile = new File(b.projectFile.getParent() + "\\Files\\"
				+ b.FileCountOfProject + ".black");
		//b.fileindex.add(b.FileCountOfProject+".black");
//		b.fileInfo.setProperty(b.FileCountOfProject + ".black",
//				String.valueOf(b.FileCountOfProject));

		Object result = new rename(b, SETNAME).open();
		if (result != null) {
			b.fileInfo.setProperty(b.FileCountOfProject + ".black",
					(String) result);
		} else
			b.fileInfo.setProperty(b.FileCountOfProject + ".black", "δ����");
		
		if (b.fileindex != null){
			b.fileindex.add(b.FileCountOfProject + ".black");
			saveFileindex();
		}
		newFile(newfile);
		++b.FileCountOfProject;
		b.projectProperties.setProperty("fileCount",
				String.valueOf(b.FileCountOfProject));
		saveFileInfoCFG();
		saveProjectCFG();
		b.listProjectFile();
		//addLog(b.projectProperties.getProperty("fileCount"));

	}

	/**
	 * ɾ���ļ� ����ļ��ڲݸ��䣬�˷������ļ��Ӳݸ����ƶ��������� ����ļ��������䣬�������ɾ�� �˷������ⲿ����
	 */
	public void moveFileToRecycle() {
		TreeItem[] tis = b.tree.getSelection();
		for (TreeItem ti : tis) {
			if (!ti.equals(b.draft) && !ti.equals(b.treeItem_1)) {
				if (ti.getParentItem().equals(b.draft)) {
					moveFileToRecycle((String) ti.getData("realname"), true);
					// ti.dispose();
				} else if (ti.getParentItem().equals(b.treeItem_1)) {
					MessageBox mb = new MessageBox(b, SWT.OK | SWT.CANCEL
							| SWT.ICON_WARNING);
					mb.setMessage("ȷʵҪɾ���ļ� - " + ti.getText() + "?\n�˲������޷�����");
					int result = mb.open();
					if (result == SWT.OK) {
						deleteFile((String) ti.getData("realname"));
						// ti.dispose();
					}
				}
			}
		}

		b.listProjectFile();
	}

	/**
	 * ���ݸ�����ļ��ƶ��������� �˷�����֧���ⲿ����
	 * 
	 * @param realname
	 * @param saveCFG
	 */
	protected void moveFileToRecycle(String realname, boolean saveCFG) {
		b.recycle.setProperty(realname, "true");
		if (saveCFG)
			saveRecycleCFG();
		
	}

	/**
	 * ����ɾ���������е��ļ� �˷�����֧���ⲿ����
	 * 
	 * @param realname
	 */
	protected void deleteFile(String realname) {
		File f = new File(b.projectFile.getParent() + "\\Files\\" + realname);
		if (f.exists()) {
			if (b.getCurrentEditFile() != null)
				if (b.getCurrentEditFile().equals(f)) {
					b.disposeTextArea();
					b.setCurrentEditFile(null);
				}
			deleteKeyFromFileInfo(realname, true);
			b.fileindex.remove(realname);
			saveFileindex();
			b.recycle.remove(realname);
			f.delete();
			b.projectProperties.setProperty("fileCount",
					String.valueOf(b.FileCountOfProject));
			saveProjectCFG();
			saveRecycleCFG();
		}
	}

	/**
	 * ����������ļ��Ƶ��ݸ��� �˷����ɹ��ⲿ����
	 */
	public void restoreFile() {
		TreeItem[] tis = b.tree.getSelection();
		for (TreeItem ti : tis) {
			if (!ti.equals(b.draft) && !ti.equals(b.treeItem_1)) {
				if (!ti.getParentItem().equals(b.draft)) {
					restoreFile((String) ti.getData("realname"));
					ti.dispose();
				}
			}
		}
	}

	protected void restoreFile(String realname) {
		b.recycle.remove(realname);
		TreeItem ti = b.getDocTreeItem(b.draft,
				b.fileInfo.getProperty(realname, realname));
		ti.setData("realname", realname);
		saveRecycleCFG();
	}

	/**
	 * ɾ��fileinfo�����Ŀ���÷������Զ�ɾ���������realname��������������Ŀ
	 * 
	 * @param realname
	 * @param saveCFG
	 */
	protected void deleteKeyFromFileInfo(String realname, boolean saveCFG) {
		b.fileInfo.remove(realname);
		b.fileInfo.remove(realname + "TopPixel");
		b.fileInfo.remove(realname + "CaretOffset");

		if (saveCFG)
			saveFileInfoCFG();
	}

	protected void rename(String realname, String newname) {
		b.fileInfo.setProperty(realname, newname);
		saveFileInfoCFG();
		b.applySetting();
	}

	protected void saveFileInfoCFG() {
		File fileinfoFile = new File(b.projectFile.getParent()
				+ "\\Settings\\fileinfo");
		cfg_read_write.cfg_write(b.fileInfo, fileinfoFile);
	}

	protected void saveRecycleCFG() {
		File recyclefile = new File(b.projectFile.getParent()
				+ "\\Settings\\recycle");
		cfg_read_write.cfg_write(b.recycle, recyclefile);
	}

	protected void saveProjectCFG() {
		cfg_read_write.cfg_write(b.projectProperties, b.projectFile);
	}

	protected void saveFileindex() {
		if (b.fileindex != null) {
			File fileindexfile = new File(b.projectFile.getParent()
					+ "\\Settings\\fileindex.blaobj");
			ioThread io = new ioThread(b, b.fileindex, fileindexfile, 1);
			b.getDisplay().syncExec(io);
		}
	}

	/**
	 * ��༭�������ı� 
	 * �˷������Զ��������ƫ����
	 * �����жϳ����Ƿ���ڱ༭�� 
	 * �����ı�������Զ�����������ı���
	 * 
	 * @param text
	 */
	public void insertText(String text,StyledText st) {
		if (st != null) {
			int caretoffset = st.getCaretOffset();
			//�жϹ���Ƿ��ѱ������������
			Point old = st.getCaret().getLocation();
			st.insert(text);
			if(!st.isDisposed() && st.getCaret().getLocation().equals(old))
				st.setCaretOffset(caretoffset + text.length());
		}
	}

	/**
	 * �ڱ༭�������һ������б� ����λ���Ǳ༭����ǰ��CaretOffset
	 * 
	 * @param insertlist
	 */
	public void insertList(boolean insertlist, final String style,final StyledText st) {
		if (st != null)
			if (insertlist) {
				if (numberlist != null) {
					st.removeKeyListener(numberlist);
					listindex = 1;
				}
				if (style != null)
					addListNumber(st,style);
				else
					addListNumber(st,null);

				numberlist = new KeyListener() {

					@Override
					public void keyReleased(KeyEvent e) {
						// TODO Auto-generated method stub

					}

					@Override
					public void keyPressed(KeyEvent e) {
						// TODO Auto-generated method stub
						if (e.keyCode == 8) {
							if (st.getLine(
									st.getLineAtOffset(st
											.getCaretOffset())).length() < 1) {
								st.removeKeyListener(numberlist);
								listindex = 1;
							}
						} else if (e.keyCode == 13) {
							if (style != null)
								addListNumber(st,style);
							else
								addListNumber(st,null);
						}
						// System.out.println(e.keyCode);
					}
				};

				st.addKeyListener(numberlist);
			} else {
				if (numberlist != null) {
					st.removeKeyListener(numberlist);
				}
			}
	}

	/**
	 * ΪStyledText������������ ����insertList��������
	 */
	protected void addListNumber(StyledText st, String style) {
		int lineoffset = st.getOffsetAtLine(st.getLineAtOffset(st
				.getCaretOffset()));
		int oldCaretOffset = st.getCaretOffset();
		st.setCaretOffset(lineoffset);
		st.getCaret().setVisible(false);
		String s = null;
		if (style == null)
			s = listindex + ".";
		else
			s = style;
		st.insert(s);
		st.setCaretOffset(oldCaretOffset + s.length());
		st.getCaret().setVisible(true);
		++listindex;
	}

	/**
	 * ���½�/����Ŀ�Ի���
	 */
	public void openNewProjectDialog() {
		newProject np = new newProject(b, SWT.None);
		boolean result = (boolean) np.open();
		if(!result) {
			if(b.projectFile == null)
				b.dispose();
		}
	}

	public void clearRecycle() {
		Enumeration<Object> enu = b.recycle.keys();
		if (enu.hasMoreElements()) {
			MessageBox mb = new MessageBox(b, SWT.OK | SWT.CANCEL
					| SWT.ICON_WARNING);
			mb.setMessage("ȷ��Ҫ��������䣿\n�������ڵ������ļ�������ɾ��");
			int i = mb.open();
			if (i == SWT.OK && b.recycle != null) {
				while (enu.hasMoreElements()) {
					String s = (String) enu.nextElement();
					File f = new File(b.projectFile.getParent() + "\\Files\\"
							+ s);
					if (f.exists()) {
						if (b.getCurrentEditFile() != null
								&& b.getCurrentEditFile().equals(f))
							b.closeCurrentFile(false);
						f.delete();
						b.fileindex.remove(f.getName());
						deleteKeyFromFileInfo(f.getName(), false);
					}
				}
				b.projectProperties.setProperty("fileCount",
						String.valueOf(b.FileCountOfProject));
				b.recycle.clear();
				b.listProjectFile();
				saveRecycleCFG();
				saveProjectCFG();
				saveFileInfoCFG();
				saveFileindex();
			}
		}
	}

	public void importFiles(boolean onlytext, String textfileencode) {
		TextViewer tv = new TextViewer(b, SWT.None);
		tv.getTextWidget().setVisible(false);
		FileDialog fd = new FileDialog(b, SWT.MULTI);
		fd.setFilterExtensions(b.getIO().filterExtensionsForOpen);
		fd.setText("����");
		fd.open();
		int filecount = 0;
		String[] filenames = fd.getFileNames();

		if (filenames.length > 0) {
			for (String filename : filenames) {
				File f = new File(fd.getFilterPath() + "\\" + filename);

				if (f.getName().matches(".*.docx")) {
					ioThread io = new ioThread(b);

					if (onlytext) {
						Document doc = new Document(io.readDocxFile(f));
						io.writeBlackFile(
								new File(b.projectFile.getParent()
										+ "\\Files\\" + b.FileCountOfProject
										+ ".black"), doc, null);
					} else {
						io.readDocxFile(f, tv.getTextWidget(), tv);
						io.writeBlackFile(
								new File(b.projectFile.getParent()
										+ "\\Files\\" + b.FileCountOfProject
										+ ".black"), tv.getDocument(),
								getAllStyleRange(tv.getTextWidget()));
					}
					b.fileindex.add(b.FileCountOfProject + ".black");
					b.fileInfo.setProperty(b.FileCountOfProject + ".black",
							stringAction.spiltFileName(f.getName(), ".docx"));
					saveFileInfoCFG();
					b.FileCountOfProject++;
					b.projectProperties.setProperty("fileCount",
							b.FileCountOfProject + "");
					saveProjectCFG();
					saveFileindex();
					filecount++;
					b.listProjectFile();
				} else if (f.getName().matches(".*.black")) {
					io.copyFile(f, new File(b.projectFile.getParent()
							+ "\\Files\\" + b.FileCountOfProject + ".black"));
					b.fileindex.add(b.FileCountOfProject + ".black");
					b.fileInfo.setProperty(b.FileCountOfProject + ".black",
							stringAction.spiltFileName(f.getName(), ".black"));
					saveFileInfoCFG();
					b.FileCountOfProject++;
					b.projectProperties.setProperty("fileCount",
							b.FileCountOfProject + "");
					saveProjectCFG();
					saveFileindex();
					filecount++;
					b.listProjectFile();
				} else if (f.getName().matches(".*.txt")) {
					ioThread io = new ioThread(b);
					Document doc = new Document(io.readTextFile(f,
							textfileencode));
					io.writeBlackFile(new File(b.projectFile.getParent()
							+ "\\Files\\" + b.FileCountOfProject + ".black"),
							doc, null);
					b.fileindex.add(b.FileCountOfProject + ".black");
					b.fileInfo.setProperty(b.FileCountOfProject + ".black",
							stringAction.spiltFileName(f.getName(), ".txt"));
					saveFileInfoCFG();
					b.FileCountOfProject++;
					b.projectProperties.setProperty("fileCount",
							b.FileCountOfProject + "");
					saveProjectCFG();
					saveFileindex();
					filecount++;
					b.listProjectFile();
				} else if (f.getName().matches(".*.doc")) {
					ioThread io = new ioThread(b);
					Document doc = new Document(io.readDocFile(f));
					io.writeBlackFile(new File(b.projectFile.getParent()
							+ "\\Files\\" + b.FileCountOfProject + ".black"),
							doc, null);
					b.fileindex.add(b.FileCountOfProject + ".black");
					b.fileInfo.setProperty(b.FileCountOfProject + ".black",
							stringAction.spiltFileName(f.getName(), ".doc"));
					saveFileInfoCFG();
					b.FileCountOfProject++;
					b.projectProperties.setProperty("fileCount",
							b.FileCountOfProject + "");
					saveProjectCFG();
					saveFileindex();
					filecount++;
					b.listProjectFile();
				}
			}
		}
		if (filenames.length > 0)
			getMessageBox("", "������" + filecount + "���ļ�");
	}
	/**
	 * ��ȡһ���ļ��Ի���
	 * @param text�ļ��Ի���ı���
	 * @param parent��Shel
	 * @param style��ʽ�����籣�桢�򿪡���ѡ����ѡ
	 * @param extensions��չ������������*.*.txt
	 * @return
	 */
	public FileDialog getFileDialog(String text,Shell parent,int style,String[] extensions){
		FileDialog fd = new FileDialog(parent,style);
		fd.setText(text);
		fd.setFilterExtensions(extensions);
		fd.open();
		return fd;
	}
	public void restartBlack(){
		blackMain.restart();
	}
	public boolean saveCurrentFileAsPDF(){
		boolean issave = false;
		if(b.text != null){
			b.text.print();
			issave = true;
		}
		return issave;
	}
	public boolean saveCurrentFileAsTXT(File f,String encode){
		boolean issave = false;
		if(b.text != null){
			if(!encode.equals("")){
				if(Charset.isSupported(encode)){
					ioThread io = new ioThread(b);
					io.writeTextFile(f, b.text.getText(), encode);
					issave = true;
				}else getMessageBox("", "����֧�ֵ��ַ���");
			}else{
				ioThread io = new ioThread(b);
				io.writeTextFile(f, b.text.getText(), Charset.defaultCharset().name());
				issave = true;
			}
		}
		return issave;
	}
	public void exportFiles(ArrayList<String> al, File outputfile) {
		if (b.fileindex != null) {
			TextViewer tv = new TextViewer(b, SWT.V_SCROLL | SWT.WRAP);
			StyledText styledText = tv.getTextWidget();
			//blackTextArea blackTextArea = new blackTextArea(styledText, b);
			styledText.setVisible(false);
			XWPFDocument doc = new XWPFDocument();
			ioThread io = new ioThread(b);
			Iterator<String> it = al.iterator();
			while (it.hasNext()) {
				String filename = it.next();
				File file = new File(b.projectFile.getParent() + "\\Files\\"
						+ filename);
				if (file.exists()) {
					io.readBlackFile(file, tv);
					saveStylesToDocxFile(styledText, doc);
					// doc.createParagraph().set
				}
			}
			BufferedOutputStream bos = io
					.getBufferedFileOutputStream(outputfile);
			try {
				doc.write(bos);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			tv.getTextWidget().dispose();
			getMessageBox("", "������"+al.size()+"���ļ�");
		}
	}

	public void showCharCount() {
		if (b.text != null) {
			b.label_4.setText(getCharsCount() + "���ַ�");
		}
	}

	/**
	 * ����Ŀ��������ļ��в��Ҹ����Ĺؼ���
	 */
	public void findInAllFiles(String word, boolean forwardSearch,
			boolean caseSensitive, boolean wholeWord, boolean showAll,boolean regularExpressions) {
		if (b.projectFile != null) {
			File dir = new File(b.projectFile.getParent() + "\\Files");
			String[] files = dir.list();
			for (String file : files) {
				File f = new File(dir + "\\" + file);
				ioThread io = new ioThread(b, f, 0, null, null, null);
				b.getDisplay().syncExec(io);
				ArrayList<IRegion> al = findwordInAllFiles(io.doc, word,
						forwardSearch, caseSensitive, wholeWord,regularExpressions);
				if (al != null && al.size() > 0) {
					TreeItem ti = b
							.addFindResultToTree(b.fileInfo.getProperty(
									f.getName(), f.getName())
									+ " " + al.size() + "�����");
					ti.setData("file", f);
					ti.setData("iregions", al);
				}
			}
		}
	}

	public void replaceInAllFile(String word1, String word2,
			boolean forwardSearch, boolean caseSensitive, boolean wholeWord,boolean regularExpressions) {
		int i = 0;
		if (b.projectFile != null) {
			File dir = new File(b.projectFile.getParent() + "\\Files");
			String[] files = dir.list();
			TextViewer tv = new TextViewer(b, SWT.None);
			// �滻��ʼǰ���沢�رյ�ǰ����ʹ�õ��ļ�
			File oldfile = b.getCurrentEditFile();
			b.closeCurrentFile(true);
			for (String file : files) {
				File f = new File(dir + "\\" + file);
				ioThread io = new ioThread(b, f, 0, null, tv, null);
				b.getDisplay().syncExec(io);

				int a = b.blackTextArea.replace(io.doc, word1, word2,
						forwardSearch, caseSensitive, wholeWord, false, regularExpressions);
				i += a;
				if (a > 0) {
					ioThread ioi = new ioThread(b, f, 1, io.doc, null,
							getAllStyleRange(tv.getTextWidget()));
					b.getDisplay().asyncExec(ioi);
				}
			}
			tv.getTextWidget().dispose();
			getMessageBox("����/�滻��Ϣ", "�滻��ɣ�\n���滻��" + i + "��");
			openFile(oldfile,true);
		}
	}

	

	public void showFindResult(TreeItem ti) {
		if (ti != null) {
			File f = (File) ti.getData("file");
			if (f != null) {
				openFile(f,false);
				ArrayList<IRegion> al = (ArrayList<IRegion>) ti.getData("iregions");
				if (al != null) {
					Iterator<IRegion> it = al.iterator();
					while (it.hasNext()) {
						IRegion ir = it.next();
						b.blackTextArea.styles = new ArrayList<StyleRange[]>();
						StyleRange sr = new StyleRange(ir.getOffset(),
								ir.getLength(), b.color_textBackground,
								org.eclipse.wb.swt.SWTResourceManager
										.getColor(SWT.COLOR_DARK_GREEN));
						StyleRange[] s = b.getEditer().getStyleRanges(
								ir.getOffset(), ir.getLength());
						if (s != null)
							b.blackTextArea.styles.add(s);
						b.getEditer().setStyleRange(sr);
					}
				}

			}
		}
	}

	public void hideFindResult() {
		if (b.findresult != null && !b.findresult.isDisposed()) {
			b.findresult.dispose();
		}
	}

	public ArrayList<IRegion> findwordInAllFiles(IDocument doc, String word,
			boolean forwardSearch, boolean caseSensitive, boolean wholeWord,boolean regularExpressions) {
		ArrayList<IRegion> al = null;
		if (doc != null) {
			al = new ArrayList<>();
			FindReplaceDocumentAdapter frda = new FindReplaceDocumentAdapter(
					doc);
			int start = 0;
			IRegion ir;
			try {
				while ((ir = frda.find(start, word, forwardSearch,
						caseSensitive, wholeWord, regularExpressions)) != null) {
					al.add(ir);
					start = ir.getOffset() + ir.getLength();
				}
			} catch (BadLocationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return al;
	}

	/**
	 * ���ļ� 
	 * �Զ��ж�File�Ƿ�Ϊ�����Ƿ���� 
	 * �����ļ��򿪺󽫱༭����ͼ���赽��һ�δ�ʱ��λ��
	 * 
	 * @param file
	 */
	public void openFile(File file,boolean resetView) {
		if (file != null) {
			if (file.exists()) {
				if (b.getCurrentEditFile() != null) {
					if (!b.getCurrentEditFile().equals(file)) {
						b.closeCurrentFile(true);
						b.getIO().open(file);
					}
				}else{
					b.getIO().open(file);
				}
				if (resetView){
					b.resetStyledTextTopPixelAndCaretOffset(file.getName(),b.text);
					b.text.setFocus();
				}
			}
		}
	}
	public void changeColorForAllChildren(Color foreground, Color background, Composite com){
		Control[] cons = com.getChildren();
		for(Control con:cons){
			con.setForeground(foreground);
			con.setBackground(background);
			if(con.getClass().equals(Composite.class)){
				changeColorForAllChildren(foreground,background, (Composite)con);
			}
		}
	}
	public void changeColorForAllChildren(Color foreground, Color background, Shell shell){
		Control[] cons = shell.getChildren();
		shell.setBackground(background);
		shell.setForeground(foreground);
		for(Control con:cons){
			con.setForeground(foreground);
			con.setBackground(background);
			if(con.getClass().equals(Composite.class)){
				changeColorForAllChildren(foreground,background, (Composite)con);
			}
		}
	}
	public void changeColor(Color foreground,Color background){
		changeColorForAllChildren(foreground, background, b);
		b.color_label_exit = background;
	}
	public void eyeColor(boolean iseye){
		if(iseye){
			changeColor(b.color_line,b.color_eye);
		}
		else {
			changeColor(b.color_line,b.color_area);
		}
		
		b.appProperties.setProperty("EyeColor", String.valueOf(iseye));
	}
	void findinAllText(String str){
		if(b.wv == null || b.wv.isDisposed()){
			
			findi = new findinfo(b,b,SWT.None);
		}else {
			findi = new findinfo(b.wv, b, SWT.None);
		}
		initFindinfoResult();
		List<List<TextRegion>> lis = new ArrayList<List<TextRegion>>();
		if(b.text != null){
			lis.add(cheakDocument.searchByLine(b.text.getText(), str,b.fileInfo.getProperty(b.getCurrentEditFile().getName(), b.getCurrentEditFile().getName())));
		}
		for(findinfo_ findi:findinfoResult.findin){
			List<TextRegion> list = cheakDocument.searchByLine(findi.stringbuilder.toString(), str,findi.subname);
			lis.add(list);
		}
		int i = 0;
		Iterator<List<TextRegion>> it = lis.iterator();
		while(it.hasNext()){
			List<TextRegion> lis_tr = it.next();
			Iterator<TextRegion> it_tr = lis_tr.iterator();
			while(it_tr.hasNext()){
				TextRegion tr = it_tr.next();
				TreeItem ti = new TreeItem(findi.tree, SWT.None);
				ti.setText(tr.name + " - " + tr.text);
				ti.setData("textregion", tr);
				ti.setData("index", i);
				i++;
			}
		}
		if(findi.tree.getItemCount() > 0)
			findi.setVisible(true);
			else closeFindInfoDialog();
	}
	public void initFindinfoResult(){
		if(findinfoResult == null || !b.getCurrentEditFile().equals(findinfoResult.currenteditfile)){
			findinfo_[] alltext = getAllTextFromProject(false,includeRecycle);
			findinfoResult  = new findinfo_result(b.getCurrentEditFile(), alltext);
		}
	}
	void findinMark(){
		initFindinfoResult();
		List<List<TextRegion>> lis = new ArrayList<List<TextRegion>>();
		if(b.text != null){
			List<TextRegion> list = new cheakDocument().splitString(b.text.getText(), ' ', false, b.fileInfo.getProperty(b.getCurrentEditFile().getName(), 
					b.getCurrentEditFile().getName()));
			if(list.size() > 0)
				lis.add(list);
		}
		for(findinfo_ findi:findinfoResult.findin){
			List<TextRegion> list = new cheakDocument().splitString(findi.stringbuilder.toString(), ' ', false, findi.subname);
			if(list.size() > 0)
				lis.add(list);
		}
		if(lis.size() > 0) {
			if(b.wv == null || b.wv.isDisposed())
				findi = new findinfo(b,b,SWT.None);
			else findi = new findinfo(b.wv, b, SWT.None);
			Iterator<List<TextRegion>> it = lis.iterator();
			int index = 0;
			List<TextRegion> tr_no = new ArrayList<TextRegion>();
			
			while(it.hasNext()){
				List<TextRegion> lis_textr = it.next();
				Iterator<TextRegion> it_tr = lis_textr.iterator();
				while(it_tr.hasNext()){
					TextRegion tr = it_tr.next();
					TextRegion describe = cheakDocument.checkCommand(tr.text, "#");
					if(describe != null){
						tr.describe = describe.text;
						tr.text = tr.text.substring(0, describe.start);
					}
					if(b.text.getCaretOffset() > 0){
						if(cheakDocument.findString(tr.text, b.text.getText(b.text.getCaretOffset()-1,b.text.getCaretOffset()-1))){
							TreeItem ti = new TreeItem(findi.tree, SWT.None);
							if(tr.describe != null)
								ti.setText(tr.text+"("+tr.describe+") - "+tr.name);
							else ti.setText(tr.text+" - "+tr.name);
							ti.setData("textregion", tr);
							ti.setData("index",index);
							index++;
						}else{
							tr_no.add(tr);
						}			
					}else{
						TreeItem ti = new TreeItem(findi.tree, SWT.None);
						if(tr.describe != null)
							ti.setText(tr.text+"("+tr.describe+") - "+tr.name);
						else ti.setText(tr.text+" - "+tr.name);
						ti.setData("textregion", tr);
						ti.setData("index",index);
						index++;
					}
					
					//ti.setImage(SWTResourceManager.getImage(black.class, "/yang/app/black/icons/push_pin_icon&16.png"));
				}
				
			}
			Iterator<TextRegion> it_no = tr_no.iterator();
			while(it_no.hasNext()){
				TextRegion trno = it_no.next();
				TreeItem ti = new TreeItem(findi.tree, SWT.None);
				if(trno.describe != null)
					ti.setText(trno.text+"("+trno.describe+") - "+trno.name);
				else ti.setText(trno.text+" - "+trno.name);
				ti.setData("textregion", trno);
				ti.setData("index",index);
				index++;
			}
			findi.setVisible(true);
		}
	}
	public void findInfo(){
		if(b.text.getSelectionCount() == 0){
			Runnable runn = new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					findinMark();
				}
			};
			b.getDisplay().asyncExec(runn);
		}
		else{ 
			Runnable runn = new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					findinAllText(b.text.getSelectionText());
				}
			};
			b.getDisplay().asyncExec(runn);
		}
				
	}
	public void closeFindInfoDialog(){
		if(findi != null && !findi.isDisposed()){
			findi.dispose();
			findi = null;
		}
	}
	/**
	 * ��ȡ�������ļ���
	 * @return
	 */
	public int getRecycleFileCount(){
		int filecount = 0;
		Enumeration<Object> coll = b.recycle.keys();
		while(coll.hasMoreElements()){
			String filename = (String)coll.nextElement();
			File f = new File(b.projectFile.getParent()+"\\Files\\"+filename);
			if(f.exists()){
				filecount++;
			}
		}
		return filecount;
	}
	
	/**
	 * ��ȡ��Ŀ�������ļ����ı�
	 * @return
	 */
	public findinfo_[] getAllTextFromProject(boolean isgetcurrenteditfile,boolean includerecycle){
		findinfo_[] findin = null;
		if (b.projectFile != null) {
			File dir = new File(b.projectFile.getParent() + "\\Files");
			String[] files = dir.list();
			if(isgetcurrenteditfile && includerecycle) findin = new findinfo_[files.length];
			else if(!isgetcurrenteditfile && !includerecycle){
				if(b.getCurrentEditFile() != null)
					findin= new findinfo_[files.length-1-getRecycleFileCount()];
				else findin = new findinfo_[files.length-getRecycleFileCount()];
			}else if(!isgetcurrenteditfile){
				if(b.getCurrentEditFile() != null)
					findin= new findinfo_[files.length-1];
				else findin = new findinfo_[files.length];
			}else{
				findin= new findinfo_[files.length-getRecycleFileCount()];
			}
			
			int i = 0;
			for (String file : files) {
				StringBuilder sb = new StringBuilder();
				File f = new File(dir + "\\" + file);
				if(b.getCurrentEditFile() != null){
					if(!b.getCurrentEditFile().equals(f)){
						String value = b.recycle.getProperty(f.getName());
						if(!includerecycle){
							if(value == null){
								ioThread io = new ioThread(b);
								sb.append(io.readBlackFile(f, null).get());
								findin[i] = new findinfo_(sb, b.fileInfo.getProperty(f.getName(), f.getName()));
								if(i<findin.length-1)
									i++;
							}
						}else{
							ioThread io = new ioThread(b);
							sb.append(io.readBlackFile(f, null).get());
							findin[i] = new findinfo_(sb, b.fileInfo.getProperty(f.getName(), f.getName()));
							if(i<findin.length-1)
								i++;
						}
					}else{
						if(isgetcurrenteditfile){
							sb.append(b.text.getText());
							findin[i] = new findinfo_(sb, b.fileInfo.getProperty(f.getName(), f.getName()));
							if(i<findin.length-1)
								i++;
						}
					}
				}else{
					ioThread io = new ioThread(b);
					sb.append(io.readBlackFile(f, null).get());
					i++;
					findin[i] = new findinfo_(sb, b.fileInfo.getProperty(f.getName(), f.getName()));
				}
				
//				if(!isgetcurrenteditfile){
//					if(b.getCurrentEditFile() != null){
//						if(!b.getCurrentEditFile().equals(f)){
//							if(i+1 < files.length-1)
//								i++;
//						}
//					}else{
//						if(i+1 < files.length-1)
//							i++;
//					}
//				}else{
//					if(i+1 < files.length)
//						i++;
//				}
			}
		}
		return findin;
	}
	public void howtoUseExpressions(){
		//ioThread io = new ioThread(b);
		
	}
	
	public void resetCaret(int style){
		b.text.setCaret(new mycaret(b.text,style));
		if(style == SWT.VERTICAL)
			b.appProperties.setProperty("CaretV", "true");
		else b.appProperties.setProperty("CaretV", "false");
	}
	/**
	 * ���������ڵĴ�С������black�����app���Զ��󣬸�app���Զ������black��������ǰ������д�����
	 * @param shell
	 */
	public void saveWindowSizeToAppProperties(Shell shell){
		b.appProperties.setProperty(shell.getClass().getName()+"_windowSizeX",String.valueOf(shell.getSize().x));
		b.appProperties.setProperty(shell.getClass().getName()+"_windowSizeY",String.valueOf(shell.getSize().y));
	}
	/**
	 * ��black�����app���Զ�����Ϊ����shell��ȡ��Ӧ�ô��ڴ�С����
	 * @param shellҪ���贰�ڴ�С��shell����
	 * @param defaultsize ��black��app���Զ�����û�и�shell�Ĵ�����Ϣʱ��Ӧ�õ�ȱʡ��С
	 * @return
	 */
	public void readWindowSizeFromAppProperties(Shell shell,Point defaultsize){
		int x = Integer.valueOf(b.appProperties.getProperty(shell.getClass().getName()+"_windowSizeX",String.valueOf(defaultsize.x)));
		int y = Integer.valueOf(b.appProperties.getProperty(shell.getClass().getName()+"_windowSizeY",String.valueOf(defaultsize.y)));
		shell.setSize(x, y);
	}
	public void serializationBlack(){
		File serialFile = new File("./serializa/black");
		File serialDir = new File("./serializa");
		if(!serialDir.exists()) serialDir.mkdir();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(serialFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(b);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void hideOrShowLeftPanel(){
		//if(b.appProperties.getProperty("LeftPanel_Show", "true"));
			
	}
	public void hideOrShowBottomPanel(){
		
	}
	public void changeWritingViewTextWidth(int width){
		b.appProperties.setProperty("WritingView_TextX", String.valueOf(width));
		if(b.wv != null && !b.wv.isDisposed()){
			b.wv.setStyledTextWidth(width);
		}
	}
	public int getChineseCharsCount(){
		return wordCountStat.chineseWordCount(b.getEditer());
	}
	/*
	 * ��ȡ�ַ��������ƻ��з��Ϳո�
	 */
	public int getCharsCount(){
		wordCountStat wcs = new wordCountStat();
		wcs.wordStat(b.text.getText());
		return b.text.getCharCount() - wcs.enterCount - wcs.spaceCount;
	}
//	public int getCharsCount(){
//		
//	}
	public int getAllCharsCount(){
		return b.getEditer().getCharCount();
	}
	public void setSlider(Slider slider){
		if(b.text != null && !b.text.isDisposed()){
			sliderListener = new Listener() {
				
				@Override
				public void handleEvent(Event arg0) {
					// TODO Auto-generated method stub
					if(slider != null && !slider.isDisposed()){
						ScrollBar vb = b.text.getVerticalBar();
						slider.setValues(vb.getSelection(), vb.getMinimum(), vb.getMaximum(), vb.getThumb(), vb.getIncrement(), vb.getPageIncrement());
					}
				}
			};
			b.text.addListener(SWT.Paint, sliderListener); 
		}
	}

}
class findinfo_result{
	public File currenteditfile;
	public findinfo_[] findin;
	public findinfo_result(File currenteditfile, findinfo_[] findin){
		this.currenteditfile = currenteditfile;
		this.findin = findin;
	}
	public String getAllText(){
		StringBuilder sb = new StringBuilder();
		for(findinfo_ findinfo: findin){
			sb.append(findinfo.stringbuilder.toString());
		}
		return sb.toString();
	}
}
class findinfo_{
	public StringBuilder stringbuilder;
	public String subname;
	public findinfo_(StringBuilder sb, String subname){
		stringbuilder = sb;
		this.subname = subname;
	}
}
class textInfo{
	public String fontName;
	public int fontSize,fontStyle,alignment;
	public boolean scrikeout,underline;
	public textInfo(String fontname, int fontsize, int fontstyle,boolean scrikeout,boolean underline,int alignment){
		this.fontName = fontname;
		this.fontSize = fontsize;
		this.fontStyle = fontstyle;
		this.scrikeout = scrikeout;
		this.underline = underline;
		this.alignment = alignment;
	}
}
class alignmentInfo{
	public int linestartoffset,alignment;
	public alignmentInfo(int linestartoffset, int alignment){
		this.linestartoffset = linestartoffset;
		this.alignment = alignment;
	}
}
class fileInfo{
	String showname,realname;
	int caretoffset,toplinx,toppixel;
	boolean inrecycle;
	public fileInfo(String realname,String showname){
		this.realname = realname;
		this.showname = showname;
	}
}
