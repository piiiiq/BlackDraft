package yang.app.black;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.lang.management.ManagementFactory;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.regex.Pattern;

import javafx.scene.text.Font;

import org.eclipse.wb.swt.SWTResourceManager;

import sun.management.ManagementFactoryHelper;
import yang.demo.allPurpose.autoDO;
import yang.demo.allPurpose.stringAction;

public class test {

 public static void main(String[] args) {
	autoDO dof = new autoDO(1) {
		
		@Override
		public void action() {
			// TODO Auto-generated method stub
			System.out.println(System.currentTimeMillis());
		}
	};
	dof.start();
 }
 
 public static void testarraylist(){
	
 }
 public static void a(){
	 long a = 3600L*1000L*24L*60L;
		Calendar cal = Calendar.getInstance();
		long l = cal.getTimeInMillis();
		Time t = new Time(l);
		long newtime = a+l;
		System.out.println(newtime);
		Date d = new Date(newtime);
		System.out.println(d);
 }
 public static void b(){
	 ArrayList<c> al = new ArrayList<c>();
	 al.add(new c("hello world"));
	 File f = new File("d:\\a");
	 FileOutputStream fos = null;
	try {
		fos = new FileOutputStream(f);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 try {
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(al);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
 }
public static void readobject(){
	 ArrayList<c> al = null;
	 File f = new File("D:\\a");
	 FileInputStream fis = null;
	try {
		fis = new FileInputStream(f);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 ObjectInputStream ois = null;
	try {
		ois = new ObjectInputStream(fis);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 try {
		al = (ArrayList<c>)ois.readObject();
		System.out.println(al.get(0).name);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
}
class c implements Serializable{
	String name;
	public c(String name){
		this.name = name;
	}
}
class testarraylist{
	String name,value;
	public testarraylist(String name, String value){
		this.name = name;
		this.value = value;
	}
}