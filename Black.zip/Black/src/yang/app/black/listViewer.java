package yang.app.black;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.jface.viewers.IOpenListener;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.OpenEvent;
import org.eclipse.swt.SWT;
import org.eclipse.jface.fieldassist.ControlDecoration;

import com.sun.glass.ui.MenuItem;


public class listViewer extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public listViewer(Composite parent, int style) {
		super(parent, style);
		
		ListViewer listViewer = new ListViewer(this, SWT.CENTER|SWT.V_SCROLL);
		List list = listViewer.getList();
		list.setBounds(0, 0, 450, 300);
		
		ControlDecoration controlDecoration = new ControlDecoration(list, SWT.LEFT | SWT.TOP);
		controlDecoration.setDescriptionText("Some description");
		
		Menu menu = new Menu(list);
		list.setMenu(menu);
		org.eclipse.swt.widgets.MenuItem mi = new org.eclipse.swt.widgets.MenuItem(menu, SWT.None);
		listViewer.add("hellor");
		listViewer.add("ccccc");
		
		
		
		listViewer.addOpenListener(new IOpenListener() {
			
			@Override
			public void open(OpenEvent event) {
				// TODO Auto-generated method stub
				System.out.println("sssssss");
			}
		});
		

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
