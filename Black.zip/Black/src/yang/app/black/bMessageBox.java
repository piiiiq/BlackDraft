package yang.app.black;

import java.io.Serializable;

import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.custom.StyledText;

import yang.demo.swt.windowLocation;

public class bMessageBox extends Dialog implements Serializable{
	static final long serialVersionUID = 42L;

	protected Object result;
	protected Shell shell;
	private StyledText text;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public bMessageBox(Shell parent, int style) {
		super(parent, style);
		createContents();
	}
	
	public void readOnly(boolean readOnly){
		text.setEditable(readOnly);
//		if(readOnly){
//			text.setIME(null);
//		}
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}
	
	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM|SWT.MIN);
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		shell.setSize(450, 510);
		windowLocation.showWindowOnScreenCenter(shell);
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(0, 431, 444, 50);
		
		Button btnNewButton = new Button(composite, SWT.NONE);
		btnNewButton.setBounds(354, 10, 80, 27);
		btnNewButton.setText("\u786E\u5B9A");
		btnNewButton.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				shell.dispose();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		text = new StyledText(shell, SWT.READ_ONLY | SWT.WRAP | SWT.V_SCROLL | SWT.MULTI);
		text.setFont(((black)getParent()).text.getFont());
		text.setLeftMargin(20);
		text.setLineSpacing(5);
		text.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		text.setBounds(0, 0, 444, 431);
		
	}
	public void setText(String str){
		text.setText(str);
	}
	public void setTitle(String str){
		shell.setText(str);
	}
}
