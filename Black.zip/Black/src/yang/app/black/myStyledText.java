package yang.app.black;

import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;

public class myStyledText extends StyledText{

	public myStyledText(Composite parent, int style) {
		super(parent, style);
		// TODO Auto-generated constructor stub
	}
	

}
