package yang.app.black.starter;

import org.eclipse.swt.widgets.Display;
import yang.app.black.black;

public class blackMain {
	public static black b;
	public static void main(String args[]) {
		b = new black();
		while (!b.isDisposed()) {
			if (!Display.getDefault().readAndDispatch()) {
				Display.getDefault().sleep();
			}
		}
	}
	public static void restart(){
		if(b != null && !b.isDisposed()){
			b.dispose();
		}
		main(null);
	}
	
}
