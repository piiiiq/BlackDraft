package yang.app.black;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.FindReplaceDocumentAdapter;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CaretEvent;
import org.eclipse.swt.custom.CaretListener;
import org.eclipse.swt.custom.ExtendedModifyEvent;
import org.eclipse.swt.custom.ExtendedModifyListener;
import org.eclipse.swt.custom.ST;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.wb.swt.SWTResourceManager;

import qt.hellow;
import yang.demo.allPurpose.time;

public class blackTextArea implements Serializable{
	static final long serialVersionUID = 42L;
	static int addSpaceAfterParagraph = 0;//unuse
	private black black;
	int wordIndex, wordLength;// ���ҵ�����ֵ
	private StyleRange[] oldsr;// ���ַ�����ǰ�ķ��
	StyledText st;
	KeyListener readingModeKey,simpleModeKey,defaultKeyListener;
	KeyListener typeModeListener;
	ExtendedModifyListener commandListener;
	Color oldColor;
	int oldLineIndex;
	MouseListener forStyledPanel;
	List<StyleRange[]> styles;
	TextStyle defaultStyle;
	ArrayList<Integer> parspace = new ArrayList<>();
	ArrayList<checkKey> cheakkey = new ArrayList<checkKey>();
	ArrayList<command> commands = new ArrayList<command>();
	mycaret caret;
	String linestr;
	checkKey keyenter;
	int lastcaretOffset,caretOffset,keycode;
	MouseListener forCharCount;

	public blackTextArea(final StyledText st, final black black) {
		this.black = black;
		this.st = st;
		st.setDoubleClickEnabled(false);
		if(black.wv != null && !black.wv.isDisposed())
			st.setMargins(130, 10, 110, 0);
		else st.setMargins(30, 10, 10, 0);
		
		restoreSettings();
		addDefaultKeyListener();
		addMenu(st);
		addModifyListener(st);
		st.setKeyBinding(SWT.TAB,-1);
		addKeyAction(new checkKey(SWT.TAB) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				scrollForTypeMode();
			}
		});
		
		
		addParSpace();
	}
	/**
	 * ��ȡȥ����ʽ���������У�����ı�
	 * @return
	 */
	public String getText(){
		String text = st.getText();
		text = Pattern.compile("^\n", Pattern.MULTILINE).matcher(text).replaceAll("");
		return text;
	}
	void insertPar(){
		black.ba.insertText("\n\n", st);
		st.setSelection(st.getCaretOffset());
		//st.insert("\n\n");
//		int newline = st.getTopIndex()+2;
//		st.setTopIndex(newline);
	}
	void p(Object o){
		System.out.println(o);
	}
	void addP(){
		
	}
	/**
	 * �ڶ��������һ������
	 * 
	 */
	public void addParSpace(){
		st.setKeyBinding(13, -1);
		st.setKeyBinding(8, -1);
		st.addKeyListener(new KeyListener() {
			
			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub
				//p(":"+st.getCaretOffset());

//				switch(arg0.keyCode){
//				case 16777217:
//					int line = st.getLineAtOffset(st.getCaretOffset());
//					if(line-2 >= 0){
//						String linetext = st.getLine(line-2);
//						st.setCaretOffset(st.getOffsetAtLine(line-2)+linetext.length());
//					}
//					break;
//				case 16777218:break;
//				case 16777220:break;
//				case 16777219:break;
//				}
			}
		});
		keyenter = new checkKey(13) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
			//	if(st.getCaretOffset()>0 && st.getCaretOffset()+1 < st.getCharCount())
			//	if(!st.getText(st.getCaretOffset()+1, st.getCaretOffset()+1).equals("\n"))
					insertPar();
			}
		};
		addKeyAction(keyenter);
		addKeyAction(new checkKey(8) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				if(st.getSelectionCount() > 0) st.replaceTextRange(st.getSelectionRange().x, st.getSelectionCount(), "");
				else if(st.getCaretOffset()-1 > 0){
					if(!st.getText(st.getCaretOffset()-1, st.getCaretOffset()-1).equals("\n")) st.invokeAction(ST.DELETE_PREVIOUS);
					else{
						if(st.getCaretOffset()-2 > 0 && st.getText(st.getCaretOffset()-2, st.getCaretOffset()-2).equals("\n")){
							st.replaceTextRange(st.getCaretOffset()-2, 2, "");
						}else st.invokeAction(ST.DELETE_PREVIOUS);
					}
				}else st.invokeAction(ST.DELETE_PREVIOUS);
				
			}
		});
		st.addCaretListener(new CaretListener() {
			
			@Override
			public void caretMoved(CaretEvent arg0) {
				// TODO Auto-generated method stub
				//p(keycode);
				lastcaretOffset = caretOffset;
				caretOffset = arg0.caretOffset;
				if(st.getCaretOffset()-3>0 && st.getCaretOffset() < st.getCharCount()){
					String t1 = st.getText(st.getCaretOffset()-3, st.getCaretOffset()-3);
					String t2 = st.getText(st.getCaretOffset()-2, st.getCaretOffset()-2);
					String t3 = st.getText(st.getCaretOffset()-1, st.getCaretOffset()-1);

					if(!t1.equals("\n") && t2.equals("\n") && t3.equals("\n"));
					else{
						String t = st.getText(st.getCaretOffset()-1, st.getCaretOffset());
						if(arg0.caretOffset != st.getCharCount()-1){
							if(t.equals("\n\n")){
								p_();
							}
						}
					}
				}
				else if(st.getCaretOffset()>0 && st.getCaretOffset() < st.getCharCount()){
					String t = st.getText(st.getCaretOffset()-1, st.getCaretOffset());
					if(arg0.caretOffset != st.getCharCount()-1){
						if(t.equals("\n\n")){
							p_();
						}
					}
				}
			}
		});
	}
	void p_(){
		if(caretOffset > lastcaretOffset)
			st.setCaretOffset(caretOffset+1);
		if(caretOffset < lastcaretOffset)
			st.setCaretOffset(caretOffset-1);
	}
	public void restoreSettings(){
		st.setIndent(black.getEditerIndent());
		addCaret();
		st.setCaret(caret);
		addCommandListener();
		addDefaultCommand();
		if(black.ba.isSimpleMode()) {
			normalMode();
			simpleMode(true);
		}
		else normalMode();
		eyeColor();
		
	}
	public void eyeColor(){
		if(Boolean.valueOf(black.appProperties.getProperty("EyeColor", "flase"))){
			black.ba.eyeColor(true);
		}else black.ba.eyeColor(false);
	}
	public void addCaret(){
		if(Boolean.valueOf(black.appProperties.getProperty("CaretV","true")))
			caret = new mycaret(st, SWT.VERTICAL);
		else caret = new mycaret(st,SWT.HORIZONTAL);
	}
	public void addModifyListener(final StyledText st){
		st.addModifyListener(new ModifyListener() {

			@Override
			public void modifyText(ModifyEvent e) {
				// TODO Auto-generated method stub
				black.setFileIsSave(0);
				black.ba.showCharCount();
				//black.applySetting();
				//showMark();
			}
		});
		
		//Ϊ��������ַ�������ʽ
		st.addExtendedModifyListener(new ExtendedModifyListener() {
			
		
			public void modifyText(ExtendedModifyEvent event) {
				
				if(!st.isDisposed()){
					if(event.start > 0 && event.start <= st.getCharCount()){
						int alignment = st.getLineAlignment(st.getLineAtOffset(event.start-1));
						st.setLineAlignment(st.getLineAtOffset(event.start), 1, alignment);
						
						StyleRange s = st.getStyleRangeAtOffset(event.start-1);
						if(s != null && s.start+s.length < st.getCharCount()){
							s.start = event.start;
							s.length = 1;
							
							st.setStyleRange(s);
						}
					}
					if(event.start+event.length == st.getCharCount() && defaultStyle != null){
						StyleRange sr = new StyleRange(defaultStyle);
						sr.start = event.start;
						sr.length = event.length;
						st.setStyleRange(sr);
						defaultStyle = null;
					}
				}
			}
		});
	}
	public void addCommandListener(){
		if(commandListener == null){
		commandListener = new ExtendedModifyListener() {
			
			@Override
			public void modifyText(ExtendedModifyEvent event) {
				// TODO Auto-generated method stub
				linestr = st.getLine(st.getLineAtOffset(st.getCaretOffset()));
				String command_str = "@";
				TextRegion tr_command_str = cheakDocument.find(linestr, command_str);
				//����⵽�û�����@ʱ
				if(st.getCaretOffset() > 0){
					String currentStr = st.getText(st.getCaretOffset()-1, st.getCaretOffset()-1);
					if(currentStr.equals(command_str)){
						TextRegion tr_current = new TextRegion(currentStr, st.getCaretOffset()-1, st.getCaretOffset());
						if(tr_current != null){
							if(black.ba.findi == null){
								if(black.wv == null || black.wv.isDisposed())
									black.ba.findi = new findinfo(black,black,SWT.None);
								else black.ba.findi = new findinfo(black.wv, black, SWT.None);
								
								for(int i=0; i<commands.size();i++){
									command com = commands.get(i);
									TreeItem ti = new TreeItem(black.ba.findi.tree,SWT.None);
									ti.setData("index", i);
									ti.setData("textregion", 
											new TextRegion(com.command, tr_current.end,
													tr_current.end+com.command.length()));
									if(com.describe != null)
										ti.setText(com.command+"("+com.describe+")");
									else ti.setText(com.command);
								}
								if(black.ba.findi.tree.getItemCount() > 0)
									black.ba.findi.tree.setSelection(black.ba.findi.tree.getItem(0));
								black.ba.findi.setVisible(true);
							}
						}
					}else{
						//̽���û��ڵ�ǰ����������ַ�ǰ���Ƿ����@����
						if(tr_command_str != null){
							if(tr_command_str.start+getLineOffset() < st.getCaretOffset()){
								String str = linestr.substring(tr_command_str.start+1, st.getCaretOffset()-getLineOffset());
								if(black.ba.findi == null) black.ba.findi = new findinfo(black, black, SWT.None);
								else black.ba.findi.tree.removeAll();
								int a = 0;
								for(int i=0; i<commands.size(); i++){
									command com = commands.get(i);
									int index = com.command.indexOf(str);
									if(index != -1){
										TreeItem ti = new TreeItem(black.ba.findi.tree,SWT.None);
										ti.setData("index", a);
										ti.setData("textregion", 
												new TextRegion(com.command, tr_command_str.start+getLineOffset(),
														tr_command_str.end+getLineOffset()+str.length()));
										if(com.describe != null)
											ti.setText(com.command+"("+com.describe+")");
										else ti.setText(com.command);
										a++;
									}
								}
								black.ba.findi.setVisible(true);
							}
						}
					}
				}
				
				
				if(tr_command_str != null)
				for(int i=0; i<commands.size(); i++){
						command com = commands.get(i);
						
						TextRegion command_tr = cheakDocument.find(linestr, command_str+com.command);
						if(command_tr != null){	
								if(!com.needmore){
									st.replaceTextRange(getLineOffset()+command_tr.start,
											command_tr.end-command_tr.start, "");
									com.action(command_tr);
								}else{									
									TextRegion tr = cheakDocument.subString(linestr, command_tr.start+command_tr.text.length(),
											" ");
									if(tr != null){
										st.replaceTextRange(getLineOffset()+command_tr.start,
												command_tr.text.length()+tr.text.length()+1, "");
										com.action(tr);
									}
								}
								break;
						}
				}
			}
		};
		st.addExtendedModifyListener(commandListener);
		}
	}
	public void addCommand(command com){
		if(com != null)
			commands.add(com);
		else throw new NullPointerException();
	}
	public void removeAllCommand(){
		commands.removeAll(new ArrayList<command>());
	}
	public void removeCommand(command com){
		if(com != null) commands.remove(com);
		else throw new NullPointerException();
	}
	public void addDefaultCommand(){
		defautCommand.defaultCommand(black, st,this);
	}
	public int getLineOffset(){
		return st.getOffsetAtLine(st.getLineAtOffset(st.getCaretOffset()));
	}
	public void insertForCommandListener(String text,int start,int end){
		st.replaceTextRange(start, end-start, text);
		st.setCaretOffset(start+text.length());
	}
	public void showMark(){
		int lineindex = st.getLineAtOffset(st.getCaretOffset());
		int lineoffset = st.getOffsetAtLine(lineindex);
		List<TextRegion> lis = new cheakDocument().splitString(st.getLine(st.getLineAtOffset(st.getCaretOffset())), ' ', false, null);
		Iterator<TextRegion> it = lis.iterator();
		StyleRange sr = new StyleRange();
		while(it.hasNext()){
			TextRegion tr = it.next();
			sr.background = SWTResourceManager.getColor(SWT.COLOR_GREEN);
			sr.start = tr.start+lineoffset;
			sr.length = tr.end-tr.start;
			st.setStyleRange(sr);
			
		}
	}
	public void writingView(){
		//st.setBackground(SWTResourceManager.getColor(175, 205, 133));
		st.getVerticalBar().setVisible(false);
		
		st.setFocus();
		black.ba.getMenuItem(st.getMenu(), "", SWT.SEPARATOR);
		black.ba.getMenuItem(st.getMenu(), "�˳�д����ͼ	ESC", SWT.None).addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.wv.exit();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		MenuItem mi1 = black.ba.getMenuItem(st.getMenu(), "", SWT.SEPARATOR);
		MenuItem mi2 = black.ba.getMenuItem(st.getMenu(), "�ַ���	"+black.ba.getCharsCount()+"����", SWT.None);
		
		mi2.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.ba.wordCountStat(black.wv);
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
			forCharCount = new MouseListener() {
			@Override
			public void mouseUp(MouseEvent arg0) {
				// TODO Auto-generated method stub
				if(!mi2.isDisposed()){
					if(arg0.button == 3){
						mi2.setText("�ַ���	"+black.ba.getCharsCount()+"����");
					}
				}else{
					if (forCharCount != null)
						st.removeMouseListener(forCharCount);
				}
			}
			
			@Override
			public void mouseDown(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseDoubleClick(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}};
			st.addMouseListener(forCharCount);
	}
	/**
	 * ��ͨģʽ
	 */
	public void normalMode(){
		st.setFont(new Font(st.getDisplay(), black.getEditorDefaultFontFromCFG(),
				black.getZoomedFontSize(black.ba.getEditerDefaultFontSize()), 0));
		st.setLineSpacing(black.getEditerLineSpace());
		black.ba.changeColor(black.color_line,black.color_area);
		st.setFocus();
		addKeyActionForNormal();
		
		//��ʾ�༭�����
		if(forStyledPanel == null)
		 forStyledPanel = new MouseListener() {
			
			public void mouseUp(MouseEvent e) {
				if(e.button == 3)
					if(black.wv == null || black.wv.isDisposed())
						new editerStyledPanel(black, new Point(e.x, e.y)).open();
			}
			@Override
			public void mouseDown(org.eclipse.swt.events.MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseDoubleClick(org.eclipse.swt.events.MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			
		};
		
		st.addMouseListener(forStyledPanel);
		
		
	}
	
	public void simpleMode(boolean simplemode){
		if(simplemode){
			if(black.getMenuBar() != null && !black.getMenuBar().isDisposed()){
				black.getMenuBar().dispose();
			}
			black.composite.setVisible(false);
			black.tree.setVisible(false);
			black.resetLayoutData();
			
		}else{
			if(black.getMenuBar() == null || black.getMenuBar().isDisposed()){
				black.createMenuBar();
			}
			black.tree.setVisible(true);
			black.composite.setVisible(true);
			black.resetLayoutData();
		}
	}

	
	/**
	 * ��������ı�ʱ���õĸ������
	 */
	public void clearSelection() {
		if (oldsr != null && black.getEditer() != null && !black.getEditer().isDisposed()) {
			st.setStyleRanges(oldsr);
		}
		if(styles != null && black.getEditer() != null && !black.getEditer().isDisposed()){
			Iterator<StyleRange[]> it = styles.iterator();
			while(it.hasNext()){
				black.getEditer().setStyleRanges(it.next());
			}
		}
	}
	public void clearFindHistory(){
		wordIndex = wordLength = 0;
	}
	/**
	 * ����
	 * 
	 * @param word
	 */
	public void findWord(IDocument doc,String word,boolean forwardSearch, boolean caseSensitive, boolean wholeWord,boolean showAll,boolean regularExpressions) {
		clearSelection();
		FindReplaceDocumentAdapter frda = new FindReplaceDocumentAdapter(doc);
		if(forwardSearch == true)
			wordIndex+=wordLength;
		else wordIndex-=1;
		//�Ƿ���ʾȫ��
		if(!showAll){
			IRegion ir = null;
			try {
				ir = frda.find(wordIndex, word, forwardSearch, caseSensitive, wholeWord, regularExpressions);
				
			} catch (BadLocationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			if (ir != null) {
				wordIndex = ir.getOffset();
				int line = st.getContent().getLineAtOffset(wordIndex);
				st.setTopIndex(line);
				wordLength = ir.getLength();
				StyleRange sr = new StyleRange(wordIndex, wordLength,
						black.color_textBackground,
						org.eclipse.wb.swt.SWTResourceManager
								.getColor(SWT.COLOR_DARK_GREEN));
				// ������ַ�����ǰ�ķ��
				oldsr = st.getStyleRanges(wordIndex, wordLength);
				st.setStyleRange(sr);
				
				
			}else{
				if(wordIndex == 0)
					black.ba.getMessageBox("����/�滻��Ϣ", "δ���ҵ����");
				else{
					if(forwardSearch)
						black.ba.getMessageBox("����/�滻��Ϣ","�Ѳ������ĵ�ĩβ���´ν����ĵ���ʼ���²���");
					else black.ba.getMessageBox("����/�滻��Ϣ","�Ѳ������ĵ����ˣ��´ν����ĵ�ĩβ���²���");
				}
				wordIndex = 0; wordLength = 0;
			}
		}else{//��ʾȫ����
			IRegion ir;
			int i = 0;
			try {
				while((ir = frda.find(wordIndex, word, forwardSearch, caseSensitive, wholeWord, regularExpressions)) != null){
					styles = new ArrayList<StyleRange[]>();
					wordIndex = ir.getOffset();
					wordLength = ir.getLength();
					StyleRange sr = new StyleRange(wordIndex, wordLength,
							black.color_textBackground,
							org.eclipse.wb.swt.SWTResourceManager
									.getColor(SWT.COLOR_DARK_GREEN));
					styles.add(black.getEditer().getStyleRanges(wordIndex, wordLength));
					black.getEditer().setStyleRange(sr);
					wordIndex+=wordLength;
					++i;
				}
				black.ba.getMessageBox("����/�滻��Ϣ", "���ҵ�"+i+"��");
				wordIndex = 0; wordLength = 0;
			} catch (BadLocationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * �滻�ı�
	 * 
	 * @param word1
	 *            Ҫ�滻���ַ���
	 * @param word2
	 *            �滻Ϊ
	 */
	public int replace(IDocument doc,String word1, String word2,boolean forwardSearch, boolean caseSensitive, boolean wholeWord,boolean showmessage,boolean regularExpressions) {
		int i =0;
		try {
			FindReplaceDocumentAdapter frda = new FindReplaceDocumentAdapter(doc);
			while(frda.find(0, word1, true, caseSensitive, wholeWord, regularExpressions) != null){
				frda.replace(word2, regularExpressions);
				i++;
			}
			if(showmessage)
			black.ba.getMessageBox("����/�滻��Ϣ","�滻��"+i+"��");
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public void scrollForTypeMode(){
		if(!st.isDisposed()){
			st.setRedraw(false);
			if(st.getCaret().getLocation().y > st.getClientArea().height/2){
				int toppixel = st.getTopPixel()+(st.getCaret().getLocation().y-st.getClientArea().height/2);
				st.setRedraw(true);
				st.setTopPixel(toppixel);
			}
			else {
				int toppixel = st.getTopPixel()-((st.getClientArea().height/2)-st.getCaret().getLocation().y);
				st.setRedraw(true);
				st.setTopPixel(toppixel);
				
			}
		}
	}
	/**
	 * ���ֻ�����
	 * @param b
	 */
	public void typeMode(boolean b) {
		if(b){
			if(typeModeListener == null){
				typeModeListener = new KeyListener() {
					
					@Override
					public void keyReleased(KeyEvent arg0) {
						// TODO Auto-generated method stub
					}
					
					@Override
					public void keyPressed(KeyEvent arg0) {
						// TODO Auto-generated method stub
						scrollForTypeMode();
					}
				};
			st.addKeyListener(typeModeListener);
		}else{
			if(typeModeListener != null){
				st.removeKeyListener(typeModeListener);
			}
		}
		}
	}
	public void addMenu(final StyledText st) {
		Menu menu = new Menu(st);
		st.setMenu(menu);
		
		MenuItem mntmNewItem_ = new MenuItem(menu, SWT.None);
		mntmNewItem_.setText("���뵱ǰ����	Alt+D");
		mntmNewItem_.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				black.ba.insertText(time.getCurrentDate("-"),st);
			}
		});
		MenuItem mntmNewItem_1 = new MenuItem(menu, SWT.None);
		mntmNewItem_1.setText("���뵱ǰʱ��	Alt+T");
		mntmNewItem_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				black.ba.insertText(time.getCurrentTime(),st);
			}
		});
		MenuItem mntmNewItem_2 = new MenuItem(menu, SWT.None);
		mntmNewItem_2.setText("��������б�	Alt+N");
		mntmNewItem_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				black.ba.insertList(true,null,st);
			}
		});
		MenuItem sep = new MenuItem(menu,SWT.SEPARATOR);

		
		final MenuItem mntmNewItem_4 = new MenuItem(menu, SWT.None);
		mntmNewItem_4.setText("д����ͼ	F11/Esc");
		mntmNewItem_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				black.ba.openWritingView();
			}
		});
		MenuItem mi = black.ba.getMenuItem(st.getMenu(), "������ͼ	F11/Esc", SWT.None);
		mi.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.ba.simpleMode();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});

		MenuItem sep_ = new MenuItem(menu,SWT.SEPARATOR);

		MenuItem mntmNewItem = new MenuItem(menu, SWT.None);
		mntmNewItem.setText("����	Ctrl+C");
		mntmNewItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				black.ba.copyText(st);
			}
		});
		MenuItem menupaset = new MenuItem(menu,SWT.CONTROL);
		menupaset.setText("ճ��Ϊ���ı�	Ctrl+V");
		menupaset.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.ba.pasteText(st);
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		MenuItem sep_3 = new MenuItem(menu,SWT.SEPARATOR);
		MenuItem menucut = new MenuItem(menu,SWT.None);
		menucut.setText("����	Ctrl+X");
		menucut.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.ba.cutText(st);
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		MenuItem sep_1 = new MenuItem(menu,SWT.SEPARATOR);
		MenuItem menuSelectAll = new MenuItem(menu,SWT.None);
		menuSelectAll.setText("ȫѡ	Ctrl+A");
		menuSelectAll.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				black.ba.selectAllText(st);
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
			}
		});
		black.ba.getMenuItem(st.getMenu(), "", SWT.SEPARATOR);
		MenuItem menuitem = black.ba.getMenuItem(st.getMenu(), "�������ļ�", SWT.CASCADE);
		Menu menu1 = new Menu(menuitem);
		menuitem.setMenu(menu1);
		MenuItem mi1 = black.ba.getMenuItem(menu1, "�ݸ�", SWT.CASCADE);
		Menu menu_ = new Menu(mi1);
		mi1.setMenu(menu_);
		
		MenuItem mire = black.ba.getMenuItem(menu1, "������", SWT.CASCADE);
		Menu menu_1 = new Menu(mire);
		mire.setMenu(menu_1);
		if(black.fileindex != null){
			Iterator<String> it = black.fileindex.iterator();
			while(it.hasNext()){
				final String name = it.next();
				if(black.recycle.getProperty(name) == null){
					black.ba.getMenuItem(menu_, black.fileInfo.getProperty(name, name), SWT.None).addSelectionListener(new SelectionListener() {
						
						@Override
						public void widgetSelected(SelectionEvent e) {
							// TODO Auto-generated method stub
							File f = new File(black.projectFile.getParent()+"\\Files\\"+name);
							black.ba.openFile(f, true);
						}
						
						@Override
						public void widgetDefaultSelected(SelectionEvent e) {
							// TODO Auto-generated method stub
							
						}
					});
					
				}else{
					black.ba.getMenuItem(menu_1, black.fileInfo.getProperty(name, name), SWT.None).addSelectionListener(new SelectionListener() {
						
						@Override
						public void widgetSelected(SelectionEvent e) {
							// TODO Auto-generated method stub
							black.ba.openFile(new File(black.projectFile.getParent()+"\\Files\\"+name), true);
						}
						
						@Override
						public void widgetDefaultSelected(SelectionEvent e) {
							// TODO Auto-generated method stub
							
						}
					});
				}
			}
		}
	}
	public void addKeyAction(checkKey ck){
		if(ck != null)
			cheakkey.add(ck);
	//	else throw new NullPointerException();
	}
	public void removeKeyAction(checkKey ck){
		if(cheakkey != null){
			if(ck != null)
				cheakkey.remove(ck);
			//else throw new NullPointerException();
		}//else throw new NullPointerException();
	}
	public void removeAllKeyAction(){
		cheakkey = new ArrayList<>();
	}
	void addKeyActionForNormal(){
		addKeyAction(new checkKey(SWT.CONTROL|'n') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.openNewProjectDialog();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'i') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				new importFiles(black, SWT.None).open();

			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'e') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				new exportFiles(black,SWT.None).open();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'f') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.findReplaceWord();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'=') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.addFileToProject();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'-') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.moveFileToRecycle();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'c') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.clearRecycle();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'p') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				new projectInfo(black,SWT.None).open();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'r') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.restoreFile();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'g') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				if(black.text != null)
					new editerStyledPanel(black, null).open();
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'d') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertText(time.getCurrentDate("-"),st);
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'t') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertText(time.getCurrentTime(),st);
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'n') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertList(true,null,st);
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'i') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertList(true,"��",st);
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'k') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.wordCountStat(black);
			}
		});
		addKeyAction(new checkKey(SWT.F1) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.showSettings();
			}
		});
		
		addKeyAction(new checkKey(SWT.F11) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.openWritingView();
			}
		});
		addKeyAction(new checkKey(SWT.F12) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.simpleMode();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|SWT.SHIFT|'a') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.aboutBlack();
			}
		});
		
		addKeyAction(new checkKey(SWT.CONTROL|SWT.ALT|SWT.SHIFT|'s') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.getSystemInfo();
				//black.ba.getMessageBox("ϵͳ��Ϣ", "ʣ�������������"+black.getsafe().getTryedDays());
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'/') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				if(black.ba.findi == null)
					black.ba.findInfo();
			}
		});
	}
	void addDefaultKeyAction(){
		addKeyAction(new checkKey(SWT.CONTROL|'a') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.selectAllText(st);
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'s') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.saveFile(false, false);
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'z') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.Undo();
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'z') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.Redo();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'=') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.zoomOut();
			}
		});
		addKeyAction(new checkKey(SWT.CONTROL|'-') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.zoomIn();
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'j') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertText("��", st);
			}
		});
		addKeyAction(new checkKey(SWT.ALT|'k') {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				black.ba.insertText("��", st);
			}
		});
		addKeyAction(new checkKey(SWT.ESC) {
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				if(black.ba.findi != null && !black.ba.findi.isDisposed()){
					black.ba.findi.dispose();
				}else if(black.ba.isSimpleMode()){
					black.ba.simpleMode();
				}else if(black.wv != null && !black.wv.isDisposed()){
					black.wv.exit();
				}
			}
		});		
	}
	void addDefaultKeyListener() {
		if(defaultKeyListener == null){
		defaultKeyListener = new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(cheakkey != null){
					for(int i=0; i<cheakkey.size(); i++){
						checkKey chkey = cheakkey.get(i);
						if((e.stateMask|e.keyCode) == chkey.key){
							chkey.action();
						}
					}
				}
			}
		};
		st.addKeyListener(defaultKeyListener);
		addDefaultKeyAction();
		}
	}
}
abstract class command implements Serializable{
	static final long serialVersionUID = 42L;
	String command,describe;
	boolean needmore;
	public command(String command){
		this.command = command;
	}
	public command(String command, String describe){
		this.command = command;
		this.describe = describe;
	}
	public command(String command, String describe, boolean needmore){
		this.command = command;
		this.describe = describe;
		this.needmore = needmore;
	}
	public command(String command, boolean needmore){
		this.command = command;
		this.needmore = needmore;
	}
	public abstract void action(TextRegion command_tr);
}
abstract class checkKey implements Serializable{
	static final long serialVersionUID = 42L;
	KeyEvent e;
	int key;
	/**
	 * �󶨼�
	 * @param key��ϼ�����Ctrl|Alt|Shift|'t'
	 */
	public checkKey(int key){
		this.key = key;
	}
	void setKeyEvent(KeyEvent e){
		this.e = e;
	}
	/**
	 * �����ϼ��󶨵Ķ���
	 */
	public abstract void action();
}
