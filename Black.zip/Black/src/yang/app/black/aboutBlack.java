package yang.app.black;

import java.io.Serializable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import yang.demo.swt.animateWindows;
import yang.demo.swt.windowLocation;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.StyledText;

public class aboutBlack extends Dialog implements Serializable{
	static final long serialVersionUID = 42L;

	protected Object result;
	protected Shell shell;
	private StyledText txtBlackEditor;
	private black black;
	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public aboutBlack(Shell parent, int style) {
		super(parent, SWT.APPLICATION_MODAL);
		this.black = (black) parent;
		setText("����Black");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.PRIMARY_MODAL);
		shell.addShellListener(new ShellAdapter() {
			@Override
			public void shellDeactivated(ShellEvent e) {
				closeThis();
			}
		});
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		shell.setSize(516, 332);
		shell.setText(getText());
		
		txtBlackEditor = new StyledText(shell, SWT.READ_ONLY | SWT.WRAP | SWT.V_SCROLL | SWT.MULTI);
		txtBlackEditor.getCaret().dispose();
		txtBlackEditor.setLineSpacing(3);
		txtBlackEditor.setLeftMargin(10);
		txtBlackEditor.setText("Black (Bradypus pygmaeus) - \u7528\u4E8E\u64B0\u5199\u548C\u7BA1\u7406\u6587\u5B66\u4F5C\u54C1\u9879\u76EE\r\n\u672C\u7A0B\u5E8F\u4F7F\u7528Java\u7F16\u5199\uFF0C\u57FA\u4E8EEclipse-SWT/Jface\u90E8\u4EF6\u5DE5\u5177\u7BB1\u6784\u5EFA\u3002\r\n\uFF08\u672C\u7A0B\u5E8F\u6240\u4F7F\u7528\u7684\u5F00\u653E\u6E90\u4EE3\u7801\u8F6F\u4EF6/\u5E93\uFF09\r\n\u8DE8\u5E73\u53F0\u7684GUI\u90E8\u4EF6\u5E93\uFF1ASWT/Jface - EPL\uFF08Eclipse\u516C\u7528\u8BB8\u53EF\u534F\u8BAE\uFF09-www.eclipse.org\r\n\u5FAE\u8F6FWord\uFF08doc\uFF0Cdocx\uFF09\u683C\u5F0F\u8BFB\u5199\u652F\u6301\uFF1AApache POI - Apache License\uFF08Apache\u534F\u8BAE\uFF09- poi.apache.org\r\nJava\u542F\u52A8\u5668\uFF1AWinRun4J - EPL\uFF08Eclipse\u516C\u7528\u8BB8\u53EF\u534F\u8BAE\uFF09\r\n\uFF08\u7F16\u7A0B\uFF09\r\n\u6BB5\u6653\u9633-beihuiguixian@hotmail.com\r\n\uFF08\u6D4B\u8BD5\u4EBA\u5458\uFF09\r\n\uFF08Linux\u7248\u672C\uFF09");
		
		txtBlackEditor.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		txtBlackEditor.setEditable(false);
		txtBlackEditor.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		txtBlackEditor.setFont(SWTResourceManager.getFont("΢���ź�", 9, SWT.NORMAL));
		txtBlackEditor.setBounds(0, 0, 510, 216);
		
		Button btnOk = new Button(shell, SWT.NONE);
		btnOk.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				closeThis();
			}
		});
		btnOk.setBounds(420, 266, 80, 27);
		btnOk.setText("\u786E\u5B9A");
		
		Label label = new Label(shell, SWT.WRAP);
		label.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label.setBounds(10, 237, 490, 56);
		label.setText(black.codeName+
					"\nBlack�汾�� " +
					yang.app.black.black.getAppVersion() +
					"\n�������ڣ� " +
					yang.app.black.black.getBuildDate());
		
		showThis();
	}
	public void showThis()
	{
		windowLocation.dialogLocation(black, shell);
	}
	public void closeThis()
	{
		shell.dispose();
	}
}
