package yang.app.black;

import java.io.Serializable;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.jface.text.TextViewerUndoManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.events.ShellListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Slider;
import org.eclipse.wb.swt.SWTResourceManager;

import yang.app.mud.mud;
import yang.demo.swt.windowLocation;

public class writingView extends mud implements Serializable{
	static final long serialVersionUID = 42L;
	String painttext;
	black b;
	int x;
	Slider slider;
	/**
	 * Create the shell.
	 * @param display
	 */
	public writingView(final black b) {
		super(SWT.SHELL_TRIM,"writingView");
		
		b.setVisible(false);
		addMouseMoveListener(new MouseMoveListener() {
			
			@Override
			public void mouseMove(MouseEvent e) {
				// TODO Auto-generated method stub
				if(slider != null && !slider.isDisposed()){
					if(e.x >= getClientArea().width-slider.getSize().x-30){
						slider.setVisible(true);
					}else slider.setVisible(false);
					
				}
			}
		});
		
		setImage(b.getImage());
		setBackground(SWTResourceManager.getColor(106,106,106));
		setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		this.b = b;
		setStyledTextWidth(Integer.valueOf(b.appProperties.getProperty("WritingView_TextX", String.valueOf(windowLocation.returnScreenWidth()-
				windowLocation.returnScreenWidth()/4))));
		createContents();
		//setMaximized(true);
		if(b.tv != null){
			b.tv.getTextWidget().setParent(this);
			b.tv.getTextWidget().setMargins(130, 10, 110, 0);
			b.blackTextArea.writingView();
			setStyledTextLayout(x);
		}
		
		if(b.fileIsSave == 0) painttext = "+";
		addPaintListener(new PaintListener() {
			
			@Override
			public void paintControl(PaintEvent arg0) {
				// TODO Auto-generated method stub
				arg0.gc.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
				if(painttext != null) arg0.gc.drawText(painttext, 10, 10);
			}
		});
		addSlider();
		open();
		layout();
	}
	public void addSlider(){
		slider = new Slider(this,SWT.V_SCROLL);
		slider.setVisible(false);
		slider.setBackground(SWTResourceManager.getColor(106,106,106));
		FormData fd_slider = new FormData();
		fd_slider.top = new FormAttachment(0);
		fd_slider.bottom = new FormAttachment(100);
		fd_slider.right = new FormAttachment(100);
		slider.setLayoutData(fd_slider);
		layout();
		b.ba.setSlider(slider);
		slider.addListener(SWT.Selection, new Listener() {
			
			@Override
			public void handleEvent(Event arg0) {
				// TODO Auto-generated method stub
				b.text.setTopPixel(slider.getSelection());
			}
		});
	}
	public void disposeTextArea(){
		if(b.tv.getTextWidget() != null && !b.tv.getTextWidget().isDisposed()){
			b.closeCurrentFile(true);			
		}
	}
	public void setStyledTextWidth(int width){
		x = (windowLocation.returnScreenWidth()-width)/2;
		if(b.text != null && !b.text.isDisposed())
			setStyledTextLayout(x);
	}
	public void setStyledTextLayout(int x){
		FormData fd_styledText = new FormData();
		fd_styledText.bottom = new FormAttachment(100);
		fd_styledText.right = new FormAttachment(100, 0-x);
		fd_styledText.top = new FormAttachment(0);
		fd_styledText.left = new FormAttachment(0, x);
		b.text.setLayoutData(fd_styledText);
		layout();
	}
	public void createTextArea(IDocument iDocument){
		if(b.text != null && !b.text.isDisposed()){
			b.text.dispose();
		}
		b.tv = new TextViewer(b, SWT.V_SCROLL|SWT.WRAP);
		b.text = b.tv.getTextWidget();
		b.text.setParent(this);
		setStyledTextLayout(x);
		layout();
		b.blackTextArea = new blackTextArea(b.text,b);
		b.blackTextArea.writingView();
		b.tv.setUndoManager(new TextViewerUndoManager(50));
		b.tv.activatePlugins();
		if(iDocument != null) {
			b.tv.setDocument(iDocument);
		}
		addSlider();
		b.text.setFocus();
	}
	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("\u5199\u4F5C\u89C6\u56FE");
		setLayout(new FormLayout());
	}
	public void exit(){
		if(!isDisposed()){
			if(b.ba.numberlist != null){
				b.ba.insertList(false, null, b.text);
			}
			if(b.text != null && !b.text.isDisposed()){
				b.text.setMargins(30, 10, 10, 0);
				b.text.getVerticalBar().setVisible(true);
				b.text.setParent(b);
				super.dispose();
				b.resetLayoutData();
				b.blackTextArea.st.getMenu().dispose();
				b.blackTextArea.addMenu(b.blackTextArea.st);
				b.blackTextArea.eyeColor();
				b.text.setFocus();
				b.open();
				b.setActive();
				b.setAppProperties("isWritingView", "false");
			}
		}
	}
	public void resetView(){
		b.resetStyledTextTopPixelAndCaretOffset(b.getCurrentEditFile().getName(), b.text);
		b.text.redraw();
//		ScrollBar vb = b.text.getVerticalBar();
//		slider.setValues(vb.getSelection(), vb.getMinimum(), vb.getMaximum(), vb.getThumb(), vb.getIncrement(), vb.getPageIncrement());
	}
	public void dispose(){
		b.setAppProperties("isWritingView", "true");
//		b.text.setParent(b);
//		b.resetLayoutData();
//		b.open();
		super.saveAppData();
	//	throw new NullPointerException();
		b.dispose();
	
		//System.exit(0);
	}
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
