package yang.app.black.tests;

public class testas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c = '\n';
		System.out.println((int)c);
	}

}
