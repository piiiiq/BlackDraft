package yang.demo.allPurpose;

import java.io.File;
import java.io.Serializable;

public class isYourNeedFile
  implements Serializable
{
  static final long serialVersionUID = 42L;
  private String Filter_rule = ".*.jar";
  private File youNeedFile;
  
  /**
   * 获取指定目录中的指定类型的文件
   * @param dirFile
   * @param filter_rule 需要返回的文件类型，例如".*.jar"（不含双引号）可返回jar文件
   */
  public isYourNeedFile(File dirFile, String filter_rule)
  {
    this.youNeedFile = dirFile;
    this.Filter_rule = filter_rule;
  }
  
  public File getYouNeedFiles()
  {
    return this.youNeedFile;
  }
  
  public String[] Filter()
  {
    String[] s = this.youNeedFile.list(new MyFileFilter(this.Filter_rule));
    return s;
  }
}
