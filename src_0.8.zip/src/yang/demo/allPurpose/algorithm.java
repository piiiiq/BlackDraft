package yang.demo.allPurpose;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.IOException;
/**
 * 此类写了一些通用算法
 */
import java.util.ArrayList;
import java.util.Iterator;

import yang.app.qt.black.cheakDocument;
import yang.app.qt.black.io;

public class algorithm {

	/**
	 * 对set数组中的setIndex对象进行排序
	 * setIndex数组中装有setIndex对象，对象v值大的，排在返回的数组的上面
	 * @param set
	 * @return返回的数组只包含排序后的setIndex对象的s值，也就是其包含的字符串
	 */
	public static ArrayList<String> setIndex(ArrayList<setIndex> set) {
		ArrayList<String> s = new ArrayList<>();
		ArrayList<setIndex> sett = set;

		while(sett.size() != 0) {
			int i=0;
			int index = 0;
			String text = null;
			for(int a=0;a<sett.size();a++) {
				setIndex setIndex = sett.get(a);
				if(setIndex.v > i) {
					i=setIndex.v;
					text = setIndex.s;
					index = a;
				}
			}
			s.add(text);
			sett.remove(index);
		}
		return s;
		
	}
	/**
	 * 为文本文件去重的算法，这个算法用来给英文词汇去重用的，会对英文词汇及其中文释义进行拆分，然后对比，没有通用性，不可能直接使用
	 * @param inpath
	 * @param outpath
	 */
	public static void quChong(String inpath,String outpath) {
		File file = new File(inpath);
		String txt = io.readTextFile(file, "utf-8");
		ArrayList<String> allLine = cheakDocument.getAllLine(txt);
		ArrayList<String> al = new ArrayList<>();
		StringBuffer sb = new StringBuffer();
		for(String line:allLine) {
			String[] subString = cheakDocument.subString(line, ",");
			boolean ishas = false;
			for(String s:al) {
				if(subString[0].equals(s)) {
					ishas = true;
					break;
				}
			}
			
			if(!ishas) {
				sb.append(line+"\n");
				al.add(subString[0]);
			}
			
		}
		io.writeTextFile(new File(outpath), sb.toString(), "utf-8");
	}
	/**
	 * 从txt文件中获取指定行数的内容，每按下回车键，就从文件剩余行数中输出指定行数的内容，这个方法没有完成，使用时需要将方法内的代码拿出来使用
	 * @param filepath
	 * @param textcode
	 * @param startLineNumber 开始为第0行
	 * @return
	 */
	public static String getContextFromText(String filepath,String textcode,int startLineNumber) {
		File f = new File(filepath);
		String text = io.readTextFile(f, textcode);
		ArrayList<String> allLine = cheakDocument.getAllLine(text);
		int i = 0;
		int start = 0;
		
		StringBuffer sb = new StringBuffer();
		//a是从文本文件的第几行开始输出
		for(int a=startLineNumber;a<allLine.size();a++) {
			//i的值决定了每次输出多少行
			if(i == 600 || a == allLine.size()-1) {
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				//有时需要等待极短的时间才能获取到剪切板对象
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// 封装字符串
				StringSelection selection = new StringSelection(sb.toString());
				// 设置剪贴板内容
				clipboard.setContents(selection, null);
				if( a != allLine.size()-1) {
					System.out.println("已将600行文本复制到粘贴板，"+ start+"-"+a+"从单词"+allLine.get(start)+"到单词"+allLine.get(a-1));
					System.out.println("请按下回车键继续复制下一个600行文本...");
				}else {
					System.out.println("已经复制到末尾，程序结束！"+ start+"-"+a+"从单词"+allLine.get(start)+"到单词"+allLine.get(a));
					break;
				}
				
				try {
					while(true) {
						int read = System.in.read();
						if(read == '\n') {
//							System.out.println("read: "+ read);
							break;
						}
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				sb = new StringBuffer();
				i=0;
				
			}
			if(i == 0) {
				sb.append("将下列英文词汇翻译成中文，要求翻译结果尽可能简短，在5字以内，结果以英文词汇->中文形式输出，翻译后的中文不要包含标点符号等无用的字符，翻译结果必须提供简短的中文含义，而不是引用其他词汇的翻译，例如crest-> crest（可译为“波峰”或保留原词，此处简化为“波峰”）这种，应该输出crest->波峰\r\n" + 
						"需要翻译的词汇如下：\r\n" + 
						"\r\n" + 
						"");
				start = a;
			}
			String str = allLine.get(a);
			sb.append(str+"\n");
			
			i++;
			
		}
		return null;
	}
	/**
	 * 返回a中有多少字符被b包含
	 * @param a
	 * @param b
	 * @return
	 */
	public static int valueBySame(String a,String b) {
		int same = 0;
		for(int i=0;i<a.length();i++) {
			char charAt = a.charAt(i);
			if(b.indexOf(charAt)!=-1) {
				same++;
			}
		}
		return same;
	}
	
}
