package yang.demo.allPurpose;
public class HtmlMerger {

    public static String mergeHtmlDocuments(String docTitle,String[] htmlContents) {
        if (htmlContents == null || htmlContents.length == 0) {
            return "";
        }

        StringBuilder mergedHtml = new StringBuilder();

        // 添加HTML 4文档类型和基本结构
        mergedHtml.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n");
        mergedHtml.append("<html>\n<head>\n");
        mergedHtml.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
        mergedHtml.append("<title>"+docTitle+"</title>\n");
        mergedHtml.append("</head>\n<body>\n");

        // 合并所有HTML内容的主体部分
        for (String html : htmlContents) {
            if (html != null) {
                // 提取body内容，如果存在的话
                String bodyContent = extractBodyContent(html);
                mergedHtml.append(bodyContent);
            }
        }

        mergedHtml.append("</body>\n</html>");

        return mergedHtml.toString();
    }

    private static String extractBodyContent(String html) {
        // 简单处理：查找<body>和</body>标签之间的内容
        int bodyStart = html.toLowerCase().indexOf("<body");
        if (bodyStart == -1) {
            // 如果没有找到<body>标签，直接返回整个内容
            return html;
        }

        // 找到<body>标签的结束位置
        bodyStart = html.indexOf('>', bodyStart) + 1;
        int bodyEnd = html.toLowerCase().indexOf("</body>", bodyStart);
        if (bodyEnd == -1) {
            bodyEnd = html.length();
        }

        return html.substring(bodyStart, bodyEnd).trim();
    }

    // 示例用法
    public static void main(String[] args) {
        String[] htmls = {
            "<html><body><h1>First Document</h1><p>Content from first document.</p></body></html>",
            "<html><body><h2>Second Document</h2><div>Content from second document.</div></body></html>",
            "<h3>Third Part</h3><p>Standalone content without full HTML structure.</p>"
        };

        String merged = mergeHtmlDocuments("test",htmls);
        System.out.println(merged);
    }
}