package yang.demo.allPurpose;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import io.qt.widgets.QMessageBox;
import yang.app.qt.black.black;
import yang.app.qt.black.httpsDownloader;
import yang.app.qt.black.httpsDownloader.TrustAnyHostnameVerifier;

public class yangIO implements Serializable {
	static final long serialVersionUID = 42L;
	FileReader fr;
	FileWriter fw;
	BufferedReader br;
	BufferedWriter bw;

	public String readLineFromFile(File file) {
		try {
			if (this.fr == null) {
				this.fr = new FileReader(file);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		if (this.br == null) {
			this.br = new BufferedReader(this.fr);
		}
		try {
			String str;
			if ((str = this.br.readLine()) != null) {
				return str;
			}
			this.br.close();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int writeStringToFile(File file, String str) {
		try {
			if (this.fw == null) {
				this.fw = new FileWriter(file);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (this.bw == null) {
			this.bw = new BufferedWriter(this.fw);
		}
		try {
			this.bw.write(str);
			this.bw.close();
			return 1;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}
	/**
	 * 该方法用来从https连接下载数据，比getFileFromURL(String u)方法下载的速度更快
	 * @param u
	 * @param b 如果传入black对象，则会调用black的日志输出功能输出网络错误信息，该参数可以为null
	 * @return
	 */
	public static byte[] getDataFormHttpsURL(String u,black b) {
		byte[] bytes = null;
		try {
			URL url = new URL(u);
			// 创建SSLContext
			SSLContext sslContext = SSLContext.getInstance("SSL");
			TrustManager[] tm = { new httpsDownloader() };
			// 初始化
			sslContext.init(null, tm, new java.security.SecureRandom());
			// 获取SSLSocketFactory对象
			SSLSocketFactory ssf = sslContext.getSocketFactory();
	
			// 打开连接
			HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
			/**
			 * 这一步的原因: 当访问HTTPS的网址。您可能已经安装了服务器证书到您的JRE的keystore
			 * 但是服务器的名称与证书实际域名不相等。这通常发生在你使用的是非标准网上签发的证书。
			 *
			 * 解决方法：让JRE相信所有的证书和对系统的域名和证书域名。
			 *
			 * 如果少了这一步会报错:java.io.IOException: HTTPS hostname wrong: should be <localhost>
			 */
			conn.setHostnameVerifier(new httpsDownloader().new TrustAnyHostnameVerifier());
			// 设置一些参数
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(true);
			// 设置当前实例使用的SSLSoctetFactory
			conn.setSSLSocketFactory(ssf);
			conn.connect();
	
			// 得到输入流
			InputStream inputStream = conn.getInputStream();
				bytes = inputStream.readAllBytes();
		}catch (Exception e) {
			if(b != null) {
				b.p("从https链接获取数据时出现："+e.getClass().getName()+"错误");
//				if(e.getClass().getName().equals("java.net.MalformedURLException")) {
//					QMessageBox mb = b.getMessageBox(b, "图片地址错误", "请输入正确的图片地址！");
//					mb.exec();
//				}
			}else e.printStackTrace();
			
		}
		return bytes; 
	}
	/**
	 * 获取给定的url指向的数据到byte数组
	 * 此方法配合此类的其他的方法，可下载远程数据到文件或内存
	 * @param u
	 * @return
	 */
	public static byte[] getDataFromURL(String u) {
		byte[] bytes = null;
		try {
			URL url = new URL(u);
			URLConnection oc = url.openConnection();
			oc.setConnectTimeout(15000);
			oc.setReadTimeout(15000);
			DataInputStream dataInputStream = new DataInputStream(oc.getInputStream());
			bytes = dataInputStream.readAllBytes();
			dataInputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if(e.getClass().getName().equals("java.net.SocketTimeoutException")) {
					black.p("连接url("+u+")超时");
			}else if(e.getClass().getName().equals("java.net.UnknownHostException")) {
				black.p("网络连接出错：未知主机错误");
			}else if(e.getClass().getName().equals("javax.net.ssl.SSLException")){
				black.p("网络连接出错：连接被重置");
			}else{
				e.printStackTrace();

			}
		}
			
		
		
		return bytes;
	}
	/**
	 * 将给定的字节数组内的数据保存到文件中
	 * @param b
	 * @param file
	 * @return 写入是否成功
	 */
	public static boolean writeFileFromBytes(byte[] b,String file) {
		File f = new File(file);
		boolean isOk = true;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(f);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			isOk = false;
			e1.printStackTrace();
		}
		DataOutputStream dos = new DataOutputStream(fos);
		try {
			dos.write(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		try {
			dos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		try {
			dos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		return isOk;
	}
}
