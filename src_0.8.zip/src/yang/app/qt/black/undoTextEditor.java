package yang.app.qt.black;

import io.qt.core.Qt;
import io.qt.gui.QDragMoveEvent;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QUndoStack;

public class undoTextEditor extends QTextEdit {
	private QUndoStack us;
	public undoTextEditor() {
		us = new QUndoStack(this.document());
	}
	@Override
	protected void keyPressEvent(QKeyEvent e) {
		// TODO Auto-generated method stub

		if(e.key() == Qt.Key.Key_Return.value()) {
			this.textCursor().insertText("\n");
		}else if(e.key() == Qt.Key.Key_Backspace.value()) {
			QTextCursor tc = this.textCursor();
			tc.setPosition(tc.position()-1,MoveMode.KeepAnchor);
			tc.deleteChar();
			this.setTextCursor(tc);
		}else {
			QTextCursor tc = this.textCursor();
			tc.insertText(e.text());
			this.setTextCursor(tc);
		}
		this.ensureCursorVisible();
		
		
	}
	@Override
	protected void dragMoveEvent(QDragMoveEvent e) {
		// TODO Auto-generated method stub
		super.dragMoveEvent(e);
//		System.out.println("drag");
		
	}
	
}
