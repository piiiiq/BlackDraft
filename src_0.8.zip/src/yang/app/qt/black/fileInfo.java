package yang.app.qt.black;

import io.qt.gui.QTextBlock;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextDocument;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

class fileInfo implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;
	public String showName;
	public String fileName;
	public String charCountOfLastInput;
	public int isRoot = -1;
	public int cursorPos;
	public int scrollbarValue;
	public int selectionStart = -1;
	public int charCount;
	public long editTime;
	public long editTime_today;
	long lastTextChangeTime = System.currentTimeMillis();
	public boolean isFile;
	public boolean isDir;
	public boolean expaned;
	public boolean isFiles;
	public boolean isKeyWordsList;
	public boolean isNotes;
	public boolean setTitleStyle = false;
	public boolean showMark = false;
	public ArrayList<fileInfo> subfiles;
	public ArrayList<editPoint> editPoints;
	public int autoscrollvalue = 0;
	public int editPointIndex;
	
	public fileInfo(String showName, String fileName) {
		this.showName = showName;
		this.fileName = fileName;
	}

	public ArrayList<fileInfo> initFloder() {
		this.subfiles = new ArrayList();
		return this.subfiles;
	}
	void resetPosChanged(int caretPos,editPoint point) {
		int pos = -1;
		//需要根据oldpos和当前光标的pos的大小来确定需要更新哪个pos之后的编辑点偏移量
		//更新较大数值的pos之后的编辑点的偏移量
		//point.oldPos与caretPos之间的区间就是编辑点文本改变前后的范围
		if(point.oldPos >= caretPos) pos = point.oldPos;
		else pos = caretPos;
		//遍历数组，对pos之后的编辑点进行偏移修正
		Iterator<editPoint> it = editPoints.iterator();
		while(it.hasNext()) {
			editPoint next = it.next();
			int p = next.getPos();
			int p_old = next.oldPos;
			if(!next.equals(point)) {
				if(p > pos) {
					next.setPos(p+black.text.contentsChangePos[3]);
				}else {
					System.out.println("point.oldPos:"+point.oldPos+" caretPos:"+caretPos+" p:"+p+" p_old:"+p_old);
					//光标位置减小
					if(point.oldPos > caretPos) {
						if((p >= caretPos && p <= point.oldPos) || (p_old >= caretPos && p_old <= point.oldPos)) {
							it.remove();
							black.debugPrint("A删除编辑点");
						}
					//光标位置增加
					}else if(point.oldPos < caretPos) {
						if((p >= point.oldPos && p <= caretPos) || (p_old >= point.oldPos && p_old <= caretPos)) {
							it.remove();
							black.debugPrint("B删除编辑点");
						}
					//光标位置没有变化。可能不会出现这种情况
					}else if(point.oldPos == caretPos) {
						if(p == point.oldPos || p_old == point.oldPos) {
							it.remove();
//							black.getMessageBox(null,"", "C删除编辑点");
//							black.debugPrint("确实出现了C删除编辑点，所以这个判断应该保留");
						}
					}
				}		
			}
		}
	}
	public void addEditPoint(int pos,int oldpos) {
		if ((this.isFile) || (this.isFiles)) {
			if (this.editPoints == null) {
				this.editPoints = new ArrayList();
			}
			if (this.editPoints.size() > appInfo.maxEditPointCount) {
				this.editPoints.remove(0);
				black.debugPrint("当前编辑点数量"+editPoints.size()+",超出编辑点记录上限数量("+appInfo.maxEditPointCount+")，所以删除一个编辑点");
			}
			
			//此处pos和oldpos一致，所以无需判断
			editPoint editPoint = new editPoint(pos);
			editPoint.oldPos = oldpos;
			resetPosChanged(pos,editPoint);
			this.editPoints.add(editPoint);
			this.editPointIndex = -1;
		}
	}

	public void updateLastEditPoint(int pos) {
		if ((this.editPoints != null) && (this.editPoints.size() > 0)) {
			editPoint editPointInfo = (editPoint) this.editPoints.get(this.editPoints.size() - 1);
			editPointInfo.setPos(pos);
			this.editPointIndex = -1;
		}
	}

	public editPoint getLastEditPoint() {
		if ((this.editPoints != null) && (this.editPoints.size() > 0)) {
			return (editPoint) this.editPoints.get(this.editPoints.size() - 1);
		}
		return null;
	}

	public editPoint getPreviousEditPoint() {
		if ((this.editPoints != null) && (this.editPoints.size() > 0)) {
			if (this.editPointIndex == -1) {
				editPoint lastWalkInfo = getLastEditPoint();
				QTextCursor tc = black.text.textCursor();
				if (lastWalkInfo.getPos() == tc.position()) {
					this.editPointIndex = (this.editPoints.size() - 2);
				} else {
					this.editPointIndex = (this.editPoints.size() - 1);
				}
			} else if (this.editPointIndex > 0) {
				this.editPointIndex -= 1;
			} else {
				editPointIndex = 0;
			}
			if (this.editPointIndex >= 0) {
				return (editPoint) this.editPoints.get(this.editPointIndex);
			}
		}
		return null;
	}

	public editPoint getNextEditPoint() {
		if ((this.editPoints != null) && (this.editPoints.size() > 0)) {
			if (this.editPointIndex == -1) {
				return null;
			}
			if (this.editPointIndex < this.editPoints.size() - 1) {
				this.editPointIndex += 1;
			} else {
				editPointIndex = editPoints.size()-1;
			}
			if (this.editPointIndex < this.editPoints.size()) {
				return (editPoint) this.editPoints.get(this.editPointIndex);
			}
		}
		return null;
	}
	public editPoint getCurrentEditPoint() {
		if(editPointIndex >= 0 && editPointIndex < editPoints.size())
			return editPoints.get(editPointIndex);
		else return null;
	}
	public void removeCurrentEditPoint() {
		if ((this.editPointIndex >= 0) && (this.editPointIndex < this.editPoints.size())) {
			this.editPoints.remove(this.editPointIndex);
			if (this.editPointIndex == this.editPoints.size()) {
				this.editPointIndex = -1;
			}
		}
	}
	public String getShowName() {
		if(showName == null) return "";
		
		if(black.des_doc != null) {
			return bAction.getStringWithDncrypt(black.des_doc, showName);
		}
		return showName;
	}
	public void setShowName(String showname) {
		if(black.des_doc != null) {
			showname = bAction.getStringWithEncrypt(black.des_doc, showname);
		}
		this.showName = showname;
	}
	public fileInfo clone() {
		fileInfo clone = null;
		try {
			clone = (fileInfo) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}

	public String toString() {
		String str = "------------------\n显示名称：" + this.showName + "\n" + "文件名称：" + this.fileName + "\n" + "是根目录："
				+ this.isRoot + "\n" + "是文件：" + this.isFile + "\n" + "是目录：" + this.isDir + "\n" + "是文件集：" + this.isFiles
				+ "\n" + "是关键词列表：" + this.isKeyWordsList + "\n" + "是笔记：" + this.isNotes + "\n" + "------------------";
		return str;
	}
}
