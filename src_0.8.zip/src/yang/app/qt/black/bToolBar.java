package yang.app.qt.black;

import java.util.ArrayList;

import io.qt.core.QEvent;
import io.qt.core.QPointF;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.core.Qt;
import io.qt.core.Qt.ToolButtonStyle;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QGradient;
import io.qt.gui.QLinearGradient;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPen;
import io.qt.widgets.QAction;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QComboBox;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QLayout.SizeConstraint;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QToolBar;
import io.qt.widgets.QToolButton;
import io.qt.widgets.QWidget;
public class bToolBar extends QToolBar{
	ArrayList<QWidget> widgets = new ArrayList<QWidget>();
	int width,height,lineSpace = 0,itemSpace = 5;
	QSize separatorItemSize = new QSize(10, 20);
	boolean noBackground;
	boolean setKeyMode;
	bToolBar(QWidget parent){
		super(parent);
		setIconSize(new QSize(16,16));
//		setToolButtonStyle(ToolButtonStyle.ToolButtonTextUnderIcon);
	}
	protected void paintEvent(QPaintEvent e) {
		super.paintEvent(e);
		if(!noBackground) {
			QPainter painter = new QPainter(this);
			painter.setRenderHint(QPainter.RenderHint.Antialiasing, true);
			QLinearGradient linearGradient = new QLinearGradient(new QPointF(0.0D, 0.0D), new QPointF(0.0D, height()));
			QColor a = new QColor(247, 249, 250);
			QColor b = new QColor(232, 236, 240);

			linearGradient.setColorAt(0.0D, new QColor(Qt.GlobalColor.white));
			linearGradient.setColorAt(0.4D, a);
			linearGradient.setColorAt(1.0D, b);

			painter.setPen(new QPen(new QBrush(linearGradient), 1.0D));
			linearGradient.setSpread(QGradient.Spread.PadSpread);
			painter.setBrush(linearGradient);
			painter.drawRect(rect());
			painter.setPen(new QPen(new QBrush(black.borderColor), 2.0D));
			painter.drawLine(0, height(), width(), height());

			painter.end();
		}
		
	}
	/**
	 * 如果setKeyMode是true，添加的item会被设置一个数字objectname（如果该item原本的objectname是空字符串的话）
	 * @param w
	 */
	public void addItem(QWidget w) {
		widgets.add(w);
		if(black.b != null && setKeyMode && !w.objectName().equals("bToolBarSeparatorItem")) {
			if(!w.objectName().isEmpty()) {
				if(QComboBox.class.isInstance(w)) {
//					QComboBox cast = QComboBox.class.cast(w);				
				}else if(QToolButton.class.isInstance(w)) {
					QToolButton cast = QToolButton.class.cast(w);
					black.b.ba.addShortcut(Integer.valueOf(cast.objectName()), "", cast.toolTip(), new Runnable() {
						public void run() {
							cast.clicked.emit();
						}
					});
				}
			}
			
		}
//		try {
//			QToolButton bu = (QToolButton) w;
//			bu.setIconSize(new QSize(10,10));
////			bu.setText(bu.toolTip());
//		}catch(Exception e) {}
		if(isVisible())
			listWidgets();
	}
	public void setSeparatorItemSize(int w,int h) {
		separatorItemSize.setWidth(w);
		separatorItemSize.setHeight(h);
		
	}
	public void addSeparatorItem() {
		QToolButton sp = new QToolButton();
		sp.setObjectName("bToolBarSeparatorItem");
		sp.setText("|");
		sp.setEnabled(false);
		addItem(sp);
	}
	
	public void listWidgets() {
		for(QWidget w:widgets) {
			w.hide();
		}
		int x = 0, y = 0;
		QRect cr = this.contentsRect();
		int length = 0,start = 0;
		int maxHeight = 0;
		int x_ = x;
		boolean list = false;
		for(int a=0;a<widgets.size();a++) {
			QWidget w = widgets.get(a);
			if(w.objectName().equals("bToolBarSeparatorItem")) {
				QFont font = w.font();
				font.setPointSize(5);
				w.setFont(font);
				w.setFixedSize(separatorItemSize);
			}else {
				w.adjustSize();
			}
			x_+=(itemSpace+w.width());
//			System.out.println("c: "+ x_+" "+length+" "+cr.width()+" "+start);
			if(x_ <= cr.width()) {
				if(maxHeight < w.height()) maxHeight = w.height();
//				if(length < widgets.size())
				length++;
//				System.out.println("e: "+ maxHeight +" "+length+" "+cr.width());

				if(length == widgets.size()) list = true;
			}else {
				list = true;
			}
//			System.out.println("d: "+ list);
			if(list) {
				//如果某个控件自身宽度已经超过工具栏的宽度，则不再绘制其及其之后的所有控件
				if(length == start) {
					if(length > 0)
						setFixedHeight(y-lineSpace);
					else setFixedHeight(y);
					return;
				}
				int xx = x;
//				System.out.println(start+" "+length +" "+widgets.size());
				for(int i=start;i<length;i++) {
					QWidget wid = widgets.get(i);
					
					wid.setParent(this);

					int yy = y;
					if(wid.height() < maxHeight) {
						yy = y+(maxHeight-wid.height())/2;
					}
//					System.out.println("a "+ xx+" "+ yy);
					wid.setGeometry(xx, yy, wid.width(), wid.height());
					wid.show();
					xx+=(itemSpace+wid.width());
					list = false;
				}
				y+=(maxHeight+lineSpace);
				start = length;
				x_ = x;
				maxHeight = 0;
				if(length != widgets.size())
					if(a > 0) a-=1;
//				break;
			}

		}
		setFixedHeight(y);
		
	}
	
	@Override
	public boolean event(QEvent event) {
		// TODO Auto-generated method stub
		if(event.type() == QEvent.Type.Resize) {
			listWidgets();
		}else if(event.type() == QEvent.Type.ShowToParent) {
			listWidgets();
		}else if(event.type() == QEvent.Type.Show) {
			listWidgets();
		}
		return super.event(event);
	}
	
	
}
