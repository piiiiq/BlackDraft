package yang.app.qt.black;

import io.qt.core.QRect;
import io.qt.core.Qt;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;

public class addKeys {
	public static keyLink styleKey(int index,keyboard kb,String modifierkey,int keycode,int styleindex) {
		styleInfo si = kb.b.setTextStyles.styles.get(styleindex);
		key key = new key(modifierkey,keycode,si.getStyleName(),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.setTextStyles.setStyle(si);
				return true;
			}
			
		};
		key.keyActionIndex = styleindex;
		key.keytype = 5;
		kb.addKey(index, key);
		return key;
	}
	/**
	 * 
	 * @param index 
	 * @param kb
	 * @param modifierkey
	 * @param keycode
	 * @param edit
	 * @return
	 */
	public static keyLink customInputText(int index,keyboard kb,String modifierkey,int keycode,String text) {
		key key = new key(modifierkey,keycode,text,0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.bInsertText(kb.b.text, text, -1, false);
				return true;
			}
			
		};
		key.keytype = 1;
		kb.addKey(index, key);
		return key;
	}
	public static void addKeys(keyboard kb) {
		key key0 = new key("",Qt.Key.Key_Tab.value(),languageTool.getString(1307),0,0,false) {
			
			@Override
			boolean action() {
				// TODO Auto-generated method stub
				if (!kb.b.infoOfCurrentEditing.isKeyWordsList) {
					kb.b.btext.scroll();
					black.findview = 0;
					kb.b.showKeyWords();
				}
				return true;
			}
		};
		kb.addKey(0,key0);
		
		//添加链接实例
//		kb.addKey(10, new keyLink("alt", Qt.Key.Key_V.value(), 0, 0, key0,false));
		
		kb.addKey(1,new key("",Qt.Key.Key_Tab.value(),languageTool.getString(1308),0,0,true) {
			
			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.btext.scroll();
				black.findview = 1;
				kb.b.showFindInfo(black.text, kb.b.TreeWidgetItemOfCurrentEditing.parent(), true);
				return true;
			}
		});
		kb.addKey(2, new key("ctrl",Qt.Key.Key_Tab.value(),languageTool.getString(1309),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.changedForOpenedFiles();
				return true;
				
			}
			
		});
		kb.addKey(3, new key("ctrl",Qt.Key.Key_Tab.value(),languageTool.getString(1310),0,0,true) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				if(kb.b.TreeWidgetItemOfCurrentEditing.parent() != null) {
					kb.b.btext.scroll();
					black.findview = 1;
					kb.b.showFindInfo(black.text, kb.b.TreeWidgetItemOfCurrentEditing.parent(), false);
				}
				return true;

			}
			
		});
		kb.addKey(4, new key("",Qt.Key.Key_Return.value(),languageTool.getString(1311),0,0,true) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.ba.addOrRemoveKeywords();
				return true;
			}
			
		});
		kb.addKey(5, new key("alt",Qt.Key.Key_Return.value(),languageTool.getString(1312),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				black.findview = 2;
				kb.b.showTitleList();
				return true;
			}
			
		});
		kb.addKey(6, new key("ctrl",Qt.Key.Key_Return.value(),languageTool.getString(1313),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.showMoveList();
				return true;
			}
			
		});
		kb.addKey(7, new key("ctrl+shift",Qt.Key.Key_Return.value(),languageTool.getString(1314),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.checkIsHasDiffKeyWordsList();
				return true;
			}
			
		});
		kb.addKey(8, new key("",Qt.Key.Key_Home.value(),languageTool.getString(1315),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				QTextCursor tc = kb.b.text.textCursor();
				QRect r = kb.b.text.cursorRect();
				QRect r_ = kb.b.text.viewport().rect();
				if ((r.y() + r.height() < 0) || (r.y() > r_.height())) {
					kb.b.btext.scroll();
				} else if (tc.atBlockStart()) {
//					scroll();
					kb.b.text.moveCursor(QTextCursor.MoveOperation.Start);
				} else {
					kb.b.text.moveCursor(QTextCursor.MoveOperation.StartOfBlock);
					kb.b.btext.scroll();
				}
				return true;
			}
			
		});
		kb.addKey(9, new key("",Qt.Key.Key_End.value(),languageTool.getString(1316),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				QTextCursor tc = kb.b.text.textCursor();
				if (tc.atBlockEnd()) {
					kb.b.text.moveCursor(QTextCursor.MoveOperation.End);
//					scroll();
				} else if (tc.atEnd()) {
					kb.b.text.verticalScrollBar().setValue(kb.b.text.verticalScrollBar().maximum());
				} else {
					kb.b.text.moveCursor(QTextCursor.MoveOperation.EndOfBlock);
					kb.b.btext.scroll();
				}
				return true;
			}
			
		});

		kb.addKey(13, new key("ctrl",Qt.Key.Key_Left.value(),languageTool.getString(1317),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.moveToPreviousTitle(true);
				return true;
			}
			
		});
		kb.addKey(14, new key("ctrl",Qt.Key.Key_Right.value(),languageTool.getString(1318),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.moveToNextTitle(true);
				return true;
			}
			
		});
		kb.addKey(15, new key("alt",Qt.Key.Key_Up.value(),languageTool.getString(1319),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.moveToPreviousOpenedFile();
				return true;
			}
			
		});
		kb.addKey(16, new key("alt",Qt.Key.Key_Down.value(),languageTool.getString(1320),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.moveToNextOpenedFile();
				return true;
			}
			
		});
		kb.addKey(17, new key("ctrl",Qt.Key.Key_C.value(),languageTool.getString(1321),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.copyText();
				return true;
			}
			
		});
		kb.addKey(18, new key("ctrl",Qt.Key.Key_X.value(),languageTool.getString(1322),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.cutText();
				return true;
			}
			
		});
		kb.addKey(19, new key("ctrl+alt",Qt.Key.Key_V.value(),languageTool.getString(1323),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.pasteWithCurrentFormat();
				return true;
			}
			
		});
		kb.addKey(20, new key("ctrl",Qt.Key.Key_A.value(),languageTool.getString(1324),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.ba.selectAll();
				return true;
			}
			
		});
		kb.addKey(21, new key("",Qt.Key.Key_Escape.value(),languageTool.getString(1325),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				if(black.b.isHasActiveDialogOnChildren())return false;
				//因为关键词对话框不获取焦点，所以上面的检测焦点的方法无法判断关键词对话框是否正在显示，所以需要针对关键词对话框进行特殊处理
				else if(black.b.keywords != null && black.b.keywords.isVisible()) return false;
				else if(black.writingView > 0) {
					kb.b.exitWritingView();
					return true;
				}else return false;
			}
			
		});
		kb.addKey(22, new key("shift",Qt.Key.Key_Escape.value(),languageTool.getString(1326),1,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.exit();
				return true;
			}
			
		});
		kb.addKey(23, new key("ctrl",Qt.Key.Key_Z.value(),languageTool.getString(1327),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
					kb.b.text.undo();
					return true;
			}
			
		});
		kb.addKey(24, new key("ctrl",Qt.Key.Key_Y.value(),languageTool.getString(1328),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
					kb.b.text.redo();
					return true;
			}
			
		});
		kb.addKey(25, new key("",Qt.Key.Key_Up.value(),languageTool.getString(1329),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				Object navigation = kb.b.ba.tempData.get(languageTool.getString(1330));
				if(navigation == null && kb.b.infoOfCurrentEditing != null && kb.b.infoOfCurrentEditing.autoscrollvalue == 0)
				return kb.b.ba.fastFindUp();
				else {
					kb.b.btext.scrollWithAnimation(kb.b.text.verticalScrollBar().value()-(kb.b.text.cursorRect().height()+kb.b.getEditorLineSpaceValue()));
					return true;
				}
			}
			
		});
		kb.addKey(26, new key("",Qt.Key.Key_Down.value(),languageTool.getString(1331),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				if(black.text == null || black.text.isDisposed()) return false;
				Object navigation = kb.b.ba.tempData.get(languageTool.getString(1332));
				if(navigation == null && kb.b.infoOfCurrentEditing.autoscrollvalue == 0)
				return kb.b.ba.fastFindDown();
				else {
					kb.b.btext.scrollWithAnimation(kb.b.text.verticalScrollBar().value()+(kb.b.text.cursorRect().height()+kb.b.getEditorLineSpaceValue()));
					return true;
				}
			}
			
		});
		kb.addKey(27, new key("",Qt.Key.Key_PageUp.value(),languageTool.getString(1333),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				if(kb.b.btext == null)return false;
				kb.b.btext.doNotScroll = true;
				kb.b.btext.scrollWithAnimation(kb.b.text.verticalScrollBar().value()-kb.b.text.viewport().height()+kb.b.b.getEditorLineSpaceValue()+kb.b.getEditorParagraphSpaceValue());
				kb.b.btext.doNotScroll = false;
				return true;
			}
			
		});
		kb.addKey(28, new key("",Qt.Key.Key_PageDown.value(),languageTool.getString(1334),0,0,false) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				kb.b.btext.doNotScroll = true;
				kb.b.btext.scrollWithAnimation(kb.b.text.verticalScrollBar().value()+kb.b.text.viewport().height()-(kb.b.getEditorLineSpaceValue()+kb.b.getEditorParagraphSpaceValue()));
				kb.b.btext.doNotScroll = false;
				return true;
			}
			
		});
		kb.addKey(29, new key("alt",Qt.Key.Key_PageDown.value(),languageTool.getString(1335),1,0,false) {

			@Override
			boolean action() {
				kb.b.ba.changeBackgroundImage();
				return true;
			}
			
		});
		kb.addKey(30, new key("alt",-1,languageTool.getString(1336),0,0,true) {

			@Override
			boolean action() {
				kb.b.showAllSelectionInCurrentScreen(kb.b.text, kb.b.text.textCursor().selectedText());
				return false;
			}
			
		});
		kb.addKey(31, new key("alt",Qt.Key.Key_I.value(),languageTool.getString(1337),0,0,false) {

			@Override
			boolean action() {
				kb.b.btext.moveUp();
				return true;
			}
			
		});
		kb.addKey(32, new key("alt",Qt.Key.Key_K.value(),languageTool.getString(1338),0,0,false) {

			@Override
			boolean action() {
				kb.b.btext.moveDown();
				return true;
			}
			
		});
		kb.addKey(33, new key("alt",Qt.Key.Key_J.value(),languageTool.getString(1339),0,0,false) {

			@Override
			boolean action() {
				kb.b.btext.moveLeft();;
				return true;
			}
			
		});
		kb.addKey(34, new key("alt",Qt.Key.Key_L.value(),languageTool.getString(1340),0,0,false) {

			@Override
			boolean action() {
				kb.b.btext.moveRight();
				return true;
			}
			
		});
		kb.addKey(35, new key("alt",Qt.Key.Key_U.value(),languageTool.getString(1341),0,0,false) {

			@Override
			boolean action() {
				kb.b.moveToPreviousEditPoint();
				return true;
			}
			
		});
		kb.addKey(36, new key("alt",Qt.Key.Key_O.value(),languageTool.getString(1342),0,0,false) {

			@Override
			boolean action() {
				kb.b.moveToNextEditPoint();
				return true;
			}
			
		});
		kb.addKey(37, new key("ctrl",Qt.Key.Key_Up.value(),languageTool.getString(1343),0,0,false) {

			@Override
			boolean action() {
				if(kb.b.ba.tempData.get(languageTool.getString(1344)) == null)
					kb.b.ba.tempData.put(languageTool.getString(1345), 0);
				else kb.b.ba.tempData.remove(languageTool.getString(1346));
				kb.b.btext.doNotScroll = true;
				kb.b.btext.scrollWithAnimation(kb.b.text.verticalScrollBar().value()-(kb.b.text.cursorRect().height()+kb.b.getEditorLineSpaceValue()));
				kb.b.btext.doNotScroll = false;
				return true;
			}
			
		});
		kb.addKey(38, new key("ctrl",Qt.Key.Key_Down.value(),languageTool.getString(1347),0,0,false) {

			@Override
			boolean action() {
				if(kb.b.ba.tempData.get(languageTool.getString(1348)) == null)
					kb.b.ba.tempData.put(languageTool.getString(1349), 0);
				else kb.b.ba.tempData.remove(languageTool.getString(1350));
				kb.b.btext.doNotScroll = true;
				kb.b.btext.scrollWithAnimation(kb.b.btext.text.verticalScrollBar().value()+(kb.b.btext.text.cursorRect().height()+kb.b.getEditorLineSpaceValue()));
				kb.b.btext.doNotScroll = false;
				return true;
			}
			
		});
		kb.addKey(107, new key("",Qt.Key.Key_F11.value(),languageTool.getString(1351),1,0,false) {

			@Override
			boolean action() {
				kb.b.writingView(true);
				return true;
			}
			
		});
		kb.b.ba.setShortcuts();
	}
}
