package yang.app.qt.black;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.mail.search.IntegerComparisonTerm;

import org.apache.batik.transcoder.TranscoderException;

import com.hankcs.hanlp.utility.ByteUtil;

import io.qt.QFlags;
import io.qt.core.QBuffer;
import io.qt.core.QByteArray;
import io.qt.core.QEvent;
import io.qt.core.QIODevice;
import io.qt.core.QModelIndex;
import io.qt.core.QObject;
import io.qt.core.QPoint;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.core.Qt;
import io.qt.core.QLocale.QuotationStyle;
import io.qt.core.Qt.Alignment;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.ConnectionType;
import io.qt.core.Qt.FindChildOption;
import io.qt.core.Qt.FocusPolicy;
import io.qt.core.Qt.GlobalColor;
import io.qt.core.Qt.ItemFlag;
import io.qt.core.Qt.ItemFlags;
import io.qt.core.Qt.MatchFlag;
import io.qt.core.Qt.ScrollBarPolicy;
import io.qt.core.Qt.TextElideMode;
import io.qt.core.Qt.ToolButtonStyle;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.core.Qt.WindowFlags;
import io.qt.core.Qt.WindowType;
import io.qt.gui.QBackingStore;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QFont.SpacingType;
import io.qt.gui.QFont.Style;
import io.qt.gui.QFont.StyleHint;
import io.qt.gui.QFont.StyleStrategy;
import io.qt.gui.QPainter.CompositionMode;
import io.qt.gui.QFontMetrics;
import io.qt.gui.QPalette.ColorRole;
import io.qt.gui.QPixmap;
import io.qt.gui.QStyleHints;
import io.qt.gui.QIcon;
import io.qt.gui.QImage;
import io.qt.gui.QImageReader;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QMouseEvent;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPalette;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextBlockFormat.LineHeightTypes;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCharFormat.UnderlineStyle;
import io.qt.gui.QTextCharFormat.VerticalAlignment;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextFormat;
import io.qt.gui.QTextFragment;
import io.qt.gui.QTextFrame;
import io.qt.gui.QTextImageFormat;
import io.qt.gui.QTextLayout.FormatRange;
import io.qt.gui.QTextLength;
import io.qt.gui.QTextList;
import io.qt.gui.QTextListFormat;
import io.qt.gui.QTextTable;
import io.qt.gui.QTextTableFormat;
import io.qt.widgets.QAbstractItemView;
import io.qt.widgets.QAbstractItemView.EditTrigger;
import io.qt.widgets.QAbstractItemView.EditTriggers;
import io.qt.widgets.QAbstractSlider.SliderAction;
import io.qt.widgets.QAction;
import io.qt.widgets.QApplication;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QCheckBox;
import io.qt.widgets.QColorDialog;
import io.qt.widgets.QComboBox;
import io.qt.widgets.QComboBox.SizeAdjustPolicy;
import io.qt.widgets.QDialog;
import io.qt.widgets.QDoubleSpinBox;
import io.qt.widgets.QFileDialog;
import io.qt.widgets.QFileDialog.Result;
import io.qt.widgets.QFontComboBox;
import io.qt.widgets.QGroupBox;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLayout;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QListView;
import io.qt.widgets.QListView.Movement;
import io.qt.widgets.QListView.ResizeMode;
import io.qt.widgets.QListView.ViewMode;
import io.qt.widgets.QListWidget;
import io.qt.widgets.QListWidgetItem;
import io.qt.widgets.QMenu;
import io.qt.widgets.QMessageBox;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QSizePolicy;
import io.qt.widgets.QSizePolicy.ControlType;
import io.qt.widgets.QSizePolicy.Policy;
import io.qt.widgets.QSpacerItem;
import io.qt.widgets.QSpinBox;
import io.qt.widgets.QStyle.ComplexControl;
import io.qt.widgets.QStyle.ControlElement;
import io.qt.widgets.QStyle.StateFlag;
import io.qt.widgets.QStyleOption;
import io.qt.widgets.QStyleOptionComboBox;
import io.qt.widgets.QStyleOptionViewItem;
import io.qt.widgets.QStylePainter;
import io.qt.widgets.QStyledItemDelegate;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QToolBar;
import io.qt.widgets.QToolButton;
import io.qt.widgets.QToolButton.ToolButtonPopupMode;
import yang.demo.allPurpose.SVG2PNGUtils;
import yang.demo.allPurpose.yangIO;
import io.qt.widgets.QWidget;

public class setTextStyles extends QObject{
	QTextEdit editor;
	bToolBar tools;
	private QFontComboBox setFont;
	private QComboBox setFontSize;
	/**
	 * combox（包括字体combox）当前index被代码更改后，会触发对应的信号槽，导致重复调用，所以需要添加此开关
	 */
	boolean ignoreComboxChange;
	private QToolButton setBold;
	private QToolButton setItalic;
	private QToolButton setUnderLine;
	private QToolButton setStrikeLine;
	int lastUsedUnderlineType = 5;
	private QColor lastUsedUnderlineColor;
	private QToolButton setSuperscript;
	private QToolButton setSubscript;
	private QToolButton setForeground;
	private QColor lastUsedTextForeground,lastUsedTextBackground;
	/**
	 * 当前编辑器文字的默认颜色，文字的默认颜色在不同的写作视图/夜间或日间模式中可能不同
	 */
	QColor defalutTextForeground = new QColor(GlobalColor.black),defalutTextBackground = new QColor(GlobalColor.white);
	private QToolButton setBackground;
	private QToolButton setAlignJustify;
	private QToolButton setAlignLeft;
	private QToolButton setAlignCenter;
	private QToolButton setAlignRight;
	black b = black.b;
	ArrayList<styleInfo> styles = null;
	boolean stylesChaneged = false;
	private QComboBox selectStyle;
	private int lastUsedListType = 0;
	private int lastUsedNumberListType = 3;
	protected int lastUsedTableRows = 1;
	protected int lastUsedTableCols = 1;
	private int lastUseTableAction = -1;
	private int lastUsedImageAction = 0;
	QSize styleViewSize = new QSize(300,100);
	private int maxNameIndex;
	private bRunnable cursorPositionChangedCheckAction;
	
	public setTextStyles(QTextEdit text,QLayout layout) {
		File file = new File(appInfo.appCfgDir+"stylesData");
		if(file.exists()) {
			styles = (ArrayList<styleInfo>) io.readObjFile(file);
		}else styles = new ArrayList<styleInfo>();
		
		this.editor = text;
		
//		QPalette p = text.palette();
//		p.setColor(ColorRole.Text, defalutTextForeground);
//		p.setColor(ColorRole.Base, defalutTextBackground);
		if(text != null) {
			text.cursorPositionChanged.connect(this, "cursorPositionChanged()");
			text.selectionChanged.connect(this, "cursorPositionChanged()");
		}
		
		tools = new bToolBar(text);
		if(b != null)
			tools.setKeyMode = true;
		//按照添加到tools的顺序分配index值，不能改动顺序，保险起见，应该手动分配固定的objectname
		layout.setContentsMargins(0, 0, 0, 0);
		layout.addWidget(tools);
		layout.setWidgetSpacing(0);
		
		selectStyle = new QComboBox() {
			
			@Override
			public boolean event(QEvent event) {
				// TODO Auto-generated method stub
				if(event.type() == QEvent.Type.FontChange) {
					if(setFont != null) {
						setFixedHeight(setFont.height());
					}
					setStylesListViewSize();
				}
				return super.event(event);
			}
			@Override
			protected void paintEvent(QPaintEvent e) {
				// TODO Auto-generated method stub
				QStylePainter painter = new QStylePainter(this);
				painter.setPen(palette().color(ColorRole.Text));
				QStyleOptionComboBox opt = new QStyleOptionComboBox();
				initStyleOption(opt);
				opt.setCurrentIcon(new QIcon());
				opt.setIconSize(new QSize());
				
				painter.drawComplexControl(ComplexControl.CC_ComboBox, opt);
				painter.drawControl(ControlElement.CE_ComboBoxLabel, opt);
				painter.end();

//				super.paintEvent(e);
			
			}
			@Override
			public void showPopup() {
				// TODO Auto-generated method stub
				setStylesListViewSize();
				super.showPopup();
			}
		};
		selectStyle.setFixedSize(100, 20);
		selectStyle.setObjectName("139");
//		selectStyle.setAttribute(WidgetAttribute.WA_TranslucentBackground);
		//设置背景透明后会导致item背景变成黑色，所以需要对item颜色进行特别设置
		selectStyle.setStyleSheet("QComboBox{background-color:transparent;}QComboBox QAbstractItemView::item{background-color:white}");
		selectStyle.setToolTip(languageTool.getString(195));
		selectStyle.activated.containingObject().connect(selectStyle, "activated(int)", this, "test(int)",ConnectionType.AutoConnection);
//		selectStyle.setPlaceholderText("");
		tools.addItem(selectStyle);
		selectStyle.setEditable(false);
		showStyles();
		addToolButton(languageTool.getString(196), "management-16.png", "managementStyles()","140");
		addToolButton(languageTool.getString(197),"grab-16.png","saveStyle()","141");
		addToolButton(languageTool.getString(198), "paragraph-16.png", "setParagraph()","142");
		tools.addSeparatorItem();

		setFont = new QFontComboBox();
		setFont.setStyleSheet("QComboBox{background-color:transparent;}QComboBox QAbstractItemView::item{background-color:white}");
		setFont.setToolTip(languageTool.getString(199));
		setFont.currentFontChanged.connect(this, "changedFont(QFont)");
		setFont.setObjectName("143");
//		setFont.setMaximumWidth(100);
		tools.addItem(setFont);
		setFontSize = new QComboBox();
		setFontSize.setObjectName("144");
		setFontSize.setStyleSheet("QComboBox{background-color:transparent;}QComboBox QAbstractItemView::item{background-color:white}");
		setFontSize.setToolTip(languageTool.getString(200));
		setFontSize.currentTextChanged.connect(this, "changedFontSize(String)");
		setFontSize.setEditable(true);
		for(double i=5;i<=72;i++)
			setFontSize.addItem(String.valueOf(i));
		tools.addItem(setFontSize);
		tools.addSeparatorItem();
		addToolButton(languageTool.getString(201), "increase-font-16.png", "increaseFont()","145");
		addToolButton(languageTool.getString(202), "decrease-font-16.png", "decreaseFont()","146");
		tools.addSeparatorItem();
		setBold = new QToolButton();
		setBold.setObjectName("147");
		setBold.setCheckable(true);
		setBold.setIcon(new QIcon(appInfo.icons_16+"bold-16.png"));
		setBold.setToolTip(languageTool.getString(203));
		setBold.clicked.connect(this, "setBold()");
		setItalic = new QToolButton();
		setItalic.setObjectName("148");
		setItalic.setToolTip(languageTool.getString(204));
		setItalic.setCheckable(true);
		setItalic.setIcon(new QIcon(appInfo.icons_16+"italic-16.png"));
		setItalic.clicked.connect(this, "setItalic()");
		tools.addItem(setBold);
		tools.addItem(setItalic);
		tools.addSeparatorItem();
		setUnderLine = new QToolButton();
		setUnderLine.setObjectName("149");
		underLineMenu();
		setUnderLine.setCheckable(true);
		setUnderLine.setIcon(new QIcon(appInfo.icons_16+"underline-16.png"));
		setUnderLine.setText(languageTool.getString(205));
		setUnderLine.setToolTip(languageTool.getString(205));
		setUnderLine.clicked.connect(this, "setUnderLine()");
		tools.addItem(setUnderLine);
		setStrikeLine = new QToolButton();
		setStrikeLine.setObjectName("150");
		setStrikeLine.setCheckable(true);
		setStrikeLine.setToolTip(languageTool.getString(206));
		setStrikeLine.setIcon(getIcon("strikethrough-16.png"));
		setStrikeLine.clicked.connect(this, "setStrikeLine()");
		tools.addItem(setStrikeLine);
		tools.addSeparatorItem();
		setSuperscript = new QToolButton();
		setSuperscript.setObjectName("151");
		setSuperscript.setToolTip(languageTool.getString(207));
		setSuperscript.setCheckable(true);
		setSuperscript.setIcon(getIcon("superscript-16.png"));
		setSuperscript.clicked.connect(this, "setSuperscript()");
		tools.addItem(setSuperscript);
		setSubscript = new QToolButton();
		setSubscript.setObjectName("152");
		setSubscript.setToolTip(languageTool.getString(208));
		setSubscript.setCheckable(true);
		setSubscript.setIcon(getIcon("subscript-16.png"));
		setSubscript.clicked.connect(this, "setSubscript()");
		tools.addItem(setSubscript);
		tools.addSeparatorItem();
		setForeground = new QToolButton();
		setForeground.setObjectName("153");
		setForeground.setToolTip(languageTool.getString(209));
		setForeground.setIcon(getIcon("text-16.png"));
		setForeground.clicked.connect(this, "setForeground()");
		tools.addItem(setForeground);
		QMenu foregroundmenu = new QMenu();
		foregroundmenu.aboutToShow.connect(this, "setForegroundColor()");
		setForeground.setMenu(foregroundmenu);
		setForeground.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		setBackground = new QToolButton();
		setBackground.setObjectName("154");
		setBackground.setToolTip(languageTool.getString(210));
		setBackground.setIcon(getIcon("text-color-16.png"));
		setBackground.clicked.connect(this, "setBackground()");
		QMenu backgroundmenu = new QMenu();
		backgroundmenu.aboutToShow.connect(this, "setBackgroundColor()");
		setBackground.setMenu(backgroundmenu);
		setBackground.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		tools.addItem(setBackground);
		tools.addSeparatorItem();
		setAlignJustify = new QToolButton();
		setAlignJustify.setObjectName("155");
		setAlignJustify.setToolTip(languageTool.getString(211));
		setAlignJustify.setIcon(getIcon("align-justify-16.png"));
		setAlignJustify.setCheckable(true);
		setAlignJustify.clicked.connect(this, "setAlignJustify()");
		tools.addItem(setAlignJustify);
		setAlignLeft = new QToolButton();
		setAlignLeft.setToolTip(languageTool.getString(212));
		setAlignLeft.setObjectName("156");
		setAlignLeft.setIcon(getIcon("align-left-16.png"));
		setAlignLeft.setCheckable(true);
		setAlignLeft.clicked.connect(this, "setAlignLeft()");
		tools.addItem(setAlignLeft);
		setAlignCenter = new QToolButton();
		setAlignCenter.setObjectName("157");
		setAlignCenter.setToolTip(languageTool.getString(213));
		setAlignCenter.setIcon(getIcon("align-center-16.png"));
		setAlignCenter.setCheckable(true);
		setAlignCenter.clicked.connect(this, "setAlignCenter()");
		tools.addItem(setAlignCenter);
		setAlignRight = new QToolButton();
		setAlignRight.setObjectName("158");
		setAlignRight.setToolTip(languageTool.getString(214));
		setAlignRight.setIcon(getIcon("align-right-16.png"));
		setAlignRight.setCheckable(true);
		setAlignRight.clicked.connect(this, "setAlignRight()");
		tools.addItem(setAlignRight);
		tools.addSeparatorItem();
		addToolButton(languageTool.getString(215),"outdent-16.png", "outdent()","159");
		addToolButton(languageTool.getString(216),"indent-16.png", "indent()","160");
		tools.addSeparatorItem();
		
		QToolButton addList = addToolButton(languageTool.getString(217), "list-16.png", "addList()","161");
		addList.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		QMenu listMenu = new QMenu();
		addList.setMenu(listMenu);
		QAction addListAction0 = new QAction();
		addListAction0.setObjectName("162");
		addListAction0.setText(languageTool.getString(218));
		addListAction0.triggered.connect(this, "addList0()");
		uiTool.addActionToMenu(addListAction0, listMenu, b);
		QAction addListAction1 = new QAction();
		addListAction1.setObjectName("163");
		addListAction1.setText(languageTool.getString(219));
		addListAction1.triggered.connect(this, "addList1()");
		uiTool.addActionToMenu(addListAction1, listMenu, b);
		QAction addListAction2 = new QAction();
		addListAction2.setObjectName("164");
		addListAction2.setText(languageTool.getString(220));
		addListAction2.triggered.connect(this, "addList2()");
		uiTool.addActionToMenu(addListAction2, listMenu, b);
		
		QToolButton addList1 = addToolButton(languageTool.getString(221), "listnumber-16.png", "addNumberList()","165");
		addList1.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		QMenu listMenu1 = new QMenu();
		addList1.setMenu(listMenu1);
		QAction addListAction3 = new QAction();
		addListAction0.setObjectName("166");
		addListAction3.setText(languageTool.getString(222));
		addListAction3.triggered.connect(this, "addList3()");
		uiTool.addActionToMenu(addListAction3, listMenu1, b);
		QAction addListAction4 = new QAction();
		addListAction4.setObjectName("167");
		addListAction4.setText(languageTool.getString(223));
		addListAction4.triggered.connect(this, "addList4()");
		uiTool.addActionToMenu(addListAction4, listMenu1, b);
		QAction addListAction5 = new QAction();
		addListAction5.setObjectName("168");
		addListAction5.setText(languageTool.getString(224));
		addListAction5.triggered.connect(this, "addList5()");
		uiTool.addActionToMenu(addListAction5, listMenu1, b);
		QAction addListAction6 = new QAction();
		addListAction6.setText(languageTool.getString(225));
		addListAction6.setObjectName("169");
		addListAction6.triggered.connect(this, "addList6()");
		uiTool.addActionToMenu(addListAction6, listMenu1, b);
		QAction addListAction7 = new QAction();
		addListAction7.setObjectName("170");
		addListAction7.setText(languageTool.getString(226));
		addListAction7.triggered.connect(this, "addList7()");
		uiTool.addActionToMenu(addListAction7, listMenu1, b);
		QAction addListAction8 = new QAction();
		addListAction8.setObjectName("171");
		addListAction8.setText(languageTool.getString(227));
		addListAction8.triggered.connect(this, "addList8()");
		uiTool.addActionToMenu(addListAction8, listMenu1, b);
		QAction addListAction9 = new QAction();
		addListAction9.setObjectName("172");
		addListAction9.setText(languageTool.getString(228));
		addListAction9.triggered.connect(this, "addList9()");
		uiTool.addActionToMenu(addListAction9, listMenu1, b);
		QAction addListAction10 = new QAction();
		addListAction10.setObjectName("173");
		addListAction10.setText(languageTool.getString(229));
		addListAction10.triggered.connect(this, "addList10()");
		uiTool.addActionToMenu(addListAction10, listMenu1, b);
		
		QToolButton addTable = addToolButton(languageTool.getString(230), "table-16.png", "addTable()","174");
		addTable.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		QMenu tableMenu = new QMenu();
		addTable.setMenu(tableMenu);
		QAction addTable1 = new QAction();
		addTable1.setObjectName("175");
		addTable1.setText(languageTool.getString(231));
		addTable1.triggered.connect(this, "addTable1()");
		uiTool.addActionToMenu(addTable1, tableMenu, b);
		QAction addTable2 = new QAction();
		addTable2.setObjectName("176");
		addTable2.setText(languageTool.getString(232));
		addTable2.triggered.connect(this, "addTable0()");
		uiTool.addActionToMenu(addTable2, tableMenu, b);
		
		QAction addTable3 = new QAction();
		addTable3.setObjectName("177");
		addTable3.setText(languageTool.getString(233));
		addTable3.triggered.connect(this, "addTable2()");
		uiTool.addActionToMenu(addTable3, tableMenu, b);
		tableMenu.addSeparator();
		
		QAction addTable4 = new QAction();
		addTable4.setObjectName("178");
		addTable4.setText(languageTool.getString(234));
		addTable4.triggered.connect(this, "addTable3()");
		uiTool.addActionToMenu(addTable4, tableMenu, b);
		
		QAction addTable5 = new QAction();
		addTable5.setObjectName("179");
		addTable5.setText(languageTool.getString(235));
		addTable5.triggered.connect(this, "addTable4()");
		uiTool.addActionToMenu(addTable5, tableMenu, b);
		
		tableMenu.addSeparator();

		QAction addTable6 = new QAction();
		addTable6.setObjectName("180");
		addTable6.setText(languageTool.getString(236));
		addTable6.triggered.connect(this, "addTable5()");
		uiTool.addActionToMenu(addTable6, tableMenu, b);
		
		QAction addTable7 = new QAction();
		addTable7.setObjectName("181");
		addTable7.setText(languageTool.getString(237));
		addTable7.triggered.connect(this, "addTable6()");
		uiTool.addActionToMenu(addTable7, tableMenu, b);
		tableMenu.addSeparator();
		
		QAction addTable8 = new QAction();
		addTable8.setObjectName("182");
		addTable8.setText(languageTool.getString(238));
		addTable8.triggered.connect(this, "addTable7()");
		uiTool.addActionToMenu(addTable8, tableMenu, b);
		
		QToolButton addImage = addToolButton(languageTool.getString(239), "image-16.png", "addImage()","183");
		QMenu addImageMenu = new QMenu();
		addImage.setMenu(addImageMenu);
		addImage.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
		QAction addImage0 = new QAction();
		addImage0.setObjectName("184");
		addImage0.setText(languageTool.getString(240));
		addImage0.triggered.connect(this, "addImage0()");
		uiTool.addActionToMenu(addImage0, addImageMenu, b);
		QAction addImage1 = new QAction();
		addImage1.setText(languageTool.getString(241));
		addImage1.setObjectName("185");
		addImage1.triggered.connect(this, "addImage1()");
		uiTool.addActionToMenu(addImage1, addImageMenu, b);
		if(b == null) {
			tools.addSeparatorItem();
			addToolButtonSvg("", "save.svg", "saveDoc()");
		}
	}
	void saveDoc() {
		
	}
	void managementStyles() {
		showStylesDialog();
	}
	void whenBlackClose() {
		if(stylesChaneged) {
			File file = new File(appInfo.appCfgDir+"stylesData");
			io.writeObjFile(file, styles);
		}
		
	}
	void addImage(int type) {
		lastUsedImageAction = type;
		switch(type) {
		case 0:
			QWidget parent = null;
			if(b != null) parent = b;
			List<QByteArray> supportedImageFormats = QImageReader.supportedImageFormats();
			StringBuffer imageformats = new StringBuffer();
			imageformats.append("(");
			for(QByteArray b:supportedImageFormats) {
				String format = b.toString();
				
				imageformats.append(" *"+format);
				imageformats.append(" *"+format.toUpperCase());
			}
			imageformats.append(")");
			Result<List<String>> filesname = QFileDialog.getOpenFileNames(parent,languageTool.getString(242),"",""
					+ languageTool.getString(243)+imageformats);
			if(filesname == null) return;
			List<String> files = filesname.result;
			QTextEdit text = getEditor();
			text.setUpdatesEnabled(false);
			QTextCursor tc = text.textCursor();
			
			tc.beginEditBlock();
			for(String file:files) {
				File f = new File(file);
				if(!f.exists()) continue;
				
				byte[] bytes = null;
				String base64 = null;
				try {
					bytes = Files.readAllBytes(f.toPath());
					QImage img = QImage.fromData(bytes);
					QByteArray ba = new QByteArray();
					QBuffer buffer = new QBuffer(ba);
					buffer.open(QIODevice.OpenModeFlag.WriteOnly);
					img.save(buffer, "jpg",-1);
					base64 = ba.toBase64().toString();
//					base64 = Base64.getEncoder().encodeToString(bytes);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(base64 == null) {
					tc.endEditBlock();
					text.setUpdatesEnabled(true);
					continue;
				}
				
				String src = "<img src=\"data:image/jpg;base64,"+base64+"\"/>";
				tc.insertHtml(src);
			}
			tc.endEditBlock();
			text.setUpdatesEnabled(true);
			break;
		case 1:
			InputDialog id = new InputDialog(b,languageTool.getString(244),languageTool.getString(245),false,false,"") {
				
				@Override
				void whenOkButtonPressed() {
					// TODO Auto-generated method stub
					String text = copyLineText();
					byte[] bytes = yangIO.getDataFormHttpsURL(text, b);
					if(bytes == null) {
						b.getMessageBox(languageTool.getString(246), languageTool.getString(247));
						return;
					}
					QImage img = QImage.fromData(bytes);
					QByteArray ba = new QByteArray();
					QBuffer buffer = new QBuffer(ba);
					buffer.open(QIODevice.OpenModeFlag.WriteOnly);
					boolean save = img.save(buffer, "jpg");
					if(!save) {
						if(b != null) b.getMessageBox(languageTool.getString(248), languageTool.getString(249));
						else System.out.println(languageTool.getString(247));
						return;
					}
					String base64 = ba.toBase64().toString();
					
			
					String src = "<img src=\"data:image/jpg;base64,"+base64+"\"/>";
					QTextCursor tc = getEditor().textCursor();
					tc.insertHtml(src);
					
					close();
				}
				
				@Override
				void whenClose() {
					// TODO Auto-generated method stub
					close();
				}
				
				@Override
				void whenCannelButtonPressed() {
					// TODO Auto-generated method stub
					close();
				}
			};
			id.setMessageText(languageTool.getString(251));
			id.noHide = true;
			id.show();
			break;
		}
	}

	public static String bytes2Hex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (byte b : bytes) {
			String hex = Integer.toHexString(b & 0xff);
			sb.append(hex.length() == 2 ? hex : ("0" + hex));
		}
		return sb.toString();
	}
	void addImage1(){
		addImage(1);
	}
	void addImage0(){
		addImage(0);
	}
	void addImage() {
		addImage(lastUsedImageAction);
	}
	QTextEdit getEditor() {
		if(editor == null) return b.text;
		else return editor;
	}
	void addTable0() {
		tableAction(0);
	
	}
	void addTable2(){
		tableAction(1);
	}
	
	void addTable3(){
		tableAction(2);
	}
	void addTable4(){
		tableAction(3);
	}
	void addTable5(){
		tableAction(4);
	}
	void addTable6(){
		tableAction(5);
	}
	void addTable7() {
		tableAction(6);
	}

	void tableAction(int type) {
		QTextCursor tc = getEditor().textCursor();
		QTextTable ct = tc.currentTable();
		if(ct == null) return;
		
//		QTextTableFormat ttf = new QTextTableFormat();
//		ArrayList<QTextLength> al = new ArrayList<QTextLength>();
//		QTextLength tl = new QTextLength(QTextLength.Type.PercentageLength, 20);
//		al.add(tl);
//		ttf.setColumnWidthConstraints(al);
		switch(type) {
		case 0:
			ct.appendColumns(1);
//			ct.setFormat(ttf);
			break;
		case 1:
			ct.appendRows(1);
			break;
		case 2:
			//在前面插入一列
			ct.insertColumns(ct.cellAt(tc).column(), 1);
			break;
		case 3:
			//在前面插入一行
			ct.insertRows(ct.cellAt(tc).row(), 1);
			break;
		case 4:
			ct.removeColumns(ct.cellAt(tc).column(), 1);
			break;
		case 5:
			ct.removeRows(ct.cellAt(tc).row(), 1);
			break;
		case 6:
			ct.mergeCells(tc);
			break;
		case 7:
			break;
		}
		lastUseTableAction = type;
	}
	void addTable1() {
		QDialog dia = new QDialog();
		if(b != null) dia.setWindowIcon(b.windowIcon());
		dia.setWindowTitle(languageTool.getString(252));
		dia.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		QBoxLayout layout = uiTool.getBoxLayout(0);
		dia.setLayout(layout);
		QBoxLayout bl1 = uiTool.getBoxLayout(2);
		layout.addLayout(bl1);
		QLabel l1 = new QLabel(languageTool.getString(253));
		bl1.addWidget(l1);
		QSpinBox sb1 = new QSpinBox();
		bl1.addWidget(sb1);
		QLabel l2 = new QLabel(languageTool.getString(254));
		bl1.addWidget(l2);
		QSpinBox sb2 = new QSpinBox();
		bl1.addWidget(sb2);
		sb1.setMinimum(1);
		sb2.setMinimum(1);
		sb1.setValue(lastUsedTableRows);
		sb2.setValue(lastUsedTableCols);
		QBoxLayout bl2 = uiTool.getBoxLayout(2);
		layout.addLayout(bl2);
		QPushButton pb = new QPushButton();
		pb.setText(languageTool.getString(255));
		QObject ok = new QObject() {
			void createTable(){
				QTextEdit text = getEditor();
				QTextCursor tc = text.textCursor();
				QTextBlockFormat bf = tc.blockFormat();
				QTextTableFormat ttf = new QTextTableFormat();
//				ttf.setAlignment(text.alignment());
				
//				ArrayList<QTextLength> al = new ArrayList<QTextLength>();
//				QTextLength tl = new QTextLength(QTextLength.Type.PercentageLength, 100);
//				al.add(tl);
//				ttf.setColumnWidthConstraints(al);
//				QTextCharFormat cf = text.currentCharFormat();
				tc.insertTable(sb1.value(), sb2.value(), ttf);
				
//				text.setCurrentCharFormat(cf);
				lastUsedTableRows = sb1.value();
				lastUsedTableCols = sb2.value();
				lastUseTableAction = -1;
				dia.close();
			}
		};
		pb.clicked.connect(ok, "createTable()");
		bl2.addWidget(pb);
		dia.exec();
	}

	void addTable() {
		if(lastUseTableAction == -1) {
			QTextCursor tc = getEditor().textCursor();
			tc.insertTable(lastUsedTableRows, lastUsedTableCols);
		}else tableAction(lastUseTableAction);
	}
	void addNumberList() {
		addList(lastUsedNumberListType);
	}
	void addList(int type) {
		QTextCursor tc = getEditor().textCursor();
		QTextListFormat tlf = new QTextListFormat();
		switch(type) {
		case 0:
			tlf.setStyle(QTextListFormat.Style.ListDisc);
			break;
		case 1:
			tlf.setStyle(QTextListFormat.Style.ListCircle);
			break;
		case 2:
			tlf.setStyle(QTextListFormat.Style.ListSquare);
			break;
		case 3:
			tlf.setStyle(QTextListFormat.Style.ListDecimal);
			break;
		case 4:
			tlf.setStyle(QTextListFormat.Style.ListLowerAlpha);
			break;
		case 5:
			tlf.setStyle(QTextListFormat.Style.ListUpperAlpha);
			break;
		case 6:
			tlf.setStyle(QTextListFormat.Style.ListLowerRoman);
			break;
		case 7:
			tlf.setStyle(QTextListFormat.Style.ListUpperRoman);
			break;
		case 8:
			tlf.setStyle(QTextListFormat.Style.ListDecimal);
			tlf.setNumberSuffix(")");
			break;
		case 9:
			tlf.setStyle(QTextListFormat.Style.ListDecimal);
			tlf.setNumberPrefix("(");
			tlf.setNumberSuffix(")");
			break;
		case 10:
			tlf.setStyle(QTextListFormat.Style.ListDecimal);
			tlf.setNumberPrefix("[");
			tlf.setNumberSuffix("]");
			break;
		}
		tc.insertList(tlf);
		if(type < 3)
			lastUsedListType = type;
		else lastUsedNumberListType = type;
	}
	void addList0() {
		addList(0);
	}
	void addList1() {
		addList(1);
	}
	void addList2() {
		addList(2);
	}
	//小数列表
	void addList3() {
		addList(3);
	}
	//小写英文列表
	void addList4() {
		addList(4);
	}
	//大写英文列表
	void addList5() {
		addList(5);
	}
	//小写数字列表
	void addList6() {
		addList(6);
	}
	//大写数字列表
	void addList7() {
		addList(7);
	}
	void addList8() {
		addList(8);
	}
	void addList9() {
		addList(9);
	}
	void addList10() {
		addList(10);
	}

	void addList() {
		addList(lastUsedListType);
	}
	void test(int i) {
		if(ignoreComboxChange) return;
		setStyle(styles.get(i));
		cursorPositionChanged();
	}
	void setStyle(QTextEdit text,styleInfo si) {
		setStyle(text, si.getFontname(), si.getFontsize()+"", si.getBold()+"",
				si.getItialc()+"", si.getUnderline()+"", si.getUnderlinecolor(), si.getStrikeline()+"",
				si.getSuperscript()+"",
				si.getSubscript()+"", si.getForeground(), si.getBackground(),
				si.getAlign()+"", si.getIndent()+"", si.getFirstLineIndent()+"",
				si.getLineHeightType()+" "+si.getLineHeightValue(), 
				si.getLeftMargin()+" "+si.getTopMargin()+" "+si.getRightMargin()+" "+si.getBottomMargin(),
				si.getHeadType()+"", "-1",
				si.getLetterSpaceType()+" "+si.getLetterSpaceValue()
				);
	}
	void setStyle(styleInfo si) {
			setStyle(getEditor(),si);	
	}
	
	void showStyles() {
		ignoreComboxChange = true;
		selectStyle.clear();
		QTextEdit te = new QTextEdit();
		te.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		te.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
		te.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
		te.setFixedSize(styleViewSize);
		te.hide();

		te.setText(languageTool.getString(256));
		te.append(languageTool.getString(257));

		QTextCursor tc = te.textCursor();
		selectStyle.setIconSize(te.size());
		QFont font = selectStyle.font();
		QFontMetrics fm = new QFontMetrics(font);
		int max = 0;
		int index = 0;
		for(styleInfo si:styles) {
			tc.select(SelectionType.Document);
			te.setTextCursor(tc);
			setStyle(te,si);
			tc.setPosition(0);
			te.setTextCursor(tc);
			te.ensureCursorVisible();
			QPixmap grab = te.grab(te.contentsRect());
			QIcon icon = new QIcon(grab);
			selectStyle.addItem(icon, si.getStyleName());
			int width = fm.width(si.getStyleName());
			if(width > max) {
				max = width;
				maxNameIndex = index; 
			}
			index++;
		}
		te.close();
		setStylesListViewSize();
		ignoreComboxChange = false;
	}
	void setStylesListViewSize() {
		if(styles.size() == 0) return;
		//简易测量一下text最长的item连图标带文字的宽度
		String styleName = styles.get(maxNameIndex).getStyleName();
		QFont font = selectStyle.font();
		QFontMetrics fm = new QFontMetrics(font);
		int wid = fm.width(styleName);
		int scrollbar = 0;
		if(selectStyle.view().verticalScrollBar() != null && selectStyle.view().verticalScrollBar().isVisible())
			scrollbar = selectStyle.view().verticalScrollBar().width();
		QPoint mapToGlobal = selectStyle.mapToGlobal(new QPoint(0,selectStyle.height()));
		QRect dg = bAction.desktopGeometry(false);
		int h = dg.height()-mapToGlobal.y();
		
		int hall = styleViewSize.height()*styles.size();
		if(hall < h) h = hall;
//		
//		//只要设定的view高度小于Qt计算出来的高度，下拉列表上下就会出现黑边
		int ww = styleViewSize.width()+wid+40+scrollbar;
		int hh = h;
		//下面这行必须要有，不然下拉列表会出现上下黑边
		selectStyle.view().parentWidget().setFixedSize(ww,hh);
		selectStyle.view().setFixedSize(ww,hh);
//		selectStyle.view().viewport().setFixedSize(styleViewSize.width()+wid+40+scrollbar,400);
		
	}
	void showStylesDialog() {
		QWidget parent = null;
		if(b != null) parent = b;
		QDialog dia = new QDialog(parent);
		dia.setWindowTitle(languageTool.getString(258));
		dia.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		QBoxLayout layout1 = uiTool.getBoxLayout(0);
		dia.setLayout(layout1);		
		QTextEdit te = new QTextEdit(dia);
		te.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
		te.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
		te.setFixedSize(300, 100);
		te.hide();

		te.setText(languageTool.getString(256));
		te.append(languageTool.getString(257));
		QTextCursor tc = te.textCursor();
		getKey getKey = new getKey();
		QPushButton removekeyButton = uiTool.getQPushButton(languageTool.getString(259), null, null);
		removekeyButton.setEnabled(false);

		QListWidget lw = new QListWidget() {
			boolean editText = false;
			@Override
			protected void mousePressEvent(QMouseEvent event) {
				// TODO Auto-generated method stub
				if(editText) {
					editText = false;
					Object data = currentItem().data(9);
					if(data != null)
						currentItem().setText((String)data);
				}
				super.mousePressEvent(event);
			}
			@Override
			protected void mouseDoubleClickEvent(QMouseEvent event) {
				// TODO Auto-generated method stub
//				super.mouseDoubleClickEvent(event);
				if(!editText) {
					editText = true;
					currentItem().setData(9, currentItem().text());
					editItem(currentItem());
				}
			}
			@Override
			protected void keyReleaseEvent(QKeyEvent event) {
				// TODO Auto-generated method stub
				super.keyReleaseEvent(event);
				if(event.key() == Qt.Key.Key_Return.value()) {
					if(editText) {
//						System.out.println("重命名"+currentItem().text());
						editText = false;
						if(!currentItem().text().equals(currentItem().data(9))) {
							styles.get(currentRow()).setStyleName(currentItem().text());
							stylesChaneged = true;
							showStyles();
						}
					}
				}
			}
			
			@Override
			protected void currentChanged(QModelIndex current, QModelIndex previous) {
				// TODO Auto-generated method stub
				if(current == null) return;
				super.currentChanged(current, previous);
//				System.out.println(current.row()+" "+current.column());
				if(editText) {
					QListWidgetItem item = item(previous.row());
					Object data = item.data(9);
					if(data != null)
						item.setText((String)data);
					editText = false;
					styles.get(current.row()).setStyleName(item(current.row()).text());
					stylesChaneged = true;
					showStyles();
				}
				keyLink key = b.ba.keyboard.findStyleKey(current.row());
				if(key != null) {
					removekeyButton.setText(languageTool.getString(260,key.getKeyText()));
					removekeyButton.setEnabled(true);
				}else {
					removekeyButton.setText(languageTool.getString(261));
					removekeyButton.setEnabled(false);
				}
			}
		};
		
		EditTriggers editTriggers = lw.editTriggers();
		editTriggers.set(EditTrigger.DoubleClicked);
		lw.setEditTriggers(editTriggers);
		lw.setIconSize(te.size());
		lw.setViewMode(ViewMode.IconMode);
		lw.setResizeMode(ResizeMode.Adjust);
		for(styleInfo si:styles) {
			tc.select(SelectionType.Document);
			te.setTextCursor(tc);
			setStyle(te,si);
			tc.setPosition(0);
			te.setTextCursor(tc);
			te.ensureCursorVisible();
			QPixmap grab = te.grab(te.contentsRect());
			QListWidgetItem lwi = new QListWidgetItem(new QIcon(grab), si.getStyleName());
			lw.addItem(lwi);
			ItemFlags flags = lwi.flags();
			flags.set(ItemFlag.ItemIsEditable);
			lwi.setFlags(flags);
		}
		layout1.addWidget(lw);
		QBoxLayout layout2 = uiTool.getBoxLayout(2);
		layout1.addLayout(layout2);
		layout2.addWidget(getKey);
		QObject action = new QObject(dia) {
			void setKey(){
				keyLink key = b.ba.keyboard.findStyleKey(lw.currentRow());
				if(key != null && key.getKeyText().equals(getKey.keyText)) {
					b.getMessageBox(languageTool.getString(262), languageTool.getString(263));
					return;
				}
				boolean hasKey = b.ba.keyboard.isHasKey(getKey.keyText, false);
				if(hasKey) return;
				
				if(key != null) {
					key.setKey(getKey.modifierKey, getKey.keycode);
				}else {
					addKeys.styleKey(-1, b.ba.keyboard, getKey.modifierKey, getKey.keycode, lw.currentRow());
				}
				b.ba.keyboard.saveAppKeyData();
				b.getMessageBox(languageTool.getString(262), languageTool.getString(264,getKey.keyText,lw.currentItem().text()));
				removekeyButton.setText(languageTool.getString(265,getKey.keyText));
				removekeyButton.setEnabled(true);
				getKey.clearKey();
			}
			void removeKey() {
				int messageBoxWithYesNO = b.getMessageBoxWithYesNO(languageTool.getString(266), languageTool.getString(267), languageTool.getString(1389), languageTool.getString(1390),QMessageBox.Icon.Warning , 0);
				if(messageBoxWithYesNO == 0) return;
				
				b.ba.keyboard.removeStyleKey(lw.currentRow());
				b.getMessageBox(languageTool.getString(266), languageTool.getString(1391));
				b.ba.keyboard.saveAppKeyData();
				removekeyButton.setText(languageTool.getString(261));
				removekeyButton.setEnabled(false);
			}
			void removeStyle() {
				if(styles.size() == 0) return;
				b.ba.keyboard.removeStyleKey(lw.currentRow());
				styles.remove(lw.currentRow());
				lw.takeItem(lw.currentRow());
				b.ba.keyboard.saveAppKeyData();
				stylesChaneged = true;
				showStyles();
			}
			void renameStyle() {
//				lw.setFocus();
//				lw.itemDoubleClicked.emit(lw.currentItem());
				InputDialog id = new InputDialog(dia,"重命名样式","新名称：",false,false,"",false) {
					
					@Override
					void whenOkButtonPressed() {
						// TODO Auto-generated method stub
						if(this.value().isEmpty()) return;
						styles.get(lw.currentRow()).setStyleName(value());
						stylesChaneged = true;
						showStyles();
						lw.currentItem().setText(value());
					}
					
					@Override
					void whenClose() {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					void whenCannelButtonPressed() {
						// TODO Auto-generated method stub
						
					}
				};
				id.setMessageText("为选中的样式设置新的名称");
				id.show();
			}
			void setAsDefaultStyle() {
				b.settings.setValue(appInfo.defaultStyle, lw.currentRow()+"");
				b.getMessageBox(languageTool.getString(1394), languageTool.getString(1393));
			}
		};
		QPushButton setkeyButton = uiTool.getQPushButton(languageTool.getString(262), action, "setKey()");
		layout2.addWidget(setkeyButton);
		
		removekeyButton.clicked.connect(action, "removeKey()");
		layout2.addWidget(removekeyButton);
		layout2.addSpacerItem(new QSpacerItem(50, 50));
		
		QPushButton renameStyleButton = uiTool.getQPushButton(languageTool.getString(268), action, "renameStyle()");
		layout2.addWidget(renameStyleButton);
		
		QPushButton removeStyleButton = uiTool.getQPushButton(languageTool.getString(269), action, "removeStyle()");
		layout2.addWidget(removeStyleButton);
		
		QPushButton setAsDefaultStyle = uiTool.getQPushButton(languageTool.getString(1392), action, "setAsDefaultStyle()");
		layout2.addWidget(setAsDefaultStyle);
		
		dia.show();
		dia.setGeometry(dia.x(), dia.y(),getEditor().width(),getEditor().height());
		
		if(b != null) {
			b.showDialogAtCenter(dia);
		}

	}
	
	void saveStyle(){
		styleInfo si = getStyleInfo(getEditor());
		InputDialog id = new InputDialog(getEditor(),languageTool.getString(270),languageTool.getString(271),false,false,"",true) {
			
			@Override
			void whenOkButtonPressed() {
				if(copyLineText().isEmpty()) {
					return;
				}
				si.setStyleName(copyLineText());
				int index = -1;
				for(int i=0;i<styles.size();i++) {
					styleInfo s = styles.get(i);
					if(s.getStyleName().equals(si.getStyleName())) {
						index = i;
						break;
					}
				}
				if(index != -1) {
					styles.remove(index);
					styles.add(index, si);
				}else styles.add(si);
				stylesChaneged = true;
				showStyles();
				close();
				
			}
			
			@Override
			void whenClose() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub
				
			}
		};
		id.setMessageText(languageTool.getString(272));
		QComboBox cb = id.getComboBox();
		for(styleInfo s:styles)
			cb.addItem(s.getStyleName());
		cb.setCurrentText(languageTool.getString(273)+styles.size());
		id.show();
	}
	<T>T findChild(QObject object, Class<T> cl,String objectname) {
		T findChild = (T) object.findChild((Class<? extends QObject>) cl, objectname,FindChildOption.FindChildrenRecursively);
		if(cl.isInstance(findChild)) {
			return (T) cl.cast(findChild);
		}
		return null;
	}
	void setParagraphDone() {
		styleInfo si = getStyleInfo(getEditor());
		QObject o = getEditor();
		if(b != null) o = b;
		QDialog d = findChild(o, QDialog.class, "setParagraphDialog");
		if(d == null) return;
		
		QSpinBox sb0 = findChild(d, QSpinBox.class, "setParagraph0");
		QDoubleSpinBox dsb0 = findChild(d, QDoubleSpinBox.class, "setParagraph1");
		QComboBox cb0 = findChild(d, QComboBox.class, "setParagraph2");
		QDoubleSpinBox dsb1 = findChild(d, QDoubleSpinBox.class, "setParagraph3");
		QDoubleSpinBox dsb2 = findChild(d, QDoubleSpinBox.class, "setParagraph4");
		QDoubleSpinBox dsb3 = findChild(d, QDoubleSpinBox.class, "setParagraph5");
		QDoubleSpinBox dsb4 = findChild(d, QDoubleSpinBox.class, "setParagraph6");
		QDoubleSpinBox dsb5 = findChild(d, QDoubleSpinBox.class, "setParagraph7");
		QCheckBox chb0 = findChild(d, QCheckBox.class, "setParagraph8");
		QSpinBox sb1 = findChild(d, QSpinBox.class, "setParagraph9");
		QPushButton bt1 = findChild(d, QPushButton.class, "setParagraph10");
		QComboBox cb1 = findChild(d, QComboBox.class, "setParagraph11");
		QDoubleSpinBox dsb6 = findChild(d, QDoubleSpinBox.class, "setParagraph12");
		String indent = String.valueOf(sb0.value());
		String textindent = String.valueOf(dsb0.value());
		String lineheight = null;
		if(cb0.currentIndex() == 5) lineheight = "-1 "+dsb1.value();
		else lineheight = cb0.currentIndex()+" "+dsb1.value();
		String blockmargin = dsb2.value()+" "+dsb4.value()+" "+dsb3.value()+" "+dsb5.value();
		String headtype = String.valueOf(sb1.value());
		if(!chb0.isChecked()) {
			if(si.getHeadType() >= 1) headtype = "0";
			else if(si.getHeadType() <= 0) headtype = "-1";
		}
		String letterspace = cb1.currentIndex()+" "+dsb6.value();
		if(cb1.currentIndex() == 2) letterspace = "-1 "+dsb6.value();
		System.out.println("indent "+indent+" textindent "+ textindent+" lineheight "+lineheight+" blockmargin "+blockmargin+" headtype "+headtype+" letterspace "+letterspace);
		setStyle(getEditor(),null,"-1","-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "-1", indent, textindent, lineheight, blockmargin, headtype, "-1",letterspace);
		bt1.setEnabled(false);
	}
	void setParagraph0() {
		QObject o = getEditor();
		if(b != null) o = b;
		QDialog d = findChild(o, QDialog.class, "setParagraphDialog");
		if(d == null) return;
		
		QPushButton bt1 = findChild(d, QPushButton.class, "setParagraph10");
		if(bt1 == null) return;
		bt1.setEnabled(true);
		
		QComboBox cb0 = findChild(d, QComboBox.class, "setParagraph2");
		QDoubleSpinBox dsb1 = findChild(d, QDoubleSpinBox.class, "setParagraph3");
		if(cb0 == null)return;
		if(dsb1 == null) return;
		if(cb0.currentIndex() == 5 || cb0.currentIndex() == 0) dsb1.setEnabled(false);
		else dsb1.setEnabled(true);
		
		QComboBox cb1 = findChild(d, QComboBox.class, "setParagraph11");
		QDoubleSpinBox dsb6 = findChild(d, QDoubleSpinBox.class, "setParagraph12");
		if(cb1 == null || dsb6 == null) return;
		
		if(cb1.currentIndex() == 2) dsb6.setEnabled(false);
		else dsb6.setEnabled(true);
		
	}
	void setParagraphLineHeightComboBox() {
		QObject o = getEditor();
		if(b != null) o = b;
		QDialog d = findChild(o, QDialog.class, "setParagraphDialog");
		if(d == null) return;
		QComboBox cb0 = findChild(d, QComboBox.class, "setParagraph2");
		if(cb0 == null)return;
		QDoubleSpinBox dsb1 = findChild(d, QDoubleSpinBox.class, "setParagraph3");
		if(dsb1 == null) return;
		if(cb0.currentIndex() == 0 || cb0.currentIndex() == 5) {
			dsb1.setEnabled(false);
		}else dsb1.setEnabled(true);
	}
	void setParagraph() {
		styleInfo si = getStyleInfo(getEditor());
		System.out.println("lineheighttype "+si.getLineHeightType());
		QDialog dialog = null;
		if(b != null) dialog = new QDialog(b);
		else dialog = new QDialog(getEditor());
		dialog.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		WindowFlags wf = dialog.windowFlags();
		wf.clear(WindowType.WindowContextHelpButtonHint);
		dialog.setWindowFlags(wf);
		dialog.setWindowTitle(languageTool.getString(274));
		dialog.setObjectName("setParagraphDialog");
		dialog.setModal(true);
		QBoxLayout layout1 = uiTool.getBoxLayout(0);
		dialog.setLayout(layout1);
		QGroupBox groupBox1 = uiTool.getGroupBox(dialog,0,languageTool.getString(275));
		QSpinBox spinBox1 = uiTool.insertSpinBoxAutoLayout((QBoxLayout) groupBox1.layout(), languageTool.getString(275)+"：", -1, 1500, null, null, this, "setParagraph0()");
		spinBox1.setObjectName("setParagraph0");
		spinBox1.setValue(si.getIndent());
		QDoubleSpinBox spinBox2 = uiTool.insertDoubleSpinBoxAutoLayout((QBoxLayout) groupBox1.layout(), languageTool.getString(276)+"：", -1, 1500, null, null, this, "setParagraph0()");
		spinBox2.setObjectName("setParagraph1");
		spinBox2.setValue(si.getFirstLineIndent());
		spinBox2.textChanged.connect(this, "setParagraph0()");
		QGroupBox groupBox2 = uiTool.getGroupBox(dialog, 2, languageTool.getString(277));
		
		String [] items = new String[6];
		items[0] = languageTool.getString(278);
		items[1] = languageTool.getString(279);
		items[2] = languageTool.getString(280);
		items[3] = languageTool.getString(281);
		items[4] = languageTool.getString(282);
		items[5] = languageTool.getString(283);
		QComboBox comboBox1 = uiTool.getComboBox(groupBox2, null, false, items, this, "setParagraphLineHeightComboBox()");
		comboBox1.setObjectName("setParagraph2");
		comboBox1.setCurrentIndex(si.getLineHeightType());
		
		comboBox1.currentTextChanged.connect(this, "setParagraph0()");
		QDoubleSpinBox spinBox3 = new QDoubleSpinBox();
		spinBox3.textChanged.connect(this, "setParagraph0()");
		spinBox3.setMinimum(-1);
		spinBox3.setMaximum(1500);
		spinBox3.setValue(si.getLineHeightValue());
		spinBox3.setObjectName("setParagraph3");
		groupBox2.layout().addWidget(spinBox3);
		if(si.getLineHeightType() == -1) {
			comboBox1.setCurrentIndex(5);
			spinBox3.setEnabled(false);
		}
		//根据comboBox1选中的项目设置spinBox3是否启用
		setParagraphLineHeightComboBox();
		QGroupBox groupBox3 = uiTool.getGroupBox(dialog, 0, languageTool.getString(284));
		QDoubleSpinBox spinBox4 = uiTool.insertDoubleSpinBoxAutoLayout((QBoxLayout) groupBox3.layout(), languageTool.getString(285), -1, 1500, null, null, this, "setParagraph0()");
		spinBox4.setValue(si.getLeftMargin());
		spinBox4.setObjectName("setParagraph4");
		QDoubleSpinBox spinBox5 = uiTool.insertDoubleSpinBoxAutoLayout((QBoxLayout) groupBox3.layout(), languageTool.getString(286), -1, 1500, null, null, this, "setParagraph0()");
		spinBox5.setValue(si.getRightMargin());
		spinBox5.setObjectName("setParagraph5");
		QDoubleSpinBox spinBox6 = uiTool.insertDoubleSpinBoxAutoLayout((QBoxLayout) groupBox3.layout(), languageTool.getString(287), -1, 1500, null, null, this, "setParagraph0()");
		spinBox6.setValue(si.getTopMargin());
		spinBox6.setObjectName("setParagraph6");
		QDoubleSpinBox spinBox7 = uiTool.insertDoubleSpinBoxAutoLayout((QBoxLayout) groupBox3.layout(), languageTool.getString(288), -1, 1500, null, null, this, "setParagraph0()");
		spinBox7.setValue(si.getBottomMargin());
		spinBox7.setObjectName("setParagraph7");
		QGroupBox groupBox4 = uiTool.getGroupBox(dialog, 2, languageTool.getString(289));
		QCheckBox checkBox1 = uiTool.insertCheckBox(groupBox4.layout(), languageTool.getString(290));
		checkBox1.setObjectName("setParagraph8");
		QSpinBox spinBox8 = uiTool.insertSpinBoxAutoLayout((QBoxLayout) groupBox4.layout(), languageTool.getString(291), 1, 10, null, null, this, "setParagraph0()");
		spinBox8.setObjectName("setParagraph9");
		if(si.getHeadType() > 0) {
			checkBox1.setChecked(true);
		}else {
			checkBox1.setChecked(false);
			spinBox8.setEnabled(false);
		}
		spinBox8.setValue(si.getHeadType());
		checkBox1.clicked.connect(this, "setParagraph0()");
		checkBox1.clicked.connect(spinBox8, "setEnabled(boolean)");

		QBoxLayout layout2 = uiTool.getBoxLayout(3);
		QPushButton button1 = uiTool.getQPushButton(languageTool.getString(292), this, "setParagraph0()");
		button1.clicked.connect(dialog, "close()");
		QPushButton button2 = uiTool.getQPushButton(languageTool.getString(293), this, "setParagraphDone()");
		button2.setEnabled(false);
		button2.setObjectName("setParagraph10");
		layout2.addWidget(button1,100);
		layout2.addWidget(button2,100);
		
		QGroupBox groupBox5 = uiTool.getGroupBox(dialog, 2, languageTool.getString(294));
		String [] items1 = new String[3];
		items1[0] = languageTool.getString(295);
		items1[1] = languageTool.getString(296);
		items1[2] = languageTool.getString(297);
		QComboBox comboBox2 = uiTool.getComboBox(groupBox5, null, false, items1, this, "setParagraphLetterSpaceComboBox()");
		comboBox2.setObjectName("setParagraph11");
		comboBox2.setEditable(false);
		comboBox2.setCurrentIndex(si.getLetterSpaceType());
		comboBox2.currentTextChanged.connect(this, "setParagraph0()");
		QDoubleSpinBox spinBox9 = new QDoubleSpinBox();
		spinBox9.textChanged.connect(this, "setParagraph0()");
		spinBox9.setMinimum(-1500);
		spinBox9.setMaximum(1500);
		spinBox9.setValue(si.getLetterSpaceValue());
		spinBox9.setObjectName("setParagraph12");
		groupBox5.layout().addWidget(spinBox9);
		if(si.getLetterSpaceType() == -1) {
			comboBox2.setCurrentIndex(2);
			spinBox9.setEnabled(false);
		}

		
		layout1.addLayout(layout2);
		dialog.exec();
	}
	void setParagraphLetterSpaceComboBox() {
		
	}
	void decreaseFont() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "-1", "-1", "-1", "-1 -1", "-1 -1 -1 -1", "-1", "-1","-1 -1");
		cursorPositionChanged();
	}
	void increaseFont() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "-1", "-1", "-1", "-1 -1", "-1 -1 -1 -1", "-1", "1","-1 -1");
		cursorPositionChanged();
	}
	void indent() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "-1","0 1","-1");
	}
	void outdent() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "-1","1 1","-1");
	}
	QToolButton addToolButtonSvg(String tooltip,String iconfilename,String methodname){
		QToolButton bu = new QToolButton();
		bu.setToolTip(tooltip);
		bu.setIcon(getIconSvg(iconfilename));
		bu.clicked.connect(this, methodname);
		tools.addItem(bu);
		return bu;
	}
	QToolButton addToolButton(String tooltip,String iconfilename,String methodname,String objectname){
		return addToolButton(tooltip, false, iconfilename, methodname,objectname);
	}
	QToolButton addToolButton(String tooltip,boolean checkable,String iconfilename,String methodname,String objectname){
		QToolButton bu = new QToolButton();
		bu.setToolTip(tooltip);
		bu.setObjectName(objectname);
		bu.setCheckable(checkable);
		bu.setIcon(getIcon(iconfilename));
		bu.clicked.connect(this, methodname);
		tools.addItem(bu);
		return bu;
	}
	void setAlignJustify() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "0","-1","-1");
		setAlignJustify.setChecked(true);
		setAlignLeft.setChecked(false);
		setAlignCenter.setChecked(false);
		setAlignRight.setChecked(false);
	}
	void setAlignLeft() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "1","-1","-1");
		setAlignJustify.setChecked(false);
		setAlignLeft.setChecked(true);
		setAlignCenter.setChecked(false);
		setAlignRight.setChecked(false);
	}
	void setAlignCenter() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "2","-1","-1");
		setAlignJustify.setChecked(false);
		setAlignLeft.setChecked(false);
		setAlignCenter.setChecked(true);
		setAlignRight.setChecked(false);
	}
	void setAlignRight() {
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, null, "3","-1","-1");
		setAlignJustify.setChecked(false);
		setAlignLeft.setChecked(false);
		setAlignCenter.setChecked(false);
		setAlignRight.setChecked(true);
	}
	void setBackground() {
		styleInfo si = getStyleInfo(getEditor());
		if(lastUsedTextBackground != null) {
			if(si.getBackground() == null || si.getBackground().equals(defalutTextBackground.name())) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, lastUsedTextBackground.name(), "-1","-1","-1");
			}
			else if(si.getBackground().equals(lastUsedTextBackground.name())) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, "", "-1","-1","-1");
			}else
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, lastUsedTextBackground.name(), "-1","-1","-1");


		}else {
			QColor color = colorSelector(lastUsedTextBackground, defalutTextBackground);
			if(color != null) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, color.name(), "-1","-1","-1");
				lastUsedTextBackground = color;
			}
		}
	}
	void setBackgroundColor() {
		QColor color = colorSelector(lastUsedTextBackground, defalutTextBackground);
		if(color != null) {
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", null, color.name(), "-1","-1","-1");
			lastUsedTextBackground = color;
		}
	}
	void setForegroundColor() {
		QColor color = colorSelector(lastUsedTextForeground, defalutTextForeground);
		if(color != null) {
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", color.name(), null, "-1","-1","-1");
			lastUsedTextForeground = color;
		}
	}
	void setForeground() {
		styleInfo si = getStyleInfo(getEditor());
		if(lastUsedTextForeground != null) {
			if(si.getForeground() == null || si.getForeground().equals(defalutTextForeground.name())) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", lastUsedTextForeground.name(), null, "-1","-1","-1");
			}
			else if(si.getForeground().equals(lastUsedTextForeground.name())) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", "", null, "-1","-1","-1");
			}else
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", lastUsedTextForeground.name(), null, "-1","-1","-1");


		}else {
			QColor color = colorSelector(lastUsedTextForeground, defalutTextForeground);
			if(color != null) {
				setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "-1", color.name(), null, "-1","-1","-1");
				lastUsedTextForeground = color;
			}
		}
	}
	void setSubscript() {
		styleInfo si = getStyleInfo(getEditor());
		if(si.getSubscript() > 0)
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "0", null, null, "-1","-1","-1");
		else{
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "-1", "1", null, null, "-1","-1","-1");
			setSuperscript.setChecked(false);
		}
	}
	void setSuperscript() {
		styleInfo si = getStyleInfo(getEditor());
		if(si.getSuperscript() > 0)
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "0", "-1", null, null, "-1","-1","-1");
		else {
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, "-1", "1", "-1", null, null, "-1","-1","-1");
			setSubscript.setChecked(false);
		}
	}
	void underlineMenuShow() {
		setUnderLineButtonAndMenuState(getStyleInfo(getEditor()).getUnderline());
	}
	void underLineMenu() {
		QMenu underlinemenu = new QMenu();
		underlinemenu.aboutToShow.connect(this, "underlineMenuShow()");
		setUnderLine.setMenu(underlinemenu);
		QAction line0 = new QAction(languageTool.getString(298),setUnderLine);
		QAction line1 = new QAction(languageTool.getString(299),setUnderLine);
		QAction line2 = new QAction(languageTool.getString(300),setUnderLine);
		QAction line3 = new QAction(languageTool.getString(301),setUnderLine);
		QAction line4 = new QAction(languageTool.getString(302),setUnderLine);
		QAction line5 = new QAction(languageTool.getString(303),setUnderLine);
		QAction line6 = new QAction(languageTool.getString(304),setUnderLine);
		QAction line7 = new QAction(languageTool.getString(305),setUnderLine);
		line7.setCheckable(true);
		line7.setChecked(true);
		QAction linecolor = new QAction(languageTool.getString(306),setUnderLine);
		linecolor.setEnabled(false);
		line0.setObjectName("line1");
		line1.setObjectName("line2");
		line2.setObjectName("line3");
		line3.setObjectName("line4");
		line4.setObjectName("line5");
		line5.setObjectName("line6");
		line6.setObjectName("line7");
		line7.setObjectName("line0");
		linecolor.setObjectName("underlinecolor");
		line0.triggered.connect(this, "line0()");
		line1.triggered.connect(this, "line1()");
		line2.triggered.connect(this, "line2()");
		line3.triggered.connect(this, "line3()");
		line4.triggered.connect(this, "line4()");
		line5.triggered.connect(this, "line5()");
		line6.triggered.connect(this, "line6()");
		line7.triggered.connect(this, "line7()");
		linecolor.triggered.connect(this, "linecolor()");
		underlinemenu.addAction(line7);
		underlinemenu.addSeparator();
		underlinemenu.addAction(line0);
		underlinemenu.addAction(line1);
		underlinemenu.addAction(line2);
		underlinemenu.addAction(line3);
		underlinemenu.addAction(line4);
		underlinemenu.addAction(line5);
		underlinemenu.addAction(line6);
		underlinemenu.addSeparator();
		underlinemenu.addAction(linecolor);
		setUnderLine.setPopupMode(ToolButtonPopupMode.MenuButtonPopup);
	}
	/**
	 * 
	 * @param lastUsedColor 可以为null
	 * @param defaultColor 不能为null
	 * @return
	 */
	QColor colorSelector(QColor lastUsedColor,QColor defaultColor) {
		QColor based = lastUsedColor;
		if(lastUsedColor == null) based = defaultColor;
		QColor color = QColorDialog.getColor(based);
		if(color.isValid()) {
			//无效，需要在方法外调用
			lastUsedColor = color;
			return color;
		}
		else return null;
	}
	void linecolor(){
		QColor color = colorSelector(lastUsedUnderlineColor, new QColor(GlobalColor.black));
		if(color != null) {
			setStyle(getEditor(), null, "-1", "-1", "-1", "-1", color.name(), "-1", "-1", "-1", null, null, "-1","-1","-1");
			lastUsedUnderlineColor = color;
		}
	}
	void setUnderLine(int type) {
		styleInfo si = getStyleInfo(getEditor());
		int underline = si.getUnderline();
		if(underline == type) underline = 0;
		else underline = type;
		if(underline > 0) {
			lastUsedUnderlineType = underline;
			setUnderLine.setChecked(true);
		}else setUnderLine.setChecked(false);
		String colorname = null;
		if(lastUsedUnderlineColor != null) colorname = lastUsedUnderlineColor.name();
		setStyle(getEditor(), null, "-1", "-1", "-1", underline+"", colorname, "-1", "-1", "-1", null, null, "-1","-1","-1");
		setUnderLineButtonAndMenuState(type);
	}
	void line0() {
		setUnderLine(1);
	}
	void line1() {
		setUnderLine(2);
	}
	void line2() {
		setUnderLine(3);
	}
	void line3() {
		setUnderLine(4);
	}
	void line4() {
		setUnderLine(5);
	}
	void line5() {
		setUnderLine(6);
	}
	void line6() {
		setUnderLine(7);
	}
	void line7() {
		setUnderLine(0);
	}
	void setStrikeLine(){
		styleInfo si = getStyleInfo(getEditor());
		int strikeline = 0;
		if(si.getStrikeline() == 0) strikeline = 1;
		setStyle(getEditor(), null, "-1", "-1", "-1", "-1", null, strikeline+"", "-1", "-1", null, null, "-1","-1","-1");

	}
	static QIcon getIconSvg(String filename) {
		QIcon icon =  iconFromSvg(appInfo.icons_svg+filename, new QColor(GlobalColor.blue),new QSize(16,16));
		return icon;
	}
	QIcon getIcon(String filename) {
		return new QIcon(appInfo.icons_16+filename);
	}
	static QIcon iconFromSvg(String svg_path, QColor color,QSize size){
		String svgcode = io.readTextFile(new File(svg_path), "utf-8");
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		try {
			SVG2PNGUtils.convertToPng(svgcode, baos,size.width(),size.height());
			byte[] bytes = baos.toByteArray();
			if(bytes != null && bytes.length >= 0) {
				QPixmap pixmap = new QPixmap(size);
				pixmap.loadFromData(bytes);
				QIcon icon = new QIcon(pixmap);
				return icon;
			}
		} catch (TranscoderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	void setUnderLineButtonAndMenuState(int underlinestate){
		List<QAction> underlinecolor = setUnderLine.findChildren(QAction.class,"underlinecolor",FindChildOption.FindChildrenRecursively);
		for(QAction a:underlinecolor) {
			if(underlinestate == -1 || underlinestate == 0)
				a.setEnabled(false);
			else a.setEnabled(true);
		}
		for(int i=0;i<=7;i++) {
			List<QAction> chils1 = setUnderLine.findChildren(QAction.class,"line"+i,FindChildOption.FindChildrenRecursively);
			for(QAction a:chils1) {
				if(underlinestate == -1) {
					if(i > 0) {
						a.setCheckable(true);
						a.setChecked(false);
					}
					
				}else{
					if(underlinestate == i) {
						a.setCheckable(true);
						a.setChecked(true);
					}else {
						a.setCheckable(true);
						a.setChecked(false);
					}
				}
				
			}
		}
	}
	public void cursorPositionChanged(){
		QTextEdit text = getEditor();
//		QTextCursor tc = text.textCursor();
//		tc.movePosition(MoveOperation.PreviousCharacter,MoveMode.KeepAnchor);
//		QTextCharFormat cf = tc.charFormat();
//		QFont font = text.font();
//		font.setPointSize((int)(40+((bTextEdit)text).highlighter.zoomvalue));
//		text.setFont(font);
//		text.setCurrentFont(font);
//		text.setFontPointSize(font.pointSizeF());
		styleInfo si = getStyleInfo(text);
		checkStyleInfo(si);
		//使用多线程会导致虚拟机崩溃，目前发现至少在其他线程调用textcursor setpos函数会出现一定概率的虚拟机崩溃
		//不用多线程，测试刚果惊魂约二十多万字，全选性能也可以接受
//		if(cursorPositionChangedCheckAction != null) {
//			cursorPositionChangedCheckAction.stop();
//			cursorPositionChangedCheckAction = null;
//		}
//		cursorPositionChangedCheckAction = new bRunnable(100,true,false,false,true) {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				styleInfo si = getStyleInfo(getEditor());
//				if(black.b != null)
//				black.uiRun(black.b, new Runnable() {
//					
//					@Override
//					public void run() {
//						// TODO Auto-generated method stub
//						checkStyleInfo(si);
//					}
//				});
//				else checkStyleInfo(si);
//		}};
	}
	/**
	 * 根据得到的styleinfo信息设置样式板工具栏上的控件的状态
	 * @param si
	 */
	void checkStyleInfo(styleInfo si) {
		ignoreComboxChange = true;
		if(si.getFontname() != null)
			setFont.setCurrentFont(new QFont(si.getFontname()));
		else setFont.setCurrentIndex(-1);
		ignoreComboxChange = false;
		
		ignoreComboxChange = true;
		String valueOf = String.valueOf(si.getFontsize());
		if(si.getFontsize() != -1) {
			int findText = setFontSize.findText(valueOf);
			if(findText != -1) setFontSize.setCurrentIndex(findText);
			else setFontSize.setEditText(valueOf);
		}else setFontSize.setEditText("");
		ignoreComboxChange = false;
		
		boolean bold = intToBoolean(si.getBold());
		setBold.setChecked(bold);
		
		boolean itialc = intToBoolean(si.getItialc());
		setItalic.setChecked(itialc);
		
		boolean underline = false;
		if(si.getUnderline() > 0) underline = true;
		setUnderLine.setChecked(underline);
		
		boolean strikeline = intToBoolean(si.getStrikeline());
		setStrikeLine.setChecked(strikeline);
		
		boolean superscript = intToBoolean(si.getSuperscript());
		setSuperscript.setChecked(superscript);
		
		boolean subscript = intToBoolean(si.getSubscript());
		setSubscript.setChecked(subscript);
		
		int align = si.getAlign();
		if(align == 0) {
			setAlignJustify.setChecked(true);
			setAlignLeft.setChecked(false);
			setAlignCenter.setChecked(false);
			setAlignRight.setChecked(false);
		}else if(align == 1) {
			setAlignJustify.setChecked(false);
			setAlignLeft.setChecked(true);
			setAlignCenter.setChecked(false);
			setAlignRight.setChecked(false);
		}else if(align == 2) {
			setAlignJustify.setChecked(false);
			setAlignLeft.setChecked(false);
			setAlignCenter.setChecked(true);
			setAlignRight.setChecked(false);
		}else if(align == 3) {
			setAlignJustify.setChecked(false);
			setAlignLeft.setChecked(false);
			setAlignCenter.setChecked(false);
			setAlignRight.setChecked(true);
		}else if(align == -1) {
			setAlignJustify.setChecked(false);
			setAlignLeft.setChecked(false);
			setAlignCenter.setChecked(false);
			setAlignRight.setChecked(false);
		}
		boolean find = false;
		for(int i=0;i<styles.size();i++) {
			styleInfo s = styles.get(i);
			if(s.isSameStyle(si)) {
				selectStyle.setCurrentIndex(i);
				find = true;
				break;
			}
		}
		if(!find) selectStyle.setCurrentIndex(-1);
	}
	void setStyle(QTextEdit text,String fontname,String fontsize,String bold,String italic) {
		setStyle(text, fontname, fontsize, bold, italic, "-1", null, "-1", "-1", "-1", null, null, "-1","-1","-1");
	}
	void setStyle(QTextEdit text,String fontname,String fontsize,String bold,String italic,String underline,String underlinecolor,String strikeline,String superscript,String subscript,String foreground,String background,String align,String indent,String textindent) {
		setStyle(text, fontname, fontsize, bold, italic, underline, underlinecolor, strikeline, superscript, subscript, foreground, background, align, indent, textindent,"-1 -1","-1 -1 -1 -1","-1","0","-1 -1");
	}
	/**
	 * 统一设置样式的方法，所有参数均以字符串的形式提供，忽略时必须提供忽略参数，避免产生异常
	 * @param getEditor() 需要设置样式的QTextEdit
	 * @param fontname 忽略时为null或空字符串
	 * @param fontsize 忽略时为-1
	 * @param bold 0不是粗体；1是粗体；其他参数均为不改动
	 * @param italic 0不是斜体；1是斜体，其他均为不改动
	 * @param underline 大于0为设置各种样式的下划线，0为不设置，-1为忽略
	 * @param underlinecolor null为忽略, 空字符串为重置，其他为16进制颜色代码
	 * @param strikeline 0不设置，1设置，-1忽略
	 * @param superscript 0不设置，1设置，-1忽略
	 * @param subscript 0不设置，1设置，-1忽略
	 * @param foreground null为忽略, 空字符串为重置，其他为16进制颜色代码
	 * @param background null为忽略, 空字符串为重置，其他为16进制颜色代码
	 * @param align 0左分散对齐，1居左对齐，2中对齐，3右对齐，-1忽略
	 * @param indent 需提供两个或一个参数，参数1是int值，可以省略，用来指示如何设置缩进，不提供或设为-1时强制将所有选中段落的缩进设为参数2给定的值，参数1为0时选择的段落的缩进在原有值基础上减去参数2给定值，为1时在原有基础上加参数2给定值，参数2为-1时忽略此设置
	 * @param textindent 同indent参数
	 * @param lineheight 行高，一个字符串参数中包含两个参数，第一个参数是int类型，为行高类型，第二个是double类型，为行高值，所有参数都必须提供，用空格隔开，行高类型为-1时忽略设置，其他值为QBlockformat中的行高枚举int值，参数2是行高值，可以为任何数值，
	 * @param blockmargin 段落边距，一个字符串参数中包含4个double参数，分别为左、上、右、下的距离，所有参数都必须提供，用空格隔开，每个参数为-1时忽略对应设置
	 * @param headtype 标题级别，-1忽略，0是正文，大于0是标题类型，1是一级标题，为最大的标题
	 * @param increasetext 在字体原有字号基础上增加或减小字号，为double字符串，0忽略，正数增加，负数减小
	 * @param letterspace 字符间距，字符串中需包含两个参数，一个为int类型，一个为double类型，用空格隔开，两个参数都必须提供，参数1为-1时忽略设置，0是相对字距，1是绝对字距，参数2可以为任何数值，参数1为0是绝对间距，1为相对间距，参数2是间距值
	 */
	void setStyle(QTextEdit text,String fontname,String fontsize,String bold,String italic,String underline,String underlinecolor,String strikeline,String superscript,String subscript,String foreground,String background,String align,String indent,String textindent,String lineheight,String blockmargin,String headtype,String increasetext,String letterspace) {
		if(text == null) return;
		double editorFontSize = text.font().pointSizeF();
		double fontSize = -1;
		int setBold = -1;
		int setItalic = -1;
		int setUnderLine = -1;
		QColor setUnderLineColor = null;
		if(underlinecolor != null && !underlinecolor.isEmpty()) setUnderLineColor = new QColor(underlinecolor);
		int setStrikeLine = -1;
		int setSuperScript = -1;
		int setSubScript = -1;
		QColor setForeground = null;
		if(foreground != null && !foreground.isEmpty()) setForeground = new QColor(foreground);
		QColor setBackground = null;
		if(background != null && !background.isEmpty()) setBackground = new QColor(background);
		int setAlign = -1;
		double firstLineIndent = -1;
		int lineHeightType = -1;
		double lineHeightValue = -1;
		String[] lineHeightArgs = null;
		double marginLeft=-1,marginRight=-1,marginTop=-1,marginBottom=-1;
		String[] blockMarginArgs = null;
		int headType = -1;
		double increaseText = -1;
		int letterSpaceType = -1;
		double letterSpaceValue = -1;
		String[] letterSpaceArgs = null;
		int indentType = -1;
		int indentValue = -1;
		String[] indentArgs = null;
		
		indentArgs = cheakDocument.checkCommandArgs(indent);
		lineHeightArgs = cheakDocument.checkCommandArgs(lineheight);
		blockMarginArgs = cheakDocument.checkCommandArgs(blockmargin);
		letterSpaceArgs = cheakDocument.checkCommandArgs(letterspace);

		//try内任意一个valueOf出异常都会导致其之后到catch之前的代码不被执行
		try {
			fontSize = Double.valueOf(fontsize);
			setBold = Integer.valueOf(bold);
			setItalic = Integer.valueOf(italic);
			setUnderLine = Integer.valueOf(underline);
			setStrikeLine = Integer.valueOf(strikeline);
			setSuperScript = Integer.valueOf(superscript);
			setSubScript = Integer.valueOf(subscript);
			setAlign = Integer.valueOf(align);
			firstLineIndent = Double.valueOf(textindent);
			if(indentArgs != null && indentArgs.length == 2) {
				indentType = Integer.valueOf(indentArgs[0]);
				indentValue = Integer.valueOf(indentArgs[1]);
			}else if( indentArgs != null && indentArgs.length == 1) {
				indentValue = Integer.valueOf(indentArgs[0]);
			}
			if(lineHeightArgs != null && lineHeightArgs.length == 2) {
				lineHeightType = Integer.valueOf(lineHeightArgs[0]);
				lineHeightValue = Double.valueOf(lineHeightArgs[1]);
			}
			if(blockMarginArgs != null && blockMarginArgs.length == 4) {
				marginLeft = Double.valueOf(blockMarginArgs[0]);
				marginTop = Double.valueOf(blockMarginArgs[1]);
				marginRight = Double.valueOf(blockMarginArgs[2]);
				marginBottom = Double.valueOf(blockMarginArgs[3]);
			}
			headType = Integer.valueOf(headtype);
			increaseText = Double.valueOf(increasetext);
			if(letterSpaceArgs != null && letterSpaceArgs.length == 2) {
				letterSpaceType = Integer.valueOf(letterSpaceArgs[0]);
				letterSpaceValue = Double.valueOf(letterSpaceArgs[1]);
			}
		}catch(Exception e) {}
		
		//上下标当其中一个启用时，另一个如果没有启用，必须设置为忽略，而不是显式禁用，否则会导致显式禁用的设置覆盖前面已经启用的设置
		if(setSuperScript == 1 && setSubScript == 0) setSubScript = -1;
		else if(setSuperScript == 0 && setSubScript == 1) setSuperScript = -1;
		
		long a = System.currentTimeMillis();
		QTextCharFormat cf = new QTextCharFormat();
		
		//设置字体名称
		if(fontname != null && !fontname.isEmpty()) {
			//这行代码不工作
//			cf.setFontFamily(fontname);
			ArrayList<String> al = new ArrayList<String>();
			al.add(fontname);
			cf.setFontFamilies(al);
		}
		//设置字体字号
		if(fontSize != -1)
			cf.setFontPointSize(fontSize);
		//设置粗体
		if(setBold == 1) cf.setFontWeight(QFont.Weight.Bold.value());
		else if(setBold == 0) cf.setFontWeight(QFont.Weight.Normal.value());
		//设置斜体
		if(setItalic == 1) cf.setFontItalic(true);
		else if(setItalic == 0) cf.setFontItalic(false);
		//设置下划线
		if(setUnderLine == 0) cf.setUnderlineStyle(UnderlineStyle.NoUnderline);
		else if(setUnderLine == 1) cf.setUnderlineStyle(UnderlineStyle.DashDotDotLine);
		else if(setUnderLine == 2) cf.setUnderlineStyle(UnderlineStyle.DashDotLine);
		else if(setUnderLine == 3) cf.setUnderlineStyle(UnderlineStyle.DashUnderline);
		else if(setUnderLine == 4) cf.setUnderlineStyle(UnderlineStyle.DotLine);
		else if(setUnderLine == 5) cf.setUnderlineStyle(UnderlineStyle.SingleUnderline);
		else if(setUnderLine == 6) cf.setUnderlineStyle(UnderlineStyle.SpellCheckUnderline);
		else if(setUnderLine == 7) cf.setUnderlineStyle(UnderlineStyle.WaveUnderline);
		//设置下划线颜色
		if(setUnderLineColor != null)
			cf.setUnderlineColor(setUnderLineColor);
		else if(underlinecolor != null && underlinecolor.isEmpty())
			cf.setUnderlineColor(null);			
		
		//设置删除线
		if(setStrikeLine == 1) cf.setFontStrikeOut(true);
		else if(setStrikeLine == 0) cf.setFontStrikeOut(false);
		//设置上标
		if(setSuperScript == 1)
			cf.setVerticalAlignment(VerticalAlignment.AlignSuperScript);
		else if(setSuperScript == 0) cf.setVerticalAlignment(VerticalAlignment.AlignNormal);
		//设置下标
		if(setSubScript == 1)
			cf.setVerticalAlignment(VerticalAlignment.AlignSubScript);
		else if(setSubScript == 0) cf.setVerticalAlignment(VerticalAlignment.AlignNormal);
		//设置字体前景色
		if(setForeground != null)
			cf.setForeground(new QBrush(setForeground));
		else if(foreground != null && foreground.isEmpty()) {
			//下面这行不工作
//			cf.clearForeground();
			cf.setForeground(null);
		}
	
		//设置字体背景色
		if(setBackground != null)
			cf.setBackground(new QBrush(setBackground));
		else if(background != null && background.isEmpty())
			cf.setBackground(null);
		
		//设置字符间距
		if(letterSpaceType == 0) {
			cf.setFontLetterSpacingType(SpacingType.PercentageSpacing);
			cf.setFontLetterSpacing(letterSpaceValue);
		}else if(letterSpaceType == 1) {
			cf.setFontLetterSpacingType(SpacingType.AbsoluteSpacing);
			cf.setFontLetterSpacing(letterSpaceValue);
		}
		QTextBlockFormat tbf = new QTextBlockFormat();
		//设置对齐方式
		if(setAlign == 0) {
			 tbf.setAlignment(AlignmentFlag.AlignJustify);
		}else if(setAlign == 1) {
			tbf.setAlignment(AlignmentFlag.AlignLeft);
		}else if(setAlign == 2) {
			tbf.setAlignment(AlignmentFlag.AlignCenter);
		}else if(setAlign == 3)
			tbf.setAlignment(AlignmentFlag.AlignRight);
		
		//设置缩进（缩进为统一值）
		if(indentValue >= 0 && indentType == -1)
			tbf.setIndent(indentValue);

		//设置首行缩进
		if(firstLineIndent >= 0)
			tbf.setTextIndent(firstLineIndent);
		//设置行高
		if(lineHeightType >= 0) {
			tbf.setLineHeight(lineHeightValue, lineHeightType);
		}
		//设置段落边距
		if(marginLeft >= 0) tbf.setLeftMargin(marginLeft);
		if(marginRight >= 0) tbf.setRightMargin(marginRight);
		if(marginTop >= 0) tbf.setTopMargin(marginTop);
		if(marginBottom >= 0) tbf.setBottomMargin(marginBottom);
		
		//设置段落标题级别
		if(headType >= 0)
			tbf.setHeadingLevel(headType);
		
		
		QTextCursor tc = text.textCursor();
		int start = tc.selectionStart(),end = tc.selectionEnd();
		tc.beginEditBlock();
		tc.mergeCharFormat(cf);
		tc.mergeBlockFormat(tbf);
		
		//下面应用那些需要精细遍历格式的动作，这些动作会显著增加操作延迟
		
		//这里放置那些需要遍历每个选中的字符的格式的操作
		boolean needCheckEveryCharFormat = false;
		//添加开启检查的条件
		if(increaseText != 0) needCheckEveryCharFormat = true;
		
		//没有选中文本
		if(needCheckEveryCharFormat && start == end) {
			needCheckEveryCharFormat = false;
			//增加或减小字号
			QTextCharFormat cff = text.currentCharFormat();
			double formatfontsize = cff.fontPointSize();
			if(formatfontsize == 0 || formatfontsize == -1) formatfontsize = editorFontSize;
			double newsize = formatfontsize+increaseText;
			if(newsize > 1) {
				QTextCharFormat tcff = new QTextCharFormat();
				tcff.setFontPointSize(newsize);
				text.mergeCurrentCharFormat(tcff);
			}
		}
		
		if(needCheckEveryCharFormat) {
			tc.setPosition(start);
			int startblock = tc.blockNumber();
			tc.setPosition(end);
			int endblock = tc.blockNumber();
			QTextDocument doc = tc.document();
			for(int i=startblock;i<=endblock;i++) {
				QTextBlock block = doc.findBlockByNumber(i);
				List<FormatRange> trs = block.textFormats();
				for(FormatRange tr:trs) {
					int posStart = tr.start()+block.position();
					int posEnd = posStart+tr.length();
					tc.setPosition(posStart);
					tc.setPosition(posEnd, MoveMode.KeepAnchor);
					if(start >= tc.selectionEnd()) continue;
					else if(end <= tc.selectionStart()) break;
					
//					QTextCharFormat cff = tc.charFormat();
					QTextCharFormat cff = tr.format();
					
					//选中的文本首尾都包含在某个格式区域内，要更改格式的区域就是选中文本的自身位置
					if(start >= tc.selectionStart() && start <= tc.selectionEnd()
							&&
							end >= tc.selectionStart() && end <= tc.selectionEnd()) {
						tc.setPosition(start);
						tc.setPosition(end,MoveMode.KeepAnchor);
						//选中的文本首包含某个格式区域内，要更改格式的区域是选中文本的起始位置到格式区域的末尾
					}else if(start >= tc.selectionStart() && start <= tc.selectionEnd()) {
						tc.setPosition(start);
						tc.setPosition(posEnd,MoveMode.KeepAnchor);
						//选中的文本尾部包含某个格式区域内，要更改格式的区域是格式区域的开始到选中文本的末尾
					}else if(end >= tc.selectionStart() && end <= tc.selectionEnd()) {
						tc.setPosition(posStart);
						tc.setPosition(end,MoveMode.KeepAnchor);
					}
					//增加或减小字号
					double formatfontsize = cff.fontPointSize();
					if(formatfontsize == 0 || formatfontsize == -1) formatfontsize = editorFontSize;
					double newsize = formatfontsize+increaseText;
					if(newsize > 1) {
						QTextCharFormat tcff = new QTextCharFormat();
						tcff.setFontPointSize(newsize);
						tc.mergeCharFormat(tcff);
					}
//					System.out.println("getstyles: "+ tr.start()+" "+tr.length()+" blockpos: "+block.position());
				}
			}
			
			
			
		}
		
		//这里放置那些需要遍历每个选中的段落的格式的操作
		boolean needCheckEveryBlockFormat = false;
		//添加开启检查的条件
		if(indentType != -1 && indentValue >= 0) needCheckEveryBlockFormat = true;
		
		if(needCheckEveryBlockFormat) {
			tc.setPosition(start);
			int startBlockNumber = tc.blockNumber();
			tc.setPosition(end);
			int endBlockNumber = tc.blockNumber();
//			System.out.println("test "+start+"  "+end);
			QTextDocument doc = tc.document();
			for(int i=startBlockNumber;i<=endBlockNumber;i++) {
//				System.out.println("checkblockformat "+ i);
				QTextBlock block = doc.findBlockByNumber(i);
				QTextBlockFormat bf = block.blockFormat();
				tc.setPosition(block.position()+1);
				tc.setPosition(block.position()+block.length()-1,MoveMode.KeepAnchor);
				//设置文本缩进
				if(indentType == 0) {
					if(bf.indent() > 0) {
						QTextBlockFormat bff = new QTextBlockFormat();
						bff.setIndent(bf.indent()-indentValue);
						tc.mergeBlockFormat(bff);
					}
				}else if(indentType == 1) {
					QTextBlockFormat bff = new QTextBlockFormat();
					if(bf.indent() >= 0)
						bff.setIndent(bf.indent()+indentValue);
					else
						bff.setIndent(indentValue);
					tc.mergeBlockFormat(bff);
				}
			}
		}

		tc.endEditBlock();
		
		a = System.currentTimeMillis()-a;
	}
	
	/**获取给定的text编辑器中光标位置下内容的样式（如果有选中的文本就返回选中文本包含的样式，如果没有选中文本则返回光标位置的样式）
	 * <br>返回值:
	 * <br>	字体名称，如果存在多个字体名称返回null，否则返回具体的字体名称
	 * <br>	字号，如果存在多个字号，返回-1，否则返回具体的字号
	 * <br>	粗体，-1不可用，1粗体
	 * <br>	斜体，-1不可用，1斜体
	 * <br>	下划线，-1不可用，其他值为对应的样式的下划线
	 * <br>	下划线颜色，null为不可用，其他为颜色名称
	 * <br>	删除线，-1不可用，1启用
	 * <br>	上标，1启用，其他不启用
	 * <br>	下标，同上标一样
	 * <br>	前景色，null不可用，其他为颜色名称，返回的颜色可能为编辑器预设的颜色，所以需要对颜色进行对比判断
	 * <br>	背景色，同前景色一样
	 * <br> 对齐方式，0分散对齐，1居中，2居右，-1不可用
	 * <br>	文本缩进，-1不可用，正值为缩进值
	 * <br>	首行缩进，-1不可用，正值为缩进值
	 * @param text
	 * 
	 * 
	 */
	styleInfo getStyleInfo(QTextEdit text) {
		if(text == null) return new styleInfo();
		String fontname = "";
		double fontsize = -2;
		int bold = -2;
		int italic = -2;
		int underline = -2;
		String underlinecolor = "-1";
		int strikeline = -2;
		int superscript = -2;
		int subscript = -2;
		String foreground = "-1";
		String background = "-1";
		int align = -2;
		int indent = -2;
		double textindent = -2;
		int lineHeightType = -2;
		double lineHeightValue = -2;
		double leftMargin=-2,rightMargin=-2,topMargin=-2,bottomMargin=-2;
		int headType = -2;
		int letterSpaceType = -2;
		double letterSpaceValue = -2;
		QTextCursor tc = text.textCursor();

		if(tc.hasSelection()) {
			int start = tc.selectionStart(),end = tc.selectionEnd();
			tc.setPosition(start);
			int startblock = tc.blockNumber();
			tc.setPosition(end);
			int endblock = tc.blockNumber();
			QTextDocument doc = tc.document();
			for(int i=startblock;i<=endblock;i++) {
				QTextBlock block = doc.findBlockByNumber(i);
				QTextBlockFormat bf = block.blockFormat();
				List<FormatRange> trs = block.textFormats();
				for(FormatRange tr:trs) {
					int formatstart = tr.start()+block.position();
					int formatend = formatstart+tr.length();
//					tc.setPosition(pos);
//					tc.setPosition(pos+tr.length(), MoveMode.KeepAnchor);
					if(start >= formatend) continue;
					else if(end <= formatstart) break;
//					System.out.println("getstyles: "+ tr.start()+" "+tr.length()+" blockpos: "+block.position());
					
					QTextCharFormat cf = tr.format();
					
					QFont font = cf.font();
					//解析字体名称
					if(fontname != null) {
						List <String> ff = (List) cf.fontFamilies();
						String fn = null;
						if(ff != null)
							fn = ff.get(0);
						if(fontname.isEmpty()) fontname = fn;
						else if(!fontname.equals(fn)) fontname = null;
					}
					//解析字体字号
					if(fontsize == -2 || fontsize >= 0) {
						if(fontsize == -2) fontsize = font.pointSizeF();
						else if(fontsize != font.pointSizeF()) fontsize = -1;
					}
					//解析粗体
					if(bold == -2 || bold >= 0) {
						if(bold == -2) bold = booleanToInt(font.bold());
						else if(bold != booleanToInt(font.bold())) bold = -1;
					}
					//解析斜体
					if(italic == -2 || italic >= 0) {
						if(italic == -2) italic = booleanToInt(font.italic());
						else if(italic != booleanToInt(font.italic())) italic = -1;
					}
					//解析下划线
					if(underline == -2 || underline >= 0) {
						if(underline == -2) underline = getUnderLineStyle(cf);
						else if(underline != getUnderLineStyle(cf)) underline = -1;
					}
					//解析下划线颜色
					if(underlinecolor != null || "-1".equals(underlinecolor)) {
						QColor color = cf.underlineColor();
						String color_ = null;
						if(color != null) color_ = color.name();
						else color_ = "";
						if(underlinecolor.equals("-1")) {
							underlinecolor = color_;
						}else if(!underlinecolor.equals(color_)) underlinecolor = null;
					}

					//解析删除线
					
					if(strikeline == -2 || strikeline >= 0) {
						if(strikeline == -2) strikeline = booleanToInt(cf.fontStrikeOut());
						else if(strikeline != booleanToInt(cf.fontStrikeOut())) strikeline = -1;
					}
					
					//解析上标
					if(superscript == -2 || superscript >= 0) {
						VerticalAlignment va = cf.verticalAlignment();
						int supers = -1;
						if(va == VerticalAlignment.AlignSuperScript) supers = 1;
						else supers = 0;
						if(superscript == -2) {
							superscript = supers;
						}else if(superscript != supers) superscript = -1;
					}
					//解析下标
					if(subscript == -2 || subscript >= 0) {
						VerticalAlignment va = cf.verticalAlignment();
						int subs = -1;
						if(va == VerticalAlignment.AlignSubScript) subs = 1;
						else subs = 0;
						if(subscript == -2) {
							subscript = subs;
						}else if(subscript != subs) subscript = -1;
					}
					
					
					//解析字体前景色
					if(foreground != null || "-1".equals(foreground)) {
						QColor color = cf.foreground().color();
						String color_ = null;
						if(color != null && cf.foreground().isOpaque()) color_ = color.name();
						else color_ = "";
						if(foreground.equals("-1")) {
							foreground = color_;
						}else if(!foreground.equals(color_)) foreground = null;
					}
					
					//解析字体背景色
					if(background != null || "-1".equals(background)) {
						//需要根据笔刷的透明度来判断是否设置了颜色，如果没有设置颜色，笔刷是透明的
						QBrush bursh = cf.background();
						QColor color = bursh.color();
						String color_ = null;
						if(color != null && bursh.isOpaque()) color_ = color.name();
						else color_ = "";
						if(background.equals("-1")) {
							background = color_;
						}else if(!background.equals(color_)) background = null;
					}
					
					//解析对齐方式
					if(align == -2 || align >= 0) {
						if(align == -2) align = getAlign(bf);
						else if(align != getAlign(bf)) align = -1;
					}
					
					//解析文本缩进值
					if(indent == -2 || indent >= 0) {
						if(indent == -2) indent = bf.indent();
						else if(indent != bf.indent()) indent = -1;
					}
					
					//解析首行缩进值
					if(textindent == -2 || textindent >= 0) {
						if(textindent == -2) textindent = bf.textIndent();
						else if(textindent != bf.textIndent()) textindent = -1;
					}
					//解析行高类型
					if(lineHeightType == -2 || lineHeightType >= 0) {
						if(lineHeightType == -2) lineHeightType = bf.lineHeightType();
						else if(lineHeightType != bf.lineHeightType()) lineHeightType = -1;
					}
					//解析行高值
					if(lineHeightValue == -2 || lineHeightValue >= 0) {
						if(lineHeightValue == -2) lineHeightValue = bf.lineHeight();
						else if(lineHeightValue != bf.lineHeight()) lineHeightValue = -1;
					}
					//解析段落边距
					if(leftMargin == -2 || leftMargin >= 0) {
						if(leftMargin == -2) leftMargin = bf.leftMargin();
						else if(leftMargin != bf.leftMargin()) leftMargin = -1;
					}
					if(rightMargin == -2 || rightMargin >= 0) {
						if(rightMargin == -2) rightMargin = bf.rightMargin();
						else if(rightMargin != bf.rightMargin()) rightMargin = -1;
					}
					if(topMargin == -2 || topMargin >= 0) {
						if(topMargin == -2) topMargin = bf.topMargin();
						else if(topMargin != bf.topMargin()) topMargin = -1;
					}
					if(bottomMargin == -2 || bottomMargin >= 0) {
						if(bottomMargin == -2) bottomMargin = bf.bottomMargin();
						else if(bottomMargin != bf.bottomMargin()) bottomMargin = -1;
					}
					if(headType == -2 || headType >= 0) {
						if(headType == -2) headType = bf.headingLevel();
						else if(headType != bf.headingLevel()) headType = -1;
					}
					if(letterSpaceType == -2 || letterSpaceType >= 0) {
						if(letterSpaceType == -2) letterSpaceType = cf.fontLetterSpacingType().value();
						else if(letterSpaceType != cf.fontLetterSpacingType().value()) letterSpaceType = -1;
					}
					if(letterSpaceValue == -2 || letterSpaceValue >= 0) {
						if(letterSpaceValue == -2) letterSpaceValue = cf.fontLetterSpacing();
						else if(letterSpaceValue != cf.fontLetterSpacing()) letterSpaceValue = -1;
					}
				}
			}
			
			
		}
		else {
			QTextCharFormat cf = tc.charFormat();
			QTextBlockFormat bf = tc.blockFormat();
			QFont font = cf.font();
			List <String> ff = (List) cf.fontFamilies();
			if(ff != null)
				fontname = ff.get(0);
			fontsize = font.pointSizeF();
			bold = booleanToInt(font.bold());
			italic = booleanToInt(font.italic());
			underline = getUnderLineStyle(cf);
			underlinecolor = null;
			QColor underlineColor = cf.underlineColor();
			if(underlineColor != null) underlinecolor = underlineColor.name();
			strikeline = booleanToInt(cf.fontStrikeOut());
			VerticalAlignment va = cf.verticalAlignment();
			if(va == VerticalAlignment.AlignSuperScript) superscript = 1;
			else if(va == VerticalAlignment.AlignSubScript) subscript = 1;
			else {
				superscript = -1;
				subscript = -1;
			}
			QColor fore = cf.foreground().color();
			if(fore != null && cf.foreground().isOpaque()) foreground = fore.name();
			else foreground = null;
			
			QColor back = cf.background().color();
			if(back != null && cf.background().isOpaque()) background = back.name();
			else background = null;
			
			align = getAlign(bf);
			
			indent = bf.indent();
			textindent = bf.textIndent();
			
			lineHeightType = bf.lineHeightType();
			lineHeightValue = bf.lineHeight();
			
			leftMargin = bf.leftMargin();
			rightMargin = bf.rightMargin();
			topMargin = bf.topMargin();
			bottomMargin = bf.bottomMargin();
			
			headType = bf.headingLevel();
			
			letterSpaceType = cf.fontLetterSpacingType().value();
			letterSpaceValue = cf.fontLetterSpacing();
		}
		styleInfo si = new styleInfo();
		si.setFontname(fontname);
		si.setFontsize(fontsize);
		si.setBold(bold);
		si.setItialc(italic);
		si.setUnderline(underline);
		si.setUnderlinecolor(underlinecolor);
		si.setStrikeline(strikeline);
		si.setSuperscript(superscript);
		si.setSubscript(subscript);
		si.setForeground(foreground);
		si.setBackground(background);
		si.setAlign(align);
		si.setIndent(indent);
		si.setFirstLineIndent(textindent);
		si.setLineHeightType(lineHeightType);
		si.setLineHeightValue(lineHeightValue);
		si.setLeftMargin(leftMargin);
		si.setRightMargin(rightMargin);
		si.setTopMargin(topMargin);
		si.setBottomMargin(bottomMargin);
		si.setHeadType(headType);
		si.setLetterSpaceType(letterSpaceType);
		si.setLetterSpaceValue(letterSpaceValue);
		return si;
	}
	
	int getAlign(QTextBlockFormat bf) {
		Alignment ali = bf.alignment();
		if(ali.isSet(AlignmentFlag.AlignJustify)) return 0;
		else if(ali.isSet(AlignmentFlag.AlignLeft)) return 1;
		else if(ali.isSet(AlignmentFlag.AlignCenter)) return 2;
		else if(ali.isSet(AlignmentFlag.AlignRight)) return 3;
		else return -1;
	}
	/**
	 * 	case NoUnderline: return 0; //无线
		case DashDotDotLine: return 1; //短线 点 点
		case DashDotLine: return 2; //短线 点
		case DashUnderline: return 3; //短线
		case DotLine: return 4; //点线
		case SingleUnderline: return 5; //连续线
		case SpellCheckUnderline: return 6; //拼写检查线
		case WaveUnderline: return 7;//波浪线
		
	 * @param cf
	 * @return
	 */
	int getUnderLineStyle(QTextCharFormat cf) {
		UnderlineStyle underlineStyle = cf.underlineStyle();
		switch(underlineStyle) {
		case NoUnderline: return 0;
		case DashDotDotLine: return 1;
		case DashDotLine: return 2;
		case DashUnderline: return 3;
		case DotLine: return 4;
		case SingleUnderline: return 5;
		case SpellCheckUnderline: return 6;
		case WaveUnderline: return 7;
		}
		return -1;
	}
	/**
	 * true返回1，其他值均返回0
	 * @param b
	 * @return
	 */
	int booleanToInt(boolean b) {
		if(b) return 1;
		else return 0;
	}
	/**
	 * 1返回true，其他值均返回false
	 * @param i
	 * @return
	 */
	boolean intToBoolean(int i) {
		if(i == 1)return true;
		else return false;
	}
	void changedFont(QFont font) {
		if(font == null) return;
		if(ignoreComboxChange) return;
		setStyle(getEditor(),font.family(), "-1", "-1", "-1");
		getEditor().setFocus();
	}
	void changedFontSize(String fontsize) {
		if(fontsize.isEmpty()) return;
		if(ignoreComboxChange) return;
		setStyle(getEditor(),null, fontsize, "-1", "-1");
	}
	void setBold() {
		styleInfo si = getStyleInfo(getEditor());
		int bold = si.getBold();
		if(bold == 1) {
			bold = 0;
		}
		else {
			bold = 1;
		}
		setStyle(getEditor(), null, "-1", String.valueOf(bold), String.valueOf(-1));
	}
	void setItalic(){
		styleInfo si = getStyleInfo(getEditor());
		int itialc = si.getItialc();
		if(itialc == 1) {
			itialc = 0;
		}
		else {
			itialc = 1;
		}
		setStyle(getEditor(), null, "-1", "-1", String.valueOf(itialc));
	}
	void setUnderLine() {
		styleInfo si = getStyleInfo(getEditor());
		if(si.getUnderline() > 0)
			setUnderLine(0);
		else setUnderLine(lastUsedUnderlineType);
	}
	
}
class styleInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	private String fontname = null;
	private double fontsize = -1;
	private int bold = -1;
	private int italic = -1;
	private int underline = -1;
	private String underlinecolor = null;
	private int strikeline = -1;
	private int superscript = -1;
	private int subscript = -1;
	private String foreground = null;
	private String background = null;
	private int align = -1;
	private int indent = -1;
	private double firstLineIndent = -1;
	private int lineHeightType = -1;
	private double lineHeightValue = -1;
	private double leftMargin = -1;
	private double rightMargin=-1;
	private double topMargin=-1;
	private double bottomMargin=-1;
	private int headType = -1;
	private String styleName;
	private int letterSpaceType = -1;
	private double letterSpaceValue = -1;
	/**
	 * 比较给定的styleinfo对象与当前对象中的除stylename之外的属性是否全部相同
	 * @param si
	 * @return
	 */
	public boolean isSameStyle(styleInfo si) {
		if(!isSame(fontname, si.fontname)) return false;
		else if(fontsize != si.fontsize) return false;
		else if(bold != si.bold) return false;
		else if(italic != si.italic) return false;
		else if(underline != si.underline) return false;
		else if(!isSame(underlinecolor,si.underlinecolor))return false;
		else if(strikeline != si.strikeline) return false;
		else if(superscript != si.superscript) return false;
		else if(subscript != si.subscript) return false;
		else if(!isSame(foreground, si.foreground)) return false;
		else if(!isSame(background, si.background)) return false;
		else if(align != si.align) return false;
		else if(indent != si.indent) return false;
		else if(firstLineIndent != si.firstLineIndent) return false;
		else if(lineHeightType != si.lineHeightType) return false;
		else if(lineHeightValue != si.lineHeightValue) return false;
		else if(leftMargin != si.leftMargin) return false;
		else if(rightMargin != si.rightMargin) return false;
		else if(topMargin != si.topMargin) return false;
		else if(bottomMargin != si.bottomMargin) return false;
		else if(headType != si.headType) return false;
		else if(letterSpaceType != si.letterSpaceType) return false;
		else if(letterSpaceValue != si.letterSpaceValue) return false;
		return true;
	}
	/**
	 * 比较两个对象是否相同，参数可以为null
	 * @param o1
	 * @param o2
	 * @return
	 */
	private static boolean isSame(Object o1,Object o2) {
		if(o1 != null) {
			if(o2 != null) {
				if(o1.equals(o2)) return true;
			}
		}else if(o1 == null) {
			if(o2 == null) return true;
		}
		return false;
	}
	public String getFontname() {
		return fontname;
	}
	public void setFontname(String fontname) {
		this.fontname = fontname;
	}
	public double getFontsize() {
		return fontsize;
	}
	public void setFontsize(double fontsize) {
		this.fontsize = fontsize;
	}
	public int getBold() {
		return bold;
	}
	public void setBold(int bold) {
		this.bold = bold;
	}
	public int getItialc() {
		return italic;
	}
	public void setItialc(int italic) {
		this.italic = italic;
	}
	public int getUnderline() {
		return underline;
	}
	public void setUnderline(int underline) {
		this.underline = underline;
	}
	public String getUnderlinecolor() {
		return underlinecolor;
	}
	public void setUnderlinecolor(String underlinecolor) {
		this.underlinecolor = underlinecolor;
	}
	public int getStrikeline() {
		return strikeline;
	}
	public void setStrikeline(int strikeline) {
		this.strikeline = strikeline;
	}
	public int getSuperscript() {
		return superscript;
	}
	public void setSuperscript(int superscript) {
		this.superscript = superscript;
	}
	public int getSubscript() {
		return subscript;
	}
	public void setSubscript(int subscript) {
		this.subscript = subscript;
	}
	public String getForeground() {
		return foreground;
	}
	public void setForeground(String foreground) {
		this.foreground = foreground;
	}
	public String getBackground() {
		return background;
	}
	public void setBackground(String background) {
		this.background = background;
	}
	public int getAlign() {
		return align;
	}
	public void setAlign(int align) {
		this.align = align;
	}
	public int getIndent() {
		return indent;
	}
	public void setIndent(int indent) {
		this.indent = indent;
	}
	public double getFirstLineIndent() {
		return firstLineIndent;
	}
	public void setFirstLineIndent(double firstLineIndent) {
		this.firstLineIndent = firstLineIndent;
	}
	public int getLineHeightType() {
		return lineHeightType;
	}
	public void setLineHeightType(int lineHeightType) {
		this.lineHeightType = lineHeightType;
	}
	public double getLineHeightValue() {
		return lineHeightValue;
	}
	public void setLineHeightValue(double lineHeightValue) {
		this.lineHeightValue = lineHeightValue;
	}
	public double getLeftMargin() {
		return leftMargin;
	}
	public void setLeftMargin(double leftMargin) {
		this.leftMargin = leftMargin;
	}
	public double getRightMargin() {
		return rightMargin;
	}
	public void setRightMargin(double rightMargin) {
		this.rightMargin = rightMargin;
	}
	public double getTopMargin() {
		return topMargin;
	}
	public void setTopMargin(double topMargin) {
		this.topMargin = topMargin;
	}
	public double getBottomMargin() {
		return bottomMargin;
	}
	public void setBottomMargin(double bottomMargin) {
		this.bottomMargin = bottomMargin;
	}
	public int getHeadType() {
		return headType;
	}
	public void setHeadType(int headType) {
		this.headType = headType;
	}
	public String getStyleName() {
		return styleName;
	}
	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}
	public int getLetterSpaceType() {
		return letterSpaceType;
	}
	public void setLetterSpaceType(int letterSpaceType) {
		this.letterSpaceType = letterSpaceType;
	}
	public double getLetterSpaceValue() {
		return letterSpaceValue;
	}
	public void setLetterSpaceValue(double letterSpaceValue) {
		this.letterSpaceValue = letterSpaceValue;
	}
	
}