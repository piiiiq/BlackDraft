package yang.app.qt.black;

import java.io.File;

import io.qt.core.QSysInfo;

public class appInfo {
	//月份应该比实际的小1，因为java日历获取到的月份是从0月开始的
	//要使测试日期失效，将年份和月份置为-1即可
	static int outYear = 2020,outMonth = 9;
	public static String appName = "BlackDraft";
	public static String appVersion = "0.8";
	//修改编译日期后，关于对话框中的版权结束年份会自动根据编译日期发生变化，版权结束年份是截取编译日期的前4个字符
	public static String buildDate = "2026-07-06";
	public static String appWebsite = "https://github.com/piiiiq/BlackDraft";
	public static String buildOn = "Java 14 & Qt 5.15";
	static String password_doc = "blackfile";
	static String password = "black";
	/**
	 * 返回程序cfg文件夹路径，末尾已经包含File.separator
	 */
	static String appCfgDir = "."+File.separator+"CFG"+File.separator;
	/**
	 * 一个临时计数，用于测试
	 */
	public static int test = 0;
	/**
	 * 用于指示更新来自哪个邮箱
	 */
	public static String updateFrom = "";
	/**
	 * 0公用
	 * 1自用
	 */
	public static int mode = 0;
	public static String loaderVer = "不可用";
	public static String
	icons_svg = "." + File.separator + "Icons" + File.separator+"svg"+File.separator,
	iconsScr_16 = "." + File.separator + "Icons" + File.separator + "iconsScr" + File.separator + "16" + File.separator,
	icons = "." + File.separator + "Icons" + File.separator + "icons" + File.separator,
	icons_16 = "." + File.separator + "Icons" + File.separator + "icons" + File.separator+"16"+File.separator,
	myicons = "." + File.separator + "Icons" + File.separator + "myIcons" + File.separator,
	iconsScr_32 = "." + File.separator + "Icons" + File.separator + "iconsScr" + File.separator + "32" + File.separator
	,
	currentDir = "."+File.separator,
	sp = "." + File.separator + "RC" + File.separator + "sp" + File.separator,
	bingpic = "." + File.separator + "RC" + File.separator + "Bing" + File.separator + "bing.jpg"
	;
	
	/**
	 * Linux下Qt5.15窗口失去焦点问题的修复时间，单位是毫秒
	 */
	public static int ms = 100;
	/**
	 * 每个文件保存的编辑点数量
	 */
	
	public static int maxEditPointCount = 50;
	
	
	public enum timerInfoType{
		autoSave(0),showCharCount(1),changePunctuationByKeybord(2),
		forceShowWindow(3),runingBackup(4),cannotFindBackupDir(5),
		needRunningBackup(6),getBingPic(7),autoLock(8),timer(9),
		autoHideLoadMessageLabel(10),projectAllChanageSaved(11)
		;
		int value;
		timerInfoType(int value){
			this.value = value;
		}
	}
	
	static String updateInfo =""
			+ getAppVersionText("0.7542","添加项目加密功能；重写编辑点跳转逻辑；修复已知问题")
			+ getAppVersionText("0.7522","文档加密保存；改进数据安全性；修复bug")
			+ getAppVersionText("0.7521","内联拼音输入法检索关键词支持检索中英混杂关键词;使用shift键控制插入关键词")
			+ getAppVersionText("0.7518","改进细节；修复bug")
			+ getAppVersionText("0.7516","为小狼毫输入法制作了一个内置的选词框；修复bug")
			+ getAppVersionText("0.7513","修复bug，增加快捷添加文件的功能")
			+ getAppVersionText("0.751","添加自适应布局，改进高分屏支持，添加密码锁定功能，修复查找替换中bug，改进文档加载性能")
			+ getAppVersionText("0.6991","修复linux下编码框相关bug，改进随机图片排列算法")
			+ getAppVersionText("0.699","支持通过使用空格分割拼音串的嵌入式输入法进行关键词检索")
			+ getAppVersionText("0.698","修复bug，改进对linux的支持,启用dpi自动缩放")
			+ getAppVersionText("0.697","添加输入法控制模块，启用内建光标，调整了内建输入框的配色，修复了一些bug")
			+ getAppVersionText("0.696","修正上下边距失效的问题；添加窗口背景透明度低于50或使用了背景图片时禁止绘制页面阴影线段")
			+ getAppVersionText("0.6951","修正退出写作视图不重新设置编辑器边距")
			+ getAppVersionText("0.695","启用自动滚屏时按动上下方向键会滚动页面，而不是移动光标")
			+ getAppVersionText("0.693","修改页面阴影为线段阴影；视情况添加页首空白")
			+ getAppVersionText("0.692","增加自动滚屏功能，并可以为每个文档保存自动滚屏数据；能够自定义字符间的距离")
			+ getAppVersionText("0.691","增加聊天机器人功能")
			+ getAppVersionText("0.69","修复bug，添加随机图片功能")
			+ getAppVersionText("0.681","升级底层库为最新版（Java14与Qt5.15)，迁移至64位平台，不再提供32位版本")
			+ getAppVersionText("0.6782","拼音检索时不会每次输入拼音都会重新对文档内容进行分词")
			+ getAppVersionText("0.6781","修复使用全拼输入法不能延时检索关键词的bug")
			+ getAppVersionText("0.678","改进自动完成功能，引入自动分词模块，支持在不定义关键词的情况下对文档内容进行模糊分词，并提供非精准的自动完成功能；"
					+ "在用嵌入式拼音输入法辅助自动完成功能时，可以输入大写字母来快速定位关键词条目；在文档内容发生改变时，会基于插入符前一个字符自动查找关键词;增加简繁转换;修复一些bug")
			+ getAppVersionText("0.6758","修改嵌入式输入法编码框的外观")
			+ getAppVersionText("0.6757","修复插入符在编辑器最底端时会被遮挡的问题")
			+ getAppVersionText("0.6755","修复模拟打字机移动页面模式问题；修复页面右边距问题；改进写作视图载入文档速度")
			+ getAppVersionText("0.6754","修复已经打开项目时退出打开项目对话框后自动跳转到默认项目的问题")
			+ getAppVersionText("0.6753","修复Bing故事界面右下角提示信息位置错误；将Bing故事呈现组件改为全动态布局")
			+ getAppVersionText("0.675","修复界面元素位置错误")
			+ getAppVersionText("0.674","重构一些代码；添加菜单；修复bug；增加程序健壮性")
			+ getAppVersionText("0.673","使用Bing每日图片作为背景，修复bug")
			+ getAppVersionText("0.672","修复更新模块字符编码错误；添加一些菜单项；可自动更新部署模块")
			+ getAppVersionText("0.668","自动下载&部署更新")
			+ getAppVersionText("0.667","添加增量更新，缩小更新包体积")
			+ getAppVersionText("0.665","添加高分屏模式；重写文本对话框布局代码；修复检查更新bug；用page键滚屏时保留一些像素")
			+ getAppVersionText("0.664","将背景图片更改为jpg格式，缩小图片体积以便加快载入图片速度")
			+ getAppVersionText("0.663","修复几处新发现的问题(例如加载文件缓慢的问题)；增加一些菜单项")
			+ getAppVersionText("0.662","改进项目检索功能，可跳回检索前的位置，修复检索框的一些问题")
			+ getAppVersionText("0.661","统一写作视图模式；可以修改更多界面元素的颜色，可以针对不同颜色模式设置是否启用图片背景")
			+ getAppVersionText("0.660","修正从搜索替换框中选择替换全部会出现替换错误的问题")
			+ getAppVersionText("0.659","白天和夜间模式支持高性能写作视图；修正从最大化窗口进入写作视图在退出写作视图后不还原成最大化窗口的问题")
			+ getAppVersionText("0.658","高性能写作视图下可以更改窗口透明度（全屏视图）")
			+ getAppVersionText("0.657","添加高性能写作视图模式")
			+ getAppVersionText("0.654","添加打字机模式，可以模拟打字机动态移动页面")
			+ getAppVersionText("0.652","重新加入隐藏编码框命令；可以更改插入符的颜色")
			+ getAppVersionText("0.643","禁用锚点和实验性撤销还原，修复窗口复位问题；添加文件时自动修复文件指针错误等")
			+ getAppVersionText("0.631","增加Linux系统支持")
			+ getAppVersionText("0.628","内建插入中文双引号快捷键")
			+ getAppVersionText("0.627","页面添加角标（写作视图）")
			+ getAppVersionText("0.625","修复嵌入式输入bug;写作视图下添加页面背景，可以更改写作视图下的页面和文字颜色")
			+ getAppVersionText("0.611","启用内嵌编辑")
			+ getAppVersionText("0.610","启用程序自建撤销&重做框架")
			+ getAppVersionText("0.607", "Git信息已加密储存")
			+ getAppVersionText("0.604","修复锚点列表所存在的问题")
			+ getAppVersionText("0.602","修复项目加载时的错误")
			+ getAppVersionText("0.601","可以用快捷键遍历RC目录下的背景图片")
			+ getAppVersionText("0.598","添加打字机卷动动画，增加了几个命令行参数")
			+ getAppVersionText("0.595","写作视图下显示任务栏；修改写作视图编辑器上下边距命令")
			+ getAppVersionText("0.591","重新加载背景命令；可提高（白天）或降低（晚上）背景图片亮度；编码框背景透明")
			+ getAppVersionText("0.590","添加字符间距，便于长时间查看")
			;
	public static String bugList = "<ul>"
			+ "<li>通过输入法输入文本，或者通过关键词列表插入文本时，在与锚点面板同步数据之后，redo/undo列表存在多余的步骤，应该获取Qtextcursor一次性编辑"
			+ "<li>撤销/重做同步锚点数据时存在性能问题"
			+ "<li>通过搜索框检索文本时，结果面板不应该隐藏，按下ESC键应该删除检索结果，以便重新检索"
			+ "</ul>";
	public static String addsInfo = "要使备份目录可被程序自行搜索，"
			+ "务必将备份目录建立在驱动器根目录下，并命名为BlackBackups<br>";
	public static String aboutApp = "<b>"+appName+"</b><i>"
			+ " - 用来撰写文学作品"
			+ ""
			+ "</i>";
	public static String authorInfo = "<ul><li>设计、编程、图标等由段晓阳(beihuiguixian@hotmail.com)完成"
			+ "<li>动态图片资源来自Bing每日图片(www.bing.com) & Unsplash(source.unsplash.com)"
//			+ "<li>"
			+ "</ul>";
	public static String aboutInfo = "此应用是专门为文学创作而制作的文本编辑器，与通常意义上的文本编辑器不同，这个编辑器包含了一些有利于文学创作者撰写文本内容的功能，尽量减少文学创作者在电脑前长时间创作时的痛苦。该应用当前版本提供的功能大致如下："
			+ "<ul><li>可以通过密码锁定软件，避免数据隐私被泄露；" +
			"<li>自动记忆所有文档最后一次的查看和编辑位置，且可记忆每个文档内部的历史编辑位置，可在修改内容时在编辑点之间快速跳转；"+
			"<li>可为全部功能设置快捷键，并通过快捷键插入文本；"+
			"<li>可为不同的内容设置不同的字体、字号、行距、段距等样式，提供基本的插入文本、表格、列表、图片等富文本元素的功能；"+
			"<li>自动将正在编辑的行固定在屏幕的中上方，避免持续低头看屏幕底部致颈椎疲劳；" + 
			"<li>单/多文档字数统计功能；" + 
			"<li>多种写作视图可选，可帮助创作者沉浸写作，或者高效整理文档内容。每次重新启动程序可自动还原到上一次使用的视图模式；" + 
			"<li>可自动备份数据到其他储存器，例如可移动储存器等，自动为所编辑的项目保存副本，减少数据丢失的几率；" + 
			"<li>多种界面语言支持"+
			"<li>……</ul>"
			;
	public static String systemInfo = "构建于<i> "
			+ appInfo.buildOn+"</i><br>" + "运行于<i> "
			+ QSysInfo.prettyProductName()
			+ "("+QSysInfo.kernelType()+QSysInfo.kernelVersion()+")"
			+ QSysInfo.currentCpuArchitecture()
			+ " & "
			+ System.getProperty("java.runtime.name")
			+ System.getProperty("java.runtime.version")			
			+ "</i>";
	public static String argsHelpInfo = "\n用法：Black.exe -参数" + "\n有效参数：" + "\n-help/-?/-h 输出帮助信息" + "\n-show 强制显示窗口"
			+ "\n-clone 从本地仓库克隆项目"
			+ "\n-debug 启用调试模式"
			+ "\n-full_writingView 启用全屏幕写作视图"
			+ "\n-noPageLine 禁止绘制分页线"
			+ "\n-noMarkChar 禁止绘制附加标记（例如段落标记等）"
			+ "\n-noShadowForIME 禁止为内置的用来显示内嵌编辑字符的面板绘制阴影效果"
			;
	public static  String host0 = "pop.163.com",
			username0 = "yangisboy@163.com",
			port0 = "-1",
			password0 = "dxy13633528994",
			host1 = "pop.yandex.com",
			port1 = "995",
			username1 = "blackdraft@yandex.com",
			password1 = "527332367";
		
	public static String based = "QT";
	public static String lastUsedProject = "app/lastUsedProject";
	public static String editing = "editing";
	public static String zoomValue = "app/textzoom";
	public static String font = "app/font";
	public static String lineHeight = "app/lineheight";
	public static String paragraphSpace = "app/paragraphspace";
	public static String firstLine = "app/firstline";
	public static String caretWidth = "app/caretwidth";
	public static String fontSize = "app/fontsize";
	public static String textWidthForWritingView = "app/textwidthforwritingview";
	public static String writingViewMode = "app/writingviewmode";
	public static String shadowAlphaForWritingViewWindowMode = "app/backgroundalpha";
	public static String documentMargin = "app/documentmargin";
	public static String autoSave = "app/autoSave";
	public static String fileIndex = "fileindex";
	public static String projectName = "projectname";
	public static String gitHost = "githost";
	public static String gitUsername = "gitusername";
	public static String gitPassword = "gitpassword";
	public static String keywordsWidth = "app/keywordswidth";
	public static String keywordsHeight = "app/keywordsheight";
	public static String topKeywordsCount = "app/topkeywordscount";
	public static String onlyAPart = "app/onlyapart";
	public static String isWritingView = "app/iswritingview";
	public static String timeMode = "app/timemode";
	public static String editorColor = "app/editorcolor";
	public static String moveIndex = "moveindex";
	public static String keywordsSeparator = "@";
	public static String setAlphaByTime = "app/setalphabytime";
	public static String kiwixLastURL = "app/kiwixlasturl";
	public static String goldenDictPath = "app/goldendictpath";
	public static String mainClassNameOfExtendModule = "yang.app.qt.black.black";
	public static String findIn = "findIn";
	public static String FindHistory = "findhistory";
	public static String blackCommand = "$bc";
	public static String blackCommandAndQuiet = "$bcq";
	public static String animationTime = "app/beeptime";
	public static String blurRadiusWindowMode = "app/blurRadius";
	public static String blurRadiusFullScreen = "app/blurRadiusfullscreen";
	public static String shadowAlphaForWritingViewFullScreen = "app/alphafullscreen";
	public static String windowOpacity = "app/windowOpacity";
	public static String saveMode = "app/savemode";
	public static String yellowForceColor = "app/yellowForceColor";
	public static String noCaretShadow = "app/noCaretShadow";
	public static String alpha_windowBackground = "app/alpha_windowBackground";
	public static String whatStart = "app/whatStart";
	public static String quietMode = "app/quietMode";
	public static String whatTime = "app/whatTime";
	public static String lineAndDocFirst = "app/lineAndDocFirst";
	public static String noCaret = "app/noCaret";
	public static String noCaretS = "app/noCaretS";
	public static String boldFont = "app/boldFont";
	public static String italicFont = "app/italicFont";
	public static String simpleTopPanelMask = "app/simpleTopPanelMask";
	public static String noDock = "app/noDock";
	public static String smallTop = "app/smallTop";
	public static String noTop = "app/noTop";
	public static String fastKeyWords = "app/fastKeyWords";
	public static String focusMode = "app/focusMode";
	public static String lastEditFile = "lastEditFile", typeModeValue = "app/typeModeValue",
			textVScrollbarWidth = "app/textVScrollbarWidth", appVersionKey = "app/appVersion",
			IMECodePanelFont = "app/IMECodePanelFont", // 未使用
			editorHeight = "app/editorHeight", noBackgroundForWritingView = "app/noBackgroundForWritingView",
			additionalInfo = "app/additionalInfo", hideIMEPanel = "app/hideIMEPanel",
			conversionToFullPinyin = "app/conversionToFullPinyin",
			adminPasswordWithEncrypt = "app/adminPasswordWithEncrypt",
			moreFindMarkWithPinyin = "app/moreFindMarkWithPinyin", backUpDir = "backUpDir",
			lastBackUpTime = "lastBackUpTime", backUpTime = "app/backUpTime", withoutBlueValue = "app/withoutBlueValue",
			/**
			 * 通过键盘或者鼠标进行标点符号改写，为0时通过鼠标改写，为1时通过键盘改写
			 */
			insByMouseOrKey = "insByMouseOrKey", voiceRate = "app/voiceRate", mailDat = "./RC/mailDat",
			kiwixScrollBarValue = "app/kiwixScrollBarValue", blackUD = "BlackUD",
			wifiHWID = "PCI\\VEN_168C&DEV_002B&CC_0280", wikipeidaKeywordsList = "app/wikiKeywordsList",
			LightOrDark = "app/showPic", 
			showTitlePanel = "app/showTitlePanel",
			lastReadOfYW = "app/lastReadOfYW",
			lastRunGameTime = "app/lastGameTime",
			uiFont = "微软雅黑",
			/**
			 * 1将不可编辑和查看项目内容
			 */
			miniMode = "0",
			MD5OFGetMail = "app/MD5OFGetMail",
			javawPath = "./jre/bin/javaw.exe",
			charSpace = "app/charSpace",
			writingViewTextTopAndBottom = "app/writingViewTextTopAndBottom",
			lightWindowBgImg = "app/bgImg",
			payImgSUM = "a6e9c0c297516ead0853c76c1f1cb2b7",
			useBgColor = "app/useBgColor",
			colortext = "app/colortext",
			colortextbg = "app/colortextbg",
			textbgborder = "app/border",
			Antialiasing = "app/antialiasing",
			usePinyinFindKeywords = "app/usePinyinFindKeyword",
			pageHeght = "app/pageHeght",
			caretColor_normal = "app/caretColor_N",
			caretColor_writingview = "app/caretColor_W",
			typerMode = "app/typerMode",
			simpleWritingView = "app/simpleWritingView",
			writingViewAlpha = "app/writingViewAlpha",
			lightWindowColor = "app/lightWindowColor",
			darkWindowColor = "app/darkWindowColor",
			lightTextColor = "app/lightTextColor",
			darkTextColor = "app/darkTextColor",
			lightPageColor = "app/lightPageColor",
			darkPageColor = "app/darkPageColor",
			lightCaretColor = "app/lightCaretColor",
			darkCaretColor = "app/darkCaretColor",
			darkWindowBgImg = "app/darkWindowBgImg",
			useLightWindowBgImg = "app/useLightWindowBgImg",
			useDarkWindowBgImg = "app/useDarkWindowBgImg",
			lightLoadMessageColor = "app/lightLoadMesageColor",
			darkLoadMessageColor = "app/darkLoadMessageColor",
			lightTimeMessageColor = "app/lightTimeMessageColor",
			darkTimeMessageColor = "app/darkTimeMessageColor",
			UIfontSizeAdd = "app/UIfontSizeAdd",
			useBigUIFont = "app/useBigUIFont",
			bingPicInfo = "app/bingPicInfo",
			lightBingPic = "app/lightBingPic",
			darkBingPic = "app/darkBingPic",
			usePageShadow = "app/usePageShadow",
			useSpiltCharForPinyin = "app/useSpiltCharForPinyin",
			maxCharsAutoSegment = "app/maxCharsAutoSegment",
			pinyinStartSegmentMS = "app/pinyinStartSegmentMS",
			minLenghtOfAutoSegment = "app/minLenghtOfAutoSegment",
			infoOfAutoSegment = "app/infoOfAutoSegment",
			autoSaveInputOfAutoSegment = "app/autoSaveInputOfAutoSegment",
			autoShowKeywords = "app/autoShowKeywords",
			useInLineIME = "app/useInLineIME",
			fullScreen = "app/fullScreen",
			RoundShadow = "app/RoundShadow",
			randomImg = "app/randomImg",
			randomImgKeywords = "app/randomImgKeywords",
			fixedCaretPosWhenInput = "app/fixedCaretPosWhenInput",
			noCaretWhenInput = "app/noCaretWhenInput",
			rebotAPI = "app/rebotAPI",
			charSpaceValue = "app/charSpaceValue",
			useQtCaret="app/useQtCaret",
			editorAlignment = "app/editorAlignment",
			autoLock = "app/autoLock",
			autoLockTime ="app/autoLockTime",
			autoLockPasswd = "app/autoLockPasswd",
			defaultStyle = "app/defaultStyle",
			uiLang = "app/uiLang"
			;
	
	/**
	 * 此枚举定义一些临时字段名，供baction类的tempData做键值使用，这些枚举字段一般不写入磁盘
	 * @author Administrator
	 *
	 */
	enum tempName{
		autoLockStatu,unLockTime,setLocked,autoLockerTimer,stopOpenProject,openingProject,firstOpenDocument
	}
	enum timerType{
		loadFile
	}
	enum UIObject{
		menuFile,menuProject,menuGit,menuView,menuHelp,menuEdit,menuTool,
		toolBar,none
	}
	enum actionType{
		edit,view,file,project,git,help,tool
	}
	
	
	public static String keyInfo = "选中文本按下<b>tab</b>键快速检索当前文件\n"
			+ "选中文本按下<b>ctrl+tab</b>键快速检索父目录里的所有文件\n"
			+ "选中文本按下<b>enter</b>键可将其加入关键词列表\n"
			+ "未选中文本的状态下按下<b>alt+enter</b>键可打开标题列表\n"
			+ "未选中文本的状态下按下<b>ctrl+shift+enter</b>键可重新搜索关键词列表\n"
			+ "未选中文本的状态下按下<b>ctrl+tap</b>可在打开的文件之间切换\n"
			+ "<b>ctrl+0</b>开启/关闭静音模式\n"
			+ "<b>ctrl+`</b>快速将文本中的逗号替换为句号，或反之\n"
			+ "<b>ctrl+I</b>将当日输入的字符数统计清零\n"
			+ "<b>alt+`</b>产生一个中文人名并插入正文\n"
			+ "<b>F2</b>产生一个英文男名并插入正文\n"
			+ "<b>F3</b>产生一个英文女名并插入正文\n"
			+ "<b>F4</b>产生一个意大利男名并插入正文\n"
			+ "<b>F5</b>产生一个意大利女名并插入正文\n"
			+ "<b>F6</b>产生20个中文人名\n"
			+ "<b>alt+;(分号)</b>快速移动插入符至当前的编辑点、段首或段尾\n"
			+ "<b>alt+u</b>移动到前一次编辑的位置\n"
			+ "<b>alt+o</b>移动到后一次编辑的位置\n"
			+ "<b>alt+i</b>插入符上移\n"
			+ "<b>alt+k</b>插入符下移\n"
			+ "<b>alt+j</b>插入符左移\n"
			+ "<b>alt+l</b>插入符右移\n"
			+ "<b>alt+f</b>换行\n"
			+ "<b>alt+h</b>退格\n"
			+ "<b>alt+n/m</b>插入中文左右双引号\n"
			+ "<b>F9</b>开启或关闭编辑器动画效果\n"
			+ "<b>alt+pagedown</b>下一幅背景图片\n"
			+ "<b>ctrl/alt+2</b>在写作视图中切换颜色模式\n"
			+ "<b>ctrl/alt+1</b>手动备份项目\n"
			+ "<b>ctrl/alt+4</b>切换标点改写模式（通过鼠标或键盘改写标点）\n"
			+ "<b>ctrl/alt+5</b>开启/关闭拼音输入法检索关键词\n"
			+ addKeyInfo("Shift+ESC","退出程序")
			;
	
	
	
	
	
	
	public static final String[] syls = { ".", "。", "!", "！", "?", "？", "——", "……", "”", "\"", "】", "：", ":" };
	
	
	public static String textToHtml(String text) {
		StringBuilder sb = new StringBuilder();
		sb.append(text.replaceAll("\n", "<br>"));
		return sb.toString();
	}
	static String info = "本软件可能存在某些尚未被发现和修复的错误，这些错误可能导致使用者的数据遭受损失。"
			+ "如您使用本软件，即视为您已经了解这些信息，并愿意承担使用本软件所产生的任何后果。"
			+ "对于您因使用本软件而产生的损失，开发者将不承担任何责任。";
	/**
	 * 获取测试版本的信息，此方法会计算软件过期时间
	 * 如果过期日期或月份为-1，则返回不含有关软件评估的信息
	 * @return
	 */
	static String getInfo() {
		String testInfo = "<ul><li>此版本的"+appName+"软件仅作为评估之用，评估截止日期为"
				+ outYear+"年"+(outMonth-1)+"月"
				+ "。评估期内您可以自由复制、分发和使用此软件。"
				+ "<li>"+info
						+ "<b></b>"
				+ "<li>开发者保留此软件后续版本授权的重新定义权。 "
				+ "</ul>"
				+ "\n-----------\n";
		if(outYear == -1 || outMonth == -1)
			testInfo = info;
		
		return testInfo;
	}
	static String opensourceInfo = null;
			
	/**
	 * 返回应用版本的文本描述，如果需要在更新信息中插入版本信息，使用此方法可以得到规范格式的版本信息
	 * @param ver
	 * @return
	 */
	static String getAppVersionText(String ver) {
		return "<i>"+ver+"</i> ";
	}
	static String getAppVersionText(String ver,String UpdateInfo) {
		//html行结尾是<br>，结尾添加\n是因为如果没有\n cheakDocument.getAllLine方法会无法识别行
		//添加了\n对html文字的识别也没有影响
		return getAppVersionText(ver)+UpdateInfo+"<br>\n";
	}
	static String getAppVersionText(String ver,String date,String UpdateInfo) {
		return getAppVersionText(ver)+UpdateInfo+"("+date+")<br>";
	}
	
	public enum fontSize{
		menu,tree,menubar,textTitle,fileTreeTitle,timeMessage,loadMessage,statusbar,Default,
		/**
		 * 返回增大的字号
		 */
		add,
		findLineBox,findLine,splashMessage
	}
	public enum uiSize{
		toolbarHeight
	}
	/**
	 * 添加快捷键描述信息
	 * @return
	 */
	static String addKeyInfo(String key,String info) {
		return "<b>"+key+"</b>"+info+"\n";
	}
	static String segmentInfo = "下面一行包含了所有名词词性，如果要让程序自动完成分词得到的全部名词，复制下面一行到[分词词性过滤]命令打开的词性编辑框即可：\n"
			+ "n nb nba nbc nbp nf ng nh nhd nhm ni nic nis nit nl nm nmc nn nnd nnt nr nr1 nr2 nrf nrj ns nsf nt ntc ntcb ntcf ntch nth nto nts ntu nx nz"
			+ "\n\n所有词性简写及其含义详见下面：\n"
			+ "a 	形容词\r\n" + 
			"ad 	副形词\r\n" + 
			"ag 	形容词性语素\r\n" + 
			"al 	形容词性惯用语\r\n" + 
			"an 	名形词\r\n" + 
			"b 	区别词\r\n" + 
			"	begin\r\n" + 
			"bg 	区别语素\r\n" + 
			"bl 	区别词性惯用语\r\n" + 
			"c 	连词\r\n" + 
			"cc 	并列连词\r\n" + 
			"d 	副词\r\n" + 
			"dg 	辄,俱,复之类的副词\r\n" + 
			"dl 	连语\r\n" + 
			"e 	叹词\r\n" + 
			"end 	仅用于终##终\r\n" + 
			"f 	方位词\r\n" + 
			"g 	学术词汇\r\n" + 
			"gb 	生物相关词汇\r\n" + 
			"gbc 	生物类别\r\n" + 
			"gc 	化学相关词汇\r\n" + 
			"gg 	地理地质相关词汇\r\n" + 
			"gi 	计算机相关词汇\r\n" + 
			"gm 	数学相关词汇\r\n" + 
			"gp 	物理相关词汇\r\n" + 
			"h 	前缀\r\n" + 
			"i 	成语\r\n" + 
			"j 	简称略语\r\n" + 
			"k 	后缀\r\n" + 
			"l 	习用语\r\n" + 
			"m 	数词\r\n" + 
			"mg 	数语素\r\n" + 
			"Mg 	甲乙丙丁之类的数词\r\n" + 
			"mq 	数量词\r\n" + 
			"n 	名词\r\n" + 
			"nb 	生物名\r\n" + 
			"nba 	动物名\r\n" + 
			"nbc 	动物纲目\r\n" + 
			"nbp 	植物名\r\n" + 
			"nf 	食品，比如“薯片”\r\n" + 
			"ng 	名词性语素\r\n" + 
			"nh 	医药疾病等健康相关名词\r\n" + 
			"nhd 	疾病\r\n" + 
			"nhm 	药品\r\n" + 
			"ni 	机构相关（不是独立机构名）\r\n" + 
			"nic 	下属机构\r\n" + 
			"nis 	机构后缀\r\n" + 
			"nit 	教育相关机构\r\n" + 
			"nl 	名词性惯用语\r\n" + 
			"nm 	物品名\r\n" + 
			"nmc 	化学品名\r\n" + 
			"nn 	工作相关名词\r\n" + 
			"nnd 	职业\r\n" + 
			"nnt 	职务职称\r\n" + 
			"nr 	人名\r\n" + 
			"nr1 	复姓\r\n" + 
			"nr2 	蒙古姓名\r\n" + 
			"nrf 	音译人名\r\n" + 
			"nrj 	日语人名\r\n" + 
			"ns 	地名\r\n" + 
			"nsf 	音译地名\r\n" + 
			"nt 	机构团体名\r\n" + 
			"ntc 	公司名\r\n" + 
			"ntcb 	银行\r\n" + 
			"ntcf 	工厂\r\n" + 
			"ntch 	酒店宾馆\r\n" + 
			"nth 	医院\r\n" + 
			"nto 	政府机构\r\n" + 
			"nts 	中小学\r\n" + 
			"ntu 	大学\r\n" + 
			"nx 	字母专名\r\n" + 
			"nz 	其他专名\r\n" + 
			"o 	拟声词\r\n" + 
			"p 	介词\r\n" + 
			"pba 	介词“把”\r\n" + 
			"pbei 	介词“被”\r\n" + 
			"q 	量词\r\n" + 
			"qg 	量词语素\r\n" + 
			"qt 	时量词\r\n" + 
			"qv 	动量词\r\n" + 
			"r 	代词\r\n" + 
			"rg 	代词性语素\r\n" + 
			"Rg 	古汉语代词性语素\r\n" + 
			"rr 	人称代词\r\n" + 
			"ry 	疑问代词\r\n" + 
			"rys 	处所疑问代词\r\n" + 
			"ryt 	时间疑问代词\r\n" + 
			"ryv 	谓词性疑问代词\r\n" + 
			"rz 	指示代词\r\n" + 
			"rzs 	处所指示代词\r\n" + 
			"rzt 	时间指示代词\r\n" + 
			"rzv 	谓词性指示代词\r\n" + 
			"s 	处所词\r\n" + 
			"t 	时间词\r\n" + 
			"tg 	时间词性语素\r\n" + 
			"u 	助词\r\n" + 
			"ud 	助词\r\n" + 
			"ude1 	的 底\r\n" + 
			"ude2 	地\r\n" + 
			"ude3 	得\r\n" + 
			"udeng 	等 等等 云云\r\n" + 
			"udh 	的话\r\n" + 
			"ug 	过\r\n" + 
			"uguo 	过\r\n" + 
			"uj 	助词\r\n" + 
			"ul 	连词\r\n" + 
			"ule 	了 喽\r\n" + 
			"ulian 	连 （“连小学生都会”）\r\n" + 
			"uls 	来讲 来说 而言 说来\r\n" + 
			"usuo 	所\r\n" + 
			"uv 	连词\r\n" + 
			"uyy 	一样 一般 似的 般\r\n" + 
			"uz 	着\r\n" + 
			"uzhe 	着\r\n" + 
			"uzhi 	之\r\n" + 
			"v 	动词\r\n" + 
			"vd 	副动词\r\n" + 
			"vf 	趋向动词\r\n" + 
			"vg 	动词性语素\r\n" + 
			"vi 	不及物动词（内动词）\r\n" + 
			"vl 	动词性惯用语\r\n" + 
			"vn 	名动词\r\n" + 
			"vshi 	动词“是”\r\n" + 
			"vx 	形式动词\r\n" + 
			"vyou 	动词“有”\r\n" + 
			"w 	标点符号\r\n" + 
			"wb 	百分号千分号，全角：％ ‰ 半角：%\r\n" + 
			"wd 	逗号，全角：， 半角：,\r\n" + 
			"wf 	分号，全角：； 半角： ;\r\n" + 
			"wh 	单位符号，全角：￥ ＄ ￡ ° ℃ 半角：$\r\n" + 
			"wj 	句号，全角：。\r\n" + 
			"wky 	右括号，全角：） 〕 ］ ｝ 》 】 〗 〉 半角： ) ] { >\r\n" + 
			"wkz 	左括号，全角：（ 〔 ［ ｛ 《 【 〖 〈 半角：( [ { <\r\n" + 
			"wm 	冒号，全角：： 半角： :\r\n" + 
			"wn 	顿号，全角：、\r\n" + 
			"wp 	破折号，全角：—— －－ ——－ 半角：— —-\r\n" + 
			"ws 	省略号，全角：…… …\r\n" + 
			"wt 	叹号，全角：！\r\n" + 
			"ww 	问号，全角：？\r\n" + 
			"wyy 	右引号，全角：” ’ 』\r\n" + 
			"wyz 	左引号，全角：“ ‘ 『\r\n" + 
			"x 	字符串\r\n" + 
			"xu 	网址URL\r\n" + 
			"xx 	非语素字\r\n" + 
			"y 	语气词(delete yg)\r\n" + 
			"yg 	语气语素\r\n" + 
			"z 	状态词\r\n" + 
			"zg 	状态词";
}
