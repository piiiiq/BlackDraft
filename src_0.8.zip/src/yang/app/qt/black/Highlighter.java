package yang.app.qt.black;

import java.util.List;

import io.qt.core.QPoint;
import io.qt.gui.QSyntaxHighlighter;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextFormat;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextLayout.FormatRange;
import io.qt.widgets.QTextEdit;

public class Highlighter extends QSyntaxHighlighter {

	private QTextEdit text;
	private boolean needupdateFontSize;
	double zoomvalue = 0;
	int visibleBlockNumberStart=-1,visibleBlockNumberEnd=-1;
	int updateViewport = 1;
	public Highlighter(QTextEdit text) {
		super(text.document());
		this.text = text;
//		text.verticalScrollBar().rangeChanged.connect(this, "rangeChanged()");
//		text.verticalScrollBar().sliderMoved.connect(this,"rangeChanged()");
		text.verticalScrollBar().valueChanged.connect(this,"rangeChanged()");
		
	}
	void rangeChanged() {
//		if(updateViewport == 0) {
////			updateViewport = 1;
//			return;
//		}
//		forCurrentScreen();

	}
	void zoom(double value) {
		if(value == zoomvalue) return;
		zoomvalue = value;
		text.setUpdatesEnabled(false);
		rehighlight();
//		visibleBlockNumberStart = -1;
//		visibleBlockNumberEnd = -1;
//		forCurrentScreen();
		text.setUpdatesEnabled(true);
//		forCurrentScreen();
	}
	@Override
	protected void highlightBlock(String text) {
		// TODO Auto-generated method stub
//		setFontSize(25);
//		if(!this.text.isVisible() || !needupdateFontSize) return;
//		System.out.println("highilghtblock "+ text.length()+ " currentBlock"+ currentBlock().blockNumber());
		
		
//		if(visibleBlockNumberStart == -1) return;
		
		//highlightBlock方法执行结束后currentBlock里面的内容就会被删除
		if(text.length() == 0) return;
		setFontSize(zoomvalue);
		
	}

	void forCurrentScreen() {
		QTextCursor tcStart = text.cursorForPosition(new QPoint(0, 0));
		QTextCursor tcEnd = text.cursorForPosition(new QPoint(0, text.viewport().height()));
		System.out.println(tcStart.blockNumber()+" : "+tcEnd.blockNumber());
		if(visibleBlockNumberStart == tcStart.blockNumber() && visibleBlockNumberEnd == tcEnd.blockNumber()) return;
//		visibleBlockNumberStart = tcStart.blockNumber();
//		visibleBlockNumberEnd = tcEnd.blockNumber();
		QTextDocument doc = document();
		updateViewport = 0;
		for(int i=tcStart.blockNumber();i<=tcEnd.blockNumber();i++) {
			QTextBlock block = doc.findBlockByNumber(i);
			needupdateFontSize = true;
//			updateViewport = 0;
			rehighlightBlock(block);
			needupdateFontSize = false;
		}
		updateViewport = 1;
		visibleBlockNumberStart = tcStart.blockNumber();
		visibleBlockNumberEnd = tcEnd.blockNumber();
	}
	void setFontSize(double fontsize) {
		QTextBlock block = currentBlock();
//		System.out.println("currentblock "+block.text());
		List<FormatRange> trs = block.textFormats();
		for(FormatRange tr:trs) {
//			int start = tr.start()+block.position();
//			int end = start+tr.length();				
			QTextCharFormat cff = tr.format();
			
			//增加或减小字号
			double newsize = fontsize+cff.fontPointSize();
			//如果格式中的字号为0，表示没有显式设置字号，所以采用编辑器的默认字号
			if(cff.fontPointSize() == 0) newsize = newsize+text.font().pointSizeF();
//			System.out.println("newsize: "+newsize);
			if(newsize > 1) {
				cff.setFontPointSize(newsize);
				setFormat(tr.start(), tr.length(), cff);
			}
		}
	}
	
}
