package yang.app.qt.black;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class MobiTextExtractor {

    /**
     * 直接解析 Mobi 文件结构，模拟 WordDumb 的做法
     */
    public static byte[] extractRawTextFromMobi(String mobiPath) throws IOException {
        byte[] mobiBytes = Files.readAllBytes(Paths.get(mobiPath));
        
        // Mobi 文件结构解析
        int textStartOffset = findTextRecordsStart(mobiBytes);
        int textEndOffset = findTextRecordsEnd(mobiBytes);
        
        if (textStartOffset == -1 || textEndOffset == -1) {
            throw new IOException("无法定位 Mobi 文件的文本记录");
        }
        
        // 提取文本记录数据（包含原始 HTML 标签）
        return Arrays.copyOfRange(mobiBytes, textStartOffset, textEndOffset);
    }

    /**
     * 查找文本记录的开始位置
     */
    private static int findTextRecordsStart(byte[] mobiBytes) {
        // Mobi 文件头结构：PalmDB 头 + Mobi 头
        // 文本记录通常从 0x1000 (4096) 字节左右开始
        
        // 查找文本内容的常见模式
        byte[] htmlPattern = "<html".getBytes(StandardCharsets.US_ASCII);
        byte[] bodyPattern = "<body".getBytes(StandardCharsets.US_ASCII);
        
        int htmlPos = findPattern(mobiBytes, htmlPattern);
        int bodyPos = findPattern(mobiBytes, bodyPattern);
        
        // 返回较早的位置
        return Math.min(htmlPos, bodyPos);
    }

    /**
     * 查找文本记录的结束位置
     */
    private static int findTextRecordsEnd(byte[] mobiBytes) {
        // 查找文本结束的常见模式
        byte[] endHtmlPattern = "</html>".getBytes(StandardCharsets.US_ASCII);
        byte[] endBodyPattern = "</body>".getBytes(StandardCharsets.US_ASCII);
        
        int endHtmlPos = findPattern(mobiBytes, endHtmlPattern);
        int endBodyPos = findPattern(mobiBytes, endBodyPattern);
        
        // 返回较晚的位置，加上结束标签的长度
        int endPos = Math.max(endHtmlPos, endBodyPos);
        if (endPos != -1) {
            endPos += "</html>".length(); // 包含结束标签
        }
        
        return endPos;
    }

    /**
     * 在字节数组中查找模式
     */
    private static int findPattern(byte[] bytes, byte[] pattern) {
        for (int i = 0; i <= bytes.length - pattern.length; i++) {
            boolean match = true;
            for (int j = 0; j < pattern.length; j++) {
                if (bytes[i + j] != pattern[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 计算词汇的字节偏移量（与 WordDumb 一致的方法）
     */
    public static String findWordPositions(String mobiPath, String wordList) throws IOException {
        // 1. 提取原始文本数据
        byte[] rawTextBytes = extractRawTextFromMobi(mobiPath);
        System.out.println("提取的原始文本大小: " + rawTextBytes.length + " 字节");
        
        // 2. 解析词汇列表
        Set<String> targetWords = new HashSet<>();
        for (String line : wordList.split("\\r?\\n")) {
            String word = line.trim();
            if (!word.isEmpty()) {
                targetWords.add(word.toLowerCase());
            }
        }
        
        if (targetWords.isEmpty()) {
            return "";
        }
        
        // 3. 将字节数据转换为字符串进行搜索
        String content = new String(rawTextBytes, StandardCharsets.UTF_8);
        List<String> results = new ArrayList<>();
        
        // 4. 在 body 标签内搜索（与 WordDumb 一致）
        Pattern bodyPattern = Pattern.compile(
            "<body[^>]*>(.*?)</body>", 
            Pattern.DOTALL | Pattern.CASE_INSENSITIVE
        );
        
        Matcher bodyMatcher = bodyPattern.matcher(content);
        
        while (bodyMatcher.find()) {
            String bodyContent = bodyMatcher.group(1);
            int bodyStartOffset = bodyMatcher.start(1);
            
            // 在 body 内容中查找文本节点
            findWordsInBody(bodyContent, bodyStartOffset, rawTextBytes, targetWords, results);
        }
        
        return String.join("\n", results);
    }

    /**
     * 在 body 内容中查找词汇
     */
    private static void findWordsInBody(String bodyContent, int bodyStartOffset, 
                                      byte[] rawBytes, Set<String> targetWords,
                                      List<String> results) {
        // 匹配文本节点（位于 > 和 < 之间的内容）
        Pattern textPattern = Pattern.compile(">([^<]+)<");
        Matcher textMatcher = textPattern.matcher(bodyContent);
        
        while (textMatcher.find()) {
            String textNode = textMatcher.group(1);
            int textStartInBody = textMatcher.start(1);
            int textStartInFull = bodyStartOffset + textStartInBody;
            
            processTextNode(textNode, textStartInFull, rawBytes, targetWords, results);
        }
    }

    /**
     * 处理文本节点中的词汇
     */
    private static void processTextNode(String textNode, int textStartOffset, 
                                      byte[] rawBytes, Set<String> targetWords,
                                      List<String> results) {
        // 处理 HTML 转义字符
        String unescapedText = unescapeHtml(textNode);
        
        // 分词处理
        String[] words = unescapedText.split("\\s+");
        int currentPos = 0;
        
        for (String word : words) {
            if (word.isEmpty()) continue;
            
            String cleanWord = cleanWord(word);
            if (cleanWord.isEmpty() || !targetWords.contains(cleanWord.toLowerCase())) {
                currentPos += word.length() + 1;
                continue;
            }
            
            // 找到词汇在文本中的位置
            int wordPos = unescapedText.indexOf(word, currentPos);
            if (wordPos == -1) {
                currentPos += word.length() + 1;
                continue;
            }
            
            // 计算全局字符位置
            int globalCharPos = textStartOffset + wordPos;
            
            // 计算精确的字节偏移量（关键步骤）
            int byteOffset = calculateByteOffset(rawBytes, globalCharPos);
            
            if (byteOffset != -1) {
                results.add(cleanWord + "," + byteOffset);
            }
            
            currentPos = wordPos + word.length();
        }
    }

    /**
     * 计算字节偏移量（与 WordDumb 一致的方法）
     */
    private static int calculateByteOffset(byte[] bytes, int charOffset) {
        try {
            // 关键：计算前 charOffset 个字符的 UTF-8 字节长度
            String prefix = new String(bytes, 0, charOffset, StandardCharsets.UTF_8);
            return prefix.getBytes(StandardCharsets.UTF_8).length;
        } catch (Exception e) {
            return -1;
        }
    }

    /**
     * 处理 HTML 转义字符
     */
    private static String unescapeHtml(String text) {
        return text.replace("&amp;", "&")
                  .replace("&lt;", "<")
                  .replace("&gt;", ">")
                  .replace("&quot;", "\"")
                  .replace("&apos;", "'")
                  .replace("&nbsp;", " ");
    }

    /**
     * 清理词汇
     */
    private static String cleanWord(String word) {
        return word.replaceAll("^[^\\w]+|[^\\w]+$", "").toLowerCase();
    }

    /**
     * 测试方法
     */
    public static void main(String[] args) {
        try {
            String mobiPath = "E:\\download\\mobi\\1.mobi";
            String wordList = "copyright";
            
            System.out.println("开始处理 Mobi 文件...");
            String positions = findWordPositions(mobiPath, wordList);
            
            System.out.println("找到的词汇位置:");
            System.out.println(positions);
            
        } catch (Exception e) {
            System.err.println("处理过程中出错: " + e.getMessage());
            e.printStackTrace();
        }
    }
}