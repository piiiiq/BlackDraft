package yang.app.qt.black;

import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class testjdbc {
	public static void main(String args[]) {
//		 String dbpath = "E:\\download\\coca\\wiktionary_en_zh_cn_v0.db";
//		 Connection con = SqliteJDBCUtil.createRssDBFile(dbpath);
//		
//		 
//		StringBuffer createTableSql = new StringBuffer("create table tableTest (");
//		createTableSql.append("id INTEGER, name NTEXT,");
//		createTableSql.append("typeId INTEGER, logoUrl text");
//		createTableSql.append(");");
//		SqliteJDBCUtil.createTable(con, createTableSql.toString(), "tableTest"); // 2，创建一个表
//
//		PreparedStatement prep = SqliteJDBCUtil.editSql(con); // 3， 向表中插入SQL
//
//		SqliteJDBCUtil.submitSql(con, prep); // 提交
//
//		SqliteJDBCUtil.close(prep, con);
		readtext();
	}
	
	static void readtext() {
    	WordFormsGenerator tool = WordFormsGenerator.getInstance();
		File f = new File("E:\\download\\coca\\COCA20000.txt1");
		StringBuffer sb1 = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		StringBuffer sb3 = new StringBuffer();
		StringBuffer sb4 = new StringBuffer();
		StringBuffer sb5 = new StringBuffer();
		StringBuffer sb6 = new StringBuffer();

		sb1.append("form,pos,lemma_id\n");
		sb2.append("id,lemma,ga_ipa,rp_ipa\n");
		sb3.append("id,enabled,lemma_id,pos,short_def,full_def,example,difficulty\n");
		sb4.append("id,lemma\n");
		sb5.append("id,display_lemma_id,term_id,term_lemma_id,pos_type,source_id,sense_number,synset_id,corpus_count,full_def,short_def,example_sentence\n");
		
		int lemmaid = 26665;
		int id = 41075;
		
		String text = io.readTextFile(f,"utf-8");
		ArrayList<String> allLine = cheakDocument.getAllLine(text);
		for(String line:allLine) {
			//词汇
			String word = null;
			//储存所有含义，每行储存一种含义，每种含义开头是词性加点号
			//美国音标
			String gat = "";
			//英国音标
			String rpt = "";
			//默认词性
			String pos = null;
			//编号
			String linenumber = null;
			ArrayList<String> al = new ArrayList<String>();
			ArrayList<String> argss = cheakDocument.checkCommandArgs(line, '\t');
			int i = 1;
			for(String s:argss) {
				if(i==1) linenumber = s;
				else if(i==2) {
					//提取词汇
					word = s;
				}
				else if(i==3) {
					//提取音标
					TextRegion ga = cheakDocument.subString(s, "美 [", "]");
					TextRegion rp = cheakDocument.subString(s, "英 [","]");
					if(ga != null && ga.text != null)
						gat = "/"+ga.text+"/";
					if(rp != null && rp.text != null)
						rpt = "/"+rp.text+"/";
				}
				
				
				
				else if(i==4) {
//					System.out.println(s);
					
					int startindex = -1;
					int startindexnext = -1;
					boolean ok = false;
					for(int a=0;a<s.length();a++) {
						char charAt = s.charAt(a);
						
						if(startindex == -1 && charAt >= 'a' && charAt <= 'z') {
							startindex = a;
						}
						
						else if(charAt == '.') {
							if(ok && startindexnext != -1) {
								String substring = s.substring(startindex, startindexnext);
								al.add(substring);
								startindex = startindexnext;
								startindexnext = -1;
								ok = false;
							}
							ok = true;
						}
						else if(ok && charAt >= 'a' && charAt <= 'z') {
							if(startindexnext == -1)
								startindexnext = a;
							
						}
						else if(a == s.length()-1 && startindex != -1 && ok) {
							String substring = s.substring(startindex, s.length());
							al.add(substring);
						}
					}
					String defalutInfo = al.get(0);
					pos = cheakDocument.subString(defalutInfo, 0, ".").text;
					
					String[] forms = tool.getWordForms(word);
					sb6.append(word+"\n");
					int index = -1;
					do {
						String word_ = word;
						if(index != -1 && index < forms.length) {
							word_ = cheakDocument.subString(forms[index], ",")[0];
							if(word_.equals(forms[index]) || word_.equals(word)) {
								index++;
								continue;
							}
						}else if(index != -1) {
							break;
						}
						lemmaid++;
						sb1.append(word_+","+getPos(pos)+","+lemmaid+"\n");
						sb2.append(lemmaid+","+word_+","+gat+","+rpt+"\n");
						sb4.append(lemmaid+","+word_+"\n");
						
						for(String altext:al) {
//							System.out.println(linenumber+"    "+altext);
							String alpos = cheakDocument.subString(altext, 0, ".").text;
							TextRegion subString = cheakDocument.subString(altext, ".", "；");
							String shortinfo = null;
							if(subString == null) {
								ArrayList<String> ars = cheakDocument.checkCommandArgs(altext,'.');
								if(ars.size() > 1)
								shortinfo = ars.get(1);
							}else
								shortinfo = subString.text;
							String shortinfobase64 = Base64.getEncoder().encodeToString(shortinfo.getBytes());
							String infobase64 = Base64.getEncoder().encodeToString(altext.getBytes());
							String noexmaple64 = Base64.getEncoder().encodeToString("（没有找到例句）".getBytes());
							
							id++;
							
							sb3.append(id+",1,"+lemmaid+","+getPos(alpos)+","+shortinfo+","+altext+",（没有找到例句）"+",5"+"\n");
							sb5.append(id+","+lemmaid+","+lemmaid+","+lemmaid+",0,3,1,,0,"+infobase64+","+shortinfobase64+","+noexmaple64+"\n");
							
							
						}
						
//						lemmaid++;
						index++;
//					}while(index < forms.length);
					}while(index < 0);
					
					
					
		     
					
					
					
				}
				i++;
			}
//			lemmaid++;

		}
		io.writeTextFile(new File(f.toString()+"forms")	, sb1.toString(), "utf-8");
		io.writeTextFile(new File(f.toString()+"lemmas"), sb2.toString(), "utf-8");
		io.writeTextFile(new File(f.toString()+"sences"), sb3.toString(), "utf-8");
		io.writeTextFile(new File(f.toString()+"_kll_lemmas"), sb4.toString(), "utf-8");
		io.writeTextFile(new File(f.toString()+"_kll_sences"), sb5.toString(), "utf-8");
		io.writeTextFile(new File(f.toString()+"_words"), sb6.toString(), "utf-8");

	}
	public static String getPos(String pos) {
		if(pos.equals("noun")) return pos;
		else if(pos.equals("verb")) return pos;
		else if(pos.equals("adjective")) return pos;
		else if(pos.equals("adverb")) return pos;
		else if(pos.equals("article")) return pos;
		else if(pos.equals("number")) return pos;
		else if(pos.equals("conjunction")) return pos;
		else if(pos.equals("conjunction")) return pos;
		else if(pos.equals("conjunction")) return pos;
		else if(pos.equals("other")) return pos;
		else if(pos.equals("preposition")) return pos;
		else if(pos.equals("pronoun")) return pos;
		else if(pos.equals("particle")) return pos;
		else if(pos.equals("punctuation")) return pos;
		else return "noun";
	}
}
