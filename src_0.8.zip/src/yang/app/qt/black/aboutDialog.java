package yang.app.qt.black;

import io.qt.core.Qt.Alignment;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.gui.QPixmap;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QDialog;
import io.qt.widgets.QLabel;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QTabWidget;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QWidget;

public class aboutDialog extends QDialog{
	private QTabWidget tabwidget;
	private QLabel topMessage;
	private QLabel bottomMessage;
	private QLabel icon;
	private QTextEdit aboutInfo;
	private QTextEdit opensourceInfo;
	black b;
	private QTextEdit updateInfo;
	private QTextEdit systemInfo;
	private QTextEdit creatorInfo;
	public aboutDialog(black b,String windowTitle) {
		super(b);
		if(b != null) {
			this.b = b;
		}
		setWindowTitle(windowTitle);
		setAttribute(WidgetAttribute.WA_DeleteOnClose);
		QBoxLayout bl = uiTool.getBoxLayout(0);
		QBoxLayout bl1 = uiTool.getBoxLayout(2);
		bl1.setAlignment(AlignmentFlag.AlignLeft,AlignmentFlag.AlignVCenter);
		QBoxLayout buttons = uiTool.getBoxLayout(2);
		bl.addLayout(bl1);
		topMessage = new QLabel();
		topMessage.setAlignment(new Alignment(AlignmentFlag.AlignVCenter));
		icon = new QLabel();
		bl1.addWidget(icon);
		bl1.setAlignment(icon);
		bl1.addWidget(topMessage, 0);
		bl1.setAlignment(topMessage);
		
		tabwidget = new QTabWidget();
		QWidget aboutTab = uiTool.addNewTap(tabwidget, languageTool.getString(50));
		QWidget creatorTab = uiTool.addNewTap(tabwidget, languageTool.getString(51));
		QWidget systemTab = uiTool.addNewTap(tabwidget, languageTool.getString(52));
		QWidget opensourceTab = uiTool.addNewTap(tabwidget, languageTool.getString(54));
		QWidget updateTab = uiTool.addNewTap(tabwidget, languageTool.getString(53));
		
		
		
		aboutInfo = new QTextEdit(aboutTab);
		updateInfo = new QTextEdit(updateTab);
		opensourceInfo = new QTextEdit(opensourceTab);
		systemInfo = new QTextEdit(systemTab);
		creatorInfo = new QTextEdit(creatorTab);
		
		aboutInfo.setReadOnly(true);
		updateInfo.setReadOnly(true);
		systemInfo.setReadOnly(true);
		opensourceInfo.setReadOnly(true);
		creatorInfo.setReadOnly(true);
		
		aboutTab.layout().addWidget(aboutInfo);
		creatorTab.layout().addWidget(creatorInfo);
		systemTab.layout().addWidget(systemInfo);
		updateTab.layout().addWidget(updateInfo);
		opensourceTab.layout().addWidget(opensourceInfo);
		
		bl.addWidget(tabwidget);
		bottomMessage = new QLabel();
		bottomMessage.setContentsMargins(10, 10, 20, 10);
		bottomMessage.setAlignment(AlignmentFlag.AlignRight);
		bl.addWidget(bottomMessage);
		bl.addLayout(buttons);
		QPushButton toWeb = new QPushButton(languageTool.getString(55));
		toWeb.clicked.connect(this, "toWeb()");
		QPushButton ok = new QPushButton(languageTool.getString(56));
		ok.clicked.connect(this, "ok()");
		
		buttons.addWidget(toWeb);
		buttons.addWidget(ok);
		
		setLayout(bl);
		
		ok.setFocus();
	}
	void toWeb() {
		if(b != null) b.ba.openUrl();
	}
	void ok() {
		close();
	}
	public void setIcon(QPixmap pix) {
		icon.setPixmap(pix);
	}
	public void setTopText(String text) {
		topMessage.setText(text);
	}
	public void setBottomText(String text) {
		bottomMessage.setText(text);
	}
	public void setAboutInfo(String info) {
		aboutInfo.setHtml(info);
	}
	public void setUpdateInfo(String info) {
		updateInfo.setHtml(info);
	}
	public void setOpenSourceInfo(String info) {
		opensourceInfo.setHtml(info);
	}
	public void setCreatorInfo(String info) {
		creatorInfo.setHtml(info);
	}
	public void setSystemInfo(String info) {
		systemInfo.setHtml(info);
	}
}
