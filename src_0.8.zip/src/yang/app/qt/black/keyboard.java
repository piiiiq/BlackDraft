package yang.app.qt.black;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import io.qt.core.Qt;
import io.qt.core.Qt.FindChildOption;
import io.qt.core.Qt.Key;
import io.qt.core.Qt.KeyboardModifier;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QKeySequence;
import io.qt.gui.QTextBlock.iterator;
import io.qt.widgets.QAction;
import io.qt.gui.QTextCursor;
import yang.app.qt.black.appInfo.UIObject;
import yang.demo.allPurpose.DesUtils;

public class keyboard {
	HashMap<Integer, keyLink> keys = new HashMap<Integer, keyLink>();
	HashMap<Integer, keyLink> keys_user = new HashMap<Integer, keyLink>();
//	int index_keys = -1;
//	int index_keys_user = -1;
	black b;
	public keyboard(black b) {
		this.b = b;
	}
	/**
	 * 查找给定index的样式的样式快捷键的定义
	 * @param styleindex
	 * @return
	 */
	public keyLink findStyleKey(int styleindex) {
		Collection<keyLink> values = keys_user.values();
		Iterator<keyLink> it = values.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(styleindex == next.keyActionIndex) return next;
		}
		return null;
	}
	/**
	 * 删除样式快捷键，包括定义和链接
	 * @param styleindex
	 */
	public void removeStyleKey(int styleindex) {
		keyLink key = findStyleKey(styleindex);
		ArrayList<keyLink> al = new ArrayList<keyLink>();
		al.add(key);
		if(key != null) {
			Iterator<keyLink> it = keys_user.values().iterator();
			while(it.hasNext()) {
				keyLink next = it.next();
				if(next.k != null && next.k.equals(key)) {
					al.add(next);
				}
			}
			Iterator<keyLink> remove = al.iterator();
			while(remove.hasNext()) {
				keyLink next = remove.next();
				keys_user.remove(next.index);
			}
		}
	}
	/**
	 * 获取指向同一个程序定义的动作的所有快捷键集合的文本描述，该方法只用于菜单，所以返回的文本前面可能带有\t
	 * @param k
	 * @return
	 */
	public String getKeyTextOfSameAppAction(int index) {
		keyLink k = keys.get(index);
		if(k == null) return null;
		
		keyLink key = null;
		if(k.k == null) key = k;
		else key = k.k;
		StringBuffer sb = new StringBuffer();
		String keyText = key.getKeyText();
		if(!keyText.isEmpty()) sb.append("\t"+keyText);
		Iterator<keyLink> it = keys_user.values().iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.k != null && next.k.equals(key)){
				String keyText2 = next.getKeyText();
				if(sb.length() == 0) {
					if(!keyText2.isEmpty()) sb.append("\t"+keyText2);
				}else if(!keyText2.isEmpty()) sb.append("/"+next.getKeyText());
			}
		}
		return sb.toString();
	}
	/**
	 * 判断组合键是否只含有修饰键
	 * @param key
	 * @return
	 */
	public static boolean onlyHasModifier(String key) {
		ArrayList<String> args = cheakDocument.checkCommandArgs(key, '+');
		for(String arg:args) {
//			System.out.println(arg);
			if(!arg.equals("ctrl") && !arg.equals("alt") && !arg.equals("shift")) return false;
		}
		return true;
	}
	/**
	 * 比较两个组合键文本确定是否是相同的组合键
	 * @param modifier1
	 * @param modifier2
	 * @return
	 */
	public static boolean keyTextCompare(String modifier1,String modifier2) {
		ArrayList<String> args = cheakDocument.checkCommandArgs(modifier1, '+');
		ArrayList<String> args2 = cheakDocument.checkCommandArgs(modifier2, '+');
		if(args.size() != args2.size())return false;
		for(String arg:args) {
			boolean equal = false;
			for(String arg2:args2) {
				if(arg2.equals(arg)) {
					equal = true;
					break;
				}
			}
			if(!equal)return false;
		}
		return true;
	}
	/**
	 * 获取给定keys hashmap的下一个可用的index值
	 * @param keys
	 * @return
	 */
	int getNextIndex(HashMap<Integer, keyLink> keys) {
		Set<Integer> keySet = keys.keySet();
		int i = -1;
		for(int index:keySet) {
			if(index > i) i = index;
		}
		return i+1;
	}
	/**链接和快捷短语存放在keys_user中，不能放在keys中，因为keys中的index会在程序中新加入快捷键动作后发生改变，导致数据还原出错
	 * 
	 * @param index -1时自动添加到末尾
	 * @param k
	 */
	void addKey(int index,keyLink k) {
//		System.out.println("addKeys:"+index+" "+k.info);
		int ind = index;
		//程序内置快捷键的定义
		if(k.keytype == 0 && k.k == null) {
			if(ind == -1) ind = getNextIndex(keys);
			if(keys.get(index) != null) {
				black.debugPrint("【警告】要添加的快捷键的index("+index+")已经存在，此快捷键将覆盖已存在的快捷键绑定动作");
			}
			keys.put(ind, k);
		}
		//所有非程序内置的按键定义，都存放到keys_user里
		else {
			if(ind == -1) ind = getNextIndex(keys_user);
			if(keys_user.get(index) != null) {
				black.debugPrint("【警告】要添加的快捷键的index("+index+")已经存在，此快捷键将覆盖已存在的快捷键绑定动作");
			}
			keys_user.put(ind, k);
		}
		//如果是程序内置的按键定义（非链接），检查其是否需要添加到UI界面
		k.index = ind;
		key kk = null;
		try {
			kk = (key)k;
		}catch(Exception e) {}
		if(kk != null && kk.addToUI != UIObject.none) kk.addToUI(kk.addToUI, kk.addSeparatorType,kk.before);
		else setUIKeyText(k,"");

	}
	/**
	 * 更新菜单等ui控件上的快捷键
	 */
	public void setUIKeyText(keyLink k,String oldKeyText) {
		if(k.keytype == 1) return;
		int index = -1;
		if(k.k == null) index = k.index;
		else index = k.k.index;
		
		String keyText = k.getKeyText();
		List<QAction> findChildren = black.b.findChildren(QAction.class, index+"", FindChildOption.FindChildrenRecursively);
		Iterator<QAction> it = findChildren.iterator();
		String spilt = "/";
		while(it.hasNext()) {
			QAction next = it.next();
			String text = next.text();
			
			if(k.context == -1) {
				String str1 = spilt+keyText+spilt;
				String str2 = spilt+keyText;
				String str3 = keyText+spilt;
				if(text.indexOf(str1) != -1) {
					text = text.replace(str1, spilt);
				}else if(text.indexOf(str2) != -1) {
					text = text.replace(str2, "");
				}else if(text.indexOf(str3) != -1) {
					text = text.replace(str3, "");
				}
			}else {
				if(!oldKeyText.isEmpty()) text = text.replace(oldKeyText, keyText);
				else {
					 String[] subString = cheakDocument.subString(text, "\t");
					 if(subString[1].isEmpty()) text = subString[0]+"\t"+k.getKeyText();
					 else text = text+spilt+keyText;
				}
			}
			next.setText(text);
		}
	}
	void removeProjectKeyData() {
		Collection<keyLink> values = keys.values();
		Iterator<keyLink> it = values.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.keytype == 1) it.remove();

		}
		
	}
	void saveAppKeyData() {
		String split = "\t";
		String keydataFile_app = "."+File.separator+"CFG"+File.separator+"keydata";
		StringBuffer sb = new StringBuffer();
		Collection<keyLink> values = keys.values();
		Iterator<keyLink> it = values.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.keytype == 0) {
				if(next.k == null) {
					if(!next.getKeyText().equals(next.getKeyText(next.defaultKey, next.defaultKeycode))) {
						String keydata = "0"+split+next.index+split+next.key+split+next.keycode;
						sb.append(keydata+"\n");
					}
				}
			}
		}
		Collection<keyLink> values_user = keys_user.values();
		Iterator<keyLink> it_user = values_user.iterator();
		while(it_user.hasNext()) {
			keyLink next = it_user.next();
			if(next.keytype == 0) {
				if(next.k != null) {
					String keydata = "1"+split+next.index+split+next.k.index+split+next.key+split+next.keycode;
					sb.append(keydata+"\n");
				}
			}else if(next.keytype == 5) {
				//样式快捷键不管是定义还是链接都储存在程序中
				//样式快捷键的定义
				if(next.k == null) {
					String keydata = "5"+split+next.index+split+next.keyActionIndex+split+next.key+split+next.keycode;
					sb.append(keydata+"\n");
				}else {
					//样式快捷键的链接
					String keydata = "6"+split+next.index+split+next.k.index+split+next.key+split+next.keycode;
					sb.append(keydata+"\n");
				}
			}
		}
//		System.out.println(sb.toString());
		io.writeTextFile(new File(keydataFile_app), sb.toString(), "utf-8");
	}
	void saveProjectKeyData(DesUtils des) {
		String split = "\t";
		String keydataFile_project = b.ba.getProjectSettingsDirPath()+File.separator+"keydata";
		StringBuffer sb = new StringBuffer();
		Collection<keyLink> values = keys_user.values();
		Iterator<keyLink> it = values.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.keytype == 1) {
				if(next.k == null) {
					String keydata = "1"+split+next.index+split+next.key+split+next.keycode+split+bAction.getStringWithEncrypt(des, next.info);
					sb.append(keydata+"\n");
				}else {
					String keydata = "2"+split+next.index+split+next.k.index+split+next.key+split+next.keycode;
					sb.append(keydata+"\n");
				}
				
			}
		}
		io.writeTextFile(new File(keydataFile_project), sb.toString(), "utf-8");
	}
	void readAppKeyData() {
		String keydataFile_app = "."+File.separator+"CFG"+File.separator+"keydata";
		File fileappdata = new File(keydataFile_app);
		if(fileappdata.exists()) {
			String appdata = io.readTextFile(fileappdata, "utf-8");
			ArrayList<String> allLine = cheakDocument.getAllLine(appdata);
			for(String line:allLine) {
				ArrayList<String> args = cheakDocument.checkCommandArgs(line,'\t');
//				System.out.println("keyLine: "+line +" "+args.get(0).equals("0"));
				if(args.get(0).equals("0")) {
//					keyLink keyLink = new keyLink(args.get(2),Integer.valueOf(args.get(3)),args.get(4),0,0,false);
//					keyLink.keytype = 1;
//					System.out.println("keyssize: "+keys.size());
					keyLink keyLink = keys.get(Integer.valueOf(args.get(1)));
					String keyText = keyLink.getKeyText();
					keyLink.setKey(args.get(2), Integer.valueOf(args.get(3)));
					setUIKeyText(keyLink,keyText);
//					System.out.println("keyssize: "+keys.size());

//					addKey(Integer.valueOf(args.get(1)), keyLink);
				}else if(args.get(0).equals("1")) {
					key k = (key)keys.get(Integer.valueOf(args.get(2)));
					keyLink kl = new keyLink(args.get(3), Integer.valueOf(args.get(4)),k.context,k.type,k,k.selectionText);
//					kl.defaultKey = k.defaultKey;
//					kl.defaultKeycode = k.defaultKeycode;
					addKey(Integer.valueOf(args.get(1)), kl);
					
				}else if(args.get(0).equals("5")) {
					addKeys.styleKey(Integer.valueOf(args.get(1)), this, args.get(3), Integer.valueOf(args.get(4)), Integer.valueOf(args.get(2)));
				}else if(args.get(0).equals("6")) {
					key k = (key)keys_user.get(Integer.valueOf(args.get(2)));
					keyLink kl = new keyLink(args.get(3), Integer.valueOf(args.get(4)),k.context,k.type,k,k.selectionText);
//					kl.defaultKey = k.defaultKey;
//					kl.defaultKeycode = k.defaultKeycode;
					kl.keytype = 5;
					addKey(Integer.valueOf(args.get(1)), kl);
				}
			}
		}
	}
	/**
	 * 加载并处理projectKeydata
	 *
	 */
	void readProjectKeyData() {
		String keydataFile_project = b.ba.getProjectSettingsDirPath()+File.separator+"keydata";
		File fileprodata = new File(keydataFile_project);
		
		if(fileprodata.exists()) {
			String prodata = io.readTextFile(fileprodata, "utf-8");
			ArrayList<String> allLine = cheakDocument.getAllLine(prodata);
			for(String line:allLine) {
				ArrayList<String> args = cheakDocument.checkCommandArgs(line,'\t');
//				System.out.println("keyLine: "+line +" "+args.get(0).equals("1"));
				if(args.get(0).equals("1")) {
					//处理快捷短语定义
//					keyLink keyLink = new keyLink(args.get(2),Integer.valueOf(args.get(3)),args.get(4),0,0,false);
//					keyLink.keytype = 1;
//					System.out.println("keyssize: "+keys.size());
					addKeys.customInputText(Integer.valueOf(args.get(1)),this, args.get(2), Integer.valueOf(args.get(3)), bAction.getStringWithDncrypt(black.des_doc, args.get(4)));
//					System.out.println("keyssize: "+keys.size());

//					addKey(Integer.valueOf(args.get(1)), keyLink);
				}else if(args.get(0).equals("2")) {
					//处理快捷短语链接
					key k = (key) keys_user.get(Integer.valueOf(args.get(2)));
					keyLink kl = new keyLink(args.get(3), Integer.valueOf(args.get(4)),k.context,k.type,k,k.selectionText);
					kl.keytype = k.keytype;
					kl.defaultKey = k.defaultKey;
					kl.defaultKeycode = k.defaultKeycode;
					addKey(Integer.valueOf(args.get(1)), kl);
				}
			}
		}	
	}
	/**
	 * 检测给定的按键是否已经被占用，如果已经被占用，会弹出提示框
	 * @param keytext
	 * @param selectionText
	 * @return
	 */
	public boolean isHasKey(String keytext,boolean selectionText) {
		Collection<keyLink> values = keys.values();
		Iterator<keyLink> it = values.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.selectionText == selectionText) {
				if(b.ba.keyboard.keyTextCompare(keytext, next.getKeyText())) {
					System.out.println(keytext+"  "+next.getKeyText());
					String info = next.info;
					if(next.keytype == 1) info = languageTool.getString(331)+"("+next.info+")";
					b.getMessageBox(languageTool.getString(1399), languageTool.getString(1400,keytext,next.index,info));

					return true;
				}

			}
		}
		
		Collection<keyLink> values_user = keys_user.values();
		Iterator<keyLink> it_user = values_user.iterator();
		while(it_user.hasNext()) {
			keyLink next = it_user.next();
			if(next.selectionText == selectionText) {
				if(b.ba.keyboard.keyTextCompare(keytext, next.getKeyText())) {
					String info = next.info;
					if(next.keytype == 1) info = languageTool.getString(331)+"("+next.info+")";
					int index = getNextIndex(keys)+next.index;
					b.getMessageBox(languageTool.getString(1399), languageTool.getString(1400,keytext,index,info));
					return true;
				}

			}
		}
		return false;
	}
	public static String getKeyText(int value) {
//		Key[] values = Qt.Key.values();
//		for(Key k:values) {
//			if(k.value() == value)return k.name().replaceFirst("Key_", "").toLowerCase();
//		}
//		return null;
		QKeySequence key = new QKeySequence(value);
		return key.toString();
	}
	public static String getModifierKeyName(QKeyEvent ke) {
		String key = "";
		if(ke.modifiers().isSet(KeyboardModifier.ControlModifier)) {
			if(!key.isEmpty())
				key = key+"+ctrl";
			else key = "ctrl";
		}
		if(ke.modifiers().isSet(KeyboardModifier.ShiftModifier)) {
			if(!key.isEmpty())
				key = key+"+shift";
			else key = "shift";
		}
		if(ke.modifiers().isSet(KeyboardModifier.AltModifier)) {
			if(!key.isEmpty())
			key = key+"+alt";
			else key = "alt";
		}
		return key.toLowerCase();
	}
	public static String getKeyName(QKeyEvent ke) {
		String key = "";
		if(ke.key() != Qt.Key.Key_Alt.value() && ke.key() != Qt.Key.Key_Control.value() && ke.key() != Qt.Key.Key_Shift.value())
			key = keyboard.getKeyText(ke.key()).toLowerCase();
			
		String modifierKeyName = getModifierKeyName(ke);
		if(!modifierKeyName.isEmpty()) key = modifierKeyName+"+"+key;
		
		return key;
	}

	boolean checkKey(QKeyEvent ke,int context) {
		boolean ctrl = ke.modifiers().isSet(KeyboardModifier.ControlModifier);
		boolean shift = ke.modifiers().isSet(KeyboardModifier.ShiftModifier);
		boolean alt = ke.modifiers().isSet(KeyboardModifier.AltModifier);
		
//		System.out.println("keyText:" + ke.text() +" isEmpty "+ ke.text().isEmpty()+" is"+ke.text().equals(""));
		//对于常用按键，必须按下至少一个修饰键才会检索组合键
//		if(!ke.text().isEmpty() && !ke.text().equals("") && !ctrl && !shift && !alt) return false;
		
		black.debugPrint("按下了："+keyboard.getKeyName(ke));

		Collection<keyLink> ks = keys.values();
		QTextCursor tc = null;
		if(b.text != null)
			tc = b.text.textCursor();
		
		Iterator<keyLink> it = ks.iterator();
		while(it.hasNext()) {
			keyLink next = it.next();
			if(next.key.isEmpty() && next.keycode == -1) continue;
			if(next.selectionText) {
				if(tc == null || !tc.hasSelection()) continue;
			}
			if(next.context != context) continue;
				
			if(next.keycode == ke.key() || next.keycode == -1) {
				if(next.ctrl == ctrl && next.shift == shift && next.alt == alt){
						black.debugPrint("准备执行快捷键绑定动作["+next.info+"]");
						if(next.action()) return true;
						
				}
			}
		}
		Collection<keyLink> ks_user = keys_user.values();
//		System.out.println("key size: "+ks.size());
		Iterator<keyLink> it_user = ks_user.iterator();
		while(it_user.hasNext()) {
			keyLink next = it_user.next();
//			System.out.println(next.info+" modifierKey: "+next.key+ " keyText: "+next.getKeyText());
			if(next.key.isEmpty() && next.keycode == -1) continue;
			if(next.selectionText) {
				if(tc == null || !tc.hasSelection()) continue;
			}
			if(next.context != context) continue;
			
			if(next.keycode == ke.key() || next.keycode == -1) {
				if(next.ctrl == ctrl && next.shift == shift && next.alt == alt){
					black.debugPrint("准备执行快捷键绑定动作["+next.info+"]");
					if(next.action()) return true;
				}
			}
		}
		return false;
	}
}
class keyLink{
	String key,defaultKey;
	/**
	 * 快捷键触发时的上下条件，全局触发为0，textedit中触发为1，如果对象已经被删除则此字段为-1
	 */
	int context,index;
	/**
	 * 指示快捷键类型，0为程序定义的的快捷键，1为与快捷短语关联的快捷键，5为设置文档内容样式的快捷键
	 */
	int keytype = 0;
	/**
	 * 如果key关联的动作储存在数据结构里，该参数用来指示该动作位于数据结构里的索引index，以便通过该index查询数据结构里对应的对象
	 */
	int keyActionIndex = -1;
	int keycode,type,defaultKeycode;
	boolean ctrl,shift,alt,selectionText;
	String info;
	key k;
	
	public keyLink() {
		
	}
	/**此类用于创建key类对象的快捷方式，此类没有自己的action方法，只能调用给定actionKey对象的action方法
	 * 为key参数指定ctrl/shift/alt修饰键，keycode参数指定按键的int值
	 * @param modifierkey 修饰键
	 * @param keycode,键码
	 * @param info按键功能描述
	 * @param context按键的上下文对象，即在哪个对象中触发，0是主编辑器
	 * @param type指示按键类型，0按下，1释放
	 * @param actionKey 此Kkey对象被触发后将调用的给定的actionKey对象的action方法
	 * @param selectionText 是否将选中文本作为触发条件
	 */
	public keyLink(String modifierkey,int keycode,int context,int type,key actionKey,boolean selectionText) {
		this.key = modifierkey;
		this.keycode = keycode;
		this.defaultKey = modifierkey;
		this.defaultKeycode = keycode;
		this.context = context;
		this.type = type;
		this.selectionText = selectionText;
		k = actionKey;
		info = actionKey.info;
		setModifierKeyData();
	}
	public keyLink(String modifierkey,int keycode,String info,int context,int type,boolean selectionText) {
		this.key = modifierkey;
		this.keycode = keycode;
		this.info = info;
		this.defaultKey = modifierkey;
		this.defaultKeycode = keycode;
		this.context = context;
		this.type = type;
		this.selectionText = selectionText;
		setModifierKeyData();
	}
	
	public keyLink(String keytext,String info) {
		keytextToKeydata(keytext);
		this.info = info;
	}
	
	
	void setModifierKeyData() {
		ctrl = key.indexOf("ctrl") != -1;
		alt = key.indexOf("alt") != -1;
		shift = key.indexOf("shift") != -1;
	}
	public void setKey(String modifierkey,int keycode) {
		this.key = modifierkey;
		this.keycode = keycode;
		setModifierKeyData();
	}
	public String getKeyText() {
		return getKeyText(key, keycode);
	}
	/**
	 * 返回此对象是否是keyLink类的对象，如果是keyLink类的对象返回true，如果是其子类key类的对象返回false
	 * @return
	 */
	public boolean isKeyLinkObject() {
		return k != null;
	}
	/**
	 * 返回包含所有触发条件的文本描述
	 * @return
	 */
	public String getAllText(boolean isDefalut) {
		String needSelectionText = getAddsText();
		if(!isDefalut)
		return needSelectionText+getKeyText();
		else return needSelectionText+getKeyText(defaultKey,defaultKeycode);
	}
	/**
	 * 获取附加触发条件的文本描述
	 * @return
	 */
	public String getAddsText() {
		String needSelectionText = "";
		if(selectionText) needSelectionText = languageTool.getString(1401);
		return needSelectionText;
	}
	public String getKeyText(String modifier,int keycode) {
		String keytext = null;
		if(modifier.isEmpty() && keycode != -1)keytext = keyboard.getKeyText(keycode).toLowerCase();
		else if(keycode != -1)keytext = modifier+"+"+keyboard.getKeyText(keycode).toLowerCase();
		else keytext = modifier;
		
		if(keytext != null && !keytext.isEmpty())return keytext;
		else return "";
	}
	public void keytextToKeydata(String keytext) {
		ArrayList<String> args = cheakDocument.checkCommandArgs(keytext, '+');
		StringBuffer sb = new StringBuffer();
		int code = -1;
		for(String arg:args) {
			if(arg.equals("ctrl")) {
				if(sb.length() == 0)sb.append("ctrl");
				else sb.append("+ctrl");
					
			}
			else if(arg.equals("alt")) {
				if(sb.length() == 0)sb.append("alt");
				else sb.append("+alt");
			}
			else if(arg.equals("shift")) {
				if(sb.length() == 0)sb.append("shift");
				else sb.append("+shift");
			}
			else {
				code = new QKeySequence(arg).at(0);
				break;
			}
		}
		setKey(sb.toString(), code);
		defaultKey = sb.toString();
		defaultKeycode = code;
	}
	
	boolean action() {
		return k.action();
	}
}
	abstract class key extends keyLink{
	UIObject addToUI = UIObject.none;
	String  before = null;
	/**
	 * 0在此动作前添加Separator；1在此动作后添加Separator,其他值不添加
	 */
	int addSeparatorType;
	public key(String modifierkey, int keycode, String info, int context, int type,boolean selectionText) {
		super(modifierkey, keycode, info,context, type,selectionText);
		// TODO Auto-generated constructor stub
	}
	/**
	 * 使用纯文本描述的按键组合初始化key对象
	 * @param keytext 使用小写字母描述的组合键，例如ctrl+alt+shift+a
	 * @param info
	 */
	public key(String keytext,String info) {
		super(keytext, info);
	}
	public key(String modifierkey,int keycode,String info,int context,int type,boolean selectionText,UIObject addToUI,int addSeparator) {
		super(modifierkey, keycode, info, context, type, selectionText);
		setModifierKeyData();
	}
	
	public key(String keytext,String info,UIObject addToUI,int addSeparator,QAction before) {
		super(keytext, info);
		keytextToKeydata(keytext);
		this.info = info;
	}

	void addToUI(UIObject ui,int addSeparatorType,String before) {
		this.addToUI = ui;
		this.addSeparatorType = addSeparatorType;
		QAction act = bAction.getQAction(info+"\t"+getKeyText(), index+"", this, "action()");
		black.b.ba.addActionToUI(act, ui, addSeparatorType,before);
	}
	
	abstract boolean action();
}
