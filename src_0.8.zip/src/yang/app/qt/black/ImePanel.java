package yang.app.qt.black;

import io.qt.core.QPoint;
import io.qt.core.QRect;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.GlobalColor;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.core.Qt.WindowType;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QFontMetrics;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPalette;
import io.qt.gui.QPalette.ColorRole;
import io.qt.gui.QPen;
import io.qt.gui.QPixmap;
import io.qt.widgets.QFrame;
import io.qt.widgets.QWidget;
/**
 * 因为不能在Qwidget的绘制函数内设定界面尺寸（设定尺寸不会导致重复调用，但会出现一些奇奇怪怪的问题），
 * 所以只能先对界面尺寸进行计算，并设定尺寸，然后再绘制到一张图片中，然后将图片内容绘制到界面
 * @author Administrator
 *
 */
public class ImePanel extends QFrame {
	data[] data;
	int left=0,right=0,top=1,bottom=1,space=0;
	/**
	 * 文本距离背景左侧的偏移量
	 */
	int leftText=5;
	/**
	 * 每个候选项背景左右两侧的空白宽度，-1时没有空白
	 * 
	 */
	int HSpace=5;
	int VSpace=0;
	/**
	 * info右侧与边框之间的距离
	 */
	int infoRigthSpace = 10;
	/**
	 * 左侧文本与右侧info之间的距离
	 */
	int textInfoSpace = 0;
	int infoVSpace = 0;
	int infoHSpace = 10;
	QColor defautfg = new QColor(GlobalColor.black),defautbg = new QColor(GlobalColor.white);
	private QPixmap pix;
	/**
	 * 该对象使用setdata方法传入数据后会自动调整大小，无须调用其他方法更新大小.。传入新数据前无须清除现有数据
	 * @param parent
	 */
	public ImePanel(QWidget parent) {
		setWindowFlags(WindowType.ToolTip);
		setFrameShape(Shape.StyledPanel);
		setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);
//		setFont(new QFont("",12));
	}
	public void setData(data[] data) {
		this.data = data;
		if(!isVisible())setGeometry(0, 0, width(), height());
		pix = new QPixmap();
		//先计算一次，并将窗口尺寸设为需要的大小
		QPoint size = calculate(false);
		resize(size.x(),size.y());
		pix.dispose();
		//将画面绘制到图片中
		pix = new QPixmap(width(), height());
		calculate(true);
		//将图片的内容绘制到界面
		update();
	}
	public void setDefaultColor(QColor fg,QColor bg) {
		bg.setAlpha(255);
		this.defautfg = fg;
		this.defautbg = bg;
		
		QPalette p = palette();
		p.setColor(foregroundRole(), fg);
		p.setColor(backgroundRole(), bg);
		//试图通过改变所有背景role的颜色消除调节发笑时出现的白色背景闪烁问题，这是个bug，据说在qt6.1版本已经修复
		p.setColor(ColorRole.Background, bg);
		p.setColor(ColorRole.Window, bg);
		p.setColor(ColorRole.ToolTipBase, bg);
		p.setColor(ColorRole.Base, bg);
		setPalette(p);
		update();
	}
	/**
	 * 计算界面尺寸，或者直接绘制出来
	 * 因为计算界面尺寸必须遍历所有数据，计算出最长的数据条目，从而确定界面的宽度
	 * @param isPaint
	 * @return
	 */
	QPoint calculate(boolean isPaint) {
		QPainter p = new QPainter(pix);
		QPen pen = null;
		QBrush brush = null;
		if(isPaint) {
			//默认笔和刷
			pen = new QPen(defautfg);
			brush = new QBrush(defautbg);
			p.begin(pix);
			p.setBrush(brush);
			p.setPen(pen);
			p.fillRect(rect(), brush);
		}
		
		QFont font = font();

		int index = 0;
		int y = top;
		int w = 0;
		boolean hasInfo = false;
		for(data s:data) {
			QFont textfont = font;
			if(s.font_text != null) textfont = s.font_text;
			
			QFontMetrics fm = new QFontMetrics(textfont);
			QRect br = fm.boundingRect(s.text);
			int textAndInfoWidth = br.width();
			QRect rect = null;
			if(right != 0)
				rect = new QRect(left, y, br.width()+HSpace+leftText, br.height()+VSpace);
			else rect = new QRect(0, y, pix.width(), br.height()+VSpace);
			
			if(isPaint) {
				if(s.bg != null) {
					p.fillRect(rect,new QBrush(s.bg));

					//使用自定义颜色绘制后马上还原默认笔刷颜色
					p.setBrush(brush);
				}

				if(s.fg != null) {	
					p.setPen(s.fg);
				}
				p.setFont(textfont);
				rect.setX(rect.x()+leftText);
				p.drawText(rect,AlignmentFlag.AlignVCenter.value(),s.text);

				p.setFont(font);
				//还原默认
				p.setPen(pen);
			}
			
			
			if(s.info != null) {
				hasInfo = true;
				QFont infofont = font;
				if(s.font_info != null) infofont = s.font_info;
				QFontMetrics fmInfo = new QFontMetrics(infofont);
				QRect brInfo = fmInfo.boundingRect(s.info);
				
				if(isPaint) {
					int height_infoBg = brInfo.height()+infoVSpace;
					int infoBg_y = (rect.height()-height_infoBg)/2 + y;
					QRect r = new QRect(pix.width()-brInfo.width()-infoRigthSpace-infoHSpace, infoBg_y, brInfo.width()+infoHSpace, height_infoBg);
					if(s.infoFg != null)
						p.setBrush(s.infoFg);
					p.drawRoundedRect(r, 5, 5);
					p.setBrush(brush);
					if(s.infoBg != null) p.setPen(s.infoBg);
					p.setFont(infofont);
					p.drawText(r,AlignmentFlag.AlignCenter.value(), s.info);
					p.setFont(font);
					p.setPen(pen);
				}
				
				textAndInfoWidth += brInfo.width();
			}
			if(textAndInfoWidth > w) w = textAndInfoWidth;
			
			if(index != data.length-1)
				y+=(rect.height()+space);
			else y+=rect.height();
			index++;
		}
		if(hasInfo)
		w+=(left+leftText+right+HSpace+infoHSpace+infoRigthSpace+textInfoSpace);
		else 
			w+=(left+leftText+right+HSpace);
		
		y+=bottom;
		p.end();
		return new QPoint(w,y);
	}
	@Override
	protected void paintEvent(QPaintEvent event) {
		// TODO Auto-generated method stub
		QPainter p = new QPainter(this);
		QPen pen = new QPen(defautfg);
		QBrush brush = new QBrush(defautbg);
		
		p.begin(this);
		p.setBrush(brush);
		//目的为了消除背景闪烁，但是又不能完全消除闪烁
		p.fillRect(rect(), brush);
		
		if(pix != null) {
			p.drawPixmap(rect(), pix);
		}
		p.end();
		super.paintEvent(event);
	}
}
/**
 * 该类没有被使用，废弃了
 * @author Administrator
 *
 */
class paintData{
	QRect rect;
	QPen pen;
	QBrush brush;
	paintType paintType;
	QFont font;
	QPixmap pixmap;
	public paintData(QPixmap pix, paintType type,QRect rect,QPen pen,QBrush brush,QFont font) {
		pixmap = pix;
		this.paintType = paintType;
		this.rect = rect;
		this.pen = pen;
		this.brush = brush;
		this.font = font;
	}
	
	enum paintType{
		drawText,fillRect,drawRoundedRect
	}
	/**
	 * 绘制时需要确定的数据
	 */
	enum unknown{
		width(-999999999),heigth(-999999998);
		int value;
		unknown(int value) {
			this.value = value;
		}
	}
}
class data {
	String text,info;
	QColor fg,bg,infoFg,infoBg;
	QFont font_text,font_info;
	/**
	 * 所有的参数如果不指定则传入null，如果没有显式指定颜色，则始终使用默认颜色。info的颜色与text的颜色是相反的，text的前景色是info的背景色
	 * @param edit
	 * @param info
	 * @param fg
	 * @param bg 如果没有指定，则只绘制轮廓，不进行填充
	 */
	public data(String text,String info,QColor fg,QColor bg) {
		this.text = text;
		this.info = info;
		this.fg = fg;
		this.bg = bg;
	}
	public void setInfoColor(QColor fg,QColor bg) {
		infoFg = fg;
		infoBg = bg;
	}
	/**
	 * 为文本与info设置字体，如果不设置则使用默认字体；设置了字体后会忽略字号调整设置，只使用字体字号;info的字号必须小于等于text的字号
	 * @param textfont
	 * @param infofont
	 */
	public void setFonts(QFont textfont,QFont infofont) {
		this.font_text = textfont;
		this.font_info = infofont;
	}
}
