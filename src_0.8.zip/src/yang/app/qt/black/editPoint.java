package yang.app.qt.black;

import java.io.Serializable;

public class editPoint implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;
	int oldPos;
	private int pos;

	public editPoint(int pos) {
		this.pos = pos;
		oldPos = pos;
	}
	public void setPos(int pos) {
		oldPos = this.pos+(pos-this.pos);
		this.pos = pos;
	}
	public int getPos() {
		return pos;
	}
	
	public String toString() {
		return "editPoint{pos: " + pos + " oldPos: " + oldPos+"}";
	}

	public editPoint clone() {
		editPoint clone = null;
		try {
			clone = (editPoint) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}
}