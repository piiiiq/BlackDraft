package yang.app.qt.black;

import java.io.Serializable;

class markstat
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  String text;
  public int count;
  public boolean visible;
  
  public markstat(String text, int count)
  {
	setText(text);
    this.count = count;
  }
  public void setText(String text) {
	  this.text = bAction.getStringWithEncrypt(black.des_doc, text);
  }
  public String getText() {
	  return bAction.getStringWithDncrypt(black.des_doc, text);
  }
}
