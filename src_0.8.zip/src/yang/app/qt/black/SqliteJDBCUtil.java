package yang.app.qt.black;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * 对sqlite操作 
 *           所需支持依赖     sqlite-jdbc-3.8.11.1.jar
 * @author sunzhenyang on 2019-04-18
 * 
 * 
 * 注：以下所有方法不能抛异常只能捕获  不然会报错
 */
public class SqliteJDBCUtil {

    private static String dbFilePath="";
    
    public static String getDbFilePath() {
        return dbFilePath;
    }


    /**
     * 生成一个DB文件  （创建连接）    
     * @param filePath 生成文件夹的路径  如：F:/fileTest/aabb.db
     * @return 当前DB文件的连接通道
     */
    public static Connection createRssDBFile(String filePath) {
        SqliteJDBCUtil.dbFilePath = filePath; 
        Connection con=null;    
        
        try {
            Class.forName("org.sqlite.JDBC");
            //创建了一个sqlite的  .db文件
            con = DriverManager.getConnection("jdbc:sqlite:"+filePath); 
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }   
        
        return con;
    }
    
    
    /**
     * 创建表
     * @param con                  某一个DB文件的连接 
     * @param createTableSql      创建表的语句 
     * @param tableName          表名  建表时判断表是否存在 存在即删除表 （可以不传）
     * @throws SQLException  
     */
    public static void createTable(Connection con,String createTableSql,String tableName){
        try {
            Statement stat = con.createStatement();
            if(tableName != null && !"".equals(tableName)){
                stat.executeUpdate("drop table if exists "+tableName+";");
            }
            //创建表
            stat.executeUpdate(createTableSql); 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    } 
    
    /**
     * 执行SQL 外部调用是直接设置SQL语句 以及参数 传入后直接执行
     * @throws SQLException 
     */
    public static void editSql(PreparedStatement prep,Connection con){
        //执行处理
        try {
            prep.addBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }     
    }
    
    /**
     * 执行SQL
     * @throws SQLException 
     */
    public static PreparedStatement editSql(Connection con){
        PreparedStatement prep=null;
        //向rssType表中插入数据
        try {
            prep = con.prepareStatement("insert into tableTest values (?, ?, ?, ?);");
            prep.setInt(1,1);
            prep.setString(2,"qqq");
            prep.setInt(3,2);
            prep.setString(4,"11123");
            
            prep.addBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return prep;
    }
    
    /**
     * 提交SQL语句
     * @param con
     * @param prep
     * @throws SQLException
     */
    public static void submitSql(Connection con,PreparedStatement prep){
        /**
         *  默认的话为自动提交， 每执行一个update ,delete或者insert的时候都会自动提交到数据库，无法回滚事务。 
         *  设置connection.setautocommit(false);
         *  只有程序调用connection.commit()的时候才会将先前执行的语句一起提交到数据库，这样就实现了数据库的事务。
         *  还有一点是因为sqllite数据库是一个 .db的文件  没执行一次语句都要打开一次文件  所以加入事务将全部SQL放于缓存中一次性执行  只需要打开一次文件
         */
        try {
            con.setAutoCommit(false);
            prep.executeBatch(); //批量执行 
            con.setAutoCommit(true);
        } catch (SQLException e) {
            e.printStackTrace();
        }    
    }
    
    /**
     * 使用完一定要关闭连接    ***** 务必  切记   *****
     * @param prep
     * @param con
     */
    public static void close(PreparedStatement prep,Connection con){
        try {
            if(prep!=null)
                prep.close();

            if(con!=null)
                con.close();
         
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public static void main(String[] args) throws Exception {
        Connection con  = SqliteJDBCUtil.createRssDBFile("F:/fileTest/demo.db");  //1，创建一个DB文件
        
        StringBuffer createTableSql=new StringBuffer("create table tableTest (");
        createTableSql.append("id INTEGER, name NTEXT,");
        createTableSql.append("typeId INTEGER, logoUrl text");
        createTableSql.append(");");
        SqliteJDBCUtil.createTable(con, createTableSql.toString(), "tableTest");  //2，创建一个表
        
        PreparedStatement  prep = SqliteJDBCUtil.editSql(con);   //3， 向表中插入SQL
        
        SqliteJDBCUtil.submitSql(con, prep); //提交
        
        SqliteJDBCUtil.close(prep, con);

        
    }
    
    
    
}