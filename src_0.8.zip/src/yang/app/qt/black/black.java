package yang.app.qt.black;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import org.eclipse.jgit.api.errors.CheckoutConflictException;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRefNameException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.JGitInternalException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.api.errors.RefAlreadyExistsException;
import org.eclipse.jgit.api.errors.RefNotFoundException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.transport.PushResult;
import org.eclipse.jgit.transport.RemoteRefUpdate;

import com.hankcs.hanlp.corpus.dictionary.ISaveAble;

import io.qt.QUnsuccessfulInvocationException;
import io.qt.core.QByteArray;
import io.qt.core.QCoreApplication;
import io.qt.core.QEvent;
import io.qt.core.QLocale;
import io.qt.core.QLocale.Language;
import io.qt.core.QModelIndex;
import io.qt.core.QObject;
import io.qt.core.QPoint;
import io.qt.core.QPointF;
import io.qt.core.QPropertyAnimation;
import io.qt.core.QRect;
import io.qt.core.QSettings;
import io.qt.core.QSize;
import io.qt.core.QSysInfo;
import io.qt.core.Qt;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.ApplicationAttribute;
import io.qt.core.Qt.ConnectionType;
import io.qt.core.Qt.CursorShape;
import io.qt.core.Qt.DockWidgetArea;
import io.qt.core.Qt.FocusPolicy;
import io.qt.core.Qt.FocusReason;
import io.qt.core.Qt.GlobalColor;
import io.qt.core.Qt.HighDpiScaleFactorRoundingPolicy;
import io.qt.core.Qt.PenStyle;
import io.qt.core.Qt.ScrollBarPolicy;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.core.Qt.WindowFlags;
import io.qt.core.Qt.WindowType;
import io.qt.gui.QBrush;
import io.qt.gui.QClipboard;
import io.qt.gui.QCloseEvent;
import io.qt.gui.QColor;
import io.qt.gui.QCursor;
import io.qt.gui.QFont;
import io.qt.gui.QFont.SpacingType;
import io.qt.gui.QFontMetrics;
import io.qt.gui.QGradient;
import io.qt.gui.QGuiApplication;
import io.qt.gui.QHoverEvent;
import io.qt.gui.QIcon;
import io.qt.gui.QImage;
import io.qt.gui.QInputMethodEvent;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QKeySequence;
import io.qt.gui.QLinearGradient;
import io.qt.gui.QMouseEvent;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPainter.RenderHint;
import io.qt.gui.QPainterPath;
import io.qt.gui.QPalette;
import io.qt.gui.QPalette.ColorRole;
import io.qt.gui.QPen;
import io.qt.gui.QPixmap;
import io.qt.gui.QPolygon;
import io.qt.gui.QRegion;
import io.qt.gui.QShowEvent;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.gui.QTextDocument;
import io.qt.widgets.QAbstractButton;
import io.qt.widgets.QAbstractItemView;
import io.qt.widgets.QAction;
import io.qt.widgets.QApplication;
import io.qt.widgets.QComboBox;
import io.qt.widgets.QDesktopWidget;
import io.qt.widgets.QDialog;
import io.qt.widgets.QDockWidget;
import io.qt.widgets.QDockWidget.DockWidgetFeature;
import io.qt.widgets.QFileDialog;
import io.qt.widgets.QFileDialog.Result;
import io.qt.widgets.QFrame;
import io.qt.widgets.QGraphicsDropShadowEffect;
import io.qt.widgets.QGraphicsOpacityEffect;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QMenu;
import io.qt.widgets.QMenuBar;
import io.qt.widgets.QMessageBox;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QSplashScreen;
import io.qt.widgets.QTextEdit.AutoFormattingFlag;
import io.qt.widgets.QTextEdit.ExtraSelection;
import io.qt.widgets.QToolButton;
import io.qt.widgets.QTreeWidget;
import io.qt.widgets.QTreeWidgetItem;
import io.qt.widgets.QVBoxLayout;
import io.qt.widgets.QWidget;
import net.sourceforge.pinyin4j.PinyinHelper;
import yang.app.qt.black.appInfo.fontSize;
import yang.app.qt.black.appInfo.uiSize;
import yang.demo.allPurpose.DesUtils;
import yang.demo.allPurpose.MD5;
import yang.demo.allPurpose.MSTTSSpeech;
import yang.demo.allPurpose.algorithm;
import yang.demo.allPurpose.cfg_read_write;
import yang.demo.allPurpose.debug;
import yang.demo.allPurpose.fileTool;
import yang.demo.allPurpose.gitTool;
import yang.demo.allPurpose.isYourNeedFile;
import yang.demo.allPurpose.setIndex;
import yang.demo.allPurpose.time;
import yang.demo.mail.SendMailBySSL;
/**
 * 窗口透明度信息改在QTmud类内设置
 * @author test
 *
 */
public class black extends QTmud {
	Ui_black ui = new Ui_black();
	black_tree tree;
	blacktext btext;
//	QFont menuFont = new QFont("微软雅黑", 15);
	File currentEditing;
	public static QSettings settings;
	boolean saved = true;
	public ArrayList<fileInfo> filesList;
	File filesListFile;
	File projectFile;
	Properties projectInfo;
	QIcon ico_folder = new QIcon(new QPixmap(appInfo.iconsScr_16 + "dir.png"));
	QIcon ico_file = new QIcon(new QPixmap(appInfo.iconsScr_16 + "filenochar.png"));
	QIcon ico_recycle = new QIcon(new QPixmap(appInfo.iconsScr_16 + "recyclenofile.png"));
	QIcon ico_recycleHasFile = new QIcon(new QPixmap(appInfo.iconsScr_16 + "recyclehasfiles.png"));
	QIcon ico_prevFile = new QIcon(new QPixmap(appInfo.iconsScr_16 + "prevfile.png"));
	QIcon ico_nextFile = new QIcon(new QPixmap(appInfo.iconsScr_16 + "nextfile.png"));
	QIcon ico_files = new QIcon(new QPixmap(appInfo.iconsScr_16 + "files.png"));
	QIcon ico_draft = new QIcon(new QPixmap(appInfo.iconsScr_16 + "dfart.png"));
	QIcon ico_reserach = new QIcon(new QPixmap(appInfo.iconsScr_16 + "reserach.png"));
	QIcon ico_fileOfHasText = new QIcon(new QPixmap(appInfo.iconsScr_16 + "filehaschar.png"));
	QIcon ico_notes = new QIcon(new QPixmap(appInfo.icons + "notepad_icon&48.png"));
	QIcon ico_warning = new QIcon(new QPixmap(appInfo.icons + "attention_icon&48.png"));
	QIcon ico_addItem = new QIcon(new QPixmap(appInfo.iconsScr_32 + "additem.png"));
	QIcon ico_titleface = new QIcon(new QPixmap(appInfo.iconsScr_16 + "flat.png"));
	QIcon ico_find = new QIcon(new QPixmap(appInfo.iconsScr_16 + "find.png"));
	QIcon ico_names = new QIcon(new QPixmap(appInfo.iconsScr_16 + "names.png"));
	QIcon ico_timer = new QIcon(new QPixmap(appInfo.icons + "stop_watch_icon&48.png"));
	QIcon ico_app_24 = new QIcon(new QPixmap(appInfo.myicons + "ico1_24.png"));
	QIcon ico_app_48 = new QIcon(new QPixmap(appInfo.myicons + "ico1_48.png"));
	QIcon ico_app_200 = new QIcon(new QPixmap(appInfo.myicons + "ico1_200.png"));

	QIcon ico_keywordsList = new QIcon(new QPixmap(appInfo.iconsScr_16 + "keywords.png"));
	QIcon ico_keywordFirstTop = new QIcon(new QPixmap(appInfo.myicons + "keywordFirstTop.png_"));
	QIcon ico_keywordTop = new QIcon(new QPixmap(appInfo.myicons + "keywordTop.png_"));
	QIcon ico_keywordDoc = new QIcon(new QPixmap(appInfo.myicons + "keywordDoc.png_"));
	QIcon ico_keywordLine = new QIcon(new QPixmap(appInfo.myicons + "keywordLine.png_"));
	QIcon ico_keywordNo = new QIcon(new QPixmap(appInfo.myicons + "keywordNo.png_"));
	QIcon ico_mark = new QIcon(new QPixmap(appInfo.icons + "pin_map_icon&48.png"));
	QIcon ico_mark_white = new QIcon(new QPixmap(appInfo.icons + "pin_map_icon&48_white.png"));
	QIcon ico_mark_left = new QIcon(new QPixmap(appInfo.icons + "br_prev_icon&48.png"));
	QIcon ico_mark_right = new QIcon(new QPixmap(appInfo.icons + "br_next_icon&48.png"));
	QIcon ico_mark_f = new QIcon(new QPixmap(appInfo.icons + "pin_map_icon&48_f.png"));
	QIcon ico_mark_white_f = new QIcon(new QPixmap(appInfo.icons + "pin_map_icon&48_white_f.png"));
	QIcon ico_back = new QIcon(new QPixmap(appInfo.icons + "fullscreen-exit.png"));
	QIcon ico_close = new QIcon(new QPixmap(appInfo.icons + "close.png"));
	QIcon ico_save = new QIcon(new QPixmap(appInfo.icons + "content-save-outline.png"));
	QIcon ico_exitWritingView = new QIcon(new QPixmap(appInfo.icons + "arrow-collapse.png"));
	QIcon ico_minimize = new QIcon(new QPixmap(appInfo.icons + "minus.png"));
	QIcon ico_maximize = new QIcon(new QPixmap(appInfo.icons + "window-maximize.png"));
	QIcon ico_redo = new QIcon(new QPixmap(appInfo.icons + "redo-variant.png"));
	QIcon ico_undo = new QIcon(new QPixmap(appInfo.icons + "undo-variant.png"));
	QIcon ico_wikipedia = new QIcon(new QPixmap(appInfo.icons + "wikipedia.png"));
	QImage img_topBackground = new QImage(appInfo.icons + "topbg.png");
	QTreeWidgetItem draft;
	QTreeWidgetItem recycle;
	QTreeWidgetItem reserach;
	boolean isDoubleClickedOnTreeItem;
	public QMenu treeMenu;
	boolean fileListChanged;
	boolean mustSaveFileListFile;
	public fileInfo infoOfCurrentEditing;
	public QLabel countmessage;
	public QTreeWidgetItem TreeWidgetItemOfCurrentEditing;
	public QTreeWidgetItem treeWidgetItemOfKeyWordsFile;
	List<TextRegion> markTextData;
	public String marktext;
	boolean marktextIsChanged;
	boolean markstatIsChanged;
	ArrayList<markstat> markstat = new ArrayList();
	public keyWords keywords;
	public static bTextEdit text;
	static int findview = 0;
	boolean doNotAddToMoveList;
	boolean doNotHideKeywordsDialog;
	public nameCreator namecreator;
	public QColor windowColor;
	static int writingView = 0;
	QByteArray saveGeometry;
	boolean progressBugStop;
	String progressMessage;
	int progressValue;
	static StringBuilder logsmessage = new StringBuilder();
	public static QColor borderColor = new QColor(137, 142, 150);
	treeTitle treetitle;

	textTitle textTitle;
	toolbar toolbar;
	private QMenuBar menubar;
	QDockWidget dock;
	public QComboBox zoomBox;
	ArrayList<String> moveList = new ArrayList<String>();
	int moveIndex = -1;
	ArrayList<dataForOpenedFile> openedFiles = new ArrayList();
	Qt.WindowFlags windowFlags;
	String updateinfo;
	int hasUpdate;
	long allActiveTime;
	long lastActiveTime;
	long startTime;
	long lastTime;
	String writingDate;
	boolean doNotSet_UnSave;
	private bRunnable brunnableForOSD;
	String timeMode;
	int charCountWithoutEnter;
	private ArrayList<String> superfluousFiles;
	private bRunnable timerForAutoCheckNetworks;
	private String networkList;
	boolean scrollBarHideing;
	protected boolean scrollBarOfTreeHideing;
	QLabel timeMessage;
	QLabel loadFileMessage;
	boolean isLoadFile;
	int plusCharCount;
	private String[] previousOpenedFile = new String[2];
	private String[] nextOpenedFile = new String[2];
	private String showNameOfCurrentEditingFile;
	QLineEdit findLine;
	private keyWords keywordsForFindLine;
	private QToolButton findbutton;
	ArrayList<String> findHistory;
	QComboBox findBox;
	finddialog finddialog;
	protected String readText;
	QGraphicsOpacityEffect effectForTextTitle = new QGraphicsOpacityEffect();
	ArrayList<blackCommand> commands = new ArrayList();
	ArrayList<timerInfo> timerInfos = new ArrayList();
	int timerId;
	boolean doNotShowKeepWrtingMessage = true;
	private boolean doNotShowShadow;
	protected boolean beeping;
	boolean windowOpacity;
	private boolean execCommandAndQuiet;
	private int lastRepairPos;
	static Clip clip = null;
	String[] args;
	static boolean isFoceShow;
	static boolean clipIsStart;
	boolean saveMode;
	boolean yellowForceColor;
	boolean noAnimation;
	int alpha_windowBackground;
	protected boolean addToMoveListEnd;
	boolean LineAndDocFirst_keywords;
	int alpha_text = 204;
	public long lastInputTime_long;
	private boolean textChanged;
	private File lastEditFile;
	static boolean quietMode;
	QLabel caretPos;
	long appStartTime, appRunTime;
	QFrame textWidget;
	QVBoxLayout textLayout;
	QLabel IME;
	boolean noEditorEffect;
	private QGraphicsDropShadowEffect drop;
	private pinyinTool pinyinTool;
	public static int getNetworkTime = 0;
	Process goldendict;
	String backupDir;
	int backupTime;
	Long lastBackUpTime;
	private boolean backupFromSynTime;
	int withoutBuleValue = 60;
	String userName;
	private long hideTime;
	static MSTTSSpeech speech;
	static boolean isSpeak;
	private boolean isFoceCloneFromLocal;
	static Thread thread_voice;
	int hourOfDay;
	int checkMailTimerID = -1;
	static String adminPasswd;
	long activeTime;
	boolean monitorOff;
	boolean dontNotSetMonitor = true;
	static boolean blackUD;
	static imgWidget img;
	QImage bg;
	private static bmessageBox logsBox;
	boolean inReserach;
	private int Only;
	static String day,hour,min,sec;
	/**
	 * debugMode
	 */
	static boolean dbm;
	static DesUtils des = new DesUtils("black");
	static DesUtils des_doc;
	static int minute;
	static int second;
	bAction ba;
	boolean showFind;
	boolean noPageLine;
	boolean noMarkChar;
	boolean bgImgChanged;
	protected long lastSynTitlesData;
	private boolean needResetStyleOfDoc;
	boolean donotAddEditPoint;
	private boolean findKeywordsByPinyin;
	statusbar statusbar;
	private QGraphicsDropShadowEffect se;
	protected bRunnable findInMark_brun;
	private static boolean hasUIRunnable;
	static black b;
	boolean noShadowForIME;
	static QSplashScreen splashScreen;
	private static long lastDebugPrintTime;
	settings settingsDialog;
	boolean linux = false;
	/**
	 * 因为原来的afterLoadFile如果前后设置多个action，会被覆盖，所以新增了下面的action数组
	 */
	ArrayList<action> afterLoadFileActions = new ArrayList<action>();
	boolean keywordsShowAtLeftBottom;
	private long loadFileTime_start;
	/**
	 * 用来指示有多少写入black文件的线程正在运行
	 * 每次新建线程应该将该计数加1
	 * 线程退出时将计数减1
	 * 
	 */
	int writeBlackFileThreadCount = 0;
	setTextStyles setTextStyles;

	public static void main(String[] args) {
		bAction.setUpdate();

//		String s = "QT_SCALE_FACTOR 3";
//		String[] ss = new String[]{s};
//		QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling);
		QCoreApplication.setAttribute(ApplicationAttribute.AA_UseHighDpiPixmaps);
		QGuiApplication.setHighDpiScaleFactorRoundingPolicy(HighDpiScaleFactorRoundingPolicy.PassThrough);
		QApplication init = QApplication.initialize(args);
		init.installEventFilter(new QObject() {
			@Override
			public boolean eventFilter(QObject watched, QEvent event) {
				// TODO Auto-generated method stub
				if(event.type() == QEvent.Type.KeyPress) {
					return b.ba.keyboard.checkKey((QKeyEvent) event,1);
				}
				return super.eventFilter(watched, event);
			}
		});
		splashScreen = new QSplashScreen(new QPixmap(appInfo.sp+"sp3.jpg"));
		
		QDesktopWidget desktop = QApplication.desktop();
		QPixmap pixmap = splashScreen.pixmap();
		int w = pixmap.width();
		int h = pixmap.height();
		splashScreen.setGeometry(desktop.width()/2-w/2, desktop.height()/2-h/2, w, h);
		splashScreen.show();

		QFont font = new QFont("微软雅黑",8);
		QApplication.setFont(font);
		QFont f = splashScreen.font();
		f.setPointSize(8);
		black b = new black(args);

		splashScreen.setFont(f);
		splashScreen.showMessage(languageTool.getString(78),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));

		splashScreen.finish(b);
//		b.showTime();
		b.setLocale(new QLocale(Language.Chinese));
		QApplication.exec();
	}

	public black() {
		this.ui.setupUi(this);
		setGeometry(400, 400, 400, 400);
		ba.blackShow(this, 0);
	}

	public black(String[] args) {
		b = this;
		this.settings = super.getSettings();
		treetitle = new treeTitle(this.dock);
		setAutoFillBackground(false);
		splashScreen.showMessage(languageTool.getString(79),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));
		
//		setWindowFlags(Qt.WindowType.Tool,Qt.WindowType.WindowSystemMenuHint,Qt.WindowType.WindowTitleHint);
		if (bAction.isDisable() || bAction.checkDateDisable()) {
			QMessageBox mess = getMessageBoxNotShow(languageTool.getString(348),
					"此版本的" + appInfo.appName + "已经过期！<br>请发送邮件至下面的地址提醒开发者提交新版本：<br><i>beihuiguixian@hotmail.com</i>");
//			mess.setIconPixmap(ico_app_48.pixmap(100));
			mess.setWindowIcon(ico_app_24);
			mess.exec();
			System.exit(0);
		}
		appStartTime = System.currentTimeMillis();


		String path = System.getProperty("java.class.path");
		if (path.indexOf(appInfo.blackUD) != -1) {
			blackUD = true;
			p("<b>" + appInfo.appName + "位于" + appInfo.blackUD + "文件夹内，已启用备用模式</b>");
		}
		
		splashScreen.showMessage(languageTool.getString(80),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));

		this.args = args;
		userName = System.getProperty("user.name");
//		userName = "test";
		int j = args.length;
		for (int i = 0; i < j; i++) {
			String arg = args[i];
			if (arg.equals("-show")) {
				p("\n"+languageTool.getString(81));
				isFoceShow = true;
			} else if (arg.equals("-help")) {
				p(appInfo.argsHelpInfo);
				System.exit(0);
			} else if (arg.equals("-?")) {
				p(appInfo.argsHelpInfo);
				System.exit(0);
			} else if (arg.equals("-h")) {
				p(appInfo.argsHelpInfo);
				System.exit(0);
			} else if (arg.equals("-clone")) {
				p("\n"+languageTool.getString(82));
				isFoceCloneFromLocal = true;
			} else if (arg.equals("-loaderVer")) {
				appInfo.loaderVer = arg;
			} else if (arg.equals("-debug")) {
				p("\n"+languageTool.getString(83));
				dbm = true;
			} else if (arg.equals("-noMarkChar")) {
				p("\n"+languageTool.getString(84));
				noMarkChar = true;
			} else if (arg.equals("-open")) {
				p("\n"+languageTool.getString(85));
				if (args[i + 1] != null && new File(args[i + 1]).exists())
					bAction.tempData.put("OpenProjectNow", args[i + 1]);
				else
					p(languageTool.getString(86));
			} else if (arg.equals("-noShadowForIME")) {
				p("\n"+languageTool.getString(87));
				noShadowForIME = true;
			}else if (arg.equals("-linux")) {
				p("\n"+languageTool.getString(88));
				linux = true;
			}
			else {
				System.out.println("\n" + languageTool.getString(89));
//				System.exit(0);
			}
		}
		//如果程序根目录下存在src文件夹，则打开调试模式
		if(new File(appInfo.currentDir+"src").exists()) {
			dbm = true;
			p(languageTool.getString(90));
		}
		ba = new bAction(this);
		if (!dbm && !new File("./" + appInfo.appName + ".exe").exists()) {
			System.out.println(languageTool.getString(91,appInfo.appName));
			System.exit(0);
		}
		
		setWindowIcon(this.ico_app_48);
		setWindowTitleB(appInfo.appName);
		int year = Calendar.getInstance().get(Calendar.YEAR);

		splashScreen.showMessage(languageTool.getString(92),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));
		this.ui.setupUi(this);
		this.windowColor = palette().color(QPalette.ColorRole.Window);
		QPalette p = palette();
		p.setColor(QPalette.ColorRole.Window, new QColor(Qt.GlobalColor.white));
		setPalette(p);

		setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);
		this.customContextMenuRequested.connect(this, "addMenu(QPoint)");
		this.menubar = this.ui.menubar;
	

		this.ui.addFile.triggered.connect(this, "addFile()");
		this.ui.addDir.triggered.connect(this, "addFolder()");
		this.ui.writingview.triggered.connect(this, "writingView(Boolean)");

		this.ui.newProject.triggered.connect(this, "createProject()");
		this.ui.openProject.triggered.connect(this, "findProject()");
		this.ui.moveToRecycle.triggered.connect(this, "moveFileToRecyle()");
		this.ui.clearRecycle.triggered.connect(this, "clearRecyle()");

		this.ui.addKeywords.setIcon(this.ico_keywordsList);
		this.ui.addKeywords.triggered.connect(this, "addKeyWordsListToProject()");
		this.ui.oneChineseName.triggered.connect(this, "getChineseName()");
		this.ui.engManName.triggered.connect(this, "getEnglishName_male()");
		this.ui.engWomanName.triggered.connect(this, "getEnglishName_female()");
		this.ui.itManName.triggered.connect(this, "getItalinaName_male()");
		this.ui.itWomanName.triggered.connect(this, "getItalinaName_female()");
		this.ui.find.triggered.connect(this, "find()");
		this.ui.settings.triggered.connect(this, "showSettingsDialog()");
		this.ui.charCount.triggered.connect(this, "showCharCountBox()");
		this.ui.setGit.triggered.connect(this, "setGit_ui()");
		this.ui.commit.triggered.connect(this, "commit_ui()");
//		this.ui.commit.setShortcut("ctrl+shift+c");
		this.ui.push.triggered.connect(this, "push_ui()");
		this.ui.commitAndPush.triggered.connect(this, "gitWork_ui()");
		this.ui.chineseNames.triggered.connect(this, "getChineseNames()");
		this.ui.about.triggered.connect(this, "showAbout()");
		this.ui.howPay.triggered.connect(this, "showPay()");
		this.ui.info.triggered.connect(ba, "showInfoBox()");


//		this.ui.about.setShortcut(new QKeySequence(Qt.KeyboardModifier.ControlModifier.value()
//				+ Qt.KeyboardModifier.ShiftModifier.value() + Qt.Key.Key_A.value()));
		this.ui.saveProjectAllChanged.triggered.connect(this, "saveDocumentByUser()");
		this.ui.openProjectDir.triggered.connect(this, "openProjectDir()");
		this.ui.clearTempFiles.triggered.connect(this, "clearTempFiles()");
		this.ui.clearLogs.triggered.connect(this, "clearLogs()");
		this.ui.hideFilePanel.triggered.connect(this, "hideFilesTree()");
		this.ui.checkUpdate.triggered.connect(this, "checkUpdate()");

		this.ui.dockTree.layout().setContentsMargins(0, 0, 0, 0);
		this.ui.verticalLayout.setMargin(0);

		this.ui.verticalLayout.setSpacing(0);
		this.textTitle = new textTitle(this);
		textTitle.ui.lineEdit.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);
		textTitle.ui.lineEdit.customContextMenuRequested.connect(this,"addMenuForTextTitle(QPoint)");
		this.textTitle.setEnabled(false);

		this.ui.verticalLayout.addWidget(this.textTitle);
		setTextStyles = new setTextStyles(text, ui.verticalLayout);
		setTextStyles.tools.setEnabled(false);

		this.toolbar = new toolbar(this);
		this.toolbar.setMovable(false);
		this.toolbar.setIconSize(new QSize(32, 32));
		this.toolbar.setWindowTitle(languageTool.getString(93));
		QToolButton add = new QToolButton(this.toolbar);
		add.setIcon(this.ico_addItem);
		add.setText(languageTool.getString(94));
		add.pressed.connect(this, "addFile()");
		add.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup);
		QMenu addmenu = new QMenu(add);
		addmenu.addAction(this.ui.addFile);
		addmenu.addAction(this.ui.addKeywords);
		addmenu.addAction(this.ui.addDir);
		add.setMenu(addmenu);
		this.toolbar.addWidget(add);
		this.toolbar.addAction(this.ui.writingview);
		this.findBox = new QComboBox(this.toolbar);

		this.findBox.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu);
		this.findLine = new QLineEdit(this.findBox);

//		this.findBox.currentIndexChanged.connect(this, "currentIndexChangedForFindBox()");
		QApplication.connect(findBox, "currentIndexChanged(int)", this, "currentIndexChangedForFindBox()");

		this.findBox.setLineEdit(this.findLine);

		this.findLine.setAlignment(new Qt.AlignmentFlag[] { Qt.AlignmentFlag.AlignCenter });
		this.findLine.setPlaceholderText(languageTool.getString(95));
		this.findbutton = new QToolButton(this.findBox);
		this.findbutton.setStyleSheet("QToolButton{background: transparent;border:yellow;}");
		this.findbutton.setIcon(this.ico_find);
		this.findbutton.triggered.connect(this, "findLineReturnPressd()");
		this.findbutton.pressed.connect(this, "findLineReturnPressd()");

		this.findBox.installEventFilter(this);
		this.findLine.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);
		this.findLine.customContextMenuRequested.connect(this, "addMenuForFindLine(QPoint)");

		addToolBar(this.toolbar);

		this.dock = this.ui.dockTree;
		this.dock.installEventFilter(this);
		this.dock.setWindowTitle(languageTool.getString(96));
		this.dock.setTitleBarWidget(treetitle);
		this.dock.setVisible(true);
		dock.setFeatures(DockWidgetFeature.DockWidgetMovable, DockWidgetFeature.DockWidgetFloatable);
		dock.setAllowedAreas(DockWidgetArea.LeftDockWidgetArea);
		this.tree = new black_tree(this.ui.dockTree, this);
		this.ui.dockTree.setWidget(this.tree);
		this.ui.dockWidgetContents.setContentsMargins(0, 0, 0, 0);
		this.ui.dockTree.setContentsMargins(0, 0, 0, 0);
		QPalette qPalette = this.tree.palette();
		qPalette.setColor(QPalette.ColorRole.Base, new QColor(230, 234, 238));
		this.tree.setPalette(qPalette);

		this.tree.clicked.connect(this, "treeClicked(QModelIndex)");
		this.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection);

		this.tree.setHeaderHidden(true);
		this.tree.itemPressed.connect(this, "openfile()");
		this.tree.itemChanged.connect(this, "editFinished(QTreeWidgetItem,Integer)");
//		this.tree.itemDoubleClicked.connect(ba,"test()");
		this.tree.doubleClicked.connect(this, "doubleClicked()");
		this.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);
		this.tree.customContextMenuRequested.connect(this, "showTreeMenu(QPoint)");
		this.tree.itemExpanded.connect(this, "expanded(QTreeWidgetItem)");
		this.tree.itemCollapsed.connect(this, "expanded(QTreeWidgetItem)");
		this.tree.installEventFilter(this);
//		tree.setEditTriggers(EditTrigger.DoubleClicked);

		statusbar = new statusbar(this);
		statusbar.setSizeGripEnabled(true);

//		statusbar.setMaximumHeight(20);
		setStatusBar(statusbar);
		QPalette palette = statusbar.palette();
		palette.setColor(QPalette.ColorRole.Window, this.windowColor);
		statusbar.setAutoFillBackground(true);
		statusbar.setBackgroundRole(QPalette.ColorRole.Window);
		statusbar.setPalette(palette);
		caretPos = new QLabel();
		statusbar.addPermanentWidget(caretPos);
		this.countmessage = new QLabel();
		statusbar.addPermanentWidget(this.countmessage);

		this.zoomBox = new QComboBox(this);
		this.zoomBox.setFrame(false);
		for (int i = 100; i <= 400; i += 10) {
			this.zoomBox.addItem(languageTool.getString(97)+ String.valueOf(i) + "%");
		}
		int zoomindex = this.zoomBox.findText(languageTool.getString(97) + String.valueOf(getEditorTextZoomValue() * 10 + 100) + "%");
		this.zoomBox.setCurrentIndex(zoomindex);
//		this.zoomBox.currentIndexChanged.connect(this, "setEditorZoomValue(int)");
		QApplication.connect(zoomBox, "currentIndexChanged(int)", this, "setEditorZoomValue(int)");

		statusbar.addPermanentWidget(this.zoomBox);

		installEventFilter(this);
		p(languageTool.getString(98,appInfo.appName)+" " + appInfo.appVersion);

		this.timeMessage = new QLabel(this);
		timeMessage.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);

		this.timeMessage.setAlignment(new Qt.AlignmentFlag[] { Qt.AlignmentFlag.AlignRight });
		this.timeMessage.linkActivated.connect(this, "link(String)");

		QFont font = new QFont("微软雅黑", 20+ba.getUIFontSize(fontSize.add));
		font.setBold(true);
		this.timeMessage.setFont(font);

		this.loadFileMessage = new QLabel(this);
		loadFileMessage.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);

		this.loadFileMessage.setAlignment(new Qt.AlignmentFlag[] { Qt.AlignmentFlag.AlignRight });
		font.setPointSize(ba.getUIFontSize(fontSize.loadMessage));
		this.loadFileMessage.setFont(font);
		this.loadFileMessage.hide();
		
		splashScreen.showMessage(languageTool.getString(99),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));

		this.timeMode = ((String) settings.value(appInfo.timeMode, "0"));
		this.windowOpacity = Boolean.valueOf((String) settings.value(appInfo.windowOpacity, "false")).booleanValue();
		this.saveMode = Boolean.valueOf((String) this.settings.value(appInfo.saveMode, "true")).booleanValue();
		this.yellowForceColor = Boolean.valueOf((String) this.settings.value(appInfo.yellowForceColor, "false"))
				.booleanValue();
		this.alpha_windowBackground = getIntValueFromSettings(appInfo.alpha_windowBackground, "0");
		quietMode = getBooleanValueFromSettings(appInfo.quietMode, "false");
		this.LineAndDocFirst_keywords = getBooleanValueFromSettings(appInfo.lineAndDocFirst, "false");
		backupTime = getIntValueFromSettings(appInfo.backUpTime, "86400000");
		withoutBuleValue = getIntValueFromSettings(appInfo.withoutBlueValue, "60");
		findKeywordsByPinyin = getBooleanValueFromSettings(appInfo.usePinyinFindKeywords, "true");

		if (getIntValueFromSettings(appInfo.insByMouseOrKey, "0") == 1) {
			timerInfo ti = new timerInfo(true, languageTool.getString(100), null);
			ti.type = appInfo.timerInfoType.changePunctuationByKeybord.value;
			ti.showProgress = false;
			addTimer(ti);
		}
		splashScreen.showMessage(languageTool.getString(101),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));
		addCommands.addCommands(this);

		textWidget = new QFrame(this);
		textWidget.setAutoFillBackground(true);

		textLayout = new QVBoxLayout();
		textWidget.setLayout(textLayout);
		ui.verticalLayout.addWidget(textWidget);
		
//		ba.addMenu();
		new setMenus(this);
		this.toolbar.hide();
		this.dock.hide();
		statusbar.hide();
		this.textTitle.hide();

//		if(!isAdmin()) {
//			WindowFlags wf = windowFlags();
//			if(!wf.isSet(Qt.WindowType.WindowStaysOnTopHint)) {
//				wf.set(Qt.WindowType.WindowStaysOnTopHint);
//				setWindowFlags(wf);
//			}
//		}
//		showTime();
		checkUpdate();
		splashScreen.showMessage(languageTool.getString(102),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));

		// 设置界面字体大小
		ba.applyUIFont();
		
		splashScreen.showMessage(languageTool.getString(103),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));
		
		ba.addActions();
		
		String proPath = (String) bAction.tempData.get("OpenProjectNow");
		if (proPath == null)
			reOpenProject();
		else {
			try {
				openProject(proPath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (isFoceShow) {
			ba.blackShow(this, 0);
			showAllWidget();
		}
		if (isFoceCloneFromLocal) {
			cloneFromLocal();
		}
		findLogsInRootDir();
		showAppUpdateLog();
		

		if (ba.checkBingPicIsEnable_justOne()) {
			ba.useBingPic();
			p(languageTool.getString(104));
		}
		ba.shadow();
		ba.randomImg();
		ba.setShandow(false);
		
		splashScreen.showMessage(languageTool.getString(105),Qt.AlignmentFlag.AlignBottom.value(),new QColor(Qt.GlobalColor.yellow));
		day=languageTool.getString(1569);
		hour=languageTool.getString(1570);
		min=languageTool.getString(1571);
		sec=languageTool.getString(1572);
	}

	/**
	 * 确定给定的可执行文件名称（含扩展名，区分大小写）所表示的程序是否在运行
	 * 
	 * @param exeName
	 * @return
	 */
	static boolean exeIsRuning(String exeName) {
		boolean is = false;
		try {
			Process exec = Runtime.getRuntime().exec("tasklist");
			StringBuilder sb = black.readProcessOutput(exec, "gbk");
			if (sb.toString().indexOf(exeName) != -1) {
				is = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return is;
	}

	static boolean exeIsRuningWithTitle(String windowTitle) {
		boolean is = false;
		try {
			Process exec = Runtime.getRuntime().exec("tasklist /V");
			StringBuilder sb = black.readProcessOutput(exec, "gbk");
			if (sb.toString().indexOf(windowTitle) != -1) {
				is = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return is;
	}

	void setSpeak() {
		isSpeak = !isSpeak;
		setLoadFileMessage(languageTool.getString(350,isSpeak));
	}

	void stopVoice() {
		p(thread_voice.isAlive());
		thread_voice.stop();
		thread_voice.interrupt();
		// 升级jdk14后下面这行报错，先注释掉
//		thread_voice.destroy();
		thread_voice = null;
		p("stop");
	}

	void speakText(String text, int rate) {
		if (isSpeak || rate != -1) {
			uiRun(this, new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					int voiceRate = getIntValueFromSettings(appInfo.voiceRate, "0");
					if (speech == null) {
						speech = new MSTTSSpeech();
						if (rate == -1)
							speech.setRate(voiceRate);
						else
							speech.setRate(rate);
//						speech.setVolume(10);
					}
				}
			});
			thread_voice = new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					speech.speak(text);
					thread_voice = null;
				}
			});
			thread_voice.start();
		}

	}

	


	void setLightOrDark() {
		if (writingView == 0) {
			setLoadFileMessage(languageTool.getString(106));
			return;
		}
		boolean lightOrDark = !getBooleanValueFromSettings(appInfo.LightOrDark, "false");
		settings.setValue(appInfo.LightOrDark, lightOrDark);

//		if(ba.checkBingPicIsEnable())ba.useBingPic();

		update();
		applyColorChange();
		if (lightOrDark)
			setLoadFileMessage(languageTool.getString(107));
		else
			setLoadFileMessage(languageTool.getString(108));
	}

	void applyColorChange() {
		if (text == null)
			return;
		if (se == null) {
			se = new QGraphicsDropShadowEffect(timeMessage);
			se.setBlurRadius(5);
			se.setOffset(2, 2);
		}
		se.setEnabled(false);
		
		QPalette p_textW = textWidget.palette();
		QPalette p_text = text.palette();
		QPalette pb = palette();
		QPalette p_caret = null;
		if(text != null && text.caret != null)
			p_caret = text.caret.palette();
		QPalette p_timemessage = this.timeMessage.palette();
		QPalette p_loadMessage = this.loadFileMessage.palette();
		
		p_textW.setColor(ColorRole.Window,
				(QColor)ba.getColor(0)[1]);
		p_text.setColor(ColorRole.Base, new QColor(0, 0, 0, 0));
//		int alpha = getIntValueFromSettings(appInfo.writingViewAlpha, "255");
		p_text.setColor(ColorRole.Text, (QColor)ba.getColor(1)[1]);
		p_text.setColor(QPalette.ColorGroup.All, QPalette.ColorRole.Highlight,
				(QColor)ba.getColor(8)[1]);
		p_text.setColor(QPalette.ColorGroup.All, QPalette.ColorRole.HighlightedText,
				(QColor)ba.getColor(9)[1]);
		pb.setColor(QPalette.ColorRole.Window,
				(QColor)ba.getColor(3)[1]);
		if(p_caret != null)
		p_caret.setColor(text.caret.backgroundRole(), (QColor)ba.getColor(4)[1]);
		p_timemessage.setColor(QPalette.ColorRole.WindowText, (QColor)ba.getColor(5)[1]);
		p_loadMessage.setColor(QPalette.ColorRole.WindowText,(QColor)ba.getColor(4)[1]);

		
		if(writingView > 0) {
			int v = b.getIntValueFromSettings(appInfo.randomImg, "1000");
			if(v == 0) {
				String picPath = null;
				if (!getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
					if (getBooleanValueFromSettings(appInfo.useDarkWindowBgImg, "true")) {
						if (getBooleanValueFromSettings(appInfo.darkBingPic, "true")) {
							picPath = "./RC/Bing/bing.jpg";
						} else {
							picPath = "./RC/" + (String) settings.value(appInfo.darkWindowBgImg);
						}
					}
				}else {
					if (getBooleanValueFromSettings(appInfo.useLightWindowBgImg, "true")) {
						if (getBooleanValueFromSettings(appInfo.lightBingPic, "true")) {
							picPath = "./RC/Bing/bing.jpg";
						} else {
							picPath = "./RC/" + (String) settings.value(appInfo.lightWindowBgImg);
						}
					}
				}
				if(picPath != null) {
					QImage windowBg = new QImage(picPath);
					QRect dg = ba.desktopGeometry(false);
					windowBg = windowBg.scaled(dg.width(), dg.height());
					QBrush brush = new QBrush(windowBg);
					pb.setBrush(QPalette.ColorRole.Window, brush);
				}
			}
//			se.setEnabled(true);
		}

		textWidget.setPalette(p_textW);
		text.setPalette(p_text);
		setPalette(pb);
		if(p_caret != null)
		text.caret.setPalette(p_caret);
		timeMessage.setPalette(p_timemessage);
		loadFileMessage.setPalette(p_loadMessage);
		
		
		QColor c = textWidget.palette().color(textWidget.backgroundRole());
		if(ba.getLockStatus() && (writingView == 0 || c.alpha() < 10)) {
			ba.stopRandomImg();
		}else {
			b.ba.randomImg();
		}
	}

	QColor withoutBlueColor(QColor color, int value) {
		if (writingView == 0 || getIntValueFromSettings(appInfo.editorColor, "0") == 0)
			return color;
		float lr = (255F - color.red()) / 100F;
		float lb = color.blue() / 100F;
//		float lg = (255F-color.green())/100F;
		int newR = (int) (color.red() + lr * value);
		int newB = (int) (color.blue() - lb * value);
//		int newG = (int) (color.green()+lg*value);
		if (newR > 255)
			newR = 255;
		if (newB < 0)
			newB = 0;
//		if(newG > 255) newG = 255;
		color.setRed(newR);
		color.setBlue(newB);
//		color.setGreen(newG);
		return color;
	}

	public static ArrayList<Integer> resetByMax(ArrayList<Integer> al) {
		ArrayList<Integer> re = new ArrayList<>();

		while (al.size() > 0) {
			int a = -1;
			int index_currentMax = 0;

			for (int i = 0; i < al.size(); i++) {
				int it = al.get(i);
				if (it > a) {
					a = it;
					index_currentMax = i;
				}
			}
			re.add(a);
			al.remove(index_currentMax);
		}
		return re;
	}

	void resetProjectFileIndex(boolean showMessage) {
		if (projectFile != null) {
			debugPrint("yesss");
			String path = projectFile.getParent() + "\\Files";
			File f = new File(path);
			File[] fs = f.listFiles();

			ArrayList<Integer> al = new ArrayList<>();
			for (File ff : fs) {
				String name = ff.getName();
				String[] ss = cheakDocument.subString(name, ".black");
				al.add(new Integer(ss[0]));
			}
			ArrayList<Integer> re = resetByMax(al);
			if (re.size() > 0) {
				Integer max = re.get(0);
				String property = projectInfo.getProperty("fileindex");
				String resetMessage = "";
				Integer vo = -1;
				if (property != null) {
					vo = Integer.valueOf(property);
					resetMessage = languageTool.getString(112);
					if (vo <= max) {
						projectInfo.setProperty("fileindex", (max + 1) + "");
						resetMessage = languageTool.getString(113) + max;
					}

				} else {
					projectInfo.setProperty("fileindex", (max + 1) + "");
					resetMessage = languageTool.getString(113) + max;
				}
				if (showMessage)
					getMessageBox(languageTool.getString(109),
							languageTool.getString(110) + vo + "\n"+languageTool.getString(111) + max + ".black" + resetMessage);
				else
					p(resetMessage);
			}
		}
	}

	void runBackup(String sec, String dest, int id) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				ArrayList<File> al = new ArrayList<File>();
				boolean iscopy = fileTool.copy(sec, dest, al);
				if (iscopy) {
					projectInfo.setProperty(appInfo.lastBackUpTime, System.currentTimeMillis() + "");
					lastBackUpTime = System.currentTimeMillis();
					timerInfo timerInfo = getTimerInfo(id);
					timerInfo.timerName = languageTool.getString(114,al.size());
					timerInfo.showProgress = false;
					new bRunnable(10000, true, false, false, true) {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							removeTimer(id);
						}
					};
				} else {
					removeTimer(id);
				}
			}
		}).start();
	}

	boolean isSameDir(String backupDir) {
		File backupdir = new File(backupDir);
		if (backupdir.isDirectory()) {
			if (projectFile.getParentFile().getParent().equals(backupDir)) {
				File[] files = backupdir.listFiles();
				for (File f : files) {
					if (f.getName().equals(getProjectName()) && f.isDirectory()) {
						return true;
					}
				}
			}
		}
		return false;
	}

	void backup() {
		backupDir = projectInfo.getProperty(appInfo.backUpDir, "");
		if (!backupFromSynTime)
			if (backupDir.isEmpty() || !new File(backupDir).exists() || isSameDir(backupDir)) {
				File[] roots = File.listRoots();
				for (File ff : roots) {
					File f = new File(ff.getPath() + "BlackBackups");
					if (f.exists()) {
						if (!isSameDir(f.getPath())) {
							getMessageBox(languageTool.getString(115),
									languageTool.getString(116,ff.toString(),appInfo.appName,f.getPath()));
							backupDir = f.getPath();
//							projectInfo.setProperty(appInfo.backUpDir, backupDir);
							break;
						}
					}
				}
			}

		if (backupDir.isEmpty()) {
			uiRun(black.this, new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					backupDir = getDirDialog(languageTool.getString(117));
				}
			});
			if (!backupDir.isEmpty() && new File(backupDir).isDirectory())
				projectInfo.setProperty(appInfo.backUpDir, backupDir);
		}
		if (new File(backupDir).exists()) {
			if (isSameDir(backupDir)) {
				getMessageBox(languageTool.getString(118), languageTool.getString(119));
				return;
			}
			if (isHasTimer(appInfo.timerInfoType.runingBackup.value))
				return;

			removeAllTimer(appInfo.timerInfoType.needRunningBackup.value);
			timerInfo timerInfo = new timerInfo(true, languageTool.getString(120), null);
			timerInfo.type = appInfo.timerInfoType.runingBackup.value;
			int id = addTimer(timerInfo);
			runBackup(projectFile.getParent(), backupDir, id);
		} else {
			if (!backupFromSynTime) {
				if (isHasTimer(appInfo.timerInfoType.cannotFindBackupDir.value))
					return;
				timerInfo ti = new timerInfo(true, languageTool.getString(121), null);
				ti.showProgress = false;
				ti.type = appInfo.timerInfoType.cannotFindBackupDir.value;
				int id = addTimer(ti);
				new bRunnable(5000, true, false, false, true) {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						removeTimer(id);
					}
				};
			} else {
				if (isHasTimer(appInfo.timerInfoType.needRunningBackup.value))
					return;
				timerInfo timerInfo = new timerInfo(true, languageTool.getString(122), null);
				timerInfo.showProgress = false;
				timerInfo.type = appInfo.timerInfoType.needRunningBackup.value;
				addTimer(timerInfo);
				speakText(languageTool.getString(123), -1);
			}
		}
	}

	public void cloneFromLocal() {
		File dir = null;
		if (projectFile != null)
			dir = new File(projectFile.getParent() + "_clone_" + time.getCurrentDate("-"));
		else
			dir = new File(filesListFile.getParentFile().getParent() + "_clone_" + time.getCurrentDate("-"));
		if (!dir.exists()) {
			dir.mkdir();
			p(dir);
		} else {
			getMessageBox(languageTool.getString(351), languageTool.getString(352,dir));
			p(languageTool.getString(354,dir));
			return;
		}
		int id = addTimer(new timerInfo(true, languageTool.getString(355), null));
		String dir_path = dir.getPath();

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				copyBranchFromLocal(dir_path, projectInfo.getProperty(appInfo.projectName), null, false);
				uiRun(black.this, new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						p(languageTool.getString(356));
						removeTimer(id);
						getMessageBox(languageTool.getString(357), languageTool.getString(356));
						showinExplorer(dir_path, true);
					}
				});
			}
		}).start();
	}

	public void changeAlpha_text() {
		if ((!this.windowOpacity) || (writingView != 2) || (this.alpha_windowBackground != 0)) {
			return;
		}
		if (this.alpha_text == 204) {
			this.alpha_text = 1;
		} else if (this.alpha_text == 1) {
			this.alpha_text = 50;
		} else if (this.alpha_text == 50) {
			this.alpha_text = 100;
		} else if (this.alpha_text == 100) {
			this.alpha_text = 150;
		} else if (this.alpha_text == 150) {
			this.alpha_text = 204;
		}
		update();

		setLoadFileMessage("alpha: " + this.alpha_text);
	}

	static boolean checkWord() {
		return false;
//		boolean isExists = false;
//        String system = System.getenv("SystemDrive");
//    	String path = system+"\\Program Files\\Microsoft Office\\Office16\\WINWORD.exe";
//    	if(new File(path).exists()) {
//    		isExists = true;
//    	}
//    	return isExists;
	}


	void showPay() {
		bAction.showPayBox(this);
	}

	public ArrayList<timerInfo> getAllTimer(int type) {
		ArrayList<timerInfo> al = new ArrayList<timerInfo>();
		for (timerInfo in : timerInfos) {
			if (in.type == type)
				al.add(in);
		}
		return al;
	}

	pinyinTool initPinyinTool() {
		if (pinyinTool == null) {
			pinyinTool = new pinyinTool(new File("./PinyinTool"));
		}
		return pinyinTool;
	}

	void noBackgroundForWritingView() {
		if (writingView == 0)
			return;
		boolean v = !getBooleanValueFromSettings(appInfo.noBackgroundForWritingView, "false");
		settings.setValue(appInfo.noBackgroundForWritingView, v + "");
		this.update();
	}

	void showAppUpdateLog() {
		Object value = settings.value(appInfo.appVersionKey, "-1");
		Double valueOf = Double.valueOf((String) value);
		if (valueOf < Double.valueOf(appInfo.appVersion)) {
			new bRunnable(30000,true,false,true,true) {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					getBMessageBox(appInfo.appName + "已更新", "<h2>此次更新包含以下新特性或改进：</h2>" + ba.getUpdateInfoMini(1)
					+ "<p align=right>" + "<b>更新日期" + appInfo.buildDate + "</b></p>");
				}
			};
			
		}
	}

	/**
	 * 为给定的Qwidget设定窗口显示规则，防止它超出显示范围
	 */
	void desktopRectRule(QWidget w) {
		QDesktopWidget desktop = new QDesktopWidget();
		QRect availableGeometry = desktop.availableGeometry();
		int newX = -1, newY = -1;
		if (w.x() + w.width() > availableGeometry.width()) {
			int v = w.pos().x() + w.width() - availableGeometry.width();
			newX = w.x() - v;
		} else if (w.x() <= 0)
			newX = 0;

		if (w.y() + w.height() > availableGeometry.height()) {
			int v = w.pos().y() + w.height() - availableGeometry.height();
			newY = w.y() - v;
		} else if (w.y() <= 0)
			newY = 0;

		if (newX == -1)
			newX = w.x();
		if (newY == -1)
			newY = w.y();
		w.setGeometry(newX, newY, w.width(), w.height());
	}

	void toFullPinyin(String str, int start, boolean dontfind) {
		// 在没启用嵌入式输入前，下面的代码都在方法最后的新线程内执行
		String spiltChar = "";
		if (getBooleanValueFromSettings(appInfo.useSpiltCharForPinyin, "true"))
			spiltChar = "'";

		String sub1 = initPinyinTool().toFullPinyin(str.substring(0, start), spiltChar);
		String sub2 = initPinyinTool().toFullPinyin(str.substring(start, str.length()), spiltChar);
		String fullpinyin = sub1 + sub2;
		uiRun(this, new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				showIMEString(null, -1, sub1, sub2, fullpinyin, true);
			}
		});
		findKeywordByPinyin(fullpinyin, str, dontfind);

	}

	/**
	 * 通过拼音检索关键词 此方法在延时之后开始通过拼音检索关键词
	 * 如果dontfind参数为false，调用此方法将会结束上一次调用此方法启动的延时检索动作（如果有的话）
	 * 
	 * @param fullPinyin
	 * @param doublePinyin
	 * @param dontfind
	 */
	void findKeywordByPinyin(String fullPinyin, String doublePinyin, boolean dontfind) {
//		debugPrint(debug.getNameOfClassAndMethodOfCaller());
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				uiRun(black.this, new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						int ms = getIntValueFromSettings(appInfo.pinyinStartSegmentMS, "500");
						ba.tempData.put(appInfo.pinyinStartSegmentMS, ms);
					}
				});

				if (!dontfind) {
					if (findInMark_brun != null) {
						findInMark_brun.stop();
						findInMark_brun = null;
					}

					findInMark_brun = new bRunnable(getIntValueFromSettings(appInfo.pinyinStartSegmentMS, "500"), true,
							false, false, true) {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							if (black.this.findInMark_brun != null || !dontfind)
								findMarkString(fullPinyin, doublePinyin);
						}
					};
				} else {
					if (findInMark_brun != null) {
						findInMark_brun.stop();
						findInMark_brun = null;
					}
				}
			}
		}).start();
	}

	public static void debugPrint(Object o) {
		if (dbm) {
			long tim = System.currentTimeMillis();
			long add = tim - lastDebugPrintTime;
			System.out.println("[+"+add+"ms]"+o);
			lastDebugPrintTime = tim;
		}
	}
	
	public static void debugPrintWithTime(Object o) {
		if (dbm) {
			p(o);
		}
	}

	void showIMEString(String str, int start, String sub1, String sub2, String fullpinyin, boolean dontfind) {
//		debugPrint(str);
		if(b.text == null || b.text.isDisposed()) return;
		if (text.preeditStringPos == -1 && text.IMEPreeditString.isEmpty()) {
			if (IME != null && IME.isVisible())
				IME.hide();
			return;
		}
		if (str != null) {
			if (str.isEmpty()) {
				return;
			} else {
				// 如果没有读取关键词列表，为了节省算力，禁用全拼转双拼
				if (Boolean.valueOf((String) settings.value(appInfo.conversionToFullPinyin, "false"))) {
					if (markTextData != null
							|| !Boolean.valueOf((String) settings.value(appInfo.hideIMEPanel, "false"))) {
						toFullPinyin(str, start, dontfind);
						return;
					}
				}
			}

		}
		if (getBooleanValueFromSettings(appInfo.hideIMEPanel, "false")
				|| getBooleanValueFromSettings(appInfo.useInLineIME, "false")) {
			return;
		}
		if (sub1 == null && sub2 == null) {
			if (!str.isEmpty()) {
				sub1 = str.substring(0, start);
				sub2 = str.substring(start, str.length());
			} else
				sub1 = sub2 = "";

		}

		QRect cursorRect = text.cursorRect();
		QPoint mapTo = text.viewport().mapToGlobal(new QPoint(cursorRect.x(), cursorRect.y()));
		int editorCaretWidthValue = getEditorCaretWidthValue();
		if (IME == null) {
			IME = new QLabel(textWidget) {
				@Override
				protected void paintEvent(QPaintEvent e) {
					// TODO Auto-generated method stub

					QPainter p = new QPainter(this);
					
//					QColor bg = new QColor(41, 41, 41);
					QColor bg = null;
					
					//出于可读性的考虑，不启用阴影时强制背景色为黑色，前景色是白色，启用阴影效果时颜色根据其他组件的颜色变化
					if(!noShadowForIME) {
						//非写作视图下背景色是base，反之是window
						if(writingView == 0)
							bg = text.palette().color(ColorRole.Base);
						else bg = textWidget.palette().color(ColorRole.Window);
					}else bg = new QColor(Qt.GlobalColor.black);
					//此处并非为了绘制，是为了在内部类外面取出这个颜色变量，因为光标指示符的颜色需要根据背景色来设定
					IME.palette().setColor(ColorRole.Window, bg);

					bg.setAlpha(255);
//					ba.tempData.put("IMEbg", bg);
					p.setBrush(bg);
					p.setPen(PenStyle.NoPen);
//					QRect rect = this.geometry();
//					new QRect(rect.left(), top, width, height)

					p.setRenderHint(RenderHint.Antialiasing);
					QRect rr = this.rect();
					int mar = this.margin() - 10;

					rr = new QRect(rr.left() + mar, rr.top() + mar, rr.right() - mar * 2, rr.bottom() - mar * 2);
					p.drawRoundedRect(rr, 10, 10);

					QPolygon polygon = new QPolygon();
					QRect cr = text.cursorRect();
					QPoint crmapTo = text.mapToGlobal(new QPoint(cr.x(), cr.y()));
					int x1 = crmapTo.x() + editorCaretWidthValue / 2;
					int y1 = crmapTo.y() - (mar - 5);
					int x2 = x1 - 5;
					int y2 = y1 - 6;
					int x3 = x1 + 5;
					int y3 = y2;
					QPoint map1 = this.mapFromGlobal(new QPoint(x1, y1));// 中间点
					QPoint map2 = this.mapFromGlobal(new QPoint(x2, y2));
					QPoint map3 = this.mapFromGlobal(new QPoint(x3, y3));
					debugPrint("hello: " + map1 + " " + map2 + " " + map3);
					polygon.add(map1);
					polygon.add(map2);
					polygon.add(map3);
					p.drawPolygon(polygon);

//					p.setBrush(BrushStyle.NoBrush);
//					
//					p.setPen(new QPen(new QColor(Qt.GlobalColor.lightGray),1));
//					p.drawRoundedRect(rr, 10, 10);
//					p.drawLine(map1,map2);
//					p.drawLine(map1,map3);
//					p.setPen(new QPen(bg,1));
//					p.drawLine(map2.x()+1,map2.y(),map3.x()-1,map3.y());
////					p.drawLine(map2, map3);
					p.end();
					super.paintEvent(e);

				}
			};
			Qt.WindowFlags windowFlags = new Qt.WindowFlags(new Qt.WindowType[] { Qt.WindowType.FramelessWindowHint,
					Qt.WindowType.WindowStaysOnTopHint, Qt.WindowType.Tool,Qt.WindowType.X11BypassWindowManagerHint,Qt.WindowType.BypassWindowManagerHint});
			IME.setWindowFlags(windowFlags);
//			IME.setContentsMargins(10, 10, 10, 20);
			IME.setMargin(20);
			IME.setAttribute(WidgetAttribute.WA_TranslucentBackground);
//			IME.setWindowOpacity(0.5);
			if(!noShadowForIME) {
				QGraphicsDropShadowEffect shad = new QGraphicsDropShadowEffect();
				QColor c_shad = new QColor(Qt.GlobalColor.black);
				c_shad.setAlpha(50);
				shad.setColor(c_shad);
				shad.setBlurRadius(20);
				shad.setOffset(1, 1);
				IME.setGraphicsEffect(shad);
			}
		}

//		IME.setFrameStyle(QFrame.Shape.StyledPanel.value());
//		IME.setAutoFillBackground(true);
		//字体颜色
		QColor cc = null;
		if(noShadowForIME) cc = new QColor(Qt.GlobalColor.white);
		else cc = text.palette().text().color();
		String cname = cc.name();
		//光标指示符颜色
		QColor bgcolor = IME.palette().color(ColorRole.Window);
		int blue = bgcolor.blue()+50;
		if(blue > 255) blue = bgcolor.blue()-100;
		String colorname = new QColor(bgcolor.red(),bgcolor.green(),blue).name();
		
		IME.setStyleSheet("background:translucent;color:" + cname);
		QFont font = text.font();
//		font.setFamily("Courier New");
//		font.setUnderline(true);
		QFont f = font();
		f.setPointSize(font.pointSize());
//		f.setLetterSpacing(font.letterSpacingType(), font.letterSpacing());
		IME.setFont(f);
		String mark = "^";
		IME.setAlignment(AlignmentFlag.AlignVCenter);
		IME.setText("<u>" + sub1 + "</u>" + "<font face=\"" + font.family() + ", serif\" size=\"" + 3 + "\" color=\""
				+ colorname + "\" bgcolor=\"white\"><b>" + mark + "</b></font>" + sub2);

		IME.adjustSize();
//		int newY = -1;
//		if (IME.height() > cursorRect.height()) {
//			newY = mapTo.y() - (IME.height() - cursorRect.height()) / 2;
//		} else if (IME.height() == cursorRect.height()) {
//			newY = mapTo.y();
//		} else {
//			newY = mapTo.y() + (cursorRect.height() - IME.height()) / 2;
//		}
		int width = IME.width();
		if (width < 60) {
			width = width + (60 - width);
		}

		QRect rect = new QRect(mapTo.x() - 30 - getEditorCaretWidthValue() / 2, mapTo.y() - IME.height(), width, IME.height());

		
		setAnimation(IME, "geometry", IME.geometry(), rect, 0);

		IME.show();

		desktopRectRule(IME);
		
	}

	

	void findLogsInRootDir() {
		String rootdir = System.getProperty("user.dir");
		File root = new File(rootdir);
		if (root.exists()) {
			isYourNeedFile isYourNeedFile = new isYourNeedFile(root, ".*.log");
			String[] filter = isYourNeedFile.Filter();
			if ((filter != null) && (filter.length > 0)) {
				int r = getMessageBoxWithYesNO(languageTool.getString(359), languageTool.getString(360), languageTool.getString(361), languageTool.getString(362),
						QMessageBox.Icon.Question, 0);
				if (r == 1) {
					showinExplorer(rootdir, false);
				} else {
					for (String s : filter) {
						File log = new File(root.getAbsolutePath() + File.separator + s);
						if (log.exists()) {
							if (log.delete()) {
								p(languageTool.getString(363,log.getName()));
							}
						}
					}
				}
			}
		}
	}

	QPainterPath getPathForMask(int width, int height, int r) {
		QPainterPath path = new QPainterPath();
		path.moveTo(0.0D, height + r);
		path.lineTo(0.0D, 0.0D);
		path.lineTo(width, 0.0D);
		path.lineTo(width, height + r);
		path.lineTo(width - r, height);
		path.lineTo(r, height);
		path.lineTo(0.0D, height + r);
		return path;
	}

	QPainterPath getPath(int width, int height, int r) {
		QPainterPath path = new QPainterPath();
		path.moveTo(0.0D, height + r);
		path.lineTo(0.0D, 0.0D);
		path.lineTo(width, 0.0D);
		path.lineTo(width, height + r);
		path.arcTo(width - r * 2, height, r * 2, r * 2, 0.0D, 90.0D);
		path.lineTo(r, height);
		path.arcTo(0.0D, height, r * 2, r * 2, 90.0D, 90.0D);
		return path;
	}

	QRegion getRegion(QPainterPath path) {
		return new QRegion(path.toFillPolygon().toPolygon());
	}

	void setFontStyle(QFont font) {
		if (getBooleanValueFromSettings(appInfo.boldFont, "false")) {
			font.setUnderline(true);
		}
		if (getBooleanValueFromSettings(appInfo.italicFont, "false")) {
			font.setItalic(true);
		}
	}
	void setFontStyleForEditor() {
		if(text == null) return;
		QFont font = text.font();
		if (getBooleanValueFromSettings(appInfo.boldFont, "false")) {
			font.setBold(true);
		} else {
			font.setBold(false);
		}
		
		if (getBooleanValueFromSettings(appInfo.italicFont, "false")) {
			font.setItalic(true);
		} else {
			font.setItalic(false);
		}
		
		text.setFont(font);
	}
	void setBold() {
		boolean v = !getBooleanValueFromSettings(appInfo.boldFont, "false");
		this.settings.setValue(appInfo.boldFont, v);
		setFontStyleForEditor();
	}

	void setItalic() {
		boolean v = !getBooleanValueFromSettings(appInfo.italicFont, "false");
		this.settings.setValue(appInfo.italicFont, v);
		setFontStyleForEditor();
	}

	void changedEditFile() {
		if (this.lastEditFile == null) {
			return;
		}
		File f = this.lastEditFile;
		changedFileOfCurrentEdit();
		openFileByTreeItem(findTreeItemByFileName(f.getName(), null));
		synTime();
	}

	void changedForOpenedFiles() {
		if (this.currentEditing == null) {
			return;
		}
		boolean start = false;
		boolean isFind = false;
		for (int i = 0; i < this.openedFiles.size(); i++) {
			dataForOpenedFile dataForOpenedFile = (dataForOpenedFile) this.openedFiles.get(i);
			if ((!start) && (dataForOpenedFile.filename.equals(this.currentEditing.getName()))) {
				start = true;
			} else if ((start) && (dataForOpenedFile.editor != null)
					&& (!dataForOpenedFile.filename.equals(this.currentEditing.getName()))) {
				isFind = true;
				this.addToMoveListEnd = true;
				changedFileOfCurrentEdit();
				openFileByTreeItem(findTreeItemByFileName(dataForOpenedFile.filename, null));
				synTime();
				break;
			}
		}
		if (!isFind) {
			for (int i = 0; i < this.openedFiles.size(); i++) {
				dataForOpenedFile dataForOpenedFile = (dataForOpenedFile) this.openedFiles.get(i);
				if (dataForOpenedFile.filename.equals(this.currentEditing.getName())) {
					return;
				}
				if (dataForOpenedFile.editor != null) {
					this.addToMoveListEnd = true;
					changedFileOfCurrentEdit();
					openFileByTreeItem(findTreeItemByFileName(dataForOpenedFile.filename, null));
					synTime();
					break;
				}
			}
		}
	}

	public static int getIntValueFromSettings(String key, String defaultValue) {
		return Integer.valueOf((String) settings.value(key, defaultValue));
	}
	public static double getDoubleValueFromSettings(String key, String defaultValue) {
		return Double.valueOf((String) settings.value(key, defaultValue));
	}
	public static String getStringValueFromSettings(String key, String defaultValue) {
		return (String) settings.value(key, defaultValue);
	}

	public static boolean getBooleanValueFromSettings(String key, String defaultValue) {
		return Boolean.valueOf(String.valueOf(settings.value(key, defaultValue)));
	}
	public static boolean getEncryptBooleanValueFromSettings(String key,String defaultValue) {
		return Boolean.valueOf(bAction.getStringWithDncrypt(String.valueOf(settings.value(bAction.getStringWithEncrypt(key), bAction.getStringWithEncrypt(defaultValue)))));
	}

	void quiet() {
		quietMode = !quietMode;
		if (quietMode) {
			setLoadFileMessage(languageTool.getString(364));
			stopBeepSound();
		} else {
			setLoadFileMessage(languageTool.getString(365));
		}
	}

	void te(String leftStr, String rightStr) {
		boolean is = false;
		QTextCursor tc = text.textCursor();
		int blockpos = tc.block().position();
		tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter, QTextCursor.MoveMode.KeepAnchor);
		if (tc.selectedText().equals(rightStr)) {
			QTextCharFormat cf = tc.charFormat();
			QBrush br = new QBrush(new QColor(Qt.GlobalColor.lightGray));
			QBrush fr = new QBrush(new QColor(Qt.GlobalColor.black));
			cf.setForeground(fr);
			cf.setBackground(br);
			ExtraSelection es = new ExtraSelection();
			es.setCursor(tc);
			es.setFormat(cf);
			btext.extraSelection.add(es);
		}
		do {
			tc.clearSelection();
			tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter, QTextCursor.MoveMode.KeepAnchor);
			if (tc.position() >= blockpos) {
				if (tc.selectedText().equals(leftStr)) {
					QTextCharFormat cf = tc.charFormat();
					QBrush br = new QBrush(new QColor(Qt.GlobalColor.yellow));
					QBrush fr = new QBrush(new QColor(Qt.GlobalColor.black));
					cf.setForeground(fr);
					cf.setBackground(br);
					ExtraSelection es = new ExtraSelection();
					es.setCursor(tc);
					es.setFormat(cf);
					btext.extraSelection.add(es);
					is = true;
				}
				if (tc.position() == blockpos) {
					is = true;
				}
			} else {
				is = true;
			}
		} while (!is);
	}

	void teF(String leftStr, String rightStr) {
		boolean is = false;

		QTextCursor tc = text.textCursor();
		int blockpos = tc.block().position() + tc.block().text().length();
		tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter, QTextCursor.MoveMode.KeepAnchor);
		if (tc.selectedText().equals(leftStr)) {
			QTextCharFormat cf = tc.charFormat();
			QBrush br = new QBrush(new QColor(Qt.GlobalColor.yellow));
			QBrush fr = new QBrush(new QColor(Qt.GlobalColor.black));
			cf.setForeground(fr);
			cf.setBackground(br);
			ExtraSelection es = new ExtraSelection();
			es.setCursor(tc);
			es.setFormat(cf);
			btext.extraSelection.add(es);
		}
		do {
			tc.clearSelection();
			tc.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
			if (tc.position() <= blockpos) {
				if (tc.selectedText().equals(rightStr)) {
					QTextCharFormat cf = tc.charFormat();
					QBrush br = new QBrush(new QColor(Qt.GlobalColor.lightGray));
					QBrush fr = new QBrush(new QColor(Qt.GlobalColor.black));
					cf.setForeground(fr);
					cf.setBackground(br);
					ExtraSelection es = new ExtraSelection();

					es.setCursor(tc);
					es.setFormat(cf);
					btext.extraSelection.add(es);
					is = true;
				}
				if (tc.position() == blockpos) {
					is = true;
				}
			} else {
				is = true;
			}
		} while (!is);
	}

	void setMarkBackground() {
		this.infoOfCurrentEditing.showMark = (!this.infoOfCurrentEditing.showMark);
	}

	void backspace() {
		Qt.KeyboardModifiers modifiers = new Qt.KeyboardModifiers(Qt.KeyboardModifier.NoModifier.value());
		QKeyEvent k = new QKeyEvent(QEvent.Type.KeyPress, Qt.Key.Key_Backspace.value(), modifiers);
		QApplication.postEvent(text, k);
	}

	void enter() {
		Qt.KeyboardModifiers modifiers = new Qt.KeyboardModifiers(Qt.KeyboardModifier.NoModifier.value());
		QKeyEvent k = new QKeyEvent(QEvent.Type.KeyPress, Qt.Key.Key_Enter.value(), modifiers);
		QApplication.postEvent(text, k);
	}

	void textContentsChange(int s, int e, int l) {
	}

	void showMark() {
		QTextCursor tc = text.textCursor();
		tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter, QTextCursor.MoveMode.KeepAnchor);
		String str = tc.selectedText();
		if (str.equals("“")) {
			teF("“", "”");
		} else if (str.equals("”")) {
			te("“", "”");
		} else if (str.equals("‘")) {
			teF("‘", "’");
		} else if (str.equals("’")) {
			te("‘", "’");
		} else if (str.equals("(")) {
			teF("(", ")");
		} else if (str.equals(")")) {
			te("(", ")");
		} else if (str.equals("《")) {
			teF("《", "》");
		} else if (str.equals("》")) {
			te("《", "》");
		} else if (str.equals("（")) {
			teF("（", "）");
		} else if (str.equals("）")) {
			te("（", "）");
		} else if (str.equals("【")) {
			teF("【", "】");
		} else if (str.equals("】")) {
			te("【", "】");
		}
	}

	void changeRepairBy() {
		int ins = getIntValueFromSettings(appInfo.insByMouseOrKey, "0");
		if (ins == 0) {
			settings.setValue(appInfo.insByMouseOrKey, "1");
			timerInfo ti = new timerInfo(true, languageTool.getString(124), null);
			ti.type = appInfo.timerInfoType.changePunctuationByKeybord.value;
			ti.showProgress = false;
			addTimer(ti);
			synTimeAction(brunnableForOSD);
		} else {
			settings.setValue(appInfo.insByMouseOrKey, "0");
			removeAllTimer(appInfo.timerInfoType.changePunctuationByKeybord.value);
			synTimeAction(brunnableForOSD);
		}
	}

	public void repair() {
		debugPrint(languageTool.getString(366));
		this.btext.doNotScroll = true;
		QTextCursor tc = text.textCursor();
		int pos = tc.position();
		QTextCursor cursorForPosition = null;
		if (getIntValueFromSettings(appInfo.insByMouseOrKey, "0") == 0) {
			QPoint p = QCursor.pos();
			QPoint mapF = text.mapFromGlobal(p);
			cursorForPosition = text.cursorForPosition(mapF);
		} else
			cursorForPosition = tc;

		if (cursorForPosition != null) {
			cursorForPosition.movePosition(QTextCursor.MoveOperation.NextCharacter);
			cursorForPosition.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
			if (cursorForPosition.selectedText().equals("，")) {
				aa(cursorForPosition);
			} else if (cursorForPosition.selectedText().equals("。")) {
				bb(cursorForPosition);
			} else {
				cursorForPosition.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
				cursorForPosition.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
				cursorForPosition.movePosition(QTextCursor.MoveOperation.NextCharacter,
						QTextCursor.MoveMode.KeepAnchor);
				if (cursorForPosition.selectedText().equals("，")) {
					aa(cursorForPosition);
				} else if (cursorForPosition.selectedText().equals("。")) {
					bb(cursorForPosition);
				} else {
					cursorForPosition.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
					cursorForPosition.movePosition(QTextCursor.MoveOperation.PreviousCharacter,
							QTextCursor.MoveMode.KeepAnchor);
					if (cursorForPosition.selectedText().equals("，")) {
						aa(cursorForPosition);
					} else if (cursorForPosition.selectedText().equals("。")) {
						bb(cursorForPosition);
					} else {
						if ((this.lastRepairPos == pos) ||

								(this.lastRepairPos == pos - 1)) {
							int result = getMessageBoxWithYesNO(languageTool.getString(125), languageTool.getString(126), languageTool.getString(127), languageTool.getString(128),
									QMessageBox.Icon.Question, 0);
							if (result == 0) {
								return;
							}
						}
						char cAt = text.document().characterAt(pos);
						if (cAt == 65292) {
							tc.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
							tc.insertText("。");
							tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
							text.setTextCursor(tc);
							this.lastRepairPos = tc.position();
						} else if (cAt == '。') {
							tc.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
							tc.insertText("，");
							tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
							text.setTextCursor(tc);
							this.lastRepairPos = tc.position();
						} else {
							char ccAt = text.document().characterAt(pos - 1);
							if (ccAt == 65292) {
								tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter,
										QTextCursor.MoveMode.KeepAnchor);
								this.lastRepairPos = tc.position();
								tc.insertText("。");

								text.setTextCursor(tc);
							} else if (ccAt == '。') {
								tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter,
										QTextCursor.MoveMode.KeepAnchor);
								this.lastRepairPos = tc.position();
								tc.insertText("，");

								text.setTextCursor(tc);
							}
						}
					}
				}
			}
		}
		this.btext.doNotScroll = false;
	}

	void aa(QTextCursor cursorForPosition) {
		if ((this.lastRepairPos == cursorForPosition.position())
				|| (this.lastRepairPos == cursorForPosition.position() + 1)
				|| (this.lastRepairPos == cursorForPosition.position() - 1)) {
			int result = getMessageBoxWithYesNO(languageTool.getString(125), languageTool.getString(126), languageTool.getString(127), languageTool.getString(128), QMessageBox.Icon.Question, 0);
			if (result == 1) {
				cursorForPosition.insertText("。");

				text.setTextCursor(cursorForPosition);
			}
		} else {
			cursorForPosition.insertText("。");

			text.setTextCursor(cursorForPosition);
			this.lastRepairPos = cursorForPosition.position();
		}
	}

	void bb(QTextCursor cursorForPosition) {
		if ((this.lastRepairPos == cursorForPosition.position())
				|| (this.lastRepairPos == cursorForPosition.position() + 1)
				|| (this.lastRepairPos == cursorForPosition.position() - 1)) {
			int result = getMessageBoxWithYesNO(languageTool.getString(125), languageTool.getString(126), languageTool.getString(127), languageTool.getString(128), QMessageBox.Icon.Question, 0);
			if (result == 1) {
				cursorForPosition.insertText("，");

				text.setTextCursor(cursorForPosition);
			}
		} else {
			cursorForPosition.insertText("，");

			text.setTextCursor(cursorForPosition);
			this.lastRepairPos = cursorForPosition.position();
		}
	}

	public void setBlurRadius() {
	}

	static String pinyinStr(String s) {
		ArrayList<String> list = new ArrayList();
		int start = 0;
		for (int i = 2; i <= s.length(); i += 2) {
			String substring = s.substring(start, i);
			list.add(substring);
			start = i;
		}
		System.out.println(start + " " + s.length());
		if (start != s.length()) {
			list.add(s.substring(start, s.length()));
		}
		StringBuilder sb = new StringBuilder();
		Iterator<String> it = list.iterator();
		while (it.hasNext()) {
			String next = (String) it.next();
			if (it.hasNext()) {
				sb.append(next + "'");
			} else {
				sb.append(next);
			}
		}
		return sb.toString();
	}

	void setIsShowKeepWritingMessage() {
		this.doNotShowKeepWrtingMessage = (!this.doNotShowKeepWrtingMessage);
		if (this.doNotShowKeepWrtingMessage) {
			getMessageBox(languageTool.getString(367), languageTool.getString(368));
		} else {
			getMessageBox(languageTool.getString(367), languageTool.getString(370));
		}
	}

	void addCommand(blackCommand com) {
		if (com != null) {
			this.commands.add(com);
		}
	}

	isRight isRightIntValue(String value) {
		boolean right = true;
		Object valueOf = null;
		try {
			valueOf = Integer.valueOf(value);
		} catch (NumberFormatException e) {
			right = false;
			getMessageBox(languageTool.getString(129), languageTool.getString(130));
		}
		return new isRight(right, valueOf);
	}

	void checkCommand(String com, TextRegion checkCommand) {
		boolean ishas = false;
		String[] args = cheakDocument.checkCommandArgs(com);
		if (args.length > 1) {
			if (args[1].equals("h") || args[1].equals("help") || args[1].equals(languageTool.getString(131))) {
				Iterator<blackCommand> it;
				StringBuilder sb = new StringBuilder();
				it = this.commands.iterator();
				while (it.hasNext()) {
					blackCommand next = (blackCommand) it.next();
					if (it.hasNext()) {
						sb.append("<b>" + next.command + "</b><br>" + next.info + "<br>-------<br>");
					} else {
						sb.append("<b>" + next.command + "</b><br>" + next.info);
					}
				}
				getBMessageBox(languageTool.getString(132), sb.toString());
				return;
			}
		}
		ArrayList<setIndex> setIndex = new ArrayList<setIndex>();
		for (blackCommand comm : this.commands) {
			//把整条命令按空格拆分，得到的数组内第1个项目就是命令文本
			ArrayList<String> argss = cheakDocument.checkCommandArgs(checkCommand.text, ' ');
			String commandText = null;
			if(argss.size() >= 1) commandText = argss.get(0);
			else {
				getMessageBox(languageTool.getString(133), languageTool.getString(134));
				return;
			}
			//判断命令文本与当前遍历的命令是否相同，如果不同，跳过此次循环
			if(!commandText.equals(comm.command)) {
				//命令不匹配，则计算命令中是否包含相同的字符，以便给出建议提示
				int same = algorithm.valueBySame(commandText, comm.command);
				if(same > 0) {
					String text = "";
					if(!comm.noArgs){
						text = languageTool.getString(135);
					}
					
					setIndex.add(new setIndex("$bc "+comm.command+text,same));

				}
				continue;
			}
			
			ishas = true;
			
			//如果命令相匹配，则开始提取命令给定的参数
			TextRegion command = cheakDocument.checkCommand(checkCommand.text, " " + comm.command+" ");
			//没有获取到命令给定的参数，如果命令的定义中存在参数，就给出提示，然后跳过余下的循环语句
			if (command == null) {
				if ((!comm.noArgs)) {
					getBMessageBox(languageTool.getString(136), "<b>"+languageTool.getString(137)+"</b><br><br>--------\n"+comm.info);
					continue;
				}else {
					//如果命令不需要参数，则执行，然后跳出循环
					addToFindHistory(com);
					comm.action(null);
					break;
				}
			}else {
				if ((command.text.indexOf("?") != -1) || (command.text.indexOf("？") != -1)) {
					getMessageBox(comm.command + languageTool.getString(138), comm.info);
				} else {
					String[] array = cheakDocument.checkCommandArgs(command.text);
					if ((!comm.noArgs) && (array.length > 0)) {
						addToFindHistory(com);
						comm.action(array);
					} 
					else if ((comm.noArgs) && (array.length > 0)) {
						getMessageBox(languageTool.getString(136), languageTool.getString(139));
					} 
					
				}
				break;
			}
			
		}
		if (!ishas) {
			ArrayList<String> sameComm = algorithm.setIndex(setIndex);
			if(sameComm.size() > 0) {
				StringBuffer sb = new StringBuffer();
				for(String s:sameComm) {
					sb.append(s+"\n");
				}
				getBMessageBox(languageTool.getString(136), languageTool.getString(140)+sb.toString());
			}else 
			getMessageBox(languageTool.getString(136), languageTool.getString(141));
		}
	}

	void execCommand(String com) {
		TextRegion checkCommandQ = cheakDocument.checkCommand(com, appInfo.blackCommandAndQuiet);
		if (checkCommandQ != null) {
			this.execCommandAndQuiet = true;
			checkCommand(com, checkCommandQ);
			if ((this.finddialog != null) && (this.finddialog.isVisible())) {
				this.finddialog.hide();
			}
			this.execCommandAndQuiet = false;
		} else {
			this.execCommandAndQuiet = false;
			TextRegion checkCommand = cheakDocument.checkCommand(com, appInfo.blackCommand);
			if (checkCommand != null) {
				checkCommand(com, checkCommand);
			}
		}
	}

	void currentIndexChangedForFindBox() {
		this.findLine.selectAll();
	}

	void clearMoveList() {
		this.moveList.removeAll(this.moveList);
		this.moveIndex = -1;
		updateOSDMessages(1);
		ba.clearMoveList.setText(languageTool.getString(142,moveList.size()));
	}

	void readFindHistory() {
		File file = new File(
				this.projectFile.getParent() + File.separator + "Settings" + File.separator + appInfo.FindHistory);
		if (file.exists()) {
			Object readObjFile = io.readObjFile(file);
			if (readObjFile != null) {
				this.findHistory = ((ArrayList) readObjFile);
			} else {
				this.findHistory = new ArrayList();
			}
			synFindHistoryToCombox();
		} else {
			this.findHistory = new ArrayList();
		}
	}

	void saveFindHistory() {
		String path = this.projectFile.getParent() + File.separator + "Settings" + File.separator + appInfo.FindHistory;
		io.writeObjFile(new File(path), this.findHistory);
	}

	void addToFindHistory(String findtext) {
		if (findtext.indexOf("$bc") != 0)
			return;

//		if (this.findHistory.size() >= 50) {
//			boolean isRemove = false;
//			for (int i = 0; i < this.findHistory.size(); i++) {
//				String string = (String) this.findHistory.get(i);
//				if (string.indexOf(appInfo.blackCommand) == -1) {
//					this.findHistory.remove(i);
//					isRemove = true;
//					break;
//				}
//			}
//			if (!isRemove) {
//				getMessageBox(languageTool.getString(371), languageTool.getString(372));
//				return;
//			}
//		}

		if (findHistory.size() >= 50)
			findHistory.remove(0);

		for (int i = 0; i < this.findHistory.size(); i++) {
			String string = (String) this.findHistory.get(i);
			if (string.equals(findtext)) {
				this.findHistory.remove(i);
				break;
			}
		}
		this.findHistory.add(findtext);
		synFindHistoryToCombox();
	}
	void addMenuForTextTitle(QPoint pos) {
		QMenu qm = new QMenu(text);
		ba.applyUIFont(qm);

		qm.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);
		
		QAction undo = new QAction(qm);
		undo.setText(languageTool.getString(143));
		undo.triggered.connect(textTitle.ui.lineEdit,"undo()");
		qm.addAction(undo);
		
		QAction redo = new QAction(qm);
		redo.setText(languageTool.getString(144));
		redo.triggered.connect(textTitle.ui.lineEdit,"redo()");
		qm.addAction(redo);
		
		qm.addSeparator();
		
		QAction copy = new QAction(qm);
		copy.setText(languageTool.getString(145));
		copy.setShortcut("ctrl+c");
		copy.triggered.connect(textTitle.ui.lineEdit,"copy()");
		qm.addAction(copy);

		QAction cut = new QAction(qm);
		cut.setText(languageTool.getString(146));
		cut.setShortcut("ctrl+x");
		cut.triggered.connect(textTitle.ui.lineEdit, "cut()");
		qm.addAction(cut);

		QAction paste = new QAction(qm);
		paste.setText(languageTool.getString(147));
		paste.setShortcut("ctrl+v");
		paste.triggered.connect(textTitle.ui.lineEdit, "paste()");
		qm.addAction(paste);

		qm.addSeparator();

		QAction selectAll = new QAction(qm);
		selectAll.setText(languageTool.getString(148));
		selectAll.setShortcut("ctrl+a");
		selectAll.triggered.connect(textTitle.ui.lineEdit, "selectAll()");
		qm.addAction(selectAll);
		
		qm.addSeparator();
		
//		QAction delete = new QAction(qm);
//		delete.setText(languageTool.getString(373));
//		delete.setShortcut("ctrl+d");
//		delete.triggered.connect(textTitle.ui.lineEdit, "backspace()");
//		qm.addAction(delete);
		
		QAction clear = new QAction(qm);
		clear.setText(languageTool.getString(149));
		clear.triggered.connect(textTitle.ui.lineEdit, "clear()");
		qm.addAction(clear);

		
		qm.popup(textTitle.ui.lineEdit.mapToGlobal(pos));
	}
	void addMenuForFindLine(QPoint pos) {
		QMenu qm = new QMenu(text);
		ba.applyUIFont(qm);

		qm.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);
		QAction copy = new QAction(qm);
		
		copy.setText(languageTool.getString(145));
		copy.setShortcut("ctrl+c");
		copy.triggered.connect(this.findLine, "copy()");
		qm.addAction(copy);

		QAction cut = new QAction(qm);
		cut.setText(languageTool.getString(146));
		cut.setShortcut("ctrl+x");
		cut.triggered.connect(this.findLine, "cut()");
		qm.addAction(cut);

		QAction paste = new QAction(qm);
		paste.setText(languageTool.getString(147));
		paste.setShortcut("ctrl+v");
		paste.triggered.connect(this.findLine, "paste()");
		qm.addAction(paste);

		qm.addSeparator();

		QAction selectAll = new QAction(qm);
		selectAll.setText(languageTool.getString(148));
		selectAll.setShortcut("ctrl+a");
		selectAll.triggered.connect(this.findLine, "selectAll()");
		qm.addAction(selectAll);

		qm.addSeparator();
		QAction findInCurrentFileOnly = new QAction(qm);
		findInCurrentFileOnly.setText(languageTool.getString(150));
		findInCurrentFileOnly.setCheckable(true);
		findInCurrentFileOnly.triggered.connect(this, "findInCurrent()");
		qm.addAction(findInCurrentFileOnly);

		QAction findInAll = new QAction(qm);
		findInAll.setText(languageTool.getString(151));
		findInAll.setCheckable(true);
		findInAll.triggered.connect(this, "findInAll()");
		qm.addAction(findInAll);
		if (getFindIn() == 1) {
			findInCurrentFileOnly.setChecked(true);
		} else {
			findInAll.setChecked(true);
		}
		qm.addSeparator();

		QAction clearHistoryOnlyCurrent = new QAction(qm);
		clearHistoryOnlyCurrent.setText(languageTool.getString(374));
		clearHistoryOnlyCurrent.triggered.connect(this, "clearFindHistoryOnlyCurrent()");
		qm.addAction(clearHistoryOnlyCurrent);

		QAction clearHistoryWithoutCMD = new QAction(qm);
		clearHistoryWithoutCMD.setText(languageTool.getString(375,appInfo.appName));
		clearHistoryWithoutCMD.triggered.connect(this, "clearFindHistoryWithoutCMD()");
		qm.addAction(clearHistoryWithoutCMD);

		QAction clearHistory = new QAction(qm);
		clearHistory.setText(languageTool.getString(377));
		clearHistory.triggered.connect(this, "clearFindHistory()");
		qm.addAction(clearHistory);

		qm.popup(this.findLine.mapToGlobal(pos));
	}

	void beep() {
		if ((clip != null) && (clip.isActive())) {
			clip.stop();
		} else {
			startBeepSound(-1);
		}
	}

	static void stopBeepSound() {
		if ((clip != null) && (clip.isActive())) {
			clip.stop();
		}
	}

	static void startBeepSound(int looptime) {
		startBeepSound(looptime, 0);
	}

	static void startBeepSound(final int looptime, final int type) {
		if ((quietMode) || ((clip != null) && (clip.isActive()))) {
			return;
		}
		new bRunnable(0, true, true, false, true) {
			public void run() {
				String filename = null;
				if (type == 0) {
					filename = "00.wav";
				} else if (type == 1) {
					filename = "01.wav";
				} else if (type == 2) {
					filename = "02.wav";
				} else if (type == 3) {
					filename = "03.wav";
				} else if (type == 4) {
					filename = "04.wav";
				} else if (type == 5) {
					filename = "05.wav";
				}
				File f = new File("./sound/" + filename);
				if (!f.getParentFile().exists()) {
					f.getParentFile().mkdirs();
					return;
				}
				if (!f.exists()) {
					return;
				}
				AudioInputStream audioInputStream = null;
				try {
					audioInputStream = AudioSystem.getAudioInputStream(f);
				} catch (UnsupportedAudioFileException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					clip = AudioSystem.getClip();
				} catch (LineUnavailableException e) {
					p(languageTool.getString(378));
				}
				try {
					clip.open(audioInputStream);
				} catch (LineUnavailableException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (clip == null)
					return;

				clip.loop(looptime);

				clip.addLineListener(new LineListener() {
					public void update(LineEvent event) {
						if (event.getType().equals(LineEvent.Type.START)) {
							black.clipIsStart = true;
						} else if (event.getType().equals(LineEvent.Type.STOP)) {
							clip.stop();
						}
					}
				});
				clip.start();
				while ((!clipIsStart) || (clip != null && clip.isActive())) {
					try {
						Thread.sleep(1000L);
					} catch (InterruptedException localInterruptedException) {
					}
				}
				clipIsStart = false;
				clip = null;
			}
		};
	}

	void clearFindHistoryWithoutCMD() {
		ArrayList<String> list = new ArrayList();
		for (String s : this.findHistory) {
			if (s.indexOf("$bc") == -1) {
				list.add(s);
			}
		}
		for (String s : list) {
			this.findHistory.remove(s);
		}
		synFindHistoryToCombox();
	}

	void clearFindHistoryOnlyCurrent() {
		this.findHistory.remove(this.findLine.text());
		synFindHistoryToCombox();
	}

	void clearFindHistory() {
		this.findHistory.removeAll(this.findHistory);
		synFindHistoryToCombox();
	}

	int getFindIn() {
		return Integer.valueOf((String) this.settings.value(appInfo.findIn, "1")).intValue();
	}

	void findInAll() {
		this.settings.setValue(appInfo.findIn, String.valueOf(0));
	}

	void findInCurrent() {
		this.settings.setValue(appInfo.findIn, String.valueOf(1));
	}

	void showFindDialogWithoutFindHistory() {
		if (this.finddialog == null) {
			this.finddialog = new finddialog(this);
			this.finddialog.onlyShowHistoryOfBlackCommands = true;
			this.finddialog.show();
		}
	}

	void findLineReturnPressd() {
		String str = this.findLine.text();
		if (str.length() > 0) {
			if (str.indexOf(appInfo.blackCommand) != 0) {
				addToFindHistory(str);
				showFindInfoForFindLine(str, getFindIn());
			} else {
				execCommand(str);
			}
		}
	}

	void setFindLineLocation() {
		findBox.adjustSize();
		int uiFontSize = ba.getUIFontSize(fontSize.findLineBox);
		//这里使用根据字号计算得出的工具栏高度，而非工具栏对象返回的高度，是因为各个界面组件更新尺寸存在先后顺序，有时组件对象返回的尺寸是旧的
		int toolbarHeight = ba.getUISize(uiSize.toolbarHeight).height();
		int h = findBox.height();
		int w = h*5;
		int y = toolbarHeight/2-h/2;
		this.findBox.setGeometry(width() - w -5, y, w, h);
		this.findbutton.setGeometry(this.findBox.width() - this.findBox.height() - 15, 0, this.findBox.height(),
				this.findBox.height());
	}

	public void removeTimer(int id) {
		timerInfo in = null;
		for (timerInfo info : this.timerInfos) {
			if (info.id == id) {
				in = info;
			}
		}
		this.timerInfos.remove(in);
	}

	void link(String s) {
		TextRegion com = cheakDocument.checkCommand(s, "timer");
		if (com != null) {
			removeTimer(Integer.valueOf(com.text).intValue());
		}
	}

	void addMenu(QPoint pos) {
		if(!ba.getLockStatus())return;
		if (writingView > 0) {
			QMenu qm = new QMenu();
			ba.applyUIFont(qm);
			
			qm.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);
			
			if (ba.checkBingPicIsEnable()) {
				String text = languageTool.getString(379);
				QAction showBingPicInfo = null;
				if (!textWidget.isVisible())
					text = languageTool.getString(380);
				showBingPicInfo = ba.addMenuTo(qm, text, "", ba, "showBingPicInfo()");
				qm.addAction(showBingPicInfo);
			}
			QAction exitWritingView = new QAction(qm);
			exitWritingView.setText(languageTool.getString(381));
			exitWritingView.triggered.connect(this, "exitWritingView()");
			qm.addAction(exitWritingView);
			
			qm.popup(mapToGlobal(pos));
		}
	}

	public void exitWritingView() {
		if (writingView > 0) {
			exitwritingView(Boolean.valueOf(true));
		}
	}

	void autoCheckNetworks() {
		if (this.timerForAutoCheckNetworks != null) {
			this.timerForAutoCheckNetworks.stop();
			this.timerForAutoCheckNetworks = null;
			getMessageBox("自动检查可用网络", "已停止自动检查网络");
		} else {
			final QMessageBox messageBox = getMessageBox("自动检查可用网络", "已开始自动检查网络，间隔5分钟");
			this.timerForAutoCheckNetworks = new bRunnable(10000, true, true, false, false) {
				public void run() {
					StringBuilder checkNetWorksMessage = black.this.checkNetWordksAction(true, this);
					boolean isShowAutoCheckNetworksMessage = false;
					List<String> allLine = cheakDocument.getAllLine(checkNetWorksMessage.toString());
					for (String s : allLine) {
						if (!s.equals("")) {
							if (s.indexOf("没有找到带有WEP的网络") != -1) {
								isShowAutoCheckNetworksMessage = true;
								stop();
								break;
							}
							//
							else if (s.indexOf("已连接") != -1) {
								if (s.indexOf("，但无Internet") == -1) {
									isShowAutoCheckNetworksMessage = true;
									break;
								}
							} else if ((s.indexOf("发现带有WEP关键词的无线网络") == -1) && (s.indexOf("--------") == -1)) {
								isShowAutoCheckNetworksMessage = true;
								break;
							}
						}
					}
					setData("0", Boolean.valueOf(isShowAutoCheckNetworksMessage));
					execInUIThread(new Runnable() {
						public void run() {
							p("检查可用网络：" + Data("0"));
						}
					});
					if (isShowAutoCheckNetworksMessage) {
						setData("1", checkNetWorksMessage.toString());
						execInUIThread(new Runnable() {
							public void run() {
								if (messageBox.isVisible()) {
									messageBox.hide();
								}
								black.this.getMessageBox("发现可用网络", (String) Data("1"), true);
							}
						});
					}
				}
			};
		}
	}

	void editNetWorks() {
		final File file = new File(
				this.projectFile.getParent() + File.separator + "Settings" + File.separator + "networks");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (this.networkList == null) {
			this.networkList = io.readTextFile(file, "utf-8");
		}
		bmessageBox bmessageBox = new bmessageBox(this, "编辑网络列表", "确定", this.networkList, false) {
			public void buttonPressedAction(String content) {
				if (!content.equals(black.this.networkList)) {
					io.writeTextFile(file, content, "utf-8");
					black.this.networkList = content;
				}
				close();
				dispose();
			}
		};
		bmessageBox.show();
	}

	void checkNetWorks() {
		new bRunnable(0, true, true, false, true) {
			public void run() {
				black.this.checkNetWordksAction(false, this);
			}
		};
	}

	StringBuilder checkNetWordksAction(boolean quiet, bRunnable run) {
		final StringBuilder networkOfShow = new StringBuilder();
		ArrayList<String> networklis = new ArrayList();
		try {
			Process exec = Runtime.getRuntime().exec("netsh wlan show networks mode=bssid");
			StringBuilder sb = readProcessOutput(exec, "gbk");
			String networks = sb.toString();
			File file = new File(
					this.projectFile.getParent() + File.separator + "Settings" + File.separator + "networks");
			if (!file.exists()) {
				if (!quiet) {
					run.execInUIThread(new Runnable() {
						public void run() {
							black.this.getMessageBox("警告", "没有定义网络列表！\\n请先通过右键菜单中的“无线网络-编辑网络列表”选项添加网络");
						}
					});
				}
				return networkOfShow;
			}
			if (this.networkList == null) {
				run.execInUIThread(new Runnable() {
					public void run() {
						black.this.p("读取无线网络列表");
					}
				});
				this.networkList = io.readTextFile(file, "utf-8");
			}
			List<String> allLine = cheakDocument.getAllLine(this.networkList);
			Process execc = null;
			try {
				execc = Runtime.getRuntime().exec("netsh wlan show interfaces");
			} catch (IOException e) {
				e.printStackTrace();
			}
			String interfaces = readProcessOutput(execc, "gbk").toString();
			if (networks.indexOf("WEP") != -1) {
				networklis.add("发现带有WEP关键词的无线网络");
				networklis.add("--------");
			} else
				networklis.add("没有找到带有WEP的网络，路由器可能已被重置");

			for (String s : allLine) {
				if (networks.indexOf(s) != -1) {
					if (interfaces.indexOf(s) == -1) {
						networklis.add(s);
					} else {
						int id = -1;
						Process ping = null;
						try {
							id = addTimer(new timerInfo(true, "正在检查远程网络节点", null));
							ping = Runtime.getRuntime().exec("ping www.baidu.com");
						} catch (IOException e) {
							e.printStackTrace();
						}
						StringBuilder pingSb = readProcessOutput(ping, "gbk");
						removeTimer(id);
						if (pingSb.indexOf("ms TTL=") != -1) {
							networklis.add(s + "(已连接)");
						} else {
							networklis.add(s + " (已连接，但无Internet)");
						}
					}
				}
			}
			if (networklis.size() > 0) {
				Iterator<String> it = networklis.iterator();
				while (it.hasNext()) {
					String next = (String) it.next();
					if (it.hasNext()) {
						networkOfShow.append(next + "\n");
					} else {
						networkOfShow.append(next);
					}
				}
			}
			if (!quiet) {
				run.execInUIThread(new Runnable() {
					public void run() {
						black.this.getMessageBox("发现网络", networkOfShow.toString());
					}
				});
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return networkOfShow;
	}

	void showNetWorks() {
		try {
			Process exec = Runtime.getRuntime().exec("netsh wlan show networks mode=bssid");
			StringBuilder sb = readProcessOutput(exec, "gbk");
			getBMessageBox("网络列表", sb.toString()).show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void showMoveList() {
		if ((keywords != null) && (keywords.isVisible())) {
			return;
		}
		initKeyWordsDialog();
		keywords.tree.UsedToProjectPanelOrKeywordsList = 1;
		if (keywords.tree.topLevelItemCount() > 0) {
			keywords.tree.clear();
		}
		for (int i = 0; i < this.moveList.size(); i++) {
			String s = (String) this.moveList.get(i);
			QTreeWidgetItem ti = getTreeItem(keywords.tree);
			dataForOpenedFile findInOpenedFiles = findInOpenedFiles(s);
			ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + findFileShowName(s) + " (" + i + "/"
					+ (this.moveList.size() - 1) + ")");
			if (findInOpenedFiles != null) {
				if(findInOpenedFiles.editor != null)
					ti.setData(3, 3, languageTool.getString(407));
				else ti.setData(3, 3, languageTool.getString(408));
			}	
			ti.setData(1, 0, new TextRegion(s, 0, 0));
			if (currentEditing != null && s.equals(this.currentEditing.getName())) {
				ti.setData(3, 3, languageTool.getString(407));
				QFont font = ti.font(0);
				font.setBold(true);
				font.setItalic(true);
				ti.setFont(0, font);
				keywords.tree.setCurrentItem(ti);
			}
		}
		findview = 4;
		keywords.message.setText(languageTool.getString(410,keywords.tree.topLevelItemCount()));
		keywords.statusbar.showMessage(languageTool.getString(412));
		keywords.noDefaultSelection = true;

		showDialogAtCenter(keywords);
	}

	String getMemoryAndRunTime() {
		String appUsedMemory = getAppUsedMemory();
		float F_appUsedMemory = Float.valueOf(appUsedMemory).floatValue();
		int task;

		if (F_appUsedMemory < 100.0F) {
			task = (int) (F_appUsedMemory - 32.0F);
		} else {
			task = (int) (F_appUsedMemory - 42.0F);
		}
		appRunTime = System.currentTimeMillis() - appStartTime;
		String message = languageTool.getString(413,appUsedMemory,task,time.msToTimeMoreLang(appRunTime,day,hour,min,sec));
		return message;
	}

	public void getSizeOfEditorMemory() {
		QMessageBox messageBox = getMessageBox(languageTool.getString(417), getMemoryAndRunTime());

		timerInfo timerInfo = new timerInfo(true, languageTool.getString(418), null);
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				uiRun(black.this, new Runnable() {
					public void run() {
						if (messageBox.isVisible())
							messageBox.setText(getMemoryAndRunTime());
						else {
							removeTimer(timerInfo.id);
						}
					}
				});
			}
		};
		timerInfo.setRunnable(runnable);
		addTimer(timerInfo);
	}

	public String getAppUsedMemory() {
		String lastline = null;
		String name = ManagementFactory.getRuntimeMXBean().getName();
		String pid = name.split("@")[0];
		try {
			Process exec = Runtime.getRuntime().exec("tasklist -fi \"PID eq " + pid + "\" -FO LIST");
			List<String> allLine = cheakDocument.getAllLine(readProcessOutput(exec, "gbk").toString());
			if (allLine.size() == 0) {
				lastline = "";
			} else {
				String str = (String) allLine.get(allLine.size() - 1);
				int index = str.indexOf(':');
				String substring = str.substring(index + 1, str.length() - 1);
				StringBuilder sb = new StringBuilder();
				char[] arrayOfChar;
				int j = (arrayOfChar = substring.toCharArray()).length;
				for (int i = 0; i < j; i++) {
					char c = arrayOfChar[i];
					if ((c >= '0') && (c <= '9')) {
						sb.append(c);
					}
				}
				String f = String.valueOf(Float.valueOf(sb.toString()).floatValue() / 1024.0F);
				int indexof = -1;
				if ((indexof = f.indexOf('.')) != -1) {
					f = f.substring(0, indexof + 2);
				}
				lastline = f;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return lastline;
	}

	static StringBuilder readProcessOutput(Process process, String encode) {
		StringBuilder sb = new StringBuilder();
		sb.append(read(process.getInputStream(), null, encode));
		sb.append(read(process.getErrorStream(), null, encode));
		return sb;
	}

	// 读取输入流
	static StringBuilder read(InputStream inputStream, PrintStream out, String encode) {
		StringBuilder sb = new StringBuilder();
		try {
			String enco = "gbk";
			if (encode != null)
				enco = encode;
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, enco));

			String line;
			while ((line = reader.readLine()) != null) {
				if (out != null)
					out.println(line);
				sb.append(line + "\n");
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb;
	}

	/**
	 * ping百度网，如果没有ping通，此操作将会一直阻塞线程，直到超过给定的时间
	 * 
	 * @param ms超时返回的时间
	 * @return
	 */
	static boolean ping(long ms) {
		int outtime = 0;
		while (true) {
			try {
				Process exec = Runtime.getRuntime().exec("ping www.baidu.com");
				StringBuilder ping = black.readProcessOutput(exec, "gbk");
				if (ping.indexOf("ms TTL=") != -1)
					return true;
				else {
					if (outtime >= ms)
						return false;

					try {
						Thread.sleep(500);
						outtime += 500;
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	void setTimeMessage(String message) {
		if(message == null) {
//			if(dbm)
//			getMessageBox("", "OSD信息为空！！");
			return;
		}
		if (brunnableForOSD == null) {
			timeMessage.hide();
			return;
		}

		if (!message.equals("")) {
//			QPalette palette = this.timeMessage.palette();
//			palette.setBrush(QPalette.ColorRole.WindowText, new QBrush(new QColor(Qt.GlobalColor.darkGreen)));
//			this.timeMessage.setPalette(palette);
			this.timeMessage.setText(message);
			this.timeMessage.setVisible(true);
			timeMessage.raise();
			setTimeMessageLabelLocation();
		} else {
			this.timeMessage.setVisible(false);
		}
	}
	public void setLoadFileMessage(String message) {
		this.loadFileMessage.setText(message);
		//根据字数大致计算字号数值，避免超出屏幕
		//每次设置新的文本，都需要基于基准字号进行计算，否则字号会依然沿用上一次显示时设置的字号，如果字数很少，却使用了很小的字号，或者反之，就不合适了
		QFont font = loadFileMessage.font();
		font.setPointSize(ba.getUIFontSize(fontSize.loadMessage));
		loadFileMessage.setFont(font);
		int w = width()-200;
		if(loadFileMessage.isHidden()) {
			if(message.length()*font.pointSize() > w) {
				int fontsize = w/message.length();
				font.setPointSize(fontsize);
				loadFileMessage.setFont(font);
			}
		}else {
			//如果已经显示出来，则新文本计算出来的长度应该适当放宽，避免字数微小的增加就重新调整字号
			if(message.length()*font.pointSize() > w+75) {
				int fontsize = w/message.length();
				font.setPointSize(fontsize);
				loadFileMessage.setFont(font);
			}
		}
		
		
		
		setLoadFileMessageLabelLocation();
		if (!this.loadFileMessage.isVisible()) {
			this.loadFileMessage.show();
		}
		showTime();

		removeAllTimer(appInfo.timerInfoType.autoHideLoadMessageLabel.value);
		timerInfo ti = new timerInfo(appInfo.timerInfoType.autoHideLoadMessageLabel.value, 1000, languageTool.getString(421), null, false, false);
		ti.setRunnable(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				uiRun(black.this, new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						loadFileMessage.hide();
					}
				});
				
			}
		});
		ti.hideLeftTime = true;
		addTimer(ti);
	}

	public void setLoadFileMessageLabelLocation() {
//		if(keywords != null && keywords.isVisible()) loadFileMessage.setParent(keywords);
//		else loadFileMessage.setParent(this);
		this.loadFileMessage.adjustSize();
		this.loadFileMessage.setGeometry((width() - this.loadFileMessage.width()) / 2,
				(height() - this.loadFileMessage.height()) / 2, this.loadFileMessage.width(),
				this.loadFileMessage.height());
	}

	public void setTimeMessageLabelLocation() {
		if (text == null) {
			return;
		}
		setLoadFileMessageLabelLocation();
		timeMessage.setFixedWidth(width() / 2);
		this.timeMessage.adjustSize();
		QPoint mapTo = this.ui.centralwidget.mapTo(this, textWidget.pos());
		if (writingView == 0) {
			int x = mapTo.x() + textWidget.width() - this.timeMessage.width();
			x -= 17;
			setAnimation(this.timeMessage, "geometry", this.timeMessage.geometry(),
					new QRect(x - 10, mapTo.y() + textWidget.height() - this.timeMessage.height() - 10,
							this.timeMessage.width(), this.timeMessage.height()),
					getAnimationTime());
		} else if (writingView == 1) {
			setAnimation(this.timeMessage, "geometry", this.timeMessage.geometry(),
					new QRect(width() - this.timeMessage.width() - 20, height() - this.timeMessage.height() - 10,
							this.timeMessage.width(), this.timeMessage.height()),
					getAnimationTime());
		} else {
			setAnimation(this.timeMessage, "geometry", this.timeMessage.geometry(),
					new QRect(width() - this.timeMessage.width() - 30, mapTo.y() + 40, this.timeMessage.width(),
							this.timeMessage.height()),
					getAnimationTime());
		}
	}

	public void setAnimation(final QWidget widget, final String key, Object startValue, final Object endValue,
			int time) {
		new animation(widget, key, startValue, endValue, time) {

			@Override
			public void action_endAnimation() {
				// TODO Auto-generated method stub
				
			}

		};
	}

	public void showTime() {
		if (brunnableForOSD == null) {
			this.brunnableForOSD = new bRunnable(1000, true, true, false, false) {
				public void run() {
					clearData();
					black.this.synTimeAction(this);
				}
			};
		}else synTimeAction(brunnableForOSD);
	}

	void updateOSDMessages(int what) {
		switch (what) {
		case -1:
			setShowNameOfCurrentEditingFile(getShowNameOfCurrentEditingFile());

			this.previousOpenedFile[0] = previousOpenedFile_();
			if (this.previousOpenedFile[0] != null) {
				this.previousOpenedFile[1] = findFileShowName(this.previousOpenedFile[0]);
				this.textTitle.ui.prev.setEnabled(true);
			} else {
				this.textTitle.ui.prev.setEnabled(false);
			}
			this.nextOpenedFile[0] = nextOpenedFile_();
			if (this.nextOpenedFile[0] != null) {
				this.nextOpenedFile[1] = findFileShowName(this.nextOpenedFile[0]);
				this.textTitle.ui.next.setEnabled(true);
			} else {
				this.textTitle.ui.next.setEnabled(false);
			}
			this.plusCharCount = (this.charCountWithoutEnter - this.btext.charCountAtToday);

			break;
		case 0:
			setShowNameOfCurrentEditingFile(getShowNameOfCurrentEditingFile());
			break;
		case 1:
			this.previousOpenedFile[0] = previousOpenedFile_();
			if (this.previousOpenedFile[0] != null) {
				this.previousOpenedFile[1] = findFileShowName(this.previousOpenedFile[0]);
				this.textTitle.ui.prev.setEnabled(true);
			} else {
				this.textTitle.ui.prev.setEnabled(false);
			}
			this.nextOpenedFile[0] = nextOpenedFile_();
			if (this.nextOpenedFile[0] != null) {
				this.nextOpenedFile[1] = findFileShowName(this.nextOpenedFile[0]);
				this.textTitle.ui.next.setEnabled(true);
			} else {
				this.textTitle.ui.next.setEnabled(false);
			}
			break;
		case 2:
			if(btext != null) {
				this.plusCharCount = (this.charCountWithoutEnter - this.btext.charCountAtToday);
				uiRun(this, new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						statusBar().showMessage(languageTool.getString(422,plusCharCount));
					}
				});
			}
		}
	}

	public void synTime() {
		new bRunnable(0, true, true, false, true) {
			public void run() {
				black.this.synTimeAction(this);
			}
		};
	}

	static boolean checkIsRunningOnUDiskOS() {
		String system = System.getenv("SystemDrive");
		Float size = new File(system).getTotalSpace() / 1024F / 1024F / 1024F;
//	    System.out.println(size);
		if (size == 20.002926F)
			return true;
		return false;
	}

	void turnOffMonitor() {
		ba.execNirCmd("monitor off");
		monitorOff = true;
	}

	void dontNotSetMonitor() {
		dontNotSetMonitor = !dontNotSetMonitor;
		setLoadFileMessage(languageTool.getString(423,dontNotSetMonitor));
	}

	void synTimeAction(final bRunnable run) {
//		System.out.println("timeMode"+timeMode);
		if(run == null) {
			showTime();
			return;
		}
		long currentTimeMillis = System.currentTimeMillis();
		Calendar instance = Calendar.getInstance();
		hourOfDay = instance.get(11);
		minute = instance.get(Calendar.MINUTE);
		second = instance.get(Calendar.SECOND);

		if (!dontNotSetMonitor && !monitorOff && currentTimeMillis - activeTime > 2000) {
			turnOffMonitor();
		}
		if(infoOfCurrentEditing != null && infoOfCurrentEditing.editTime_today > 0)
		if (!time.getDate(currentTimeMillis).equals(time.getDate(infoOfCurrentEditing.lastTextChangeTime))) {
			clearCharCountOfTodayInput();
		}
		if (hideTime != -1) {
			long time = currentTimeMillis - hideTime ;
//			System.out.println(time);
			if (time > 5000) {
				run.execInUIThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						
						ba.blackShow(black.this, 0);
						hideTime = -1;
						p(languageTool.getString(425));
						timerInfo ti = new timerInfo(appInfo.timerInfoType.forceShowWindow.value, 600000, languageTool.getString(425), null, false);
						ti.hideLeftTime = true;
						addTimer(ti);
					}
				});
			}
		}else if(!b.isVisible()) hideTime = currentTimeMillis;

		if (backupTime != 0) {

			try {
				Long value = currentTimeMillis - lastBackUpTime;
				if (value > backupTime) {
					backupFromSynTime = true;
					backup();
					backupFromSynTime = false;
				} else
					removeAllTimer(appInfo.timerInfoType.needRunningBackup.value);
			} catch (NullPointerException e) {
				p(languageTool.getString(426));
			}
			;
		} else
			removeAllTimer(appInfo.timerInfoType.needRunningBackup.value);

//		appRunTime = System.currentTimeMillis() - appStartTime;
//		java.sql.Time timet = new java.sql.Time(appRunTime);
//		
//		System.out.println(timet.getDay()+"-"+timet.getHours()+"-"+timet.getMinutes()+"-"+timet.getSeconds());
		if (textChanged) {
			synTextChange();
		}

		run.execInUIThread(new Runnable() {
			public void run() {
				if ((black.this.btext == null) || black.text == null || (!black.text.isVisible())) {
					run.setData("0", Boolean.valueOf(false));
					black.this.timeMessage.hide();
				}
			}
		});
		if ((run.Data("0") != null) && (!((Boolean) run.Data("0")).booleanValue())) {
			return;
		}
		String messageText = "";
		String moveInfo = "";
		if ((!this.timeMode.equals("-1")) && (!this.timeMode.equals("00"))) {
			if (writingView > 0) {
				int fontsize = ba.getUIFontSize(fontSize.add)+25;
				if (this.saved) {
					messageText = "<p style=\"font-family: 微软雅黑, serif; font-size:"+fontsize+"pt; font-style:bold;\">"
							+ this.getShowNameOfCurrentEditingFile() + "</p>";
				} else {
					messageText = "<p style=\"font-family: 微软雅黑, serif; font-size:"+fontsize+"pt; font-style:bold; font-style:italic;\">"
							+ this.getShowNameOfCurrentEditingFile() + " </p>";
				}
			}
			int fontsize = ba.getUIFontSize(fontSize.add)+9;
			if (this.moveList.size() > 0) {
				moveInfo = "<p style=\"font-family: 微软雅黑, serif; font-size:"+fontsize+"pt;\">" + this.moveIndex + "/"
						+ (this.moveList.size() - 1);
				if (this.previousOpenedFile[0] != null) {
					moveInfo = moveInfo + "<br>" + this.previousOpenedFile[1] + "▲";
				}
				if (this.nextOpenedFile[0] != null) {
					moveInfo = moveInfo + "<br>" + this.nextOpenedFile[1] + "▼";
				}
				moveInfo = moveInfo + "</p>";
			}
			timeBeep();
		}
		ArrayList<String> mess = new ArrayList();
		ArrayList<timerInfo> remove = new ArrayList();
		timerInfo info;
		for (int i = 0; i < this.timerInfos.size(); i++) {
			info = (timerInfo) this.timerInfos.get(i);
			if (info.stilLive) {
				//判断是否属于全部timeMode都显示的，或者当前是否正处于-1或00模式，如果属于这三种情况就显示
				if(!info.onlyMoreOSD || (!timeMode.equals("-1") && !timeMode.equals("00"))) {
					if (info.showProgress) {
						if (info.progressMessage.length() < 6) {
							info.progressMessage = (". " + info.progressMessage);
						} else {
							info.progressMessage = "";
						}
						mess.add(info.progressMessage + info.timerName);
					} else
						mess.add(info.timerName);
				}
					
				if (info.run != null)
					info.run.run();
			} else {
				long time_out = info.startTime + info.time;
				long time_current = time.getCurrentTime_long();
				if (time_current >= time_out) {
					remove.add(info);
					if (info.run != null)
						info.run.run();
					//onlyMoreOSD timer在-1和00模式下不显示
				} else if (!info.doNotShowTip) {
					//判断是否强制隐藏的timer
					if (!info.onlyMoreOSD || (!timeMode.equals("-1") && !timeMode.equals("00"))) {
						long leftTime_ms = time_out - time_current;
						if (info.canExit) {
							if (!info.hideLeftTime)
								mess.add(info.timerName + ": " + "<a href=timer" + info.id + ">"
										+ time.msToTimeMoreLang(leftTime_ms,day,hour,min,sec) + "</a>");
							else
								mess.add("<a href=timer" + info.id + ">" + info.timerName + "</a>");
						} else {
							if (!info.hideLeftTime)
								mess.add(info.timerName + ": " + time.msToTimeMoreLang(leftTime_ms,day,hour,min,sec));
							else
								mess.add(info.timerName);
						}
					}
				}
			}

		}
		for (timerInfo in : remove) {
			this.timerInfos.remove(in);
		}
		String timerMessage = "";
		Iterator<String> it = mess.iterator();
		while (it.hasNext()) {
			String next = (String) it.next();
			if (it.hasNext()) {
				timerMessage = timerMessage + next + "<br>";
			} else {
				timerMessage = timerMessage + next;
			}
		}
		if (mess.size() > 0) {
			int fontsize = ba.getUIFontSize(fontSize.add)+9;
			timerMessage = "<p style=\"font-family: 微软雅黑, serif; font-size:"+fontsize+"pt;\">" + timerMessage + "</p>";
		}
		if (this.timeMode.equals("00")) {
			messageText = "";
			if ((hourOfDay > 10) && (hourOfDay < 14)) {
				timeBeep();
			} else if ((hourOfDay > 18) || (hourOfDay < 6)) {
				timeBeep();
			}
		} else if (this.timeMode.equals("0")) {
			String hourOfDay = String.valueOf(Calendar.getInstance().get(11));
			messageText = messageText + hourOfDay + moveInfo;
		} else if (this.timeMode.equals("01")) {
			String hourOfDay = String.valueOf(Calendar.getInstance().get(11));
			messageText = messageText + hourOfDay + "<br>" + this.plusCharCount + moveInfo;
		} else if (this.timeMode.equals("10")) {
			messageText = messageText + time.getCurrentTime() + moveInfo;
		} else if (this.timeMode.equals("11")) {
			messageText = messageText + time.getCurrentTime() + "<br>" + this.plusCharCount + moveInfo;
		} else {
			if ((hourOfDay > 10) && (hourOfDay < 14)) {
				messageText = hourOfDay + "";
				timeBeep();
			} else if ((hourOfDay > 18) || (hourOfDay < 6)) {
				messageText = hourOfDay + "";
				timeBeep();
			} else {
				messageText = "";
			}
		}
		if (timerMessage.length() > 0) {
			messageText = messageText + timerMessage;
		}
		run.setData("1", messageText);
		run.execInUIThread(new Runnable() {
			public void run() {
				black.this.setTimeMessage((String) run.Data("1"));
			}
		});
//		run.execInUIThread(new Runnable() {
//			public void run() {
//				if (black.this.loadFileMessage.isVisible()) {
//					run.setData("2", Boolean.valueOf(true));
//				}
//			}
//		});
//		if ((run.Data("2") != null) && (((Boolean) run.Data("2")).booleanValue())) {
//			
//			long current = System.currentTimeMillis();
//			long loadFileLableShowTime = current - this.loadFileTime_end;
//			if (loadFileLableShowTime > 1000L) {
//				run.execInUIThread(new Runnable() {
//					public void run() {
//						black.this.loadFileMessage.hide();
//						loadFileTime_end = -1;
//						run.setData("2", Boolean.valueOf(false));
//					}
//				});
//			}
//		}
		bAction.secDo(this);

		// 检查是否可以停止时间守护线程运行，如果条件允许则停止线程，以便节省资源
//		if (timerInfos.size() == 0 && backupTime == 0 && timeMode.equals("00") && loadFileTime_end == -1) {
//			if(brunnableForOSD != null)
//				brunnableForOSD.stop();
//			brunnableForOSD = null;
//		}
	}

	String getDate() {
		Calendar instance = Calendar.getInstance(Locale.ENGLISH);
		String time = "";
		time = time + instance.getDisplayName(7, 2, Locale.ENGLISH);
		time = time + ", " + instance.getDisplayName(2, 2, Locale.ENGLISH);
		return time;
	}

	void timeBeep() {
		new Thread(new Runnable() {
			public void run() {
				String timeHasSecond = time.getCurrentTimeHasSecond();
				String substring = timeHasSecond.substring(2, timeHasSecond.length());
				if (substring.equals(":00:00")) {
					if (hourOfDay == 11)
						speakText(languageTool.getString(427,hourOfDay), -1);
					else if (hourOfDay == 12)
						speakText(languageTool.getString(428,hourOfDay), -1);
					else if (hourOfDay == 19)
						speakText(languageTool.getString(429,hourOfDay), -1);
					else if (hourOfDay == 20)
						speakText(languageTool.getString(430,hourOfDay), -1);

					black.startBeepSound(0, 2);
				} else if (substring.equals(":30:00")) {
					black.startBeepSound(0, 1);
				}
			}
		})

				.start();
	}

	public int addTimer(timerInfo info) {
		showTime();

		if (info.isNew) {
			for (timerInfo ti : timerInfos) {
				if (ti.type == info.type) {
					uiRun(this, new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							getMessageBox(languageTool.getString(431), languageTool.getString(432,info.timerName,ti.timerName));
						}
					});
					break;
				}
			}
		}
		info.setID(this.timerId);
		this.timerInfos.add(info);
		this.timerId += 1;
		return info.id;
	}

	public void initEditor() {
		text = new bTextEdit(this);
//		text.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		text.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
		text.setUndoRedoEnabled(false);
//		QFont font = new QFont(getEditorFontName(),getEditorFontSize());
//		text.setFont(font);
//		setStyleForCurrentDocument();
		setTextVScrollBarLocation();
//		text.setContentsMargins(0, 0, 0, 50);
		// 如果启用下面这一行，从普通视图启动后，编辑器的滚动条没反应
//		text.verticalScrollBar().setParent(textWidget);
		textLayout.addWidget(text);
		setTextMargins();
		text.lower();
//		this.ui.verticalLayout.addWidget(text);
		this.btext = new blacktext(text, this);
		
		applyColorChange();
		if (appInfo.miniMode.equals("1"))
			text.setAccicesable(false, false);
		new setMenus(this);
	}

	public bTextEdit deleteEditor() {
		if ((keywords != null) && (keywords.isVisible())) {
			keywords.hide();
		}
		
		bTextEdit backup = text;
		textLayout.removeWidget(text);
		text = null;
		this.btext = null;
		if(backup != null && !backup.isDisposed()) {
			backup.setVisible(false);
			backup.verticalScrollBar().hide();
		}
		update();
		new setMenus(this);
		return backup;
	}

	public String getProjectName() {
		String name = "";
		String projectname = this.projectInfo.getProperty(appInfo.projectName, "");
		if (projectname == null || projectname.isEmpty()) {
			String pn = projectFile.getName();
			int last = pn.lastIndexOf(".");
			name = pn.substring(0, last);
		} else
			name = projectname;
		return name;
	}

	public String getVersion() {
		return appInfo.appVersion;
	}
	void resetTextStringLayout() {
		String str = text.toPlainText();
		List<String> allLine = cheakDocument.getAllLine(str);
		StringBuilder sb = new StringBuilder();
		for (String s : allLine) {
			if (!s.isEmpty()) {
				String substring = s.substring(s.length() - 1, s.length());
				if (s.indexOf(languageTool.getString(436)) != -1 && s.indexOf(languageTool.getString(437)) != -1) {
					sb.append(s + "\n");
				} else if (!substring.equals("。") && !substring.equals("”")) {
					sb.append(s);
				} else
					sb.append(s + "\n");
			}
		}
		QTextCursor tc = text.textCursor();
		tc.select(SelectionType.Document);
		tc.beginEditBlock();
		tc.insertText(sb.toString());
		tc.endEditBlock();
		setStyleForCurrentDocument();
	}
	void showAllWidget() {
		new setMenus(this);
		if (writingView == 0) {
			if (getBooleanValueFromSettings(appInfo.noDock, "false")) {
				if (this.menubar != null) {
//					if(isAdmin() || projectInfo.keySet().size() == 0)
					this.menubar.show();
				}
				if (this.toolbar != null) {
					this.toolbar.show();
				}
				if (this.dock != null) {
					this.dock.show();
				}
			} else {
				this.ui.hideFilePanel.setChecked(true);
				dock.hide();
				menubar.hide();
				toolbar.hide();
			}
			if (this.textTitle != null) {
				this.textTitle.show();
			}
			if(setTextStyles != null)
				setTextStyles.tools.show();
			
			if (textWidget != null)
				textWidget.show();
			if (text != null) {
				text.show();
				text.verticalScrollBar().show();
			}
			if (statusBar() != null) {
				statusBar().show();
			}
		} else {
			if (text != null) {
				text.show();
			}
			if (textWidget != null)
				textWidget.show();
		}
		

	}

	void setTextMargins() {
		debugPrint(languageTool.getString(438));
		int scrollbarWidth = 0;
		if (text != null && text.verticalScrollBar() != null) {
			scrollbarWidth = text.verticalScrollBar().width();
			debugPrint(languageTool.getString(439) + text.verticalScrollBar().width());
		}
		if (writingView == 0) {
			if (!getBooleanValueFromSettings(appInfo.noDock, "false"))
				textLayout.setContentsMargins(25, 0, 25 + scrollbarWidth, 5);
			else
				textLayout.setContentsMargins(0, 0, scrollbarWidth, 5);
		} else {
			textLayout.setContentsMargins(getDocumentMargin(), 0, getDocumentMargin(), 5);
		}
	}

	public void hideFilesTree() {
		if (writingView > 0)
			return;
		boolean visible = !getBooleanValueFromSettings(appInfo.noDock, "false");
		this.dock.setVisible(visible);

		menubar.setVisible(visible);
//		textTitle.setVisible(visible);

		this.toolbar.setVisible(visible);
//		statusBar().setVisible(visible);

		settings.setValue(appInfo.noDock, visible);
		setTextMargins();
		ba.setShandow(false);
		if(text != null) text.setFocus();

	}

	public void clearLogs() {
		this.logsmessage = new StringBuilder();
		if(logsBox != null)
		logsBox.setText("");
	}

	public String previousOpenedFile_() {
		if (this.moveList.size() == 0) {
			return null;
		}
		String moveInfo = null;
		int moveindex = this.moveIndex;
		String moveinfo = null;
		String findFileShowName;
		do {
			while (moveindex == -1) {
				moveindex = this.moveList.size() - 1;
				moveinfo = (String) this.moveList.get(moveindex);
				if (!findFileShowName(moveinfo).equals(getShowNameOfCurrentEditingFile())) {
					moveInfo = moveinfo;
					return moveInfo;
				}
			}
			if (moveindex - 1 < 0) {
				break;
			}
			moveindex--;
			if (moveindex < 0 || moveindex >= moveList.size())
				return moveInfo;
			moveinfo = (String) this.moveList.get(moveindex);
			findFileShowName = findFileShowName(moveinfo);
			if (findFileShowName == null) {
				this.moveList.remove(moveindex);
				if (moveindex == this.moveList.size()) {
					moveindex = this.moveList.size() - 1;
				}
			}
		} while ((findFileShowName == null) || (findFileShowName(moveinfo).equals(getShowNameOfCurrentEditingFile())));
		moveInfo = moveinfo;

		return moveInfo;
	}

	public String nextOpenedFile_() {
		if (this.moveList.size() == 0) {
			return null;
		}
		String moveInfo = null;
		int moveindex = this.moveIndex;
		String moveinfo = null;
		String findFileShowName;
		do {
			while (moveindex == -1) {
				moveindex = this.moveList.size() - 1;
				moveinfo = (String) this.moveList.get(moveindex);
				if (!findFileShowName(moveinfo).equals(getShowNameOfCurrentEditingFile())) {
					moveInfo = moveinfo;
					return moveInfo;
				}
			}
			if (moveindex + 1 >= this.moveList.size()) {
				break;
			}
			moveindex++;
			moveinfo = (String) this.moveList.get(moveindex);
			findFileShowName = findFileShowName(moveinfo);
			if (findFileShowName == null) {
				this.moveList.remove(moveindex);
				if (moveindex == this.moveList.size()) {
					moveindex = this.moveList.size() - 1;
				}
			}
		} while ((findFileShowName == null) || (findFileShowName.equals(getShowNameOfCurrentEditingFile())));
		moveInfo = moveinfo;

		return moveInfo;
	}

	public String previousOpenedFile() {
		if (this.moveList.size() == 0) {
			return null;
		}
		String moveInfo = null;
		if (this.moveIndex == -1) {
			moveInfo = (String) this.moveList.get(this.moveList.size() - 1);
		} else if (this.moveIndex - 1 >= 0) {
			moveInfo = (String) this.moveList.get(this.moveIndex - 1);
		}
		return moveInfo;
	}

	public void moveToPreviousOpenedFile() {
		if (this.moveList.size() == 0) {
			return;
		}
		this.doNotAddToMoveList = true;
		String moveInfo = null;
		if (this.moveIndex == -1) {
			this.moveIndex = (this.moveList.size() - 1);
			moveInfo = (String) this.moveList.get(this.moveIndex);
		} else if (this.moveIndex - 1 >= 0) {
			this.moveIndex -= 1;
			moveInfo = (String) this.moveList.get(this.moveIndex);
		}
		if (moveInfo == null) {
			return;
		}
		if (this.currentEditing != null) {
			if (!moveInfo.equals(this.currentEditing.getName())) {
				changedFileOfCurrentEdit();
				openFileByTreeItem(findTreeItemByFileName(moveInfo, null));
			} else {
				moveToPreviousOpenedFile();
			}
		}
		synTime();
	}

	public String nextOpenedFile() {
		if (this.moveList.size() == 0) {
			return null;
		}
		String moveInfo = null;
		if (this.moveIndex == -1) {
			moveInfo = (String) this.moveList.get(this.moveList.size() - 1);
		} else if (this.moveIndex + 1 < this.moveList.size()) {
			moveInfo = (String) this.moveList.get(this.moveIndex + 1);
		}
		return moveInfo;
	}

	public void moveToNextOpenedFile() {
		if (this.moveList.size() == 0) {
			return;
		}
		this.doNotAddToMoveList = true;
		String moveInfo = null;
		if (this.moveIndex == -1) {
			this.moveIndex = (this.moveList.size() - 1);
			moveInfo = (String) this.moveList.get(this.moveIndex);
		} else if (this.moveIndex + 1 < this.moveList.size()) {
			this.moveIndex += 1;
			moveInfo = (String) this.moveList.get(this.moveIndex);
		}
		if (moveInfo == null) {
			return;
		}
		if (this.currentEditing != null) {
			if (!moveInfo.equals(this.currentEditing.getName())) {
				changedFileOfCurrentEdit();
				openFileByTreeItem(findTreeItemByFileName(moveInfo, null));
			} else {
				moveToNextOpenedFile();
			}
		}
		synTime();
	}

	public void sendReportInfo(String title, StringBuilder infos) {
		List<String> recipients = new ArrayList();
		recipients.add("aliceasmud@gmail.com");
		String subject = title;
		String content = infos.toString();
		List<String> attachmentNames = new ArrayList();
		SendMailBySSL sendMailBySSL = new SendMailBySSL("smtp.163.com", "465", "yangisboy@163.com", "dxy13633528994",
				recipients, subject, content, attachmentNames);
		if (sendMailBySSL.sendMail()) {
			this.logsmessage.append(languageTool.getString(440));
		}
	}

	public String getBasedInfo() {
		return appInfo.based;
	}

	public void addMoveInfoOnEnd(String filename) {
		this.addToMoveListEnd = false;
		this.moveIndex = (this.moveList.size() - 1);
		addMoveInfo(filename);
	}

	public void addMoveInfo(String filename) {
		if (this.doNotAddToMoveList) {
			this.doNotAddToMoveList = false;
			return;
		}
		ba.clearMoveList.setText(languageTool.getString(441,(moveList.size() - 1)));

		for (int i = 0; i < this.moveList.size(); i++) {
			String moveinfo = (String) this.moveList.get(i);
			if (moveinfo.equals(filename)) {
				this.moveList.remove(i);
				if ((this.moveIndex != 0) && (i <= this.moveIndex)) {
					this.moveIndex -= 1;
				}
				p(languageTool.getString(443));
			}
		}
		if ((this.moveList.size() > 0) && (this.moveIndex >= 0) && (this.moveIndex < this.moveList.size())) {
			String str = (String) this.moveList.get(this.moveIndex);
			if (str.equals(filename)) {
				return;
			}
		}
		if (this.moveList.size() >= 100) {
			this.moveList.remove(0);
			this.moveIndex -= 1;
		}
		if (this.moveList.size() == 0) {
			this.moveList.add(filename);
			this.moveIndex = (this.moveList.size() - 1);
		} else {
			if (moveIndex < 0 || moveIndex >= moveList.size())
				return;

			if (((String) this.moveList.get(this.moveIndex)).equals(filename)) {
				p(languageTool.getString(444));
				return;
			}
			if (this.moveIndex + 1 < this.moveList.size()) {
				this.moveList.add(this.moveIndex + 1, filename);
				this.moveIndex += 1;
			} else {
				this.moveList.add(filename);
				this.moveIndex = (this.moveList.size() - 1);
			}
		}
		updateOSDMessages(1);
	}

	public int findInMoveInfo(String filename) {
		int indexOf = this.moveList.indexOf(filename);
		return indexOf;
	}

	public dataForOpenedFile findInOpenedFiles(String filename) {
		for (dataForOpenedFile fileData : this.openedFiles) {
			if (fileData.filename.equals(filename)) {
				return fileData;
			}
		}
		return null;
	}

	public void addFileToOpenedFilesData(dataForOpenedFile openedfile) {
		this.openedFiles.add(openedfile);
		String showName = findFileInfoByFileName(openedfile.filename, null).getShowName();
		p(languageTool.getString(445,openedfile.filename,showName));
	}

	public void setProgressBarValue(int currentvalue, int max, String message) {
		float current_ = currentvalue;
		float max_ = max;
		int value = (int) (current_ / max_ * 100F);
		setLoadFileMessage(message + value + "%");
	}

	public void openProjectDir() {
		showinExplorer(this.projectFile.getParent(), false);
	}

	void showInExplorer() {
		showinExplorer(currentEditing.getPath(), true);
	}

	void showinExplorer(String path, boolean select) {
		String isselect = "";
		if (select) {
			isselect = "/select, ";
		}
		try {
			Runtime.getRuntime().exec("explorer " + isselect + path);
		} catch (IOException e) {
			getMessageBox("IOException", e.getMessage());
		}
	}

	public void saveProjectChanged() {
		saveAllDocuments();
		if (this.fileListChanged) {
			saveFileListFile();
		}
		statusBar().showMessage(languageTool.getString(448), 100);
		timerInfo[] timers = findTimer(appInfo.timerInfoType.projectAllChanageSaved.value);
		
		if(timers.length > 0) {
			timers[0].startTime = System.currentTimeMillis();
		}
		else {
			timerInfo ti = new timerInfo(appInfo.timerInfoType.projectAllChanageSaved.value, 5000,languageTool.getString(449),null,false);
			ti.hideLeftTime = true;
			addTimer(ti);
		}
		
	}

	public void focusMode() {
		int focusmode = getIntValueFromSettings(appInfo.focusMode, "0");
		if (focusmode == 0)
			settings.setValue(appInfo.focusMode, "1");
		else if (focusmode == 1)
			settings.setValue(appInfo.focusMode, "2");
		else
			settings.setValue(appInfo.focusMode, "0");
		// this.btext.applyEditorColor();
//		this.btext.cursorPosChanged();
	}

	public void treeClicked(QModelIndex index) {
		if (isCheackable(this.draft)) {
			this.tree.setCurrentIndex(index);
			QTreeWidgetItem item = this.tree.currentItem();
			if (item != null) {
				if (item.checkState(0).compareTo(Qt.CheckState.Checked) == 0) {
					clearOrAddSelectedStateForCheckBox(item, false);
				} else {
					clearOrAddSelectedStateForCheckBox(item, true);
				}
			}
		}
	}

	/**
	 * 显示传统的标题列表
	 */
	public void showTitleList() {
		if(text == null) return;
		if ((keywords != null) && (keywords.isVisible())) {
			return;
		}
		initKeyWordsDialog();
		keywords.tree.UsedToProjectPanelOrKeywordsList = 1;

		keywords.tree.clear();

		int pre = -1;
		QTextCursor tc_currentLine = text.textCursor();
		if (cheakDocument.cheakString(tc_currentLine.block().text())) {
			pre = tc_currentLine.block().position();
		} else {
			pre = moveToPreviousTitle(false);
		}
		QTextCursor tc = text.textCursor();
		int charCountOfDoc = text.charCountOfDoc();
		tc.setPosition(0);
		int pos = 0, lastpos = 0;

		do {
			QTextBlock tb = tc.block();
			String str = tb.text();
			if (cheakDocument.cheakStringOnly(str, appInfo.syls)) {
				lastpos = pos;
				pos = tb.position();
				if (keywords.tree.topLevelItemCount() > 0) {
					QTreeWidgetItem topLevelItem = keywords.tree.topLevelItem(keywords.tree.topLevelItemCount() - 1);
					topLevelItem.setData(3, 3, languageTool.getString(450,(pos - lastpos)));
					topLevelItem.setData(4, 4, lastpos + "$" + pos);
				}
				QTreeWidgetItem ti = getTreeItem(keywords.tree);
				ti.setText(0, str);
				QFont f = ti.font(0);
				f.setPointSize(text.font().pointSize());
				ti.setFont(0, f);
				TextRegion tr = new TextRegion(str, pos, pos + str.length());
				ti.setData(1, 0, tr);
				if (pos == pre) {
					keywords.tree.setCurrentItem(ti);
				}
			}
		} while (tc.movePosition(QTextCursor.MoveOperation.NextBlock));
		if (keywords.tree.topLevelItemCount() > 0) {
			QTreeWidgetItem topLevelItem = keywords.tree.topLevelItem(keywords.tree.topLevelItemCount() - 1);
			topLevelItem.setData(3, 3, languageTool.getString(452,(charCountOfDoc - pos)));
			topLevelItem.setData(4, 4, pos + "$" + charCountOfDoc);
		}
		keywords.message.setText(languageTool.getString(454,keywords.tree.topLevelItemCount()));
		keywords.statusbar.showMessage(languageTool.getString(456));
		keywords.onlyUserAction = true;
		keywords.noDefaultSelection = true;

		showDialogAtCenter(keywords);
	}

	void setTitleStyleForDoc() {
		QTextCursor tc = text.textCursor();
		tc.movePosition(MoveOperation.Start);
		do {
			QTextBlock tb = tc.block();
			String str = tb.text();
			QTextCursor tbc = new QTextCursor(tb);
			tbc.select(SelectionType.BlockUnderCursor);
			QTextCharFormat cf = tb.charFormat();
			QTextBlockFormat bf = cf.toBlockFormat();

			if (cheakDocument.cheakString(str)) {
				cf.setFontFamily("微软雅黑");
				cf.setFontPointSize(getEditorFontSize() + getEditorTextZoomValue() + 3);
				cf.setForeground(new QBrush(new QColor(Qt.GlobalColor.yellow)));
				bf.setTextIndent(0);
//				QFont font = new QFont("微软雅黑",getEditorFontSize()+getEditorTextZoomValue()+3);
//				cf.setFont(font);
			} else {

			}
			tbc.setCharFormat(cf);
			tbc.setBlockCharFormat(cf);
			tbc.setBlockFormat(bf);
		} while (tc.movePosition(QTextCursor.MoveOperation.NextBlock));
	}

	void clearWalkList() {
		this.infoOfCurrentEditing.editPoints = null;
		this.infoOfCurrentEditing.editPointIndex = -1;
	}
	boolean backToCurentEditPoint() {
		editPoint currentEditPoint = infoOfCurrentEditing.getCurrentEditPoint();
		if(currentEditPoint != null) {
			QTextCursor tc = text.textCursor();
			if(tc.position() != currentEditPoint.getPos()) {
				tc.setPosition(currentEditPoint.getPos());
				text.setTextCursor(tc);
				return true;
			}
		}
		return false;
	}
	void moveToPreviousEditPoint() {
		if(backToCurentEditPoint())return;
		
		boolean stil = false;
		do {
			editPoint editpoint = this.infoOfCurrentEditing.getPreviousEditPoint();
			stil = moveFromEditPoint(editpoint);
		} while (stil);
	}

	void moveToNextEditPoint() {
		if(backToCurentEditPoint())return;
		
		boolean stil = false;
		do {
			editPoint editpoint = this.infoOfCurrentEditing.getNextEditPoint();
			stil = moveFromEditPoint(editpoint);
		} while (stil);
	}
	/**
	 * 移动成功返回false，否则返回true，返回true以便让循环体继续获取下一个编辑点
	 * @param editpoint
	 * @return
	 */
	boolean moveFromEditPoint(editPoint editpoint) {
		if (editpoint == null) {
			return false;
		}
		if(editpoint.getPos() >= 0 && editpoint.getPos() <= text.charCountOfDoc()) {
			QTextCursor tc = text.textCursor();
			tc.setPosition(editpoint.getPos());
			text.setTextCursor(tc);
			this.btext.scroll();
			return false;
		}
		
		this.infoOfCurrentEditing.removeCurrentEditPoint();
		black.debugPrint(languageTool.getString(459));
		return true;
	}

	public int moveToPreviousTitle(boolean isSetView) {
		QTextDocument doc = text.document();
		QTextCursor tc = text.textCursor();
		int index = tc.blockNumber();
		if (index == 0) {
			return -1;
		}
		for (int i = index - 1; i >= 0; i--) {
			QTextBlock tb = doc.findBlockByNumber(i);
			QTextCursor curs = new QTextCursor(tb);
			String str = tb.text();
			if (cheakDocument.cheakStringOnly(str, appInfo.syls)) {
				if (isSetView) {
					QTextCursor tcfind = text.textCursor();
					tcfind.setPosition(curs.selectionStart());
					tcfind.setPosition(curs.selectionEnd(), QTextCursor.MoveMode.KeepAnchor);

					this.btext.doNotSetStyle = true;
					text.setTextCursor(tcfind);
					this.btext.scroll();
//					this.btext.doNotSetStyle = false;
				}
				return tb.position();
			}
		}
		return -1;
	}

	public int moveToNextTitle(boolean isSetView) {
		QTextDocument doc = text.document();
		QTextCursor tc = text.textCursor();
		int index = tc.blockNumber();
		if (index >= doc.blockCount() - 1) {
			return -1;
		}
		for (int i = index + 1; i < doc.blockCount(); i++) {
			QTextBlock tb = doc.findBlockByNumber(i);
			QTextCursor curs = new QTextCursor(tb);
			String str = tb.text();
			if (cheakDocument.cheakStringOnly(str, appInfo.syls)) {
				if (isSetView) {
					QTextCursor tcfind = text.textCursor();
					tcfind.setPosition(curs.selectionStart());
					tcfind.setPosition(curs.selectionEnd(), QTextCursor.MoveMode.KeepAnchor);
					this.btext.doNotSetStyle = true;
					text.setTextCursor(tcfind);
					this.btext.scroll();

//					this.btext.doNotSetStyle = false;
				}
				return tb.position();
			}
		}
		return -1;
	}

	public void showAbout() {
		String verOfSetUpdate = null;
		String path = "."+File.separator+"bin_"+File.separator+"setUpdate.jar";
		if (!new File(path).exists())
			verOfSetUpdate = languageTool.getString(460);
		else {
			try {
				Process exec = Runtime.getRuntime().exec(System.getProperty("sun.boot.library.path")+File.separator+"java -jar "+ path +" -version");
				StringBuilder sb = black.readProcessOutput(exec, "utf-8");
				verOfSetUpdate = sb.toString();
			} catch (Exception e) {
				verOfSetUpdate = languageTool.getString(460);
			}
		}
		
		String updateInfo = ba.getUpdateInfoMini(1);
//		String updateInfo = "";
//		if (appInfo.outYear != -1)
//			verinfo = "</b></i> (评估版本,评估截止期限为" + appInfo.outYear + "年" + (appInfo.outMonth - 1) + "月)<b><i>";
//		QMessageBox messageBox = getMessageBoxNotShow(languageTool.getString(462,appInfo.appName),
//				appInfo.aboutApp + updateInfo + appInfo.authorInfo + "<br>-------<br> 构建于<i> "+appInfo.buildOn+"</i><br>" + "运行于<i> "+ System.getProperty("java.runtime.name")+ System.getProperty("java.runtime.version")+ " & "+ QSysInfo.prettyProductName()+ "("+QSysInfo.kernelType()+QSysInfo.kernelVersion()+")"+ QSysInfo.currentCpuArchitecture()+ "</i><br><br>"
//						+ "<b><i>主程序版本: " + appInfo.appVersion + verinfo + "<br>部署模块版本: " + verOfSetUpdate
////				+ "<br>loader版本: " 
////				+ appInfo.loaderVer 
//						+ "<br>生成日期: " + appInfo.buildDate + "</i></b>");
////		messageBox.button(which)
//		QPushButton addButton = messageBox.addButton(QMessageBox.StandardButton.Yes);
//		addButton.setText(languageTool.getString(463));
//		addButton.clicked.connect(ba, "openUrl()");
//		messageBox.setIconPixmap(ico_app_200.pixmap(100));
//		QPushButton button_ok = messageBox.addButton(languageTool.getString(464), QMessageBox.ButtonRole.RejectRole);
//		messageBox.setDefaultButton(button_ok);
//		messageBox.exec();
		
		aboutDialog ad = new aboutDialog(this, languageTool.getString(462,appInfo.appName));
		ad.setTopText(appInfo.aboutApp);
		ad.setAboutInfo(appInfo.aboutInfo);
		ad.setCreatorInfo(appInfo.authorInfo);
		ad.setSystemInfo(appInfo.systemInfo
				+ "<br>部署模块版本: <i>" + verOfSetUpdate +"</i>");
		ad.setBottomText(
				"Copyright © 2016-"+appInfo.buildDate.substring(0,4)+" 段晓阳，保留所有权利。<br>"
//				+"<i>运行于"+QSysInfo.prettyProductName()+"</i> <br>"
						+" <i>"+languageTool.getString(1461)+" " + appInfo.appVersion + "</i>"
				+"   <i>"+languageTool.getString(1462)+" " + appInfo.buildDate+"</i> ");
				
		ad.setIcon(ico_app_200.pixmap(100));
		ad.setOpenSourceInfo(appInfo.opensourceInfo);
		ad.setUpdateInfo(appInfo.updateInfo);
		ad.setMinimumWidth(ba.desktopGeometry(true).width()/2);
		ad.exec();
	}

	public void openFileByMenu(QAction q) {
		QTreeWidgetItem qt = (QTreeWidgetItem) q.data();
		openFileByTreeItem(qt);
	}

	public void setGitMenu() {
		if ((this.projectInfo == null) || (!gitSetUp())) {
			this.ui.commit.setEnabled(false);
			this.ui.push.setEnabled(false);
			this.ui.commitAndPush.setEnabled(false);
			this.ui.branchTool.setEnabled(false);
		} else {
			this.ui.commit.setEnabled(true);
			this.ui.push.setEnabled(true);
			this.ui.commitAndPush.setEnabled(true);
		}
	}

	public void saveAsACopy() {
		if (isCheackable(this.draft)) {
			List<QTreeWidgetItem> checkedItems = getCheckedItems();
			for (QTreeWidgetItem qt : checkedItems) {
				saveAsACopy(qt);
			}
		} else {
			saveAsACopy(this.tree.currentItem());
		}
	}

	public void saveAsACopy(QTreeWidgetItem qt) {
		fileInfo in_current = getFileInfoByQTreeItem(qt);
		if (!in_current.isFile) {
			return;
		}
		String index = this.projectInfo.getProperty(appInfo.fileIndex);
		File file = new File(
				this.projectFile.getParent() + File.separator + "Files" + File.separator + index + ".black");
		if (!file.exists()) {
			QTreeWidgetItem parent = qt.parent();
			fileInfo in_new = in_current.clone();
			in_new.setShowName(languageTool.getString(466,in_new.getShowName()));
			in_new.fileName = file.getName();
			String text = readBlackFile(getFile(in_current.fileName));
			boolean isok = io.writeBlackFile(file, text, null);
			if (isok) {
				if (parent != null) {
					int indexOfChild = parent.indexOfChild(qt);
					fileInfo in_parent = getFileInfoByQTreeItem(parent);
					if (indexOfChild + 1 < in_parent.subfiles.size()) {
						in_parent.subfiles.add(indexOfChild + 1, in_new);
						QTreeWidgetItem newitem = new QTreeWidgetItem();
						newitem.setData(1, 0, in_new);
						appaySettingsForTreeItem(newitem);
						parent.insertChild(indexOfChild + 1, newitem);
					} else {
						QTreeWidgetItem newitem = new QTreeWidgetItem();
						newitem.setData(1, 0, in_new);
						appaySettingsForTreeItem(newitem);
						parent.addChild(newitem);
						in_parent.subfiles.add(in_new);
					}
				} else {
					int indexOfTopLevelItem = this.tree.indexOfTopLevelItem(qt);
					if (indexOfTopLevelItem + 1 < this.filesList.size()) {
						this.filesList.add(indexOfTopLevelItem + 1, in_new);
						QTreeWidgetItem newitem = new QTreeWidgetItem();
						newitem.setData(1, 0, in_new);
						appaySettingsForTreeItem(newitem);
						this.tree.insertTopLevelItem(indexOfTopLevelItem + 1, newitem);
					} else {
						this.filesList.add(in_new);
						QTreeWidgetItem newitem = new QTreeWidgetItem();
						newitem.setData(1, 0, in_new);
						appaySettingsForTreeItem(newitem);
						this.tree.addTopLevelItem(newitem);
					}
				}
				this.projectInfo.setProperty(appInfo.fileIndex, String.valueOf(Integer.valueOf(index).intValue() + 1));
				saveProjectFile();
				saveFileListFile();
			}
		}
	}

	public void appaySettingsForTreeItem(QTreeWidgetItem qt) {
		fileInfo in = getFileInfoByQTreeItem(qt);
		qt.setText(0, in.getShowName());
		if (in.isDir) {
			qt.setIcon(0, this.ico_folder);
		} else if (in.isRoot == -1) {
			if (in.isFiles) {
				if ((in.subfiles != null) && (in.subfiles.size() > 0)) {
					qt.setIcon(0, this.ico_files);
				} else {
					in.isFiles = false;
					in.isFile = true;
					in.subfiles = null;
					if (in.charCount == 0) {
						qt.setIcon(0, this.ico_file);
					} else {
						qt.setIcon(0, this.ico_fileOfHasText);
					}
				}
			} else if (in.isFile) {
				if (in.charCount == 0) {
					qt.setIcon(0, this.ico_file);
				} else {
					qt.setIcon(0, this.ico_fileOfHasText);
				}
			} else if (in.isKeyWordsList) {
				qt.setIcon(0, this.ico_keywordsList);
			} else {
				p(languageTool.getString(467,in));
			}
		}
		setEditable(qt, false);
	}

	public void setFileTitleAsSelectedText() {
		String selectedText = text.textCursor().selectedText();
		setTextAsFileTitle(selectedText);
	}

	public void setTextAsFileTitle(String text) {
		if ((text != null) && (!text.equals(""))) {
			this.infoOfCurrentEditing.setShowName(text);
			this.TreeWidgetItemOfCurrentEditing.setText(0, text);
			this.textTitle.setText(text);
		}
	}

	public void gitWork_ui() {
		if (gitSetUp()) {
			String[] gitInfo = getGitInfo();
			if (gitInfo != null) {
				gitWorking(gitInfo[0], gitInfo[1], gitInfo[2]);
			}
		}
	}

	public void push_ui() {
		new showProgress(this, this, languageTool.getString(468), true) {
			public void whenOkButtonPressed() {
			}

			public void whenAutoClose() {
			}

			@Override
			public void whenDialogClosed() {
				// TODO Auto-generated method stub

			}
		};
		new Thread(new Runnable() {
			public void run() {
				black.this.setProgressInfo(languageTool.getString(469), 20);
				String[] info = black.this.getGitInfo();
				black.this.push(info[0], info[1], info[2], true);

				black.this.setProgressInfo(languageTool.getString(470), 100);
			}
		}).start();
	}

	public void commit_ui() {
		if (gitSetUp()) {
			saveAllDocuments();
			int id = addTimer(new timerInfo(true, languageTool.getString(471), null));

			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					List<DiffEntry> commit = commit(null, true);
					StringBuilder sb = new StringBuilder();
					if (commit != null) {
						for (DiffEntry diff : commit) {
							sb.append(diff.getNewPath() + "\n");
						}
					}

					uiRun(black.this, new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							removeTimer(id);
							if (commit == null)
								getMessageBox(languageTool.getString(472), languageTool.getString(473));
							else {
								getBMessageBox(languageTool.getString(474,commit.size()), sb.toString());
							}

						}
					});
				}
			}).start();
		}
	}

	public void setGit_ui() {
		settings showSettingsDialog = showSettingsDialog();
		showSettingsDialog.ui.taps.setCurrentIndex(3);
	}

	public void testConn(String host, String username, String password) {
		setGitRespositoryPath();
		commit(null, true);
		push(host, username, password, true);
	}

	

	

	public void gitWorking(final String host, final String username, final String password) {
		final StringBuilder sb = new StringBuilder();
		new showProgress(this, this, languageTool.getString(476), true) {
			public void whenOkButtonPressed() {
				hide();
				dispose();
			}

			public void whenAutoClose() {
				black.this.getBMessageBox(languageTool.getString(477), sb.toString());
			}

			public void whenDialogClosed() {
				// TODO Auto-generated method stub
			}
		};
		new Thread(new Runnable() {
			public void run() {
				setProgressInfo(languageTool.getString(478), 10);
				if (!ping(30000)) {
					progressBugStop = true;
					progressMessage = languageTool.getString(479);
				}

				List<DiffEntry> commit = black.this.commit(null, true);
				black.this.setProgressInfo(languageTool.getString(480), 30);

				Iterable<PushResult> push = black.this.push(host, username, password, true);
				black.this.setProgressInfo(languageTool.getString(481), 70);
				if (commit != null) {
					sb.append(languageTool.getString(482,commit.size()));
					for (DiffEntry diff : commit) {
						sb.append(diff.getNewPath() + "\n");
					}
				}
				black.this.setProgressInfo(languageTool.getString(484), 80);
				sb.append(languageTool.getString(485));
				ArrayList<String> al = new ArrayList();
				Iterator localIterator2;
				if (push != null) {
					Iterator localIterator3;
					for (localIterator2 = push.iterator(); localIterator2.hasNext(); localIterator3.hasNext()) {
						PushResult pr = (PushResult) localIterator2.next();
						Collection<RemoteRefUpdate> remoteUpdates = pr.getRemoteUpdates();
						localIterator3 = remoteUpdates.iterator();
						// continue;
						RemoteRefUpdate rru = (RemoteRefUpdate) localIterator3.next();
						sb.append(languageTool.getString(486,rru.getRemoteName()));
						sb.append(languageTool.getString(488,rru.getNewObjectId()));
						sb.append(languageTool.getString(490,rru.getMessage()));
						sb.append(languageTool.getString(492,rru.isDelete()));
						sb.append(languageTool.getString(494,rru.isForceUpdate()));
						sb.append(languageTool.getString(496,rru.getStatus()));
						if (rru.getStatus().toString().equals("OK")) {
							al.add(rru.getRemoteName());
						}
					}
				}
				sb.append(languageTool.getString(498,al.size()) );
				for (String str : al) {
					sb.append(str + "\n");
				}
				black.this.setProgressInfo(languageTool.getString(500), 100);
			}
		})

				.start();
	}

	public String[] getGitInfo() {
		String host = null, username = null, password = null;
		try {
			host = des.decrypt(this.projectInfo.getProperty(appInfo.gitHost));
			username = des.decrypt(this.projectInfo.getProperty(appInfo.gitUsername));
			password = des.decrypt(this.projectInfo.getProperty(appInfo.gitPassword));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			p(languageTool.getString(501));
		}

		if ((host == null) || (username == null) || (password == null)) {
			return null;
		}
		return new String[] { host, username, password };
	}

	public void setProgressInfo(String message, int progressValue) {
		if (!this.progressBugStop) {
			this.progressMessage = message;
			this.progressValue = progressValue;
		} else {
		}
	}

	public void createBranch(String branchName) {
		String[] gitInfo = getGitInfo();
		String host = null, username = null, password = null;
		if (gitInfo != null) {
			host = gitInfo[0];
			username = gitInfo[1];
			password = gitInfo[2];
		} else
			return;

		try {
			gitTool.createNewBranch(branchName, this.projectFile.getParent());
		} catch (RefAlreadyExistsException e) {
			addlogs(null, e);
			return;
		} catch (RefNotFoundException e) {
			addlogs(null, e);
			return;
		} catch (InvalidRefNameException e) {
			addlogs(null, e);
			return;
		} catch (IOException e) {
			addlogs(null, e);
			return;
		} catch (GitAPIException e) {
			addlogs(null, e);
			return;
		}
		push(host, username, password, true);
	}

	public void copyBranchFromLocal(String dirpath, String branchName, Collection<String> branchs, boolean all) {
		if (!isHasGitDir()) {
			return;
		}
		try {
			gitTool.cloneFromLocal(this.projectFile.getParent(), dirpath, all, branchs, branchName);
		} catch (InvalidRemoteException e) {
			addlogs(null, e);
		} catch (TransportException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
	}

	public void copyBranchFromRemote(String dirpath, String branchName, Collection<String> branchs, boolean all) {
		String[] gitInfo = getGitInfo();
		String host = null, username = null, password = null;
		if (gitInfo != null) {
			host = gitInfo[0];
			username = gitInfo[1];
			password = gitInfo[2];
		} else
			return;

		try {
			gitTool.CloneFromRemote(dirpath, host, all, branchs, branchName, username, password);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		} catch (JGitInternalException e) {
			addlogs(null, e);
		}
	}

	public void deleteBranchFromRemote(String branchName, boolean local) {
		String[] gitInfo = getGitInfo();
		String host = null, username = null, password = null;
		if (gitInfo != null) {
			host = gitInfo[0];
			username = gitInfo[1];
			password = gitInfo[2];
		} else
			return;

		try {
			gitTool.deleteBranchFromRemote(this.projectFile.getParent(), host, branchName, local, username, password);
		} catch (InvalidRemoteException e) {
			addlogs(null, e);
		} catch (TransportException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		}
	}

	public Collection<Ref> getAllBranchFromRemote() {
		String[] gitInfo = getGitInfo();
		String host = null, username = null, password = null;
		if (gitInfo != null) {
			host = gitInfo[0];
			username = gitInfo[1];
			password = gitInfo[2];
		} else
			return null;

		Collection<Ref> allBranchFromRemote = null;
		try {
			allBranchFromRemote = gitTool.getAllBranchFromRemote(host, username, password);
		} catch (InvalidRemoteException e) {
			addlogs(null, e);
		} catch (TransportException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
		return allBranchFromRemote;
	}

	public Iterable<PushResult> push(String host, String username, String password, boolean quiet) {
		Iterable<PushResult> pushToRemote = null;
		try {
			pushToRemote = gitTool.pushToRemote(this.projectFile.getParent(), host, username, password, true);
		} catch (InvalidRemoteException e) {
			addlogs(null, e);
		} catch (TransportException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
		if ((!quiet) && (pushToRemote != null)) {
			StringBuilder sb = new StringBuilder();
			Iterator localIterator2;
			for (Iterator localIterator1 = pushToRemote.iterator(); localIterator1.hasNext(); localIterator2
					.hasNext()) {
				PushResult pr = (PushResult) localIterator1.next();
				Collection<RemoteRefUpdate> remoteUpdates = pr.getRemoteUpdates();
				localIterator2 = remoteUpdates.iterator();
				// continue;
				RemoteRefUpdate rru = (RemoteRefUpdate) localIterator2.next();
				sb.append(rru + "\n");
			}
			getBMessageBox(languageTool.getString(502), sb.toString());
		}
		return pushToRemote;
	}

	public boolean gitSetUp() {
		String[] gitInfo = getGitInfo();
		if (gitInfo != null) {

			if (isHasGitDir()) {
				return true;
			}
			setGitRespositoryPath();
			if (isHasGitDir()) {
				getMessageBox(languageTool.getString(503), languageTool.getString(504));
				return true;
			}
			getMessageBox(languageTool.getString(503), languageTool.getString(506));
			return false;
		}
		return false;
	}

	public bmessageBox getBMessageBox(String title, String message) {
		bmessageBox bmessageBox = null;
		QWidget parent = null;
		
		if ((this.finddialog == null) || (!this.finddialog.isActiveWindow())) {
			parent = this;
			
		}else parent = finddialog;
		bmessageBox = new bmessageBox(parent, title, languageTool.getString(507), message, true) {
			public void buttonPressedAction(String content) {
				close();
				dispose();
			}
		};
		if(ba != null)
		ba.applyUIFont(bmessageBox);
		return bmessageBox;
	}

	public List<DiffEntry> commit(String message, boolean quiet) {
		if (!isHasGitDir()) {
			setGitRespositoryPath();
		}
		changeBranch(this.projectInfo.getProperty(appInfo.projectName));

		String mess = null;
		List<DiffEntry> commit = null;
		if (message == null) {
			mess = languageTool.getString(512,time.getCurrentDate("-"),time.getCurrentTime());
		} else {
			mess = message;
		}
		try {
			commit = gitTool.commit(this.projectFile.getParent(), mess);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
		if ((!quiet) && (commit != null)) {
			StringBuilder sb = new StringBuilder();
			for (DiffEntry diff : commit) {
				sb.append(diff.getNewPath() + "\n");
			}
			getBMessageBox(languageTool.getString(513), sb.toString());
		}
		getCommitLogsFormLocalRespository();
		return commit;
	}

	public Iterable<RevCommit> getCommitLogsFormLocalRespository() {
		Iterable<RevCommit> rev = null;
		try {
			rev = gitTool.getCommitInfoFromLocalRespository(this.projectFile.getParent());
		} catch (NoHeadException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		}
		return rev;
	}

	public ArrayList<RevCommit> getCommits(String[] branchNames) {
		ArrayList<RevCommit> al = null;
		try {
			al = gitTool.getCommitsFromBranch(this.projectFile.getParent(), branchNames);
		} catch (NoHeadException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
		return al;
	}

	public void changeBranch(String branchName) {
		try {
			gitTool.changeBranch(this.projectFile.getParent(), branchName);
		} catch (RefAlreadyExistsException e) {
			addlogs(null, e);
		} catch (RefNotFoundException e) {
			addlogs(null, e);
		} catch (InvalidRefNameException e) {
			addlogs(null, e);
		} catch (CheckoutConflictException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		}
	}

	public boolean isHasGitDir() {
		File dir = new File(this.projectFile.getParent() + File.separator + ".git");
		if ((dir.exists()) && (dir.list().length > 0)) {
			return true;
		}
		return false;
	}

	public void setGitRespositoryPath() {
		try {
			if (!isHasGitDir()) {
				gitTool.createGitRepository(this.projectFile.getParent());
			}
		} catch (IOException e) {
			addlogs(null, e);
		} catch (IllegalStateException e) {
			addlogs(null, e);
		}
		try {
			gitTool.createNewBranch(this.projectInfo.getProperty(appInfo.projectName), this.projectFile.getParent());
		} catch (RefAlreadyExistsException e) {
			addlogs(null, e);
		} catch (RefNotFoundException e) {
			addlogs(null, e);
		} catch (InvalidRefNameException e) {
			addlogs(null, e);
		} catch (IOException e) {
			addlogs(null, e);
		} catch (GitAPIException e) {
			addlogs(null, e);
		}
	}

	public void addlogs(String log, Exception e) {
		if (e == null) {
			this.logsmessage.append("[" + time.getCurrentDate("-") + " " + time.getCurrentTime() + "] " + log + "<br>");
		} else {
			this.logsmessage.append("[" + time.getCurrentDate("-") + " " + time.getCurrentTime() + "] " + "("
					+ e.getStackTrace()[0].getClassName() + " " + e.getStackTrace()[0].getMethodName() + " "
					+ e.getStackTrace()[0].getLineNumber() + "行 ：" + e.getMessage() + "<br>");
			this.progressMessage = (languageTool.getString(514,e.getMessage()));

			this.progressBugStop = true;
		}
	}

	public void saveGitInfo(String host, String username, String password) {
		try {
			this.projectInfo.setProperty(appInfo.gitHost, des.encrypt(host));
			this.projectInfo.setProperty(appInfo.gitUsername, des.encrypt(username));
			this.projectInfo.setProperty(appInfo.gitPassword, des.encrypt(password));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		saveProjectFile();
		if (isHasGitDir()) {
			setGitMenu();
		}
	}

	void clearCharCountOfTodayInput() {
		if(infoOfCurrentEditing == null || btext == null)return;
		infoOfCurrentEditing.charCountOfLastInput = (time.getCurrentDate("-") + " 0");
		btext.charCountAtToday = charCountWithoutEnter;
		infoOfCurrentEditing.editTime_today = 0;
		updateOSDMessages(2);
	}

	public void showCharCountBox() {
		String str = text.toPlainText();
		int[] stat = cheakDocument.wordStat(str);
		int characterCount = str.length();
		int blockCount = stat[2];
		int lineCount = stat[2];
		int charCountWithoutReturn = characterCount - blockCount;
		String editTime = null;
		if (infoOfCurrentEditing.editTime_today < 1000)
			editTime = languageTool.getString(515);
		else
			editTime = time.msToTimeMoreLang(infoOfCurrentEditing.editTime_today,day,hour,min,sec);
		String editTime_all = null;
		if(infoOfCurrentEditing.editTime < 1000)
			editTime_all = languageTool.getString(515);
		else editTime_all = time.msToTimeMoreLang(infoOfCurrentEditing.editTime,day,hour,min,sec);
//		float writeSpeed = plusCharCount / (btext.editTime / 1000F) * 3600F;
		ArrayList<bTableBoxData> al = new ArrayList<bTableBoxData>();
		al.add(new bTableBoxData(languageTool.getString(517),null,null));
		al.add(new bTableBoxData(editTime+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(518),null,null));
		al.add(new bTableBoxData(editTime_all+"",new QColor(GlobalColor.white),new QColor(GlobalColor.black)));
		al.add(new bTableBoxData(languageTool.getString(519),null,null));
		al.add(new bTableBoxData(plusCharCount+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(520),null,null));
		al.add(new bTableBoxData(characterCount+"",null,new QColor(GlobalColor.yellow)));
		al.add(new bTableBoxData(languageTool.getString(521),null,null));
		al.add(new bTableBoxData(charCountWithoutReturn+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(522),null,null));
		al.add(new bTableBoxData(stat[1]+"",new QColor(GlobalColor.yellow),new QColor(GlobalColor.red)));
		al.add(new bTableBoxData(languageTool.getString(523),null,null));
		al.add(new bTableBoxData(stat[0]+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(524),null,null));
		al.add(new bTableBoxData(stat[2]+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(525),null,null));
		al.add(new bTableBoxData(blockCount+"",null,null));
//		al.add(new bTableBoxData(languageTool.getString(526),null,null));
//		al.add(new bTableBoxData(lineCount+"",null,null));
		al.add(new bTableBoxData(languageTool.getString(527),null,null));
		al.add(new bTableBoxData(caretPos.text(),null,null));
		al.add(new bTableBoxData(languageTool.getString(528),null,null));
		al.add(new bTableBoxData(text.textCursor().position()+ languageTool.getString(529),null,null));
		al.add(new bTableBoxData(languageTool.getString(530),null,null));
		al.add(new bTableBoxData((text.charCountOfDoc() - text.textCursor().position()) + languageTool.getString(531),null,null));
		bTableBox box = new bTableBox(this,2, al, true, true);

		box.setWindowTitle(languageTool.getString(532));
		
		box.show();
//		String message = languageTool.getString(533) + this.plusCharCount 
//		+ languageTool.getString(534) + editTime + languageTool.getString(535)
//				+ languageTool.getString(536)+ characterCount 
//				+ languageTool.getString(537) + charCountWithoutReturn 
//				+ languageTool.getString(538) + stat[1]
//				+ languageTool.getString(539) + stat[0] 
//						+ languageTool.getString(540) + stat[2] 
//								+ languageTool.getString(541) + blockCount 
//								+ "\n"
//				+ languageTool.getString(542) + lineCount 
//				+ languageTool.getString(543) + (languageTool.getString(544) + pageCurrent + languageTool.getString(545) + allPage + languageTool.getString(546))
//				+ languageTool.getString(547) + caretPos.text()
//				+ languageTool.getString(548) + text.textCursor().position()+ languageTool.getString(549)
//				+ languageTool.getString(550) + (text.charCountOfDoc() - text.textCursor().position()) + languageTool.getString(551);
//
//		QMessageBox messagebox = new QMessageBox(QMessageBox.Icon.NoIcon, languageTool.getString(552), message,
//				new QMessageBox.StandardButtons(QDialogButtonBox.StandardButton.Ok.value()), this);
//
//		messagebox.show();
	}

	public void removeAllSaveTimer() {
		ArrayList<timerInfo> remove = new ArrayList();
		for (timerInfo info : this.timerInfos) {
			if (info.type == appInfo.timerInfoType.autoSave.value) {
				remove.add(info);
			}
		}
		for (timerInfo info : remove) {
			this.timerInfos.remove(info);
		}
	}

	public boolean isHasSaveTimer() {
		boolean ishas = false;
		for (timerInfo info : this.timerInfos) {
			if (info.type == appInfo.timerInfoType.autoSave.value) {
				ishas = true;
				break;
			}
		}
		return ishas;
	}

	public void addSaveTimer() {
		if (isHasSaveTimer()) {
			removeAllSaveTimer();
		}
		timerInfo ti = new timerInfo(appInfo.timerInfoType.autoSave.value, getAutoSave() * 1000, languageTool.getString(553), new Runnable() {
			public void run() {
				new bRunnable(0, true, true, true, true) {
					public void run() {
						black.this.saveProjectChanged();
					}
				};
			}
		}, false);
		ti.onlyMoreOSD = true;
		addTimer(ti);
	}

	public int getAutoSave() {
		Integer save = Integer.valueOf((String) this.settings.value(appInfo.autoSave, "300"));
		return save.intValue();
	}

	public void setAutoSave(int value) {
		if (value > 0) {
			this.settings.setValue(appInfo.autoSave, String.valueOf(value));
			addSaveTimer();
		} else if (value == -1) {
			this.settings.setValue(appInfo.autoSave, String.valueOf(value));
			removeAllSaveTimer();
		}
	}

	public int getDocumentMargin() {
		Integer margin = Integer.valueOf((String) this.settings.value(appInfo.documentMargin, "20"));
		return margin.intValue();
	}

	public void setDocumentMargin(int value) {
		this.settings.setValue(appInfo.documentMargin, String.valueOf(value));
		if (writingView == 1) {
			textLayout.setContentsMargins(value, 0, value, 0);
		}
	}

	public void setWritingViewMode(int value) {
		this.settings.setValue(appInfo.writingViewMode, String.valueOf(value));
		if (writingView > 0) {
			exitwritingView(Boolean.valueOf(true));
			writingView(Boolean.valueOf(true));
		}
	}

	public void setWritingViewTextWidth(int value) {
		if (writingView > 0) {
			int margings = value / 2;
			setTextLocationForWritingView(margings);

		}
		this.settings.setValue(appInfo.textWidthForWritingView, String.valueOf(value));
	}

	public int getWritingViewTextWitdh() {
		QRect desktopGeometry = bAction.desktopGeometry(true);
		int value = Integer.valueOf((String) this.settings.value(appInfo.textWidthForWritingView,
				String.valueOf(desktopGeometry.width() / 3))).intValue();
		return value;
	}
	
	public boolean isHasActiveDialogOnChildren() {
		List<QObject> children = children();
		for (QObject o : children) {
			if(QDialog.class.isInstance(o)) {
				QDialog oo = (QDialog) o;
				if(oo.isActiveWindow()) {
					debugPrint(languageTool.getString(554,oo.windowTitle()));
					return true;
				}
			}
			
		}
		return false;
	}

	static int mapAlphaByTime() {
		int h = Calendar.getInstance().get(11);
		int m = Calendar.getInstance().get(12);

		int s = 18000;
		Float a_s = Float.valueOf(254.0F / s);
		int alpha_ = -1;
		int hourOfDay = h;
		if ((hourOfDay >= 4) && (hourOfDay < 9)) {
			int hour = hourOfDay - 4;
			int sec = m * 60;
			int secs = hour * 3600 + sec;
			alpha_ = (int) (255.0F - a_s.floatValue() * secs);
		} else if ((hourOfDay >= 9) && (hourOfDay < 17)) {
			alpha_ = 1;
		} else if ((hourOfDay >= 17) && (hourOfDay < 22)) {
			int hour = hourOfDay - 17;
			int sec = m * 60;
			int secs = hour * 3600 + sec;
			alpha_ = (int) (1.0F + a_s.floatValue() * secs);
		} else if ((hourOfDay >= 22) && (hourOfDay <= 23)) {
			alpha_ = 255;
		} else if ((hourOfDay >= 0) && (hourOfDay < 4)) {
			alpha_ = 255;
		}
		return alpha_;
	}

	void changeWritingView() {
		if (writingView == 0) {
			return;
		}
		if (writingView == 1) {
			setWritingViewMode(2);
		} else if (writingView == 2) {
			setWritingViewMode(1);
		}
	}

	double getShadowBlurRadius() {
		if (writingView == 1) {
			return Double.valueOf((String) this.settings.value(appInfo.blurRadiusWindowMode, "0")).doubleValue();
		}
		if (writingView == 2) {
			return Double.valueOf((String) this.settings.value(appInfo.blurRadiusFullScreen, "0")).doubleValue();
		}
		return -1.0D;
	}

	public void setWindowTitleB(String title) {
		setWindowTitle(title);
	}

	void setEditorHeight(int v) {
//		int width = getWritingViewTextWitdh();
//		settings.setValue(appInfo.editorHeight, v + "");
//		this.ui.verticalLayout.setContentsMargins(0, v, width, v - 1);

//		textLayout.setContentsMargins(getDocumentMargin(), 0,
//				getDocumentMargin() - getIntValueFromSettings(appInfo.textVScrollbarWidth, "15"), 0);
	}

	int getEditorHeight() {
		return this.getIntValueFromSettings(appInfo.editorHeight, "10");
	}

	public void VScrollSetValue_(int value) {
		if (value == text.verticalScrollBar().value())
			return;
//		else if(value > text.verticalScrollBar().value()) {
//			startv = value-20;
//		}else {
//			startv = value+20;
//		}
		QPropertyAnimation pro = new QPropertyAnimation();
		pro.setTargetObject(text.verticalScrollBar());
		pro.setPropertyName(new QByteArray("value"));
		pro.setStartValue(text.verticalScrollBar().value());
		pro.setEndValue(value);
		pro.setDuration(100);
		pro.start();
		new bRunnable(100, true, false, true, true) {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if ((int) pro.currentValue() != text.verticalScrollBar().value())
					text.verticalScrollBar().setValue(value);
			}
		};
	}

	void setTextLocationForWritingView(int width) {
		debugPrint(languageTool.getString(555,width));
//		this.ui.verticalLayout.setContentsMargins(27, 20, width, 20);
		String topAndBottom = getStringValueFromSettings(appInfo.writingViewTextTopAndBottom, "0 0");
		String[] args = cheakDocument.checkCommandArgs(topAndBottom);
		int top = 0, bottom = 0;
		isRight isTop = isRightIntValue(args[0]);
		if (isTop.isright) {
			top = (int) isTop.value;
		}
		isRight isBottom = isRightIntValue(args[1]);
		if (isBottom.isright) {
			bottom = (int) isBottom.value;
		}
		if(top == 0 && bottom == 0) {
			int[] r = text.setRange();
			this.ui.verticalLayout.setContentsMargins(width, r[0], width, r[1]);
		}else
			this.ui.verticalLayout.setContentsMargins(width, top, width, bottom);
	}
	@Override
	protected void showEvent(QShowEvent event) {
		// TODO Auto-generated method stub
		
		super.showEvent(event);
		setAttribute(WidgetAttribute.WA_Mapped);
		
	}
	public void writingView(Boolean isSetEditorWidth) {
		if (btext == null)
			return;

		if (writingView == 1) {
			return;
		}
		if (b.text != null && b.text.isEnabled()) {
			writingView = 1;
			saveGeometry = saveGeometry();
			if (keywords != null) {
				keywords.hide();
			}
			hide();

			this.textTitle.setVisible(false);
			if(setTextStyles != null)
			setTextStyles.tools.setVisible(false);
			
			this.ui.menubar.setVisible(false);

			this.toolbar.setVisible(false);

			statusBar().setVisible(false);

			int width = getWritingViewTextWitdh() / 2;
			setTextLocationForWritingView(width);
			setTextVScrollBarLocation();
			setTextMargins();
			
			//win10下frameLess设置会导致窗口不刷新
			float ver = ba.getWinntVersion();
			if(ver > -1 && ver < 10) {
				p(languageTool.getString(556,ver));
				windowFlags = windowFlags();
				WindowFlags newWF = windowFlags;
				debugPrint("isSetFrameLessWindowHint "+newWF.isSet(Qt.WindowType.FramelessWindowHint));
				newWF.set(Qt.WindowType.FramelessWindowHint);
				
				setWindowFlags(newWF);
//				setAttribute(WidgetAttribute.WA_Mapped);
//				QCoreApplication.processEvents();
				
			}
			
			
//			setAttribute(WidgetAttribute.WA_NoSystemBackground);
//			setAttribute(WidgetAttribute.WA_TranslucentBackground);
//			hide();// setWindowFlags使窗口隐藏后，有时需先调用一次hide方法，再调用show或showFullScreen才能让窗口显示出来

			/**
			 * 背景透明选项似乎只在全屏模式下可以开启 即便是无边框窗口，只要不是全屏幕大小都不能开启背景透明特性，开启后窗口不会显示
			 * 升级Qt到5.15后好像解决了这个问题
			 */
//			setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, true);
//			setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, false);
//			setStyleSheet("background:transparent");
			if (getBooleanValueFromSettings(appInfo.fullScreen, "true")) {
				ba.blackShow(this, 1);
			} else {
				QDesktopWidget desk = new QDesktopWidget();
				QRect availableGeometry = desk.availableGeometry();
				desk.dispose();
//				setGeometry(availableGeometry.x(), availableGeometry.y(), availableGeometry.width(), availableGeometry.height());
				setGeometry(availableGeometry);				
				ba.blackShow(this, 0);
				
			}

//			setWindowOpacity(0.99);

			if (this.ui.dockTree.isVisible()) {
				this.ui.dockTree.hide();
			}
//			this.ui.hideFilePanel.setChecked(true);
			// this.btext.applyEditorColor();

			applyColorChange();

			text.setVisible(false);
			text.setVisible(true);
			text.setFocus();
			this.btext.scroll();
			debugPrint("C " + textWidget.geometry());
			ba.setShandow(false);
			
			ba.fixQt515Linux();
			
		}
	}

	public void cutText() {
		if (!text.isAccicesable())
			return;
		QTextCursor tc = text.textCursor();
		if (!tc.hasSelection())
			return;

		text.cut();
		setLoadFileMessage(languageTool.getString(558));
	}

	public void copyText() {
		if (!text.isAccicesable())
			return;
		text.copy();
		setLoadFileMessage(languageTool.getString(559));
	}

	public void pasteWithCurrentFormat() {
		if (!text.isAccicesable())
			return;
		QTextCursor tc = text.textCursor();
		QClipboard clipboard = QApplication.clipboard();
		String originalText = clipboard.text();
		tc.insertText(originalText);

		setLoadFileMessage(languageTool.getString(560));
	}

	void resetDocumentFormat() {
		StringBuilder sb = new StringBuilder();
		QTextDocument doc = text.document();
		int count = doc.blockCount();
		for (int i = 0; i < count; i++) {
			QTextBlock block = doc.findBlockByNumber(i);
			String str = block.text();
			if (str.length() > 0) {
				for (int a = 0; a < str.length(); a++) {
					char charAt = str.charAt(a);
					if ((charAt != ' ') && (charAt != '\t') && (charAt != '　')) {
						String substring = str.substring(a, str.length());
						if (i < count - 1) {
							sb.append(substring + "\n");
							break;
						}
						sb.append(substring);
						break;
					}
				}
			}
		}
		QTextCursor tc = text.textCursor();
		tc.beginEditBlock();
		tc.movePosition(QTextCursor.MoveOperation.Start);
		tc.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor);
		tc.insertText(sb.toString());
		tc.endEditBlock();
		setStyleForCurrentDocument();
	}

	public void exitwritingView(Boolean b) {
//		if (!isAdmin())
//			return;

		if (keywords != null) {
			keywords.hide();
		}
		if (!textWidget.isVisible()) {
			QRect object = (QRect) ba.tempData.get("oldTextWidgetGeometry");
			if (object != null)
				textWidget.setGeometry(object);
			textWidget.show();
//			ba.showBingPicInfo();
			if(ba.label != null) {
				ba.label.hide();
				ba.label.setGeometry(new QRect(0, height() + 100, width(), 100));			
			}
			
		}

		QPalette palette = statusBar().palette();
		palette.setColor(QPalette.ColorRole.Window, this.windowColor);

		statusBar().setAutoFillBackground(true);
		statusBar().setBackgroundRole(QPalette.ColorRole.Window);

		statusBar().setPalette(palette);

		this.ui.verticalLayout.setContentsMargins(0, 0, 0, 0);
//		if (getBooleanValueFromSettings(appInfo.noDock, "false")) {
//			this.ui.menubar.setVisible(true);
//			this.toolbar.setVisible(true);
//			this.ui.dockTree.setVisible(true);
//			this.ui.hideFilePanel.setChecked(false);
//		}else {
//			if(dock.isVisible()) {
//				
//			}
//		}
		statusBar().setVisible(true);

		this.textTitle.setVisible(true);
		if (writingView == 1) {
			setVisible(false);
//			setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, false);
//			setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, false);
			if(windowFlags != null) {
				windowFlags.clear(WindowType.FramelessWindowHint);
				setWindowFlags(windowFlags);
			}
//			
			restoreGeometry(this.saveGeometry);
			setWindowState(new Qt.WindowState[] { Qt.WindowState.WindowNoState });

			setVisible(true);
			repaint();
			writingView = 0;

//			setWindowOpacity(0.1);			
			if (dock.isFloating())
				dock.setFloating(false);

			if (getBooleanValueFromSettings(appInfo.fullScreen, "true")) {
//				if (!getBooleanValueFromSettings(appInfo.windowIsMax, "false"))
//					showNormal();
//				else
//					showMaximized();
			} else {
				ba.blackShow(this, 0);
//				showNormal();
				
			}

			if (b) {
				ba.blackShow(this, 0);
//				showNormal();
				
			}
		}
		writingView = 0;
		text.setVisible(false);
		text.setVisible(true);
		setTextMargins();
		//退出写作视图时需要重新设置textWideget的边距
		text.setRange();
		applyColorChange();
		showAllWidget();
		this.btext.scroll();
		ba.setShandow(false);
		text.setFocus();
		if(text.useQtCaret) {
			text.setCursorWidth(getEditorCaretWidthValue());
		}
		ba.fixQt515Linux();
	}

	protected void paintEvent(QPaintEvent event) {
		QPainter p = new QPainter(this);
		if (writingView == 0 && ba.getLockStatus()) {
			int startX = this.dock.x() + this.dock.width() + 2;
			int height1 = this.dock.titleBarWidget().height() - 2;
			int startY = 0;
			if (this.toolbar.isVisible()) {
				startY = this.toolbar.y() + this.toolbar.height();
			} else {
				startY = this.ui.menubar.y() + this.ui.menubar.height();
			}
			if ((this.dock != null) && (this.dock.isVisible()) && !dock.isFloating()) {
				//绘制竖线
				p.setRenderHint(QPainter.RenderHint.HighQualityAntialiasing, true);
				p.setPen(new QPen(new QBrush(borderColor), 1.0D));
				p.drawLine(this.dock.x() + this.dock.width(), startY, this.dock.x() + this.dock.width(),
						statusBar().y());
			}
			if ((textTitle != null) && (textTitle.isVisible())) {
				QLinearGradient linearGradient = new QLinearGradient(new QPointF(startX, startY),
						new QPointF(startX, startY + height1));
				QColor a = new QColor(247, 249, 250);
				QColor b = new QColor(232, 236, 240);

				linearGradient.setColorAt(0.0D, new QColor(Qt.GlobalColor.white));
				linearGradient.setColorAt(0.4D, a);
				linearGradient.setColorAt(1.0D, b);

				p.setPen(new QPen(new QBrush(linearGradient), 0.0D));

				linearGradient.setSpread(QGradient.Spread.PadSpread);
				p.setBrush(linearGradient);

				p.drawRect(startX, startY, 3, height1);
				p.setRenderHint(QPainter.RenderHint.HighQualityAntialiasing, true);
				p.setPen(new QPen(new QBrush(borderColor), 1.0D));
				p.drawLine(this.dock.x() + this.dock.width(), startY + this.dock.titleBarWidget().height() - 1,
						this.dock.x() + this.dock.width() + 5, startY + this.dock.titleBarWidget().height() - 1);
				startY = startY + dock.titleBarWidget().height();
			}
			if ((setTextStyles != null) && (setTextStyles.tools.isVisible())) {
				int stylePanelHeight = setTextStyles.tools.height();
				QLinearGradient linearGradient = new QLinearGradient(new QPointF(startX, startY),
						new QPointF(startX, startY + stylePanelHeight));
				QColor a = new QColor(247, 249, 250);
				QColor b = new QColor(232, 236, 240);

				linearGradient.setColorAt(0.0D, new QColor(Qt.GlobalColor.white));
				linearGradient.setColorAt(0.4D, a);
				linearGradient.setColorAt(1.0D, b);

				p.setPen(new QPen(new QBrush(linearGradient), 0.0D));

				linearGradient.setSpread(QGradient.Spread.PadSpread);
				p.setBrush(linearGradient);

				p.drawRect(startX, startY, 3, stylePanelHeight);
				p.setRenderHint(QPainter.RenderHint.HighQualityAntialiasing, true);
				p.setPen(new QPen(new QBrush(borderColor), 1.0D));
				p.drawLine(this.dock.x() + this.dock.width(), startY + stylePanelHeight - 1,
						this.dock.x() + this.dock.width() + 5, startY + stylePanelHeight - 1);
			}
		}
		else {
			ba.drawImg(p);
			
		}

//		if (writingView == 1 && !getBooleanValueFromSettings(appInfo.simpleWritingView, "false")) {
//			if (appInfo.miniMode.equals("1")) {
//				p.fillRect(rect(), new QColor(Qt.GlobalColor.black));
//				String text = languageTool.getString(561);
//				QFont font = p.font();
//				font.setPointSize(font.pointSize() + getEditorTextZoomValue());
//				p.setFont(font);
//				QFontMetrics fm = p.fontMetrics();
//				QRect br = fm.boundingRect(text);
//				p.setPen(new QColor(Qt.GlobalColor.white));
//				p.drawText((width() - br.width()) / 2, (height() - br.height()) / 2, text);
//				return;
//			}
//			QColor color = palette().color(backgroundRole());
////			if(img != null && img.isVisible())
////			color.setAlpha(200);
////			else color.setAlpha(255);
//			p.fillRect(rect(), color);
//
//			int whatColor = getIntValueFromSettings(appInfo.editorColor, "0");
//			if (whatColor == 2) {
//				if (text != null && text.isVisible()) {
//					if (bg == null || bgImgChanged) {
//						bgImgChanged = false;
//						String bgimg = getStringValueFromSettings(appInfo.lightWindowBgImg, "bgF.png");
//						bg = new QImage("./RC/" + bgimg);
//					}
//					int w = 0, h = 0;
//					QDesktopWidget desk = new QDesktopWidget();
//
//					if (!getBooleanValueFromSettings(appInfo.fullScreen, "true")) {
//						QRect availableGeometry = desk.availableGeometry();
//						w = availableGeometry.width();
//						h = availableGeometry.height();
//					} else {
//						QRect geo = desk.geometry();
//						w = geo.width();
//						h = geo.height();
//					}
//
//					bg = bg.scaled(w, h);
//					QSize s = bg.size();
//					int x = (width() - s.width()) / 2;
//					int y = (height() - s.height()) / 2;
//					p.drawImage(x, y, bg);
//
//					if (getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
////							QColor bg = new QColor(106,106,106);
////							QColor fg = new QColor(Qt.GlobalColor.white);
////							QColor c = new QColor(116,112,112);
////							QRect rect = rect();
////							p.fillRect(rect, new QColor(Qt.GlobalColor.black));
////							p.fillRect(0,65,width()-50,height()-105, fg);
//
////							int focus = getIntValueFromSettings(appInfo.focusMode, "0");
////							if (inReserach || focus == 0) {
////								QColor line = new QColor(Qt.GlobalColor.black);
////								QColor title = new QColor(Qt.GlobalColor.black);
////								QColor top = new QColor(Qt.GlobalColor.blue);
////								QColor caret = new QColor(Qt.GlobalColor.black);
////								btext.titleMap(p,100,50,100,title,caret,top,line);
////							}
//
////							p.setPen(fg);
//					} else {
//						QColor bg = null;
//						// 白天添加白色层，对背景图片的亮度进行补偿。晚上相反，添加灰色层降低亮度
//						if (hourOfDay > 7 && hourOfDay < 17)
//							bg = new QColor(255, 255, 255, 100);
//						else
//							bg = new QColor(116, 112, 112, 100);
//
//						p.fillRect(0, 0, width(), height(), bg);
//
////							QColor fg = new QColor(Qt.GlobalColor.black);
////							QColor bg = new QColor(21,21,21);
////							p.fillRect(0,0,width(),20, bg);
////							p.fillRect(0,20,width()-50,height()-40, fg);
//
////							int focus = getIntValueFromSettings(appInfo.focusMode, "0");
////							if (inReserach || focus == 0) {
////								QColor textColor = text.palette().color(ColorRole.Text);
////								QColor top = new QColor(Qt.GlobalColor.blue);
////								QColor caret = new QColor(Qt.GlobalColor.yellow);
////								btext.titleMap(p,100,50,100,textColor,caret,top,textColor);	
////							}
//
//					}
//					// 绘制页面背景
//					boolean useTextbgColor = getBooleanValueFromSettings(appInfo.useBgColor, "true");
//					if (useTextbgColor) {
//						QColor pagebg = (QColor) settings.value(appInfo.colortextbg, new QColor(Qt.GlobalColor.white));
//						pagebg.setAlpha(200);
//						p.setBrush(pagebg);
//						boolean useborder = getBooleanValueFromSettings(appInfo.textbgborder, "false");
//						if (!useborder)
//							p.setPen(PenStyle.NoPen);
//						QRect mmmR = new QRect(textWidget.x() - textLayout.contentsMargins().left(),
//								textWidget.y() + textLayout.contentsMargins().top(),
//								textWidget.width() + textLayout.contentsMargins().left()
//										+ textLayout.contentsMargins().right(),
//								textWidget.height() - textLayout.contentsMargins().bottom());
////						p.fillRect(mmmR, new QColor(Qt.GlobalColor.yellow));
//						if (getBooleanValueFromSettings(appInfo.Antialiasing, "true"))
//							p.setRenderHint(RenderHint.Antialiasing);
//						p.drawRoundedRect(mmmR, 3, 3);
////						int xxx = mmmR.x()+mmmR.width();
////						int yyy = mmmR.y()+mmmR.height();
////						QPolygon ppp = new QPolygon();
////						QColor sign = new QColor(Qt.GlobalColor.black);
////						sign.setAlpha(0);
////						p.setBrush(sign);
////						int space = 20;
////						ppp.add(xxx, yyy);
////						ppp.add(xxx-space, yyy);
////						ppp.add(xxx,yyy-space);
////						p.drawPolygon(ppp);
//
//					}
//
////					QColor c = new QColor(Qt.GlobalColor.gray);
////					p.setPen(c);
////					// Courier New
////					if (text == null || !text.isTextContentVisible())
////						return;
////					QFont f = new QFont("微软雅黑", 8);
////					f.setBold(true);
////					p.setFont(f);
////					String chs = "";
////					if (text.isReadOnly())
////						chs = text.charCountOfDoc() + "";
////					else
////						chs = plusCharCount + ":" + text.charCountOfDoc();
////					
////					QRect re = p.fontMetrics().boundingRect(chs);
////					p.drawText((width() - re.width()) / 2, Math.abs((45 - re.height()) / 2), chs);
////					
////					p.setPen(new QColor(Qt.GlobalColor.white));
////					QFont ff = new QFont("微软雅黑", 9);
////					p.setFont(ff);
//					if (noPageLine)
//						return;
//					// 绘制编辑线
////					QRect cr = text.cursorRect();
////					QPoint m = text.mapTo(this, new QPoint(cr.x(),cr.y()));
////					int yy = m.y()+cr.height();
////					p.setPen(new QPen(new QColor(Qt.GlobalColor.black), 1, PenStyle.DotLine));
////					p.drawLine(0, yy, width(), yy);
////					p.drawLine(m.x(),0,m.x(),height());
//					// 绘制分页线
//					int pageHeight = getIntValueFromSettings(appInfo.pageHeght, "1619");
//					debugPrint(pageHeight);
//					pageCurrent = text.verticalScrollBar().value() / pageHeight + 1;
//					allPage = text.verticalScrollBar().maximum() / pageHeight + 1;
////					p.drawText(80, height() - 8, "第"+pageCurrent+"页，共" + allPage + "页");
//
//					int left = pageHeight - (text.verticalScrollBar().value() % pageHeight);
//					int lineLeft = textWidget.x() - textLayout.contentsMargins().left();
//					int lineRight = textWidget.width() + lineLeft + textLayout.contentsMargins().left()
//							+ textLayout.contentsMargins().right();
//					if (left >= 0 && left <= text.viewport().height()) {
//						boolean ishas = false;
//						QTextCursor tc = text.cursorForPosition(new QPoint(0, left));
//						tc.movePosition(MoveOperation.StartOfBlock);
//						QRect crr = text.cursorRect(tc);
//						QTextLayout layout = tc.block().layout();
////						System.out.println(tc.block().text() +" "+layout.lineCount());
//						for (int i = 0; i < layout.lineCount(); i++) {
//							QTextLine line = layout.lineAt(i);
//							QRectF liner = line.rect();
//							QRect re1 = new QRect((int) liner.left(), (int) (crr.top() + liner.top()),
//									(int) liner.width(), (int) liner.height());
////							System.out.println(re1 +" "+left);
//							if (re1.contains(re1.left(), left)) {
//								ishas = true;
////								p.setPen(new QPen(new QColor(Qt.GlobalColor.yellow), 1, PenStyle.DotLine));
////								p.drawLine(0, left, width(), left);
//								int a = Math.abs(re1.top() - left);
//								int b = re1.bottom() - left;
//								p.setPen(new QPen(new QColor(Qt.GlobalColor.black), 1, PenStyle.DotLine));
//								if (a < b) {
//									int y1 = re1.top() - 5;
//									QPoint map = text.mapTo(this, new QPoint(0, y1));
//
//									if (!useTextbgColor)
//										p.drawLine(0, map.y(), width(), map.y());
//									else
//										p.drawLine(lineLeft, map.y(), lineRight, map.y());
//
//									bAction.drawPageNumber(p, pageCurrent, map.y(), this);
//								} else {
//									int y1 = re1.bottom() + 5;
//									QPoint map = text.mapTo(this, new QPoint(0, y1));
//									if (!useTextbgColor)
//										p.drawLine(0, map.y(), width(), map.y());
//									else
//										p.drawLine(lineLeft, map.y(), lineRight, map.y());
//
//									bAction.drawPageNumber(p, pageCurrent, map.y(), this);
//								}
//								break;
//							} else if (left < re1.top() && left > re1.top() - 15) {
//								p.setPen(new QPen(new QColor(Qt.GlobalColor.black), 1, PenStyle.DotLine));
//								ishas = true;
////								System.out.println("a");
//								int y1 = re1.top() - 5;
//								QPoint map = text.mapTo(this, new QPoint(0, y1));
//								if (!useTextbgColor)
//									p.drawLine(0, map.y(), width(), map.y());
//								else
//									p.drawLine(lineLeft, map.y(), lineRight, map.y());
//								bAction.drawPageNumber(p, pageCurrent, map.y(), this);
//								break;
//							} else if (left > re1.bottom() && left < re1.bottom() + 15) {
//								p.setPen(new QPen(new QColor(Qt.GlobalColor.black), 1, PenStyle.DotLine));
//								ishas = true;
////								System.out.println("b");
//								int y1 = re1.bottom() + 5;
//								QPoint map = text.mapTo(this, new QPoint(0, y1));
//								if (!useTextbgColor)
//									p.drawLine(0, map.y(), width(), map.y());
//								else
//									p.drawLine(lineLeft, map.y(), lineRight, map.y());
//								bAction.drawPageNumber(p, pageCurrent, map.y(), this);
//								break;
//							}
//						}
//						if (!ishas) {
////							System.out.println("c");
//							p.setPen(new QPen(new QColor(Qt.GlobalColor.black), 1, PenStyle.DotLine));
//							QPoint map = text.mapTo(this, new QPoint(0, left));
//							if (!useTextbgColor)
//								p.drawLine(0, map.y(), width(), map.y());
//							else
//								p.drawLine(lineLeft, map.y(), lineRight, map.y());
//							bAction.drawPageNumber(p, pageCurrent, map.y(), this);
//						}
//					}
//
//				}
//			}

//			boolean nobackground = this.getBooleanValueFromSettings(appInfo.noBackgroundForWritingView, "false");
//			if (!nobackground) {
//				drop.setEnabled(false);
//				textWidget.setFrameShape(QFrame.Shape.NoFrame);
//				p.fillRect(rect(), new QColor(106,143,185,50));

//				int whatColor = getIntValueFromSettings(appInfo.editorColor, "0");
//				if(whatColor == 3) {
//					p.setPen(new QPen(new QColor(Qt.GlobalColor.white), 2));
//				}else
//					p.setPen(new QPen(new QColor(51,51,51), 2));
//				
//				if(!noEditorEffect) {
//					float maximum = text.verticalScrollBar().maximum();
//					float value = text.verticalScrollBar().value();
//					float v = (value/maximum)*(textWidget.width()-2);
//					QPalette palette = textWidget.palette();
//					int y = textWidget.y()+textWidget.height()+1;
//					
//					p.drawLine(textWidget.x()+1, y, 
//							textWidget.x()+(int)v, y);
//					if(palette.color(ColorRole.Window).alpha() < 100) {
//						p.setRenderHint(RenderHint.Antialiasing);
//						QBrush bru = new QBrush(new QColor(Qt.GlobalColor.white));
//						bru.setStyle(BrushStyle.SolidPattern);
//						p.setBrush(bru);
//						int r = 10;
//						int yy = y-r/2-1;//最后的1为线宽
//						int xx = textWidget.x()-r/2+1;
//						p.drawEllipse(xx, yy, r, r);
//						p.drawEllipse(textWidget.x()+textWidget.width()-r/2, yy, r, r);
//					}
//				}

//			}
//			else {
//				if(!noEditorEffect) {
//					p.setPen(borderColor);
//					p.drawRoundRect(textWidget.x()-1, textWidget.y()-1, textWidget.width()+1, textWidget.height()+1,0,0);
//				}
//
//			}

//		}

//		else drop.setEnabled(false);
	}

	void setMarkAndStyle() {
		if(btext == null) return;
		btext.extraSelection = new ArrayList<ExtraSelection>();
		QTextCursor tc = text.textCursor();
		
		if (showFind && !tc.selectedText().isEmpty()) {
			showAllSelectionInCurrentScreen(text, tc.selectedText());
			return;
		}
//		//focus
//		int focus = getIntValueFromSettings(appInfo.focusMode, "0");
//		if(!inReserach) {
//			if (focus > 0) {
//				int whatColor = getIntValueFromSettings(appInfo.editorColor, "0");
//				QColor bc = null;
//				if(black.writingView == 0
//						|| getBooleanValueFromSettings(appInfo.showPic, "false")) bc = new QColor(Qt.GlobalColor.cyan);
//				else bc = new QColor(21,21,21);
//				QColor fc = text.palette().color(ColorRole.Text);
//
//				QTextCharFormat bcf = tc.blockCharFormat();
//				bcf.setForeground(new QBrush(bc));
//				if (focus == 2) {
//					tc.movePosition(QTextCursor.MoveOperation.StartOfLine);
//				} else {
//					tc.movePosition(QTextCursor.MoveOperation.StartOfBlock);
//				}
//				tc.movePosition(QTextCursor.MoveOperation.Start, QTextCursor.MoveMode.KeepAnchor);
//				QTextEdit_ExtraSelection extstart = new QTextEdit_ExtraSelection();
//				extstart.setCursor(tc);
//				extstart.setFormat(bcf);
//				btext.extraSelection.add(extstart);
//
//				tc.setPosition(btext.pos);
//				if (focus == 2) {
//					tc.movePosition(QTextCursor.MoveOperation.EndOfLine);
//				} else {
//					tc.movePosition(QTextCursor.MoveOperation.EndOfBlock);
//				}
//				tc.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor);
//				QTextEdit_ExtraSelection extend = new QTextEdit_ExtraSelection();
//				extend.setCursor(tc);
//				extend.setFormat(bcf);
//				btext.extraSelection.add(extend);
//
//				bcf.setForeground(new QBrush(fc));
//
//				tc.setPosition(btext.pos);
//				if (focus == 2) {
//					tc.select(QTextCursor.SelectionType.LineUnderCursor);
//				} else {
//					tc.movePosition(QTextCursor.MoveOperation.StartOfBlock);
//					tc.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor);
//				}
//				QTextEdit_ExtraSelection extBlock = new QTextEdit_ExtraSelection();
//				extBlock.setFormat(bcf);
//				extBlock.setCursor(tc);
//				btext.extraSelection.add(extBlock);
//			}
//		}
//		
		// mark
		if (infoOfCurrentEditing.showMark)
			showMark();
//		
//		//title
//		if(inReserach || focus == 0) {
//			QTextCursor tcStart = text.cursorForPosition(new QPoint(0, 0));
//			QTextCursor tcEnd = text.cursorForPosition(new QPoint(0,height()));
//			do {
//				if(tcStart.blockNumber() > tcEnd.blockNumber())break;
//				tcStart.movePosition(MoveOperation.StartOfBlock);
//				int blockPos = tcStart.position();
//				
//				if(markTextData != null && treeWidgetItemOfKeyWordsFile.equals(btext.keywordListFile)) {
//					String b_str = tcStart.block().text();
//					for(TextRegion tr:markTextData) {
//						int index = 0;
//						while((index=b_str.indexOf(tr.text,index)) != -1) {
//							QTextEdit_ExtraSelection ex = new QTextEdit_ExtraSelection();
//							QTextCursor textCursor = text.textCursor();
//							int index_= index+blockPos;
//							textCursor.setPosition(index_);
//							textCursor.setPosition(index_+tr.text.length(), MoveMode.KeepAnchor);
////							System.out.println((index+blockPos)+" "+(index+b_str.length()+blockPos)+" "+tr.text);
//
//							QTextCharFormat cf = textCursor.charFormat();
////							cf.setForeground(new QBrush(new QColor(Qt.GlobalColor.blue)));
//							cf.setFontUnderline(true);
//							cf.setUnderlineColor(new QColor(Qt.GlobalColor.blue));
//							cf.setUnderlineStyle(UnderlineStyle.WaveUnderline);
//							ex.setCursor(textCursor);
//							ex.setFormat(cf);
//							btext.extraSelection.add(ex);
//							index = index+tr.text.length();
//						};
//						
//					}
//				}
//				int titleStyle = -1;
//				QTextCursor ttc = text.textCursor();
//				if(ttc.movePosition(MoveOperation.Start)) {
//					String str = ttc.block().text();
//					if(str.equals("$smartTitle")) {
//						titleStyle = 0;
//					}else if(str.equals("$noTitle")) {
////						titleStyle = 1;
//						continue;
//					}
//				}
//				int b = text.textCursor().blockNumber();
//				if(text.isReadOnly() || b != tcStart.blockNumber() || btext.doNotSetStyle) {
//					if(cheakDocument.cheakStringOnly(tcStart.block().text(),appInfo.syls)) {
//						boolean noShow = false;
//						if(titleStyle == 0) {
//							QTextCursor textCursor = new QTextCursor(tcStart);
//							if(textCursor.movePosition(MoveOperation.PreviousBlock)) {
//								if(cheakDocument.cheakStringOnly(textCursor.block().text(),appInfo.syls)) {
//									noShow = true;
//								}else {
//									textCursor.movePosition(MoveOperation.NextBlock);
//									if(textCursor.movePosition(MoveOperation.NextBlock)) {
//										if(cheakDocument.cheakStringOnly(textCursor.block().text(),appInfo.syls)) {
//											noShow = true;
//										}
//									}
//								}
//							}else {
//								if(textCursor.movePosition(MoveOperation.NextBlock)) {
//									if(cheakDocument.cheakStringOnly(textCursor.block().text(),appInfo.syls)) {
//										noShow = true;
//									}
//								}
//							}
//							
//						}
//						
//						if(!noShow) {
//							QTextEdit_ExtraSelection ex = new QTextEdit_ExtraSelection();
//							tcStart.select(SelectionType.BlockUnderCursor);
//							QTextCharFormat cf = tcStart.charFormat();
//							cf.setFontUnderline(true);
//							
//							ex.setCursor(tcStart);
//							ex.setFormat(cf);
//							btext.extraSelection.add(ex);
//						}
//					}
//				}
//			} while (tcStart.movePosition(QTextCursor.MoveOperation.NextBlock));
//		}

		text.setExtraSelections(btext.extraSelection);
	}

	void showAllSelectionInCurrentScreen(bTextEdit text, String str) {
		ArrayList<ExtraSelection> ex_al = new ArrayList<ExtraSelection>();
		QTextCursor tcStart = text.cursorForPosition(new QPoint(0, 0));
		QTextCursor tcEnd = text.cursorForPosition(new QPoint(0, height()));
		do {
			tcStart.movePosition(MoveOperation.StartOfBlock);
			int block_pos = tcStart.position();
			int index = 0;
			String b_str = tcStart.block().text();
			while ((index = b_str.indexOf(str, index)) != -1) {
				QTextCursor textCursor = text.textCursor();
				int index_ = index + block_pos;
				textCursor.setPosition(index_);
				textCursor.setPosition(index_ + str.length(), MoveMode.KeepAnchor);
				ExtraSelection ex = new ExtraSelection();
				QTextCharFormat cf = textCursor.charFormat();
				cf.setForeground(new QBrush(new QColor(Qt.GlobalColor.black)));
				cf.setBackground(new QBrush(new QColor(Qt.GlobalColor.yellow)));
				cf.setFontUnderline(true);
				cf.setUnderlineColor(new QColor(Qt.GlobalColor.green));
				ex.setCursor(textCursor);
				ex.setFormat(cf);
				ex_al.add(ex);
				index = index + str.length();
			}
			QRect c = text.cursorRect(tcStart);
			if (tcStart.blockNumber() > tcEnd.blockNumber())
				break;
		} while (tcStart.movePosition(QTextCursor.MoveOperation.NextBlock));

		text.setExtraSelections(ex_al);
		showFind = true;
	}

	void popPicWidget() {
		if (img != null && img.isVisible()) {
			if (!img.isActiveWindow()) {
				img.hide();
				img.show();
				img.setFocus();
			}
		}
	}

	public void importOldBlackProject() {
		String openFileName = QFileDialog.getOpenFileName(this, "", "", languageTool.getString(569,appInfo.appName)).result;
		File profile = new File(openFileName);
		if (profile.exists()) {
			cfg_read_write.cfg_read(profile);
			File indexfile = new File(
					profile.getParent() + File.separator + "Settings" + File.separator + "fileindex.blaobj");
			if (indexfile.exists()) {
				ArrayList<String> index = (ArrayList) io.readObjFile(indexfile);
				File info = new File(profile.getParent() + File.separator + "Settings" + File.separator + "fileinfo");
				if (info.exists()) {
					Properties fileinfo = cfg_read_write.cfg_read(info);
					int fileindex = Integer.valueOf(this.projectInfo.getProperty(appInfo.fileIndex)).intValue();
					this.tree.setUpdatesEnabled(false);
					for (String s : index) {
						File file = new File(profile.getParent() + File.separator + "Files" + File.separator + s);
						if (file.exists()) {
							String fileshowname = fileinfo.getProperty(file.getName(), file.getName());
							int filecharcount = Integer
									.valueOf(fileinfo.getProperty(file.getName() + "ChineseCharCount", "0")).intValue();
							String text = io.readBlackFileByLine(file);
							String intofilename = fileindex + ".black";
							io.writeBlackFile(new File(this.projectFile.getParent() + File.separator + "Files"
									+ File.separator + intofilename), text, null);
							QTreeWidgetItem treeItem = getTreeItem(this.tree);
							treeItem.setText(0, fileshowname);
							fileInfo oldinfo = new fileInfo(fileshowname, intofilename);
							if (fileshowname.equals(languageTool.getString(571))) {
								oldinfo.isKeyWordsList = true;
								treeItem.setIcon(0, this.ico_keywordsList);
							} else {
								oldinfo.isFile = true;
								if (filecharcount == 0) {
									treeItem.setIcon(0, this.ico_file);
								} else {
									treeItem.setIcon(0, this.ico_fileOfHasText);
								}
							}
							oldinfo.charCount = filecharcount;
							treeItem.setData(1, 0, oldinfo);
							setEditable(treeItem, false);
							this.filesList.add(oldinfo);
						}
						fileindex++;
					}
					this.tree.setUpdatesEnabled(true);
					this.projectInfo.setProperty("fileindex", String.valueOf(fileindex));
					saveProjectFile();
					saveFileListFile();

					getMessageBox(languageTool.getString(572), languageTool.getString(573));
				}
			}
		}
	}

	public void checkUpdate() {
		Thread t = new Thread(new Runnable() {
			public void run() {
				debugPrint(languageTool.getString(574,(ba.tempData.get(languageTool.getString(575)) != null)));
				if (ba.tempData.get("checkUpdate") == null) {
					yang.app.qt.black.checkUpdate checkUpdate = new checkUpdate(black.this) {

						@Override
						public void whenKnowUpdateSize() {
							// TODO Auto-generated method stub

						}

						@Override
						public void whenDownloadDone() {
							// TODO Auto-generated method stub

						}
					};
				} else
					return;
				
//				appInfo.updateFrom = "163";
//				p("检查更新(" + appInfo.updateFrom + ")...");
//				ba.getMessageFromMailBox(appInfo.host0, appInfo.username0, appInfo.password0, appInfo.port0);
//				if (hasUpdate == 0) {
//					p("没有在(" + appInfo.updateFrom + ")检查到更新，开始在(yandex)中检查...");
//					ba.getMessageFromMailBox(appInfo.host1, appInfo.username1, appInfo.password1, appInfo.port1);
//					appInfo.updateFrom = "yandex";
//				}
//				uiRun(black.this, new Runnable() {
//					public void run() {
//						if (hasUpdate == 0) {
//							p("检查更新完成(附加地址)，没有发现新版本");
//						} else if (hasUpdate == 1) {
//							p(" 检查更新完成(附加地址)，发现了新版本(" + appInfo.updateFrom + ")");
//							appInfo.updateFrom = "";
//							getBMessageBox("更新信息", updateinfo);
//						}
//					}
//				});
			}

		});
		t.start();
	}

	public int isWritingView() {
		Integer value = Integer.valueOf((String) this.settings.value(appInfo.isWritingView, "0"));
		return value.intValue();
	}

	public void saveWritingViewState() {
		this.settings.setValue(appInfo.isWritingView, String.valueOf(writingView));
	}

	public int onlyPart() {
		Integer value = Integer.valueOf((String) this.settings.value(appInfo.onlyAPart, "1"));
		return value.intValue();
	}

	public void setOnlyAPart(boolean ischeck) {
		int i = 0;
		if (ischeck) {
			i = 1;
		}
		this.settings.setValue(appInfo.onlyAPart, String.valueOf(i));
	}

	public void setTopKeywordsCount(int value) {
		this.settings.setValue(appInfo.topKeywordsCount, String.valueOf(value));
	}

	public int getTopKeywordsCount() {
		Integer value = Integer.valueOf((String) this.settings.value(appInfo.topKeywordsCount, "-1"));
		return value.intValue();
	}

	public int getEditorFontSize() {
		Integer value = Integer.valueOf((String) this.settings.value(appInfo.fontSize, "10"));
		return value.intValue();
	}

	public String getEditorFontName() {
		String fontname = (String) this.settings.value(appInfo.font, "宋体");
		return fontname;
	}

	public int getEditorParagraphSpaceValue() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.paragraphSpace, "0")).intValue();
		return value;
	}

	public int getEditorFirstLineValue() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.firstLine, "0")).intValue();
		return value;
	}

	public int getEditorLineSpaceValue() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.lineHeight, "0")).intValue();
		return value;
	}

	public int getEditorTextZoomValue() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.zoomValue, "0")).intValue();
		return value;
	}

	public int getEditorCaretWidthValue() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.caretWidth, "1")).intValue();
		return value;
	}

	public void setEditorFontSize(int value) {
		QFont font = text.font();
//		font.setPointSize(value + this.btext.zoomvalue);
//		text.setFont(font);
		setStyleForCurrentDocument();
		needResetStyleOfDoc = true;
		this.settings.setValue(appInfo.fontSize, String.valueOf(value));
	}

	public void setCaretWidth(int value) {
		this.settings.setValue(appInfo.caretWidth, String.valueOf(value));
		if (text.brunnable_caret == null)
			text.setCursorWidth(value);
		else
			text.caret.setFixedWidth(value);
	}

	public void setEditorFirstLine(int value) {

//		if(value == 0) return;
		boolean issaved = this.saved;
		this.settings.setValue(appInfo.firstLine, String.valueOf(value));
		setStyleForCurrentDocument();
		needResetStyleOfDoc = true;

		setSaved(issaved);
	}

	public void setEditorParagraphSpace(int value) {

		boolean issaved = this.saved;
		this.settings.setValue(appInfo.paragraphSpace, String.valueOf(value));
		setStyleForCurrentDocument();
		needResetStyleOfDoc = true;

		setSaved(issaved);
	}

	public void setEditorLineSpace(int value) {

		boolean issaved = this.saved;
		this.settings.setValue(appInfo.lineHeight, String.valueOf(value));
		setStyleForCurrentDocument();
		needResetStyleOfDoc = true;

		setSaved(issaved);
	}

	public void setEditorZoomValue(int zoomvalue) {
		boolean iszoom = bAction.showZoomTip(this,zoomvalue);
		if ((iszoom) && (zoomvalue != getEditorTextZoomValue())) {
			this.settings.setValue(appInfo.zoomValue, String.valueOf(zoomvalue));
			this.zoomBox.setCurrentIndex(zoomvalue);
			ba.zoom(zoomvalue);
		}
	}

	public void setEditorFont(QFont font) {

		font.setPointSizeF(text.font().pointSizeF());
//		font.setLetterSpacing(SpacingType.AbsoluteSpacing, 100);
//		font.setWordSpacing(-10);
//		font.setHintingPreference(HintingPreference.PreferNoHinting);
		if (!infoOfCurrentEditing.isKeyWordsList) {
			if (getBooleanValueFromSettings(appInfo.charSpace, "false"))
				font.setLetterSpacing(SpacingType.PercentageSpacing, getIntValueFromSettings(appInfo.charSpaceValue, "130"));
		}

		this.settings.setValue(appInfo.font, font.family());
		setStyleForCurrentDocument();
		needResetStyleOfDoc = true;

	}

	public settings showSettingsDialog() {
		settingsDialog = new settings(this);
		settingsDialog.setModal(false);
		settingsDialog.show();
		return settingsDialog;
	}

	public void find() {
		if (this.finddialog == null) {
			this.finddialog = new finddialog(this);
			this.finddialog.onlyShowHistoryOfBlackCommands = false;
			this.finddialog.show();
		}
	}

	public int getTextSelectionCount(bTextEdit text) {
		QTextCursor tc = text.textCursor();
		return tc.selectedText().length();
	}

	public QSize getTextSelectionRange(bTextEdit text) {
		QTextCursor tc = text.textCursor();
		return new QSize(tc.selectionStart(), tc.selectionEnd());
	}

	public void getItalinaName_male() {
		getItalinaName('m');
	}

	public void getItalinaName_female() {
		getItalinaName('f');
	}

	public void getEnglishName_male() {
		getEnglishName('m');
	}

	public void getEnglishName_female() {
		getEnglishName('f');
	}

	public void getItalinaName(char gender) {
		if (this.namecreator == null) {
			this.namecreator = new nameCreator(this, new File("./nameCreator"));
		}
		if (this.namecreator.isHasItalinaNameData()) {
			String[] s = this.namecreator.getItalinaName(gender);
			bInsertText(text, s[1] + "·" + s[0], -1, true);
		} else {
			getMessageBox(languageTool.getString(585), languageTool.getString(586));
		}
	}

	public void getEnglishName(char gender) {
		if (this.namecreator == null) {
			this.namecreator = new nameCreator(this, new File("./nameCreator"));
		}
		if (this.namecreator.isHasEnglishNameData()) {
			String[] s = this.namecreator.getEnglishName(gender);
			bInsertText(text, s[1] + "·" + s[0], -1, true);
		} else {
			getMessageBox(languageTool.getString(585), languageTool.getString(588));
		}
	}

	public void getChineseName() {
		if (this.namecreator == null) {
			this.namecreator = new nameCreator(this, new File("./nameCreator"));
		}
		if (this.namecreator.isHasChineseNameData()) {
			String[] names = this.namecreator.getChineseNames(1);

			bInsertText(text, names[0], -1, true);

		} else {
			getMessageBox(languageTool.getString(585), languageTool.getString(590));
		}
	}

	public void getChineseNames() {
		getChineseNames(20);
	}

	public void getChineseNames(int count) {
		if (this.namecreator == null) {
			this.namecreator = new nameCreator(this, new File("./nameCreator"));
		}
		if (this.namecreator.isHasChineseNameData()) {
			if ((keywords != null) && (keywords.isVisible())) {
				return;
			}
			initKeyWordsDialog();
			keywords.tree.clear();
			String[] names = this.namecreator.getChineseNames(count);
			String[] arrayOfString1;
			int j = (arrayOfString1 = names).length;
			for (int i = 0; i < j; i++) {
				String s = arrayOfString1[i];
				QTreeWidgetItem ti = getTreeItem(keywords.tree);
				ti.setText(0, s);
				TextRegion tr = new TextRegion(s, 0, 0);
				ti.setData(1, 0, tr);
				ti.setIcon(0, this.ico_names);
			}
			findview = 3;
			keywords.message.setText(languageTool.getString(591));
			showDialogAtEditorCaretPos(text, keywords);
		} else {
			getMessageBox(languageTool.getString(585), languageTool.getString(590));
		}
	}

	void readMarkFile() {
		QTreeWidgetItem findKeyWordsList = findKeyWordsList(this.TreeWidgetItemOfCurrentEditing);
		if (findKeyWordsList != null) {
			fileInfo in = getFileInfoByQTreeItem(findKeyWordsList);
			File markfile = getFile(in.fileName);
			if ((markfile != null) && (markfile.exists())) {
				debugPrint(languageTool.getString(594,markfile.getPath()));
				this.marktext = readBlackFile(markfile);
				if(marktext != null)
					marktext = marktext.replaceAll("\n\n", "\n");
				else getMessageBox(languageTool.getString(595), languageTool.getString(596,in.getShowName()));
				
				this.treeWidgetItemOfKeyWordsFile = findKeyWordsList;
				String statfileName = "markstat_" + markfile.getName().replace(".black", "");
				File statfile = new File(
						this.projectFile.getParent() + File.separator + "Settings" + File.separator + statfileName);
				if (statfile.exists()) {
					ArrayList<markstat> statdata = (ArrayList) io.readObjFile(statfile);
					if (statdata != null) {
						this.markstat = statdata;
					} else {
						getMessageBox(languageTool.getString(598), languageTool.getString(599));
					}
				}
			} else {
				getMessageBox(languageTool.getString(600), languageTool.getString(601));
			}
		} else {
			p(languageTool.getString(602));
//			getMessageBox(languageTool.getString(603), languageTool.getString(604));
		}
	}

	void writeToMarkStatFile() {
		fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(this.treeWidgetItemOfKeyWordsFile);
		File markfile = getFile(fileInfoByQTreeItem.fileName);
		if ((markfile != null) && (markfile.exists())) {
			String statfileName = "markstat_" + markfile.getName().replace(".black", "");
			File statfile = new File(
					this.projectFile.getParent() + File.separator + "Settings" + File.separator + statfileName);
			if (!statfile.exists()) {
				if (!statfile.getParentFile().exists()) {
					statfile.getParentFile().mkdir();
				}
				try {
					statfile.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
					getMessageBox(languageTool.getString(605), languageTool.getString(606));
				}
			}
			if ((this.markstat.size() > 0) && (this.markstatIsChanged)) {
				io.writeObjFile(statfile, this.markstat);
				this.markstatIsChanged = false;
			}
		}
	}

	void writeToMarkFile() {
		fileInfo in = getFileInfoByQTreeItem(this.treeWidgetItemOfKeyWordsFile);
		File markfile = getFile(in.fileName);
		if ((markfile != null) && (markfile.exists()) && (this.marktextIsChanged)) {
			saveBlackFile(markfile, this.marktext);
			this.marktextIsChanged = false;
		}
	}

	/**
	 * 添加关键词到关键词列表 此方法先检查关键词列表中是否存在要添加的关键词，如果存在则什么也不做，如果不存在则添加 此方法不会删除已存在关键词
	 * 即便添加成功，此方法也不会给出提示
	 * 
	 * @param str
	 */
	void addTextToMarkFile_(String str) {
		if (this.marktext == null) {
			readMarkFile();
			if (this.marktext == null) {
				return;
			}
		}
		if (this.markTextData == null) {
			getMarkFileText();
		}
		String newstr = str.replaceAll("\n", "");
		for (TextRegion tr : this.markTextData) {
			if (cheakDocument.subString(tr.text, appInfo.keywordsSeparator)[0].equals(newstr)) {
				return;
			}
		}

		if (!this.marktext.equals("")) {
			changeMarktext(this.marktext + "\n" + newstr);
		} else {
			changeMarktext(newstr);
		}
		getMarkFileText();

	}

	/**
	 * 添加关键词到关键词列表 如果关键词列表里已经存在要添加的关键词，则会将其从关键词列表中删除，如果没有则添加
	 * 
	 * @param str
	 */
	void addTextToMarkFile(String str) {
		if (this.marktext == null) {
			readMarkFile();
			if (this.marktext == null) {
				return;
			}
		}
		if (this.markTextData == null) {
			getMarkFileText();
		}
		String newstr = str.replaceAll("\n", "");
		String newtext = null;
		boolean ishas = false;
		for (TextRegion tr : this.markTextData) {
			if (cheakDocument.subString(tr.text, appInfo.keywordsSeparator)[0].equals(newstr)) {
				newtext = this.marktext.replaceAll(tr.text, "");
				ishas = true;
				break;
			}
		}
		if (ishas) {
			changeMarktext(newtext);
			getMessageBox(languageTool.getString(607), languageTool.getString(608));
		} else {
			if (!this.marktext.equals("")) {
				changeMarktext(this.marktext + "\n" + newstr);
			} else {
				changeMarktext(newstr);
			}
			getMessageBox(languageTool.getString(609), languageTool.getString(610));
		}
		getMarkFileText();
	}

	void changeMarktext(String newtext) {
		this.marktext = newtext.replaceAll("\n\n", "\n");

		dataForOpenedFile findInOpenedFiles = findInOpenedFiles(
				getFileInfoByQTreeItem(this.treeWidgetItemOfKeyWordsFile).fileName);
		if (findInOpenedFiles != null) {
			if (findInOpenedFiles.editor != null) {
				findInOpenedFiles.editor = null;
			}
			findInOpenedFiles.content = this.marktext;
		}
		this.marktextIsChanged = true;
	}

	QMessageBox getMessageBox(String title, String message, boolean onTop) {
		speakText(message, -1);
		QMessageBox qMessageBox = getMessageBoxNotShow(title, message);
		if (onTop) {
			Qt.WindowFlags windowf = qMessageBox.windowFlags();
			windowf.set(new Qt.WindowType[] { Qt.WindowType.WindowStaysOnTopHint });
			qMessageBox.setWindowFlags(windowf);
		}
		if(ba != null)
		ba.applyUIFont(qMessageBox);
		qMessageBox.setIcon(QMessageBox.Icon.NoIcon);
		qMessageBox.show();
		return qMessageBox;
	}

	public static QMessageBox getMessageBox(QWidget parent, String title, String message) {

		QMessageBox qMessageBox = new QMessageBox(parent);

		qMessageBox.setIcon(QMessageBox.Icon.NoIcon);
		qMessageBox.setWindowTitle(title);
		qMessageBox.setText(message);
		qMessageBox.show();
		return qMessageBox;
	}

	QMessageBox getMessageBox(String title, String message, boolean onTop, QIcon icon) {
		speakText(message, -1);

		QMessageBox qMessageBox = getMessageBoxNotShow(title, message);

		if (onTop) {
			Qt.WindowFlags windowf = qMessageBox.windowFlags();
			windowf.set(new Qt.WindowType[] { Qt.WindowType.WindowStaysOnTopHint });
			qMessageBox.setWindowFlags(windowf);
		}
		qMessageBox.setIconPixmap(icon.pixmap(100));
		if(ba != null)
		ba.applyUIFont(qMessageBox);

		if (!this.execCommandAndQuiet) {
			qMessageBox.show();
		}
		return qMessageBox;
	}

	QMessageBox getMessageBox(String title, String message, boolean onTop, QIcon icon, boolean hideOnActive) {
		speakText(message, -1);

		final QMessageBox qMessageBox = getMessageBoxNotShow(title, message);
		if (hideOnActive) {
			qMessageBox.installEventFilter(new QObject() {
				public boolean eventFilter(QObject arg__1, QEvent arg__2) {
					if ((arg__1.equals(qMessageBox)) && (arg__2.type() == QEvent.Type.MouseButtonPress)) {
						qMessageBox.close();
					}
					return super.eventFilter(arg__1, arg__2);
				}
			});
		}
		if (onTop) {
			Qt.WindowFlags windowf = qMessageBox.windowFlags();
			windowf.set(new Qt.WindowType[] { Qt.WindowType.WindowStaysOnTopHint });
			qMessageBox.setWindowFlags(windowf);
		}
		qMessageBox.setIconPixmap(icon.pixmap(100));
		if(ba != null)
		ba.applyUIFont(qMessageBox);


		qMessageBox.show();
		return qMessageBox;
	}

	QMessageBox getMessageBox(String title, String message) {
		speakText(message, -1);

		QMessageBox qMessageBox = null;
		if ((this.finddialog != null) && (this.finddialog.isVisible())) {
			qMessageBox = new QMessageBox(this.finddialog);
		} else {
			qMessageBox = new QMessageBox(this);
		}

		qMessageBox.setIcon(QMessageBox.Icon.NoIcon);
		qMessageBox.setWindowTitle(title);
		qMessageBox.setText(message);
		if(ba != null)
		ba.applyUIFont(qMessageBox);

//		blackParentWindowForQwidget(qMessageBox);
		qMessageBox.show();
		return qMessageBox;
	}

	QMessageBox getMessageBoxNotShow(String title, String message) {
		speakText(message, -1);

		QMessageBox qMessageBox = null;
		if ((this.finddialog != null) && (this.finddialog.isVisible())) {
			qMessageBox = new QMessageBox(this.finddialog);
		} else {
			qMessageBox = new QMessageBox(this);
		}

		qMessageBox.setIcon(QMessageBox.Icon.NoIcon);
		qMessageBox.setWindowTitle(title);
		qMessageBox.setText(message);
		if(ba != null)
		ba.applyUIFont(qMessageBox);

		return qMessageBox;
	}
	/**
	 * 	拒绝返回0
	 * @param title
	 * @param message
	 * @param buttonYesText
	 * @param buttonNoText
	 * @param ico
	 * @param defaultButton
	 * @return
	 */
	int getMessageBoxWithYesNO(String title, String message, String buttonYesText, String buttonNoText,
			QMessageBox.Icon ico, int defaultButton) {
		speakText(message, -1);

		QMessageBox box = getMessageBoxNotShow(title, message);
		QPushButton reject = box.addButton(buttonNoText, QMessageBox.ButtonRole.RejectRole);
		QPushButton accept = box.addButton(buttonYesText, QMessageBox.ButtonRole.AcceptRole);
		if (defaultButton == 0) {
			box.setDefaultButton(reject);
		} else if (defaultButton == 1) {
			box.setDefaultButton(accept);
		}
		if (ico != null) {
			box.setIcon(ico);
		}
		if(ba != null)
		ba.applyUIFont(box);
		return box.exec();
	}

	int getMessageBoxWithYesNO(String title, String message, String buttonYesText, String buttonNoText, QIcon ico,
			int defaultButton) {
		speakText(message, -1);

		QMessageBox box = getMessageBoxNotShow(title, message);
		QPushButton reject = box.addButton(buttonNoText, QMessageBox.ButtonRole.RejectRole);
		QPushButton accept = box.addButton(buttonYesText, QMessageBox.ButtonRole.AcceptRole);
		if (defaultButton == 0) {
			box.setDefaultButton(reject);
		} else if (defaultButton == 1) {
			box.setDefaultButton(accept);
		}
		if (ico != null) {
			box.setIconPixmap(ico.pixmap(100));
		}
		if(ba != null)
		ba.applyUIFont(box);

		return box.exec();
	}

	int getMessageBoxWithYesNO(String title, String message, String buttonYesText, String buttonNoText, QIcon ico,
			int defaultButton, boolean onTop) {
		speakText(message, -1);

		QMessageBox box = getMessageBoxNotShow(title, message);
		QPushButton reject = box.addButton(buttonNoText, QMessageBox.ButtonRole.RejectRole);
		QPushButton accept = box.addButton(buttonYesText, QMessageBox.ButtonRole.AcceptRole);
		if (onTop) {
			Qt.WindowFlags windowf = box.windowFlags();
			windowf.set(new Qt.WindowType[] { Qt.WindowType.WindowStaysOnTopHint });
			box.setWindowFlags(windowf);
		}
		if (defaultButton == 0) {
			box.setDefaultButton(reject);
		} else if (defaultButton == 1) {
			box.setDefaultButton(accept);
		}
		if (ico != null) {
			box.setIconPixmap(ico.pixmap(100));
		}
		if(ba != null)
		ba.applyUIFont(box);
		
		int exec = box.exec();
//		box.close();
		return exec;
	}

	void ishasInMarkdata() {
		if (this.markstat == null) {
			return;
		}
		Iterator<markstat> it_stat = this.markstat.iterator();
		while (it_stat.hasNext()) {
			String str = ((markstat) it_stat.next()).getText();
			boolean ishas = false;
			Iterator<TextRegion> it_mark = this.markTextData.iterator();
			while (it_mark.hasNext()) {
				String text = ((TextRegion) it_mark.next()).text;
				if (text.equals(str)) {
					ishas = true;
					break;
				}
			}
			if (!ishas) {
				it_stat.remove();
			}
		}
	}

	void deleteFromMarkStatData(String text) {
		for (int i = 0; i < this.markstat.size(); i++) {
			markstat markst = (markstat) this.markstat.get(i);
			if (markst.getText().equals(text)) {
				this.markstat.remove(i);
				break;
			}
		}
		this.markstatIsChanged = true;
	}

	hasinfo markstatIshas(String text) {
		boolean ishas = false;
		int index = 0;
		for (int i = 0; i < this.markstat.size(); i++) {
			if (text.equals(((markstat) this.markstat.get(i)).getText())) {
				ishas = true;
				index = i;
				break;
			}
		}
		return new hasinfo(ishas, index);
	}

	void setTopOnMarkstat(String text) {
		for (int i = 0; i < this.markstat.size(); i++) {
			if (((markstat) this.markstat.get(i)).getText().equals(text)) {
				int stat = ((markstat) this.markstat.get(i)).count;
				this.markstat.remove(i);
				this.markstat.add(new markstat(text, stat));
				return;
			}
		}
	}

	ArrayList<TextRegion> resetIndex(ArrayList<TextRegion> list) {
		ArrayList<TextRegion> al = new ArrayList();
		while (list.size() > 0) {
			int maxindex = 0;
			int max = 0;
			for (int i = 0; i < list.size(); i++) {
				if (((TextRegion) list.get(i)).end > max) {
					max = ((TextRegion) list.get(i)).end;
					maxindex = i;
				}
			}
			al.add((TextRegion) list.get(maxindex));
			list.remove(maxindex);
		}
		return al;
	}

	void setindexOfMarkstat() {
		this.markstatIsChanged = true;
		ArrayList<markstat> al = new ArrayList();
		while (this.markstat.size() > 0) {
			int maxindex = 0;
			int max = 0;
			for (int i = 0; i < this.markstat.size(); i++) {
				if (((markstat) this.markstat.get(i)).count > max) {
					max = ((markstat) this.markstat.get(i)).count;
					maxindex = i;
				}
			}
			al.add((markstat) this.markstat.get(maxindex));
			this.markstat.remove(maxindex);
		}
		this.markstat = al;
	}

	public static String[] checkName(String name) {
		String[] names = new String[2];
		int index;
		if ((index = name.indexOf("·")) == -1) {
			if (name.length() == 2) {
				names[0] = String.valueOf(name.charAt(0));
				names[1] = String.valueOf(name.charAt(1));
			} else if (name.length() == 3) {
				names[0] = String.valueOf(name.charAt(0));
				names[1] = name.substring(1, 3);
			}
		} else {
			names[0] = name.substring(0, index);
			names[1] = name.substring(name.lastIndexOf("·") + 1, name.length());
		}
		return names;
	}

	public static int lastIndexOf(String name, String in) {
		int max = -1;
		if (name.indexOf('·') != -1) {
			String firstname = name.substring(name.lastIndexOf('·') + 1, name.length());
			String lastname = name.substring(0, name.indexOf('·'));
			int all = in.lastIndexOf(name);
			int first = in.lastIndexOf(firstname);
			int last = in.lastIndexOf(lastname);
			if ((last == all) && (first == all + lastname.length() + 1)) {
				max = all;
			} else {
				int[] index = { all, first, last };
				for (int i = 0; i < index.length; i++) {
					if (index[i] > max) {
						max = index[i];
					}
				}
			}
		}
		return max;
	}

	/**
	 * 不要被方法名骗了，这个方法并不是通过统计数据给关键词排序 而是通过分析关键词在当前文档中的位置给关键词排序
	 * 
	 * @return
	 */
	List<TextRegion> setindexOfMarkstatBy() {
		QTextCursor tc = text.textCursor();
		if (tc.position() > 0) {
			tc.movePosition(QTextCursor.MoveOperation.Start, QTextCursor.MoveMode.KeepAnchor);
			String s = tc.selectedText();
			String text = null;
			if (onlyPart() == 0) {
				text = s;
			} else if (s.length() > 10000) {
				text = s.substring(s.length() - 10000, s.length());
			} else {
				text = s;
			}
			List<TextRegion> al = this.markTextData;
			List<TextRegion> al_new = new ArrayList();
			while (al.size() > 0) {
				int max = 0;
				int maxindex = 0;
				for (int i = 0; i < al.size(); i++) {
					String str = cheakDocument.subString(((TextRegion) al.get(i)).text, appInfo.keywordsSeparator)[0];
					int index = 0;
					if (str.indexOf('·') != -1) {
						index = lastIndexOf(str, text);
					} else {
						index = text.lastIndexOf(str);
					}
					if (index > max) {
						max = index;
						maxindex = i;
					}
				}
				TextRegion tr = al.get(maxindex);
				tr.showname = tr.text;
				tr.filename = null;
				String[] subString = cheakDocument.subString(tr.text, appInfo.keywordsSeparator);
				if (subString.length == 2 && !subString[1].isEmpty()) {
					tr.showname = subString[0];
					tr.filename = subString[1];
				}
				al_new.add(tr);
				al.remove(maxindex);
			}
			this.markTextData = al_new;
			return al_new;
		}
		return null;
	}

	public void checkIsHasDiffKeyWordsList() {
		if (this.treeWidgetItemOfKeyWordsFile == null) {
			return;
		}
		if (findKeyWordsList(this.TreeWidgetItemOfCurrentEditing) == null) {
			return;
		}
		if (!findKeyWordsList(this.TreeWidgetItemOfCurrentEditing).equals(this.treeWidgetItemOfKeyWordsFile)) {
			QMessageBox me = new QMessageBox(this);
			me.setWindowTitle(languageTool.getString(611));
			me.setIcon(QMessageBox.Icon.Question);
			me.setText(languageTool.getString(612));
			QPushButton apply = me.addButton(QMessageBox.StandardButton.Ok);
			apply.setText(languageTool.getString(613));
			QPushButton cancel = me.addButton(QMessageBox.StandardButton.Cancel);
			cancel.setText(languageTool.getString(614));

			apply.pressed.connect(this, "reLoadKeywordsList()");
			me.show();
		}
	}

	public void reLoadKeywordsList() {
		if (this.marktextIsChanged) {
			writeToMarkFile();
		}
		if (this.markstatIsChanged) {
			writeToMarkStatFile();
		}
		readMarkFile();
		getMarkFileText();
	}

	boolean findString(String text, String str) {
		if (cheakDocument.findString(text, str)) {
			return true;
		}
		if (str.indexOf("·") != -1) {
			String firstname = str.substring(str.lastIndexOf('·') + 1, str.length());
			String lastname = str.substring(0, str.indexOf('·'));
			if (text.indexOf(firstname) != -1) {
				return true;
			}
			if (text.indexOf(lastname) != -1) {
				return true;
			}
		}
		return false;
	}

	static String getCharByNumber(int number) {
		if ((number < 0) || (number >= 26)) {
			return "";
		}
		char[] c = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
				'u', 'v', 'w', 'x', 'y', 'z' };
		char ch = c[number];
		String up = String.valueOf(ch).toUpperCase();
		return up + ". ";
	}

	static int getNumberByChar(String str) {
		int number = -1;
		if ((str.length() == 0) || (str.length() > 1)) {
			return number;
		}
		char ch = str.charAt(0);
		char[] c = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
				'u', 'v', 'w', 'x', 'y', 'z' };
		for (int i = 0; i < c.length; i++) {
			if (c[i] == ch) {
				number = i;
			}
		}
		return number;
	}

	void showKeyWords() {
		if ((keywords != null) && (keywords.isVisible())) {
			return;
		}
		if (this.marktext == null) {
			readMarkFile();
		}
		if (this.marktext == null) {
			return;
		}
		if (this.markTextData == null) {
			getMarkFileText();
		}
		initKeyWordsDialog();
		keywords.tree.UsedToProjectPanelOrKeywordsList = 1;
		if (keywords.tree.topLevelItemCount() > 0) {
			keywords.tree.clear();
		}
		int index = 0;
		List<TextRegion> tr_no = new ArrayList();
		List<TextRegion> tr_line = new ArrayList();
		List<TextRegion> tr_doc = new ArrayList();

		QTextCursor tc1 = text.textCursor();
		tc1.movePosition(QTextCursor.MoveOperation.StartOfBlock, QTextCursor.MoveMode.KeepAnchor);
		String line = tc1.selectedText();
		QTextCursor tc2 = text.textCursor();
		tc2.movePosition(QTextCursor.MoveOperation.Start, QTextCursor.MoveMode.KeepAnchor);
		String doc = tc2.selectedText();
		hasinfo info = null;
		List<TextRegion> al = null;
		if ((this.LineAndDocFirst_keywords) || (getTopKeywordsCount() == -1)
				|| (this.markstat.size() < getTopKeywordsCount())) {
			al = setindexOfMarkstatBy();
		}
		Iterator<TextRegion> it_tr = null;
		if (al != null) {
			it_tr = al.iterator();
		} else {
			it_tr = this.markTextData.iterator();
		}
		while (it_tr.hasNext()) {
			TextRegion tr = (TextRegion) it_tr.next();
			String[] subString = cheakDocument.subString(tr.text, appInfo.keywordsSeparator);
			tr.showname = subString[0];
			tr.filename = subString[1];
			if ((!this.LineAndDocFirst_keywords) && ((info = markstatIshas(tr.text)).ishas)) {
				((markstat) this.markstat.get(info.index)).visible = true;
			} else if ((this.LineAndDocFirst_keywords) || (getTopKeywordsCount() == -1)
					|| (this.markstat.size() < getTopKeywordsCount())) {
				if (findString(line, tr.showname)) {
					tr_line.add(tr);
					if ((this.LineAndDocFirst_keywords) && ((info = markstatIshas(tr.text)).ishas)) {
						((markstat) this.markstat.get(info.index)).visible = false;
					}
				} else if (findString(doc, tr.showname)) {
					tr_doc.add(tr);
					if ((this.LineAndDocFirst_keywords) && ((info = markstatIshas(tr.text)).ishas)) {
						((markstat) this.markstat.get(info.index)).visible = false;
					}
				} else if ((this.LineAndDocFirst_keywords) && ((info = markstatIshas(tr.text)).ishas)) {
					((markstat) this.markstat.get(info.index)).visible = true;
				} else {
					tr_no.add(tr);
				}
			} else {
				tr_no.add(tr);
			}
		}
		if (!this.LineAndDocFirst_keywords) {
			itemOfStat(index);
			itemOfLineAndDoc(tr_line, tr_doc, index);
			itemOfNo(tr_no, index);
		} else {
			itemOfLineAndDoc(tr_line, tr_doc, index);
			itemOfStat(index);
			itemOfNo(tr_no, index);
		}
		keywords.message.setText(languageTool.getString(615,this.markTextData.size()));
		keywords.statusbar.showMessage(languageTool.getString(616));
		showDialogAtEditorCaretPos(text, keywords);
	}

	void itemOfNo(List tr_no, int index) {
		Iterator<TextRegion> it_no = tr_no.iterator();
		while (it_no.hasNext()) {
			TextRegion trno = (TextRegion) it_no.next();
			QTreeWidgetItem ti = getTreeItem(keywords.tree);
			ti.setIcon(0, this.ico_keywordNo);

			String str = null;
			if (trno.filename.equals("")) {
				str = trno.showname;
			} else {
				str = trno.showname + " (" + trno.filename + ")";
			}
			ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + str);
			ti.setData(1, 0, trno);
			ti.setData(1, 1, Integer.valueOf(index));
			index++;
		}
	}

	void itemOfLineAndDoc(List tr_line, List tr_doc, int index) {
		Iterator<TextRegion> it_line = tr_line.iterator();
		while (it_line.hasNext()) {
			TextRegion trline = (TextRegion) it_line.next();
			QTreeWidgetItem ti = getTreeItem(keywords.tree);
			ti.setIcon(0, this.ico_keywordLine);

			ti.setForeground(0, new QBrush(new QColor(Qt.GlobalColor.darkBlue)));
			String str = null;
			if (trline.filename.equals("")) {
				str = trline.showname;
			} else {
				str = trline.showname + " (" + trline.filename + ")";
			}
			ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + str);
			ti.setData(1, 0, trline);
			ti.setData(1, 1, Integer.valueOf(index));
			ti.setData(3, 3, languageTool.getString(617));
			index++;
		}
		Iterator<TextRegion> it_doc = tr_doc.iterator();
		while (it_doc.hasNext()) {
			TextRegion trdoc = (TextRegion) it_doc.next();
			QTreeWidgetItem ti = getTreeItem(keywords.tree);
			ti.setIcon(0, this.ico_keywordDoc);

			ti.setForeground(0, new QBrush(new QColor(Qt.GlobalColor.darkGreen)));
			ti.setData(1, 0, trdoc);
			ti.setData(1, 1, Integer.valueOf(index));
			ti.setData(3, 3, languageTool.getString(618));

			String str = null;
			if (trdoc.filename.equals("")) {
				str = trdoc.showname;
			} else {
				str = trdoc.showname + " (" + trdoc.filename + ")";
			}
			ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + str);

			index++;
		}
	}

	void itemOfStat(int index) {
		if (this.markstat.size() > 0) {
			markstat stat = (markstat) this.markstat.get(this.markstat.size() - 1);
			if (stat.visible) {
				TextRegion trstat = new TextRegion(stat.getText(), 0, 0);

				QTreeWidgetItem ti = getTreeItem(keywords.tree);
				ti.setIcon(0, this.ico_keywordFirstTop);
				if ((stat.count > 1) && (stat.count <= 5)) {
					ti.setBackground(0, new QBrush(new QColor(250, 254, 90)));
				} else if ((stat.count > 5) && (stat.count <= 10)) {
					ti.setBackground(0, new QBrush(new QColor(249, 254, 56)));
				} else if ((stat.count > 10) && (stat.count <= 20)) {
					ti.setBackground(0, new QBrush(new QColor(248, 254, 10)));
				} else if (stat.count > 20) {
					ti.setBackground(0, new QBrush(new QColor(191, 197, 1)));
				} else {
					ti.setBackground(0, new QBrush(new QColor(251, 254, 126)));
				}
				String[] subString = cheakDocument.subString(trstat.text, appInfo.keywordsSeparator);
				String str = null;
				if (subString[1].equals("")) {
					str = subString[0];
				} else {
					str = subString[0] + " (" + subString[1] + ")";
				}
				ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + str);
				ti.setData(1, 0, trstat);
				ti.setData(1, 1, Integer.valueOf(index));
				ti.setData(3, 3, languageTool.getString(619,((markstat) this.markstat.get(this.markstat.size() - 1)).count));
				index++;
			}
		}
		if (this.markstat.size() > 1) {
			for (int i = this.markstat.size() - 2; i >= 0; i--) {
				markstat stat = (markstat) this.markstat.get(i);
				if (stat.visible) {
					TextRegion trstat = new TextRegion(((markstat) this.markstat.get(i)).getText(), 0, 0);
					QTreeWidgetItem ti = getTreeItem(keywords.tree);
					ti.setIcon(0, this.ico_keywordTop);
					if ((stat.count > 1) && (stat.count <= 5)) {
						ti.setBackground(0, new QBrush(new QColor(250, 254, 90)));
					} else if ((stat.count > 5) && (stat.count <= 10)) {
						ti.setBackground(0, new QBrush(new QColor(249, 254, 56)));
					} else if ((stat.count > 10) && (stat.count <= 20)) {
						ti.setBackground(0, new QBrush(new QColor(248, 254, 10)));
					} else if (stat.count > 20) {
						ti.setBackground(0, new QBrush(new QColor(191, 197, 1)));
					} else {
						ti.setBackground(0, new QBrush(new QColor(251, 254, 126)));
					}
					String[] subString = cheakDocument.subString(trstat.text, appInfo.keywordsSeparator);
					String str = null;
					if (subString[1].equals("")) {
						str = subString[0];
					} else {
						str = subString[0] + " (" + subString[1] + ")";
					}
					ti.setText(0, getCharByNumber(keywords.tree.topLevelItemCount() - 1) + str);
					ti.setData(1, 0, trstat);
					ti.setData(1, 1, Integer.valueOf(index));
					ti.setData(3, 3, "(" + ((markstat) this.markstat.get(i)).count + ")");

					index++;
				}
			}
		}
	}

	public int getKeywordsDialogWidth() {
		int value = Integer
				.valueOf((String) this.settings.value(appInfo.keywordsWidth, ba.desktopGeometry(true).width() + ""))
				.intValue();
		return value;
	}

	public int getKeywordsDialogHeight() {
		int value = Integer
				.valueOf((String) this.settings.value(appInfo.keywordsHeight, ba.desktopGeometry(true).height() + ""))
				.intValue();
		return value;
	}

	public void setKeywordsDialogWidth(int value) {
		this.settings.setValue(appInfo.keywordsWidth, String.valueOf(value));
	}

	public void setKeywordsDialogHeight(int value) {
		this.settings.setValue(appInfo.keywordsHeight, String.valueOf(value));
	}

	void showDialogForFindLine() {
		if (keywordsForFindLine.tree.topLevelItemCount() == 0) {
			getMessageBox(languageTool.getString(621), languageTool.getString(622));
			return;
		}
//		this.findBox.installEventFilter(keywordsForFindLine);
		int w = ba.desktopGeometry(true).width() / 2;
		int h = ba.desktopGeometry(true).height() - 100;
		int x = 0;
		int y = 0;
//		if(findBox.isVisible()) {
//			QPoint pos = this.findBox.pos();
//			QPoint mapToGlobal = this.toolbar.mapToGlobal(pos);
//			QDesktopWidget desk = new QDesktopWidget();
//			if (mapToGlobal.x() + w > desk.width()) {
//				x = mapToGlobal.x() - (mapToGlobal.x() + w - desk.width()) - 5;
//			} else {
//				x = mapToGlobal.x();
//			}
//			keywordsForFindLine.setGeometry(x, mapToGlobal.y() + this.findBox.height() + 5, w, h);
//		}
		x = (ba.desktopGeometry(true).width() / 2) - (w / 2);
		y = 50;
		keywordsForFindLine.setGeometry(x, y, w, h);

		keywordsForFindLine.show();
	}
	/**
	 * 此方法会先show widget，然后为其设置位置
	 * @param widget
	 */
	public void showDialogAtCenter(QWidget widget) {
		widget.show();
		int x = widget.width();
		int y = widget.height();
		x = (width()-x)/2;
		y = (height()-y)/2;
		widget.setGeometry(x, y, widget.width(), widget.height());
	}
	void showDialogAtCenter(keyWords keywords) {
		if (keywords.tree.topLevelItemCount() == 0) {
			p(languageTool.getString(623));
			return;
		}
		QFont font = font();
		if(text != null) {
			text.installEventFilter(keywords);
			font = text.font();
		}else {
			keywords.activateWindow();
		}
//
//		int whatColor = getIntValueFromSettings(appInfo.editorColor, "0");
//		if (whatColor == 2 && !getBooleanValueFromSettings(appInfo.showPic, "false")) {
//			QColor bg = new QColor(116, 112, 112);
//			keywords.setStyleSheet("color:black; background:" + bg.name() + ";");
//		}

		keywords.show();

		QDesktopWidget desk = new QDesktopWidget();
		QRect g = desk.availableGeometry();
		int w = getAdjustKeywordsTreeWidth(g.width() / 2, keywords);
		int setW = 0;
		if (w > (setW = g.width() / 2)) {
			w = setW;
		}
		if (findview == 4) {
			w += font.pointSize() * 7;
		}
		int h = getAdjustKeyWordsTreeHeight(height() / 2, keywords);
		int x = x() + (width() - w) / 2;
		int y = y() + (height() - h) / 2;
		keywords.setGeometry(x, y, w, h);
	}

	void showDialogAtLeftBottom(bTextEdit text, keyWords keywordsDialog) {
		if (!b.text.inputing || keywordsDialog.tree.topLevelItemCount() == 0) {
			keywordsDialog.hide();
			return;
		}
		text.installEventFilter(keywordsDialog);
		this.btext.scroll();
		int whatColor = getIntValueFromSettings(appInfo.editorColor, "0");

		if (writingView == 0 || whatColor < 2)
			keywordsDialog.tree.setStyleSheet("background:transparent;color:white");
		else if (whatColor == 2) {
			if (!getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
				keywordsDialog.tree.setStyleSheet("background:transparent;color:yellow;");
			} else {
				keywordsDialog.tree.setStyleSheet("background:transparent;color:white;");
			}
		} else
			keywordsDialog.tree.setStyleSheet("background:transparent;color:white;");

		keywordsDialog.translucentBackgound = true;

		keywordsDialog.show();

		QRect cursorRect = text.cursorRect();
		QFont f = keywordsDialog.tree.font();
		f.setPointSize(text.font().pointSize());
		QFontMetrics fm = new QFontMetrics(f);
		int h = keywordsDialog.tree
				.visualItemRect(keywordsDialog.tree.topLevelItem(keywordsDialog.tree.topLevelItemCount() - 1)).height()
				* keywordsDialog.tree.topLevelItemCount();

		QPoint map = text.mapToGlobal(new QPoint(cursorRect.x(), cursorRect.y()));
//		int x = map.x();
//		int y = map.y() - h - 10;

		QDesktopWidget desk = new QDesktopWidget();
		int x = 0;
		int y = 0;
		if (writingView == 0)
			y = desk.availableGeometry().y() + desk.availableGeometry().height() - h;
		else
			y = desk.geometry().height() - h;
		int w = getAdjustKeywordsTreeWidth(desk.width(), keywords);
		int width = desk.rect().width();
		int height = desk.rect().height();
//		if (x + w > width) {
//			x -= w;
//		}
		keywordsDialog.setGeometry(x, y, w, h);
		desk.dispose();
		keywordsShowAtLeftBottom = true;
		if(!b.text.inputing)keywordsDialog.hide();
	}

	void showDialogAtEditorCaretPosTop(bTextEdit text, keyWords keywordsDialog) {
		if (keywordsDialog.tree.topLevelItemCount() == 0) {
			return;
		}
		text.installEventFilter(keywordsDialog);
		this.btext.scroll();
		keywordsDialog.show();

		QRect cursorRect = text.cursorRect();
		QFont f = keywordsDialog.tree.font();
		f.setPointSize(text.font().pointSize());
		QFontMetrics fm = new QFontMetrics(f);
		int h = keywordsDialog.tree
				.visualItemRect(keywordsDialog.tree.topLevelItem(keywordsDialog.tree.topLevelItemCount() - 1)).height();

		int w = fm.width(keywordsDialog.tree.topLevelItem(keywordsDialog.tree.topLevelItemCount() - 1).text(0)) + 10;

		QPoint map = text.mapToGlobal(new QPoint(cursorRect.x(), cursorRect.y()));
		int x = map.x();
		int y = map.y() - h - 10;

		QDesktopWidget desk = new QDesktopWidget();
//		int x = 0;
//		int y = desk.availableGeometry().y()+desk.availableGeometry().height()-h;
		int width = desk.rect().width();
		int height = desk.rect().height();
		if (x + w > width) {
			x -= w;
		}
		keywordsDialog.setGeometry(x, y, w, h);
		desk.dispose();
	}

	int getAdjustKeyWordsTreeHeight(int max, keyWords dig) {
		int h = 0;
//		dig.show();
		for (int i = 0; i < dig.tree.topLevelItemCount(); i++) {
			QTreeWidgetItem item = dig.tree.topLevelItem(i);
			QRect r = dig.tree.visualItemRect(item);
			h += r.height();
		}
		if (h > max) {
			h = max;
		}
		return h;
	}

	int getAdjustKeywordsTreeWidth(int max, keyWords dig) {
		int w = 0;
		QFont font = dig.tree.font();
//		font.setPointSize(text.font().pointSize());
		for (int i = 0; i < dig.tree.topLevelItemCount(); i++) {
			QTreeWidgetItem item = dig.tree.topLevelItem(i);
			QFontMetrics fm = new QFontMetrics(font);
			Object data = item.data(3, 3);
			int width = 0;
			if (data != null) {
				width = fm.width(item.text(0) + " " + data);
			} else
				width = fm.width(item.text(0));
			if (width > w) {
				w = width;
			}
		}
		w = w + 20;
		if (w > max) {
			w = max;
			return w;
		} else
			return w;
	}

	void showDialogAtEditorCaretPos(bTextEdit text, keyWords keywordsDialog) {
		if (keywordsDialog.tree.topLevelItemCount() == 0) {
			p(languageTool.getString(623));
			return;
		}
		text.installEventFilter(keywordsDialog);
//		keywordsDialog.translucentBackgound = true;
//		keywordsDialog.tree.setStyleSheet("background:transparent;color:white;");
		keywordsDialog.show();

		QRect cursorRect = text.cursorRect();
		QPoint map = text.mapToGlobal(new QPoint(cursorRect.x(), cursorRect.y()));
		int x = map.x();
		int y = map.y() + cursorRect.height();
		int w = 0;
		QDesktopWidget desk = new QDesktopWidget();
		int width = desk.availableGeometry().width();
		int height = desk.availableGeometry().height();

		if ((findview == 0) || (findview == 3) || findview == 5) {
			w = getAdjustKeywordsTreeWidth(width / 2, keywords);
		} else {
			w = text.width() / 2;
		}
		int h = getAdjustKeyWordsTreeHeight(text.height() / 2 - statusBar().height(), keywords);

		if (x + w > width) {
			x -= w;
		}
		if (y + h > height) {
			y = map.y() - h;
		}
		desk.dispose();
		keywordsDialog.setGeometry(x, y, w, h);
	}
	/**
	 * 
	 * @param textedit
	 * @param text
	 * @param pos -1不指定pos
	 * @param isSelection
	 */
	void bInsertText(bTextEdit textedit, String text, int pos, boolean isSelection) {
		if (pos != -1) {
			QTextCursor tc = textedit.textCursor();
			tc.setPosition(pos);

			tc.insertText(text);
			textedit.setTextCursor(tc);
			if (isSelection) {
				tc.setPosition(pos, QTextCursor.MoveMode.MoveAnchor);
				tc.setPosition(pos + text.length(), QTextCursor.MoveMode.KeepAnchor);
				textedit.setTextCursor(tc);
			}
		} else {
			QTextCursor tc = textedit.textCursor();
			int p = -1;
			if(tc.hasSelection())p = tc.selectionStart();
			else p = tc.position();
			
			tc.insertText(text);
			if (isSelection) {
				int p_end = tc.position();
				tc.setPosition(p, QTextCursor.MoveMode.MoveAnchor);
				tc.setPosition(p_end, MoveMode.KeepAnchor);
				textedit.setTextCursor(tc);

				// 貌似在调用方法前就清除了选择
			}
		}
		textedit.updateCaret(2);
	}

	public void addtomarkstat(String text) {
		if (markstat == null)
			return;
		hasinfo info = markstatIshas(text);
		if (info.ishas) {
			((markstat) this.markstat.get(info.index)).count += 1;

			setTopOnMarkstat(text);
		} else {
			this.markstat.add(new markstat(text, 1));
		}
		this.markstatIsChanged = true;
	}

	void initKeyWordsDialog() {

		if (keywords == null) {
			keywords = new keyWords(this, text) {
				public void whenSubmit(QTreeWidgetItem qt) {
					close();
					if (black.findview == 0) {
						TextRegion tr = (TextRegion) qt.data(1, 0);
						black.this.bInsertText(this.text,
								cheakDocument.subString(tr.text, appInfo.keywordsSeparator)[0], -1, false);
						// 添加分词出来的条目到关键词列表
						if (getBooleanValueFromSettings(appInfo.autoSaveInputOfAutoSegment, "true")) {
							addTextToMarkFile_(tr.text);
							if ((tr.describe != null) && (!tr.describe.equals(""))) {
								black.this.addtomarkstat(tr.describe);
							} else {
								black.this.addtomarkstat(tr.text);
							}
						}
					} else if (black.findview == 1) {
						final TextRegion tr = (TextRegion) qt.data(1, 0);
						if (tr.filename == null) {
							QTextCursor tc = this.text.textCursor();
							tc.setPosition(tr.start);
							tc.setPosition(tr.start + tr.end, QTextCursor.MoveMode.KeepAnchor);
							this.text.setTextCursor(tc);
							black.this.btext.scroll();
						} else {
							QTreeWidgetItem find = black.this.findTreeItemByFileName(tr.filename, null);
							black.this.changedFileOfCurrentEdit();

							black.this.openFileByTreeItem(find);
							action act = new action() {
								public void action() {
									QTextCursor tc = text.textCursor();
									tc.setPosition(tr.start);
									tc.setPosition(tr.start + tr.end, QTextCursor.MoveMode.KeepAnchor);
									text.setTextCursor(tc);
									black.this.btext.scroll();
								}
							};
							afterLoadFileActions.add(act);
						}

					} else if (black.findview == 2) {
						this.onlyUserAction = false;

						TextRegion tr = (TextRegion) qt.data(1, 0);
						QTextCursor tc = this.text.textCursor();
						tc.setPosition(tr.start, QTextCursor.MoveMode.MoveAnchor);
						black.this.btext.doNotSetStyle = true;
						this.text.setTextCursor(tc);
						black.this.btext.scroll();
					} else if (black.findview == 3) {
						TextRegion tr = (TextRegion) qt.data(1, 0);
						black.this.bInsertText(this.text, tr.text, -1, true);
					} else if (black.findview == 4) {
						TextRegion tr = (TextRegion) qt.data(1, 0);
						black.this.moveIndex = this.tree.indexOfTopLevelItem(this.tree.currentItem());

						black.this.addToMoveListEnd = true;
						black.this.changedFileOfCurrentEdit();
						QTreeWidgetItem findTreeItemByFileName = black.this.findTreeItemByFileName(tr.text, null);
						black.this.openFileByTreeItem(findTreeItemByFileName);
					} else if (black.findview == 5) {
						TextRegion tr = (TextRegion) qt.data(1, 0);
						QTextCursor tc = text.textCursor();
						int current = tc.position();
						if (!tc.movePosition(MoveOperation.PreviousCharacter, MoveMode.KeepAnchor))
							return;
						String findStr = tc.selectedText();
						if (findStr.isEmpty())
							return;
						String text = cheakDocument.subString(tr.text, appInfo.keywordsSeparator)[0];
						int indexOf = text.indexOf(findStr);
						if (indexOf != 0) {
							String startPart = text.substring(0, indexOf);
//							System.out.println("startPart: "+startPart);
							int start = tc.position() - startPart.length();
							if (start >= 0) {
								tc.clearSelection();
								tc.setPosition(start, MoveMode.KeepAnchor);
//								System.out.println("selectedText: "+tc.selectedText());
								if (tc.selectedText().equals(startPart)) {
									tc.clearSelection();
									tc.setPosition(current, MoveMode.KeepAnchor);
									tc.insertText(text);
								} else {
									tc.setPosition(current);
									tc.movePosition(MoveOperation.PreviousCharacter, MoveMode.KeepAnchor);
									tc.insertText(text);
								}
							} else
								tc.insertText(text);
						} else
							tc.insertText(text);

						// 添加分词出来的条目到关键词列表
						if (getBooleanValueFromSettings(appInfo.autoSaveInputOfAutoSegment, "true")) {
							addTextToMarkFile_(tr.text);
							if ((tr.describe != null) && (!tr.describe.equals(""))) {
								black.this.addtomarkstat(tr.describe);
							} else {
								black.this.addtomarkstat(tr.text);
							}
						}

					}
				}

				public void whenHide() {
					if(black.text != null && !black.text.isDisposed())
					this.text.removeEventFilter(black.this.keywords);
					black.this.keywords.onlyUserAction = false;
					black.this.keywords.noDefaultSelection = false;
					if (findview == 0) {
						debugPrint(languageTool.getString(625));
						ba.tempData.remove("document_lastPinyinSeg");
						keywords.tree.setFrameShape(QFrame.Shape.StyledPanel);
					}
					keywordsShowAtLeftBottom = false;
				}

				public void selectionChanged(QTreeWidgetItem qt) {
					if (black.findview == 0) {
						if (!this.donotShowMoreText) {
							// qt.setToolTip(0, qt.text(0));
							// qt.setStatusTip(0, qt.text(0));
							TextRegion tr = (TextRegion) qt.data(1, 0);

							String find = black.this.findTextByLastIndexOf(tr.text, black.this.draft);
							tr.describe = find;
						}
					} else if (black.findview == 2) {
						black.this.doNotHideKeywordsDialog = true;
						TextRegion tr = (TextRegion) qt.data(1, 0);
						QTextCursor tc = this.text.textCursor();
						tc.setPosition(tr.start, QTextCursor.MoveMode.MoveAnchor);
						black.this.btext.doNotSetStyle = true;
						this.text.setTextCursor(tc);
						black.this.btext.scroll();
						black.this.doNotHideKeywordsDialog = false;
					}
				}

				public void whenNumberTwoPressed(QTreeWidgetItem qt) {
					if (black.findview == 0) {
						String text = ((TextRegion) qt.data(1, 0)).text;
						String[] str = cheakDocument.subString(text, appInfo.keywordsSeparator);
						String[] checkName = black.checkName(str[0]);
						if (checkName[0] != null) {
							black.this.bInsertText(black.text, checkName[0], -1, false);
							black.this.addtomarkstat(text);
						}
					} else if (findview == 2) {
						String data = (String) qt.data(4, 4);
						ArrayList<String> args = cheakDocument.checkCommandArgs(data, '$');
						QTextCursor tc = text.textCursor();
						tc.setPosition(Integer.valueOf(args.get(1)));
						tc.setPosition(Integer.valueOf(args.get(0)), MoveMode.KeepAnchor);
						text.setTextCursor(tc);
//						text.copy();

//						setLoadFileMessage(languageTool.getString(626));
					}

				}

				public void whenNumberThreePressed(QTreeWidgetItem qt) {
					if (black.findview != 0) {
						return;
					}
					String text = ((TextRegion) qt.data(1, 0)).text;
					String[] str = cheakDocument.subString(text, appInfo.keywordsSeparator);
					String[] checkName = black.checkName(str[0]);
					if (checkName[1] != null) {
						black.this.bInsertText(black.text, checkName[1], -1, false);
						black.this.addtomarkstat(text);
					}
				}

				public void whenDelPressed(QTreeWidgetItem qt) {
					if (black.findview != 0) {
						return;
					}
					String text = ((TextRegion) qt.data(1, 0)).text;
					hasinfo ishas = black.this.markstatIshas(text);
					if (!ishas.ishas) {
						return;
					}
					black.this.deleteFromMarkStatData(text);
					qt.setText(0,languageTool.getString(627,qt.text(0)));
					QFont font = qt.font(0);
					font.setStrikeOut(true);
					qt.setFont(0, font);
				}

				public void whenWindowSizeChanged(QSize size) {
				}
			};
		}

	}

	void getMarkFileText() {
		List<TextRegion> list = new ArrayList();
		if (this.marktext == null) {
			return;
		}
		List<String> lis = cheakDocument.getAllLine(this.marktext);
		for (String st : lis) {
			if (!st.isEmpty()) {
				TextRegion tr = new TextRegion(st, 0, 0);
				list.add(tr);
			}
		}
		this.markTextData = list;
		ishasInMarkdata();
	}

	public static fileInfo getFileInfoByQTreeItem(QTreeWidgetItem qt) {
		fileInfo in = (fileInfo) qt.data(1, 0);
		return in;
	}
	File getFile(String filename) {

		String filepath = this.projectFile.getParent() + File.separator + "Files" + File.separator + filename;
		return new File(filepath);
	}

	void t(QTreeWidgetItem qt) {
		p(qt.text(0));
	}

	void addKeyWordsListToProject() {
		addKeyWordsListToProject(languageTool.getString(628));
	}

	public boolean eventFilter(QObject o, QEvent e) {
//		System.out.println(o.getClass().getName());
//		if(e.type() == QEvent.Type.KeyPress) {
//			System.out.println(o.getClass().getName());
//		}
//		System.out.println(e.type());
		if (o.equals(this) && (e.type() == QEvent.Type.HoverMove||e.type() ==QEvent.Type.KeyPress||e.type()==QEvent.Type.InputMethodQuery)) {
			if(ba.getLockStatus()) {
				ba.updateLockTime();
			}
		}
//		if(e.type() == QEvent.Type.KeyPress) {
//			QKeyEvent key = (QKeyEvent) e;
//			return b.ba.keyboard.checkKey(key,0);
//		}
		if (o.equals(this) && e.type() == QEvent.Type.MouseButtonDblClick) {
			QMouseEvent me = (QMouseEvent) e;
			if (me.button().name().equals("LeftButton")) {
				if(ba.getLockStatus())
				if (writingView > 0) {
					if (ba.checkBingPicIsEnable() || b.getIntValueFromSettings(appInfo.randomImg, "1000") > 0) {
						ba.showBingPicInfo();
					}
				}

			}

		} else if ((o.equals(this.tree)) && (e.type() == QEvent.Type.KeyPress)) {
			QKeyEvent key = (QKeyEvent) e;
			if (key.key() == 16777220) {
				openfile();
				return true;
			}
			if ((key.key() | key.modifiers().value()) == 150994963) {
				if (isOnSameParent()) {
					moveToTop();
					return true;
				}
			} else if ((key.key() | key.modifiers().value()) == 150994965) {
				if (isOnSameParent()) {
					moveToBottom();
					return true;
				}
			} else if ((key.key() | key.modifiers().value()) == 150994962) {
				if ((isOnSameParent()) && (!isIncludeRootDir())) {
					moveToLeft();
					return true;
				}
			} else if (((key.key() | key.modifiers().value()) == 150994964) && (isOnSameParent())
					&& (!isIncludeRootDir())) {
				moveToRight();
				return true;
			}
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.HoverMove)) {
			QHoverEvent hover = (QHoverEvent) e;
			if ((writingView > 0) && (text != null)) {
				QPoint ma = text.mapFrom(this, hover.pos());
//				System.out.println(ma+" "+hover.pos());

				if (!dock.isFloating()) {
					if (hover.pos().x() < 5) {
						dock.setFloating(true);
						dock.setGeometry(0, 0, 300, height());
						dock.show();
						//升级qt5之后必须用下面的方法才能让floating的dock获得焦点
						dock.activateWindow();
						tree.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAsNeeded);
						tree.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAsNeeded);
					}
				} else {
					QPoint mapFrom = dock.mapFrom(this, hover.pos());
					if (!dock.rect().contains(mapFrom)) {
						dock.hide();
//						tree.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
//						tree.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
						dock.setFloating(false);
					}
				}
				int x = text.width() - ma.x();
				if (x < 50) {
					if (!text.verticalScrollBar().isVisible()) {
						text.verticalScrollBar().show();
					}
				} else if (text.verticalScrollBar().isVisible()) {
					text.verticalScrollBar().hide();
				}
			} else if (((writingView == 0) || !getBooleanValueFromSettings(appInfo.fullScreen, "true"))
					&& (this.btext != null) && ((!text.verticalScrollBar().isVisible()))) {
				text.verticalScrollBar().setVisible(true);
			}
			if ((hover.pos().x() <= this.dock.x() + this.dock.width()+100) && (hover.pos().y() > this.dock.y())
					&& (hover.pos().y() <= this.dock.y() + this.dock.height()+100)) {
				this.tree.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded);
				tree.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAsNeeded);
			} else if(writingView == 0){
				this.tree.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);
				tree.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
			}
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.HoverLeave)) {
//			this.tree.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);
//			tree.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
			if ((writingView > 0) && (text != null)) {
				text.verticalScrollBar().hide();
			}
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.WindowActivate)) {
//			ba.randomImg();
			QApplication.restoreOverrideCursor();
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.WindowDeactivate)) {
			QApplication.restoreOverrideCursor();


			if ((text != null) && (text.tr != null)) {
				text.tr = null;
			}
			if (text != null && text.inputing) {
				QInputMethodEvent ime = new QInputMethodEvent();
				ime.setCommitString(null);
				text.event(ime);
			}
			

		} else if ((o.equals(this)) && (e.type() == QEvent.Type.Resize)) {
			if ((keywords != null) && (keywords.isVisible())) {
				keywords.hide();
			}

			setTimeMessageLabelLocation();
			setLoadFileMessageLabelLocation();
			setFindLineLocation();
			
		}
		
		else if ((o.equals(this)) && (e.type() == QEvent.Type.Move)) {
			if ((keywords != null) && (keywords.isVisible())) {
				keywords.hide();
			}

		} else if ((o.equals(this.findBox)) && (e.type() == QEvent.Type.FocusIn)) {
			new bRunnable(0, true, true, true, true) {
				public void run() {
					black.this.findLine.selectAll();
				}
			};

		} else if ((o.equals(this.findBox)) && (e.type() == QEvent.Type.FocusOut)) {

		} else if ((o.equals(this.findBox)) && (e.type() == QEvent.Type.KeyPress)) {
			QKeyEvent key = (QKeyEvent) e;
			if (key.key() == Qt.Key.Key_Return.value()) {
				findLineReturnPressd();
				return true;
			} else if (key.key() == Qt.Key.Key_Escape.value()) {
				if (keywordsForFindLine != null && keywordsForFindLine.isVisible())
					keywordsForFindLine.hide();
				return true;
			}
		}
		
		
		else if ((o.equals(this)) || (e.type() == QEvent.Type.Show)) {
			hideTime = -1;
		}else if ((o.equals(this)) || (e.type() == QEvent.Type.Hide)) {
			hideTime = System.currentTimeMillis();
		}
		if(e.type() == QEvent.Type.ContextMenu) {
			QApplication.restoreOverrideCursor();
		}
		if(e.type() == QEvent.Type.HoverMove) {
			QApplication.restoreOverrideCursor();
		}
		
		return false;
	}

	int getAnimationTime() {
		int value = Integer.valueOf((String) this.settings.value(appInfo.animationTime, "200")).intValue();
		return value;
	}

	void setAnimationTime(int value) {
		this.settings.setValue(appInfo.animationTime, String.valueOf(value));
	}

	void turnOffAnimation() {
		int animationTime = getAnimationTime();
		if (animationTime == 200) {
			setAnimationTime(0);
			setLoadFileMessage(languageTool.getString(629));
		} else {
			setAnimationTime(200);
			setLoadFileMessage(languageTool.getString(630));
		}
	}

	void beep(final QMessageBox mb) {
		QObject o = new QObject() {
			public boolean eventFilter(QObject arg__1, QEvent arg__2) {
				if (arg__2.type() == QEvent.Type.Hide) {
					black.stopBeepSound();
					mb.removeEventFilter(this);
				}
				return super.eventFilter(arg__1, arg__2);
			}
		};
		mb.installEventFilter(o);
		startBeepSound(-1);
	}

	boolean isHasTimer(int type) {
		for (timerInfo in : this.timerInfos) {
			if (in.type == type) {
				return true;
			}
		}
		return false;
	}

	timerInfo[] findTimer(int type) {
		ArrayList<timerInfo> al = new ArrayList();
		for (timerInfo in : this.timerInfos) {
			if (in.type == type) {
				al.add(in);
			}
		}
		return al.toArray(new timerInfo[al.size()]);
	}
	/**
	 * 按照id查找timerinfo
	 * @param id
	 * @return
	 */
	timerInfo getTimerInfo(int id) {
		for (timerInfo in : this.timerInfos) {
			if (in.id == id) {
				return in;
			}
		}
		return null;
	}

	void removeAllTimer(int type) {
		ArrayList<timerInfo> forremove = new ArrayList();
		for (timerInfo in : this.timerInfos) {
			if (in.type == type) {
				forremove.add(in);
			}
		}
		for (timerInfo in : forremove) {
			this.timerInfos.remove(in);
		}
	}

	void expanded(QTreeWidgetItem qt) {
		if (qt.isExpanded()) {
			fileInfo in = (fileInfo) qt.data(1, 0);
			in.expaned = true;
		} else {
			fileInfo in = (fileInfo) qt.data(1, 0);
			in.expaned = false;
		}
		this.fileListChanged = true;
	}

	boolean isOnSameParent() {
		Object p = null;
		List<QTreeWidgetItem> checkedItems = getCheckedItems();
		for (QTreeWidgetItem qt : checkedItems) {
			QTreeWidgetItem parent = qt.parent();
			if (p == null) {
				p = parent;
			} else if (!p.equals(parent)) {
				return false;
			}
		}
		return true;
	}

	public void rename() {
		this.isDoubleClickedOnTreeItem = true;
		this.tree.editItem(this.tree.currentItem());
	}

	public boolean isRootDir() {
		QTreeWidgetItem currentItem = this.tree.currentItem();
		if ((currentItem != null) && ((currentItem.equals(this.draft)) || (currentItem.equals(this.reserach))
				|| (currentItem.equals(this.recycle)))) {
			return true;
		}
		return false;
	}

	void showTreeMenu(QPoint pos) {
		this.treeMenu = new QMenu(this.tree);
		this.treeMenu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);
		this.treeMenu.addAction(ba.exportFileOne);
		QFont font = treeMenu.font();
		int fs = ba.getUIFontSize(fontSize.menu);
		font.setPointSize(fs);
		treeMenu.setFont(font);
		treeMenu.addSeparator();

		if (!isCheackable(this.draft)) {
			this.treeMenu.addAction(this.ui.addFile);
			this.treeMenu.addAction(this.ui.addKeywords);
			this.treeMenu.addAction(this.ui.addDir);
			this.treeMenu.addSeparator();
		}

		QAction rename = new QAction(this.treeMenu);
		rename.setText(languageTool.getString(631));
		rename.triggered.connect(this, "rename()");
		this.treeMenu.addAction(rename);
//		QAction saveasCopy = new QAction(this.treeMenu);
//		saveasCopy.setText(languageTool.getString(632));
//		saveasCopy.triggered.connect(this, "saveAsACopy()");
//		if ((getCheckedItems().size() == 0) && (this.tree.currentItem() == null)) {
//			saveasCopy.setEnabled(false);
//		}
//		if ((isRootDir()) || (isIncludeRootDir())) {
//			saveasCopy.setEnabled(false);
//		}
//		this.treeMenu.addAction(saveasCopy);
		this.treeMenu.addSeparator();

		QAction amove = new QAction(this.treeMenu);
		this.treeMenu.addAction(amove);
		amove.setText(languageTool.getString(633));
		if (!isCheackable(this.draft)) {
			amove.setEnabled(false);
			amove.setText(languageTool.getString(634));
		} else if (getCheckedItems().size() == 0) {
			amove.setEnabled(false);
			amove.setText(languageTool.getString(634));
		} else if (isIncludeRootDir()) {
			amove.setEnabled(false);
			amove.setText(languageTool.getString(636));
		} else {
			Menu moveMenu = new Menu();
			amove.setMenu(moveMenu);
			QAction ato = new QAction(moveMenu);
			ato.setText(languageTool.getString(637));
			moveMenu.addAction(ato);
			Menu listMenu = listMenuWithTreeWidget(null, "triggered_listMenu(QAction)", true);
			ato.setMenu(listMenu);
			if (isOnSameParent()) {
				QAction atop = new QAction(moveMenu);
				atop.setText(languageTool.getString(638));
				atop.triggered.connect(this, "moveToTop()");
				QAction abottom = new QAction(moveMenu);
				abottom.setText(languageTool.getString(639));
				abottom.triggered.connect(this, "moveToBottom()");
				QAction aleft = new QAction(moveMenu);
				aleft.setText(languageTool.getString(640));
				aleft.triggered.connect(this, "moveToLeft()");
				QAction aright = new QAction(moveMenu);
				aright.setText(languageTool.getString(641));
				aright.triggered.connect(this, "moveToRight()");
				moveMenu.addAction(atop);
				moveMenu.addAction(abottom);
				moveMenu.addAction(aleft);
				moveMenu.addAction(aright);
			}
			moveMenu.triggered.connect(this, "triggered_moveMenu(QAction)");
		}
		QAction selectTreeItem = new QAction(this.treeMenu);
		this.treeMenu.addAction(selectTreeItem);
		if (!isCheackable(this.draft)) {
			selectTreeItem.setText(languageTool.getString(642));
		} else {
			selectTreeItem.setText(languageTool.getString(643));
			if (getCheckedItems().size() > 0) {
				QAction clearselect = new QAction(this.treeMenu);
				clearselect.setText(languageTool.getString(644));
				clearselect.triggered.connect(this, "clearSelectedOnCheckBox()");
				this.treeMenu.addAction(clearselect);
			}
			QAction selectOne = new QAction(this.treeMenu);
			selectOne.setText(languageTool.getString(645));
			selectOne.triggered.connect(this, "selectOne()");
			this.treeMenu.addAction(selectOne);
			QAction selectAll = new QAction(this.treeMenu);
			selectAll.setText(languageTool.getString(646));
			selectAll.triggered.connect(this, "selectAll()");
			this.treeMenu.addAction(selectAll);
		}
		selectTreeItem.triggered.connect(this, "selectTreeItem()");

		this.treeMenu.addSeparator();
		this.treeMenu.addAction(this.ui.moveToRecycle);
		this.treeMenu.addAction(this.ui.clearRecycle);
		this.treeMenu.addSeparator();

		QAction QAction = new QAction(this.treeMenu);
		QAction.setText(languageTool.getString(647,getCharCountBySelectedItems()));
		QAction.setEnabled(false);
		this.treeMenu.addAction(QAction);
		this.treeMenu.popup(this.tree.mapToGlobal(pos));
		QTreeWidgetItem itemAt = this.tree.itemAt(pos);
		if (itemAt == null) {
			this.tree.clearSelection();
			this.tree.setCurrentItem(null);
		}
	}

	public void selectOne() {
		this.tree.currentItem().setCheckState(0, Qt.CheckState.Checked);
	}

	public void selectAll() {
		clearOrAddSelectedStateForCheckBox(null, false);
	}

	public void selectionAllSubItem() {
		List<QTreeWidgetItem> items = getCheckedItems();
		for (QTreeWidgetItem qt : items) {
			clearOrAddSelectedStateForCheckBox(qt, false);
		}
	}

	public void clearSelectedOnCheckBox() {
		clearOrAddSelectedStateForCheckBox(null, true);
	}

	public void selectTreeItem() {
		if (!isCheackable(this.draft)) {
			setCheckableForTreeItem(null, true);
		} else {
			setCheckableForTreeItem(null, false);
		}
	}

	public List<QTreeWidgetItem> getCheckedItems() {
		return getCheckedItems(null);
	}

	public boolean isCheackable(QTreeWidgetItem qt) {
		Object data = qt.data(0, 10);
		if (data != null) {
			return true;
		}
		return false;
	}

	public List<QTreeWidgetItem> getCheckedItems(QTreeWidgetItem qt) {
		ArrayList<QTreeWidgetItem> list = new ArrayList();
		if (qt == null) {
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				Qt.CheckState checkState = topLevelItem.checkState(0);
				if (checkState.compareTo(Qt.CheckState.Checked) == 0) {
					list.add(topLevelItem);
				}
				if (topLevelItem.childCount() > 0) {
					List<QTreeWidgetItem> list2 = getCheckedItems(topLevelItem);
					list.addAll(list2);
				}
			}
		} else {
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				Qt.CheckState checkState = child.checkState(0);
				if (checkState.compareTo(Qt.CheckState.Checked) == 0) {
					list.add(child);
				}
				if (child.childCount() > 0) {
					List<QTreeWidgetItem> list2 = getCheckedItems(child);
					list.addAll(list2);
				}
			}
		}
		return list;
	}

	public void clearOrAddSelectedStateForCheckBox(QTreeWidgetItem qt, boolean isclear) {
		if (qt == null) {
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				if (isclear) {
					topLevelItem.setCheckState(0, Qt.CheckState.Unchecked);
				} else {
					topLevelItem.setCheckState(0, Qt.CheckState.Checked);
				}
				if (topLevelItem.childCount() > 0) {
					clearOrAddSelectedStateForCheckBox(topLevelItem, isclear);
				}
			}
		} else {
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				if (isclear) {
					child.setCheckState(0, Qt.CheckState.Unchecked);
				} else {
					child.setCheckState(0, Qt.CheckState.Checked);
				}
				if (child.childCount() > 0) {
					clearOrAddSelectedStateForCheckBox(child, isclear);
				}
			}
		}
	}

	public void setCheckableForTreeItem(QTreeWidgetItem qt, boolean addOrRemoveCheckbox) {
		if (qt == null) {
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				if (addOrRemoveCheckbox) {
					topLevelItem.setCheckState(0, Qt.CheckState.Unchecked);
				} else {
					topLevelItem.setData(0, 10, null);
				}
				if (topLevelItem.childCount() > 0) {
					setCheckableForTreeItem(topLevelItem, addOrRemoveCheckbox);
				}
			}
		} else {
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				if (addOrRemoveCheckbox) {
					child.setCheckState(0, Qt.CheckState.Unchecked);
				} else {
					child.setData(0, 10, null);
				}
				if (child.childCount() > 0) {
					setCheckableForTreeItem(child, addOrRemoveCheckbox);
				}
			}
		}
	}

	public int getCharCountBySelectedItems() {
		int charCount = 0;
		List<QTreeWidgetItem> selectedItems = null;
		if (!isCheackable(this.draft)) {
			selectedItems = this.tree.selectedItems();
		} else {
			selectedItems = getCheckedItems();
		}
		if (selectedItems != null) {
			for (QTreeWidgetItem qt : selectedItems) {
				fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(qt);
				charCount += fileInfoByQTreeItem.charCount;
			}
		}
		return charCount;
	}

	QTreeWidgetItem getItemUnderCursor() {
		QPoint pos = this.tree.mapFromGlobal(this.treeMenu.pos());
		QTreeWidgetItem itemAt = this.tree.itemAt(pos);
		return itemAt;
	}

	boolean isIncludeRootDir() {
		List<QTreeWidgetItem> checkedItems = getCheckedItems();
		for (QTreeWidgetItem qt : checkedItems) {
			if ((qt.equals(this.draft)) || (qt.equals(this.reserach)) || (qt.equals(this.recycle))) {
				return true;
			}
		}
		return false;
	}

	void moveToRight() {
		List<QTreeWidgetItem> selectedItems = getCheckedItems();
		QTreeWidgetItem parent = ((QTreeWidgetItem) selectedItems.get(0)).parent();
		QTreeWidgetItem item = null;
		if (parent != null) {
			fileInfo in_parent = (fileInfo) parent.data(1, 0);
			int indexOfChild = parent.indexOfChild((QTreeWidgetItem) selectedItems.get(0));
			if (indexOfChild > 0) {
				QTreeWidgetItem child = parent.child(indexOfChild - 1);
				fileInfo in_child = (fileInfo) child.data(1, 0);
				for (Iterator localIterator = selectedItems.iterator(); localIterator.hasNext();) {
					item = (QTreeWidgetItem) localIterator.next();
					fileInfo in = (fileInfo) item.data(1, 0);
					if ((in_child.isDir) || (in_child.isFiles) || (in_child.isRoot != -1)) {
						parent.removeChild(item);
						child.addChild(item);
						item.setExpanded(in.expaned);
						child.setExpanded(true);
						in_parent.subfiles.remove(indexOfChild);
						in_child.subfiles.add(in);
					} else if (in_child.isFile) {
						parent.removeChild(item);
						if ((in_parent.isFiles) && (in_parent.subfiles.size() == 0)) {
							in_parent.subfiles = null;
							in_parent.isFiles = false;
							in_parent.isFile = true;
							if (in_parent.charCount == 0) {
								parent.setIcon(0, this.ico_file);
							} else {
								parent.setIcon(0, this.ico_fileOfHasText);
							}
						}
						child.addChild(item);
						item.setExpanded(in.expaned);
						child.setExpanded(true);
						child.setIcon(0, this.ico_files);
						in_parent.subfiles.remove(indexOfChild);
						in_child.isFiles = true;
						in_child.isFile = false;
						in_child.initFloder().add(in);
					}
				}
			}
		} else {
			int indexOfTopLevelItem = this.tree.indexOfTopLevelItem((QTreeWidgetItem) selectedItems.get(0));
			if (indexOfTopLevelItem > 0) {
				QTreeWidgetItem child = this.tree.topLevelItem(indexOfTopLevelItem - 1);
				fileInfo in_child = (fileInfo) child.data(1, 0);
				for (QTreeWidgetItem it : selectedItems) {
					int index = this.tree.indexOfTopLevelItem(it);
					fileInfo in = (fileInfo) it.data(1, 0);
					if ((in_child.isDir) || (in_child.isFiles) || (in_child.isRoot != -1)) {
						this.tree.takeTopLevelItem(index);
						child.addChild(it);
						it.setExpanded(in.expaned);
						child.setExpanded(true);
						this.filesList.remove(indexOfTopLevelItem);
						in_child.subfiles.add(in);
					} else if (in_child.isFile) {
						this.tree.takeTopLevelItem(index);

						child.addChild(it);
						it.setExpanded(in.expaned);
						child.setExpanded(true);
						child.setIcon(0, this.ico_files);
						this.filesList.remove(indexOfTopLevelItem);
						in_child.isFiles = true;
						in_child.isFile = false;
						in_child.initFloder().add(in);
					}
				}
			}
		}
		this.tree.setCurrentItem((QTreeWidgetItem) selectedItems.get(0));
		this.fileListChanged = true;
	}

	void moveToLeft() {
		List<QTreeWidgetItem> selectedItems = getCheckedItems();
		QTreeWidgetItem parent = ((QTreeWidgetItem) selectedItems.get(0)).parent();
		if (parent != null) {
			QTreeWidgetItem parentOfparent = parent.parent();
			fileInfo in_parent = (fileInfo) parent.data(1, 0);
			QTreeWidgetItem item;
			if (parentOfparent != null) {
				fileInfo in_parentOfparent = (fileInfo) parentOfparent.data(1, 0);
				int indexOfParent = parentOfparent.indexOfChild(parent);
				if (indexOfParent + 1 < parentOfparent.childCount()) {
					for (QTreeWidgetItem it : selectedItems) {
						fileInfo in = (fileInfo) it.data(1, 0);
						parent.removeChild(it);
						parentOfparent.insertChild(indexOfParent + 1, it);
						it.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						in_parentOfparent.subfiles.add(indexOfParent + 1, in);
						if ((in_parent.isFiles) && (in_parent.subfiles.size() == 0)) {
							if (in_parent.charCount == 0) {
								parent.setIcon(0, this.ico_file);
							} else {
								parent.setIcon(0, this.ico_fileOfHasText);
							}
							in_parent.isFiles = false;
							in_parent.isFile = true;
							in_parent.subfiles = null;
						}
					}
				} else {
					Iterator it = selectedItems.iterator();
					while (it.hasNext()) {
						QTreeWidgetItem ite = (QTreeWidgetItem) it.next();
						fileInfo in = (fileInfo) ite.data(1, 0);
						parent.removeChild(ite);
						parentOfparent.addChild(ite);
						ite.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						in_parentOfparent.subfiles.add(in);
						if ((in_parent.isFiles) && (in_parent.subfiles.size() == 0)) {
							if (in_parent.charCount == 0) {
								parent.setIcon(0, this.ico_file);
							} else {
								parent.setIcon(0, this.ico_fileOfHasText);
							}
							in_parent.isFiles = false;
							in_parent.isFile = true;
							in_parent.subfiles = null;
						}
					}
				}
			} else {
				int indexOfTopLevelItem = this.tree.indexOfTopLevelItem(parent);
				if (indexOfTopLevelItem + 1 < this.tree.topLevelItemCount()) {
					for (QTreeWidgetItem it : selectedItems) {
						fileInfo in = (fileInfo) it.data(1, 0);
						parent.removeChild(it);
						this.tree.insertTopLevelItem(indexOfTopLevelItem + 1, it);
						it.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						this.filesList.add(indexOfTopLevelItem + 1, in);
						if ((in_parent.isFiles) && (in_parent.subfiles.size() == 0)) {
							if (in_parent.charCount == 0) {
								parent.setIcon(0, this.ico_file);
							} else {
								parent.setIcon(0, this.ico_fileOfHasText);
							}
							in_parent.isFile = true;
							in_parent.isFiles = false;
							in_parent.subfiles = null;
						}
					}
				} else {
					for (QTreeWidgetItem it : selectedItems) {
						fileInfo in = (fileInfo) it.data(1, 0);
						parent.removeChild(it);
						this.tree.addTopLevelItem(it);
						it.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						this.filesList.add(in);
						if ((in_parent.isFiles) && (in_parent.subfiles.size() == 0)) {
							if (in_parent.charCount == 0) {
								parent.setIcon(0, this.ico_file);
							} else {
								parent.setIcon(0, this.ico_fileOfHasText);
							}
							in_parent.isFile = true;
							in_parent.isFiles = false;
							in_parent.subfiles = null;
						}
					}
				}
			}
			this.tree.setCurrentItem((QTreeWidgetItem) selectedItems.get(0));
		}
		this.fileListChanged = true;
	}

	void moveToBottom() {
		List<QTreeWidgetItem> selectedItems = getCheckedItems();
		for (int i = selectedItems.size() - 1; i >= 0; i--) {
			QTreeWidgetItem item = (QTreeWidgetItem) selectedItems.get(i);
			if (item != null) {
				if (item.parent() != null) {
					QTreeWidgetItem parent = item.parent();
					fileInfo in = (fileInfo) item.data(1, 0);
					fileInfo in_parent = (fileInfo) parent.data(1, 0);
					int index = parent.indexOfChild(item);
					if (index + 1 < parent.childCount()) {
						parent.removeChild(item);
						parent.insertChild(index + 1, item);
						item.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						in_parent.subfiles.add(index + 1, in);
					}
				} else {
					fileInfo in = (fileInfo) item.data(1, 0);
					int indexOfTopLevelItem = this.tree.indexOfTopLevelItem(item);
					if (indexOfTopLevelItem + 1 < this.tree.topLevelItemCount()) {
						this.tree.takeTopLevelItem(indexOfTopLevelItem);
						this.tree.insertTopLevelItem(indexOfTopLevelItem + 1, item);
						item.setExpanded(in.expaned);
						this.filesList.remove(in);
						this.filesList.add(indexOfTopLevelItem + 1, in);
					} else {
						return;
					}
				}
				this.tree.setCurrentItem(item);
			}
		}
		this.fileListChanged = true;
	}

	void moveToTop() {
		List<QTreeWidgetItem> selectedItems = getCheckedItems();
		for (QTreeWidgetItem item : selectedItems) {
			if (item != null) {
				if (item.parent() != null) {
					QTreeWidgetItem parent = item.parent();
					fileInfo in = (fileInfo) item.data(1, 0);
					fileInfo in_parent = (fileInfo) parent.data(1, 0);
					int index = parent.indexOfChild(item);
					if (index > 0) {
						parent.removeChild(item);
						parent.insertChild(index - 1, item);
						item.setExpanded(in.expaned);
						in_parent.subfiles.remove(in);
						in_parent.subfiles.add(index - 1, in);
					}
				} else {
					fileInfo in = (fileInfo) item.data(1, 0);
					int indexOfTopLevelItem = this.tree.indexOfTopLevelItem(item);
					if (indexOfTopLevelItem > 0) {
						this.tree.takeTopLevelItem(indexOfTopLevelItem);
						this.tree.insertTopLevelItem(indexOfTopLevelItem - 1, item);
						item.setExpanded(in.expaned);
						this.filesList.remove(in);
						this.filesList.add(indexOfTopLevelItem - 1, in);
					} else {
						return;
					}
				}
				this.tree.setCurrentItem(item);
			}
		}
		this.fileListChanged = true;
	}

	void triggered_moveMenu(QAction a) {
		if (a.isEnabled()) {
			hideTreeMenu();
			if (a.menu() != null) {
				triggered_listMenu(a);
			} else {
				a.triggered.emit(Boolean.valueOf(true));
			}
		}
	}

	void hideTreeMenu() {
		if (this.treeMenu != null) {
			this.treeMenu.hide();
		}
	}

	void showLogsText() {
		if (logsBox == null) {
			logsBox = new bmessageBox(this, languageTool.getString(649), languageTool.getString(650), this.logsmessage.toString(), true) {

				@Override
				public void buttonPressedAction(String paramString) {
					// TODO Auto-generated method stub
					setVisible(false);
				}
			};
		} else
			logsBox.setVisible(true);
		logsBox.ui.textEdit.moveCursor(QTextCursor.MoveOperation.End);
	}

	public static void p(Object o) {
		String log_time = time.getCurrentDate("-") + " " + time.getCurrentTimeHasSecond();
		String log_message = o.toString();
		System.out.println(log_time + " " + log_message);
		String log = "<b>" + log_time + "</b> " + log_message + "<br>";
		logsmessage.append(log);
		//下面的判断句必须放在uiRun方法外部执行，因为如果放在内部会导致主线程被阻塞时无法判断
		//不可以根据主窗口是否隐藏来做限制，因为主窗口隐藏时也有可能需要更新日志对话框中的内容
		if (logsBox != null)
			uiRun(b, new Runnable() {
	
				@Override
				public void run() {
					// TODO Auto-generated method stub
					logsBox.ui.textEdit.insertHtml(log);
					logsBox.ui.textEdit.moveCursor(QTextCursor.MoveOperation.End);
				}
			});
//		speakText(o.toString(), -1);
	}

	void p_(Object o) {
		p(o);
	}

	void p__(Object o) {
		p(o);
		statusBar().showMessage(o.toString());
//		speakText(o.toString(), -1);
	}

	void triggered_listMenu(QAction a) {
		if (a.isEnabled()) {
			hideTreeMenu();
			QTreeWidgetItem to = (QTreeWidgetItem) a.data();
			List<QTreeWidgetItem> selectedItems = getCheckedItems();
			for (QTreeWidgetItem src : selectedItems) {
				QTreeWidgetItem from = src.parent();
				moveFile(src, from, to);
				clearOrAddSelectedStateForCheckBox(src, true);
			}
		}
	}

	void moveFile(QTreeWidgetItem src, QTreeWidgetItem from, QTreeWidgetItem to) {
		if (src != null) {
			if ((src.equals(this.draft)) || (src.equals(this.reserach)) || (src.equals(this.recycle))
					|| (isHas(src, to))) {
				return;
			}
			fileInfo info_src = (fileInfo) src.data(1, 0);
			if (to != null) {
				fileInfo info_to = (fileInfo) to.data(1, 0);
				if (info_to.isDir) {
					if (from != null) {
						fileInfo info_from = (fileInfo) from.data(1, 0);
						info_from.subfiles.remove(info_src);
						from.removeChild(src);
						if ((info_from.isFiles) && (info_from.subfiles.size() == 0)) {
							from.setIcon(0, this.ico_file);
							info_from.isFiles = false;
							info_from.subfiles = null;
						}
					} else {
						this.filesList.remove(info_src);
						this.tree.takeTopLevelItem(this.tree.indexOfTopLevelItem(src));
					}
					info_to.subfiles.add(info_src);
					to.addChild(src);
					setExpanded(to, true);
				} else if (info_to.isRoot != -1) {
					if (from != null) {
						fileInfo info_from = (fileInfo) from.data(1, 0);
						info_from.subfiles.remove(info_src);
						from.removeChild(src);
						if ((info_from.isFiles) && (info_from.subfiles.size() == 0)) {
							from.setIcon(0, this.ico_file);
							info_from.isFiles = false;
							info_from.subfiles = null;
						}
					} else {
						this.filesList.remove(info_src);
						this.tree.takeTopLevelItem(this.tree.indexOfTopLevelItem(src));
					}
					info_to.subfiles.add(info_src);
					to.addChild(src);
					setExpanded(to, true);
				} else if (info_to.isFiles) {
					if (from != null) {
						fileInfo info_from = (fileInfo) from.data(1, 0);
						info_from.subfiles.remove(info_src);
						from.removeChild(src);
						if ((info_from.isFiles) && (info_from.subfiles.size() == 0)) {
							from.setIcon(0, this.ico_file);
							info_from.isFiles = false;
							info_from.subfiles = null;
						}
					} else {
						this.filesList.remove(info_src);
						this.tree.takeTopLevelItem(this.tree.indexOfTopLevelItem(src));
					}
					info_to.subfiles.add(info_src);
					to.addChild(src);
					setExpanded(to, true);
				} else if (info_to.isFile) {
					if (from != null) {
						fileInfo info_from = (fileInfo) from.data(1, 0);
						info_from.subfiles.remove(info_src);
						from.removeChild(src);
						if ((info_from.isFiles) && (info_from.subfiles.size() == 0)) {
							from.setIcon(0, this.ico_file);
							info_from.isFiles = false;
							info_from.subfiles = null;
						}
					} else {
						this.filesList.remove(info_src);
						this.tree.takeTopLevelItem(this.tree.indexOfTopLevelItem(src));
					}
					to.setIcon(0, this.ico_files);
					to.addChild(src);
					setExpanded(to, true);
					info_to.isFiles = true;
					info_to.isFile = false;
					info_to.initFloder();
					info_to.subfiles.add(info_src);
				}
			} else if (from != null) {
				fileInfo info_from = (fileInfo) from.data(1, 0);
				info_from.subfiles.remove(info_src);
				from.removeChild(src);
				if ((info_from.isFiles) && (info_from.subfiles.size() == 0)) {
					from.setIcon(0, this.ico_file);
					info_from.isFiles = false;
					info_from.subfiles = null;
				}
				this.tree.addTopLevelItem(src);
				this.filesList.add(info_src);
			}
			this.fileListChanged = true;
		}
	}

	void initKeywordsForFindLine() {
		if (keywordsForFindLine == null) {
			keywordsForFindLine = new keyWords(null, true) {
				public void whenWindowSizeChanged(QSize size) {
				}

				public void whenSubmit(QTreeWidgetItem qt) {
//					close();
					// 首次跳转前保存位置信息，方便回到原来的位置
					if (!qt.text(0).isEmpty()) {
						TextRegion lastEdit = new TextRegion("", 0, 0);
						lastEdit.filename = currentEditing.getName();
						QTextCursor lastTc = black.this.text.textCursor();
						lastEdit.start = lastTc.selectionStart();
						lastEdit.end = lastTc.selectionEnd() - lastEdit.start;
						ba.tempData.put("lastEditLocation", lastEdit);
					}

					final TextRegion tr = (TextRegion) qt.data(1, 0);
					if (tr.filename.equals(black.this.currentEditing.getName())) {
						QTextCursor tc = black.this.btext.text.textCursor();
						tc.setPosition(tr.start);
						tc.setPosition(tr.start + tr.end, QTextCursor.MoveMode.KeepAnchor);
						black.this.btext.text.setTextCursor(tc);
						black.this.btext.scroll();
					} else {
						QTreeWidgetItem find = black.this.findTreeItemByFileName(tr.filename, null);
						doNotSet_UnSave = true;
						black.this.changedFileOfCurrentEdit();
						black.this.openFileByTreeItem(find);
						afterLoadFileActions.add(new action() {
							public void action() {
								QTextCursor tc = black.this.btext.text.textCursor();
								tc.setPosition(tr.start);
								tc.setPosition(tr.start + tr.end, QTextCursor.MoveMode.KeepAnchor);
								black.this.btext.text.setTextCursor(tc);
								black.this.btext.scroll();
							}
						});
					}
				}

				public void whenNumberTwoPressed(QTreeWidgetItem qt) {

				}

				public void whenNumberThreePressed(QTreeWidgetItem qt) {
				}

				public void whenHide() {
//					black.this.findBox.removeEventFilter(black.this.keywordsForFindLine);
					this.noDefaultSelection = false;
					ba.tempData.remove("lastEditLocation");
					ba.tempData.remove("lastFindIn");
					ba.tempData.remove("lastFindText");
					ba.tempData.remove("needReSerach");
				}

				public void whenDelPressed(QTreeWidgetItem qt) {
				}

				public void selectionChanged(QTreeWidgetItem qt) {
				}
			};
			QAction act_back = new QAction(keywordsForFindLine);
			act_back.setShortcut("ctrl+1");
			act_back.setShortcut("alt+1");
			act_back.triggered.connect(black.this, "testComeBack()");
			keywordsForFindLine.addAction(act_back);
			QAction act_reFind = new QAction(keywordsForFindLine);
			act_reFind.setShortcut("ctrl+2");
			act_reFind.setShortcut("alt+2");
			act_reFind.triggered.connect(black.this, "testReFind()");
			keywordsForFindLine.addAction(act_reFind);
			keywordsForFindLine.setWindowTitle(languageTool.getString(651));
			keywordsForFindLine.setWindowIcon(this.windowIcon());
		}
	}

	/**
	 * 检索框中按下数字键2，可以跳转到上一次编辑的位置
	 */
	void testComeBack() {
		QTreeWidgetItem newqt = new QTreeWidgetItem();
		newqt.setData(1, 0, ba.tempData.get("lastEditLocation"));
		keywordsForFindLine.whenSubmit(newqt);
	}

	/**
	 * 重新检索项目
	 */
	void testReFind() {
//		findLineReturnPressd();
		showFindInfoForFindLine((String) ba.tempData.get("lastFindText"), (int) ba.tempData.get("lastFindIn"));
	}

	/**
	 * 全局检索框
	 * 
	 * @param text
	 * @param findIn为0时搜索整个项目，非0时只搜索当前文件
	 */
	public void showFindInfoForFindLine(String text, int findIn) {
		if (keywordsForFindLine != null) {
			keywordsForFindLine.tree.clear();
		} else {
			initKeywordsForFindLine();
		}
		ba.tempData.put("lastFindText", text);
		ba.tempData.put("lastFindIn", findIn);

		keywordsForFindLine.tree.clear();
		ArrayList<TextRegion> findTextAsFast = null;
		findTextAsFast = (ArrayList) cheakDocument.searchByLine(this.text.toPlainText(), text,
				getShowNameOfCurrentEditingFile(), this.currentEditing.getName());
		if (findIn == 0) {
			findTextAsFast.addAll(findTextAsFast(text, null, new ArrayList()));
		}
		for (TextRegion tr : findTextAsFast) {
			tr.describe = tr.text;
			tr.text = text;
			QTreeWidgetItem treeItem = getTreeItem(keywordsForFindLine.tree);
			treeItem.setText(0, tr.showname + " - " + tr.describe);
			treeItem.setData(1, 0, tr);
		}
		keywordsForFindLine.setWindowTitle(languageTool.getString(651));
		keywordsForFindLine.statusbar.showMessage(languageTool.getString(653,keywordsForFindLine.tree.topLevelItemCount()));
		if (getFindIn() == 0) {
			keywordsForFindLine.message.setText(languageTool.getString(654));
		} else {
			keywordsForFindLine.message.setText(languageTool.getString(655,getShowNameOfCurrentEditingFile()));
		}
		keywordsForFindLine.forFindLine = true;
		ba.tempData.put(languageTool.getString(657), 0);

		showDialogForFindLine();
	}

	public void showFindInfo(bTextEdit text, QTreeWidgetItem qt, boolean onlyCurrentDocument) {
		String findText = text.textCursor().selectedText();
		findBox.lineEdit().setText(findText);
		int findIn = 1;
		if (!onlyCurrentDocument)
			findIn = 0;
		showFindInfoForFindLine(findText, findIn);
//		if ((keywords != null) && (keywords.isVisible())) {
//			return;
//		}
//		if (keywords == null) {
//			initKeyWordsDialog();
//		}
//		keywords.tree.clear();
//		String str = text.textCursor().selectedText();
//		addToFindHistory(str);
//		ArrayList<TextRegion> findTextAsFast = null;
//		if (!onlyCurrentDocument) {
//			findTextAsFast = findTextAsFast(str, qt, new ArrayList());
//			keywords.message.setText("检索父目录(" + findTextAsFast.size() + "条结果)");
//		} else {
//			findTextAsFast = (ArrayList) cheakDocument.searchByLine(text.toPlainText(), str, languageTool.getString(660), null);
//			keywords.message.setText("检索当前文档(" + findTextAsFast.size() + "条结果)");
//		}
//		keywords.statusbar.showMessage(languageTool.getString(663));
//		for (TextRegion tr : findTextAsFast) {
//			tr.describe = tr.text;
//			tr.text = str;
//			QTreeWidgetItem treeItem = getTreeItem(keywords.tree);
//			if (onlyCurrentDocument) {
//				treeItem.setText(0, tr.describe);
//			} else {
//				treeItem.setText(0, tr.showname + " - " + tr.describe);
//			}
//			treeItem.setData(1, 0, tr);
//		}
//		showDialogAtEditorCaretPos(text, keywords);

	}

	public ArrayList<TextRegion> findTextAsFast(String text, QTreeWidgetItem qt, ArrayList<TextRegion> al) {
		if (qt == null) {
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(topLevelItem);
				if (((!topLevelItem.equals(this.TreeWidgetItemOfCurrentEditing)) && (fileInfoByQTreeItem.isFile))
						|| (fileInfoByQTreeItem.isFiles)) {
					File file = getFile(fileInfoByQTreeItem.fileName);
					String str = readBlackFile(file);
					QTextDocument doc = new QTextDocument(str);
					if (str != null) {
						List<TextRegion> searchByLine = cheakDocument.searchByLine(doc.toPlainText(), text,
								fileInfoByQTreeItem.getShowName(), fileInfoByQTreeItem.fileName);
						al.addAll(searchByLine);
					}
				}
				if (topLevelItem.childCount() > 0) {
					findTextAsFast(text, topLevelItem, al);
				}
			}
		} else {
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(child);
				if (((!child.equals(this.TreeWidgetItemOfCurrentEditing)) && (fileInfoByQTreeItem.isFile))
						|| (fileInfoByQTreeItem.isFiles)) {
					File file = getFile(fileInfoByQTreeItem.fileName);
					String str = readBlackFile(file);
					QTextDocument doc = new QTextDocument(str);
					if (str != null) {
						List<TextRegion> searchByLine = cheakDocument.searchByLine(doc.toPlainText(), text,
								fileInfoByQTreeItem.getShowName(), fileInfoByQTreeItem.fileName);
						al.addAll(searchByLine);
					}
				}
				if (child.childCount() > 0) {
					findTextAsFast(text, child, al);
				}
			}
		}
		return al;
	}

	public String findByLastOfLine(String text, String str) {
		List<String> allLine = cheakDocument.getAllLine(text);
		for (int i = allLine.size() - 1; i >= 0; i--) {
			String line = (String) allLine.get(i);
			int index = -1;
			index = line.lastIndexOf(str);
			if (index != -1) {
				return line;
			}
			if (str.indexOf("·") != -1) {
				String firstname = str.substring(str.lastIndexOf('·') + 1, str.length());
				String lastname = str.substring(0, str.indexOf('·'));
				index = line.lastIndexOf(firstname);
				if (index != -1) {
					return line;
				}
				index = line.lastIndexOf(lastname);
				if (index != -1) {
					return line;
				}
			}
		}
		return null;
	}

	public String findTextByLastIndexOf(String text, QTreeWidgetItem qt) {
		if (qt == null) {
			for (int i = this.tree.topLevelItemCount() - 1; i >= 0; i--) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				if (topLevelItem.childCount() > 0) {
					String findTextByLastIndexOf = findTextByLastIndexOf(text, topLevelItem);
					if (findTextByLastIndexOf != null) {
						return findTextByLastIndexOf;
					}
				}
				fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(topLevelItem);
				if ((fileInfoByQTreeItem.isFile) || (fileInfoByQTreeItem.isFiles)) {
					String str = null;
					if (!fileInfoByQTreeItem.equals(this.infoOfCurrentEditing)) {
						File file = getFile(fileInfoByQTreeItem.fileName);
						str = readBlackFile(file);
					} else {
						str = this.text.toPlainText();
					}
					if (str != null) {
						String findByLastOfLine = findByLastOfLine(str, text);
						if (findByLastOfLine != null) {
							return findByLastOfLine;
						}
					}
				}
			}
		} else {
			for (int i = qt.childCount() - 1; i >= 0; i--) {
				QTreeWidgetItem child = qt.child(i);
				if (child.childCount() > 0) {
					String findTextByLastIndexOf = findTextByLastIndexOf(text, child);
					if (findTextByLastIndexOf != null) {
						return findTextByLastIndexOf;
					}
				}
				fileInfo fileInfoByQTreeItem = getFileInfoByQTreeItem(child);
				if ((fileInfoByQTreeItem.isFile) || (fileInfoByQTreeItem.isFiles)) {
					String str = null;
					if (!fileInfoByQTreeItem.equals(this.infoOfCurrentEditing)) {
						File file = getFile(fileInfoByQTreeItem.fileName);
						str = readBlackFile(file);
					} else {
						str = this.text.toPlainText();
					}
					if (str != null) {
						String findByLastOfLine = findByLastOfLine(str, text);
						if (findByLastOfLine != null) {
							return findByLastOfLine;
						}
					}
				}
			}
		}
		return null;
	}

	int repearFileInfos(fileInfo in) {
		int count = 0;
		if (in == null) {
			for (int i = 0; i < this.filesList.size(); i++) {
				fileInfo fileInfo = (fileInfo) this.filesList.get(i);
				if ((!fileInfo.isDir) && (!fileInfo.isFiles) && (fileInfo.isRoot == -1) && (!fileInfo.isFile)
						&& (!fileInfo.isKeyWordsList)) {
					if (getFile(fileInfo.fileName).exists()) {
						if (fileInfo.subfiles != null) {
							if (fileInfo.subfiles.size() > 0) {
								fileInfo.isFiles = true;
							} else {
								fileInfo.isFile = true;
								fileInfo.subfiles = null;
							}
						} else {
							fileInfo.isFile = true;
						}
					} else if (fileInfo.subfiles != null) {
						fileInfo.isDir = true;
					}
					p(languageTool.getString(664,fileInfo.getShowName()));
					count++;
				}
				if (fileInfo.subfiles != null) {
					count += repearFileInfos(fileInfo);
				}
			}
		} else {
			for (int i = 0; i < in.subfiles.size(); i++) {
				fileInfo fileInfo = (fileInfo) in.subfiles.get(i);
				if ((!fileInfo.isDir) && (!fileInfo.isFiles) && (fileInfo.isRoot == -1) && (!fileInfo.isFile)
						&& (!fileInfo.isKeyWordsList)) {
					if (getFile(fileInfo.fileName).exists()) {
						if (fileInfo.subfiles != null) {
							if (fileInfo.subfiles.size() > 0) {
								fileInfo.isFiles = true;
							} else {
								fileInfo.isFile = true;
								fileInfo.subfiles = null;
							}
						} else {
							fileInfo.isFile = true;
						}
					} else if (fileInfo.subfiles != null) {
						fileInfo.isDir = true;
					}
					p(languageTool.getString(664,fileInfo.getShowName()));
					count++;
				}
				if (fileInfo.subfiles != null) {
					count += repearFileInfos(fileInfo);
				}
			}
		}
		return count;
	}

	String clearPlusInShowName(fileInfo in) {
		StringBuilder sb = new StringBuilder();
		if (in == null) {
			for (int i = 0; i < this.filesList.size(); i++) {
				fileInfo fileInfo = (fileInfo) this.filesList.get(i);
				if (fileInfo.getShowName().indexOf("+") == 0) {
					String oldName = fileInfo.getShowName();
					fileInfo.setShowName(fileInfo.getShowName().substring(1, fileInfo.getShowName().length()));
					QTreeWidgetItem findTreeItemByFileInfo = findTreeItemByFileInfo(fileInfo, null);
					findTreeItemByFileInfo.setText(0, fileInfo.getShowName());
					if (fileInfo.fileName != null && fileInfo.fileName.equals(currentEditing.getName()))
						textTitle.setText(fileInfo.getShowName());
					sb.append(oldName + " -> " + fileInfo.getShowName() + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(clearPlusInShowName(fileInfo));
				}
			}
		} else {
			for (int i = 0; i < in.subfiles.size(); i++) {
				fileInfo fileInfo = (fileInfo) in.subfiles.get(i);
				if (fileInfo.getShowName().indexOf("+") == 0) {
					String oldName = fileInfo.getShowName();
					fileInfo.setShowName(fileInfo.getShowName().substring(1, fileInfo.getShowName().length()));
					QTreeWidgetItem findTreeItemByFileInfo = findTreeItemByFileInfo(fileInfo, null);
					findTreeItemByFileInfo.setText(0, fileInfo.getShowName());
					if (fileInfo.fileName != null && fileInfo.fileName.equals(currentEditing.getName()))
						textTitle.setText(fileInfo.getShowName());
					sb.append(oldName + " -> " + fileInfo.getShowName() + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(clearPlusInShowName(fileInfo));
				}
			}
		}
		return sb.toString();
	}

	void statCharCountForManyDoc() {
		String statCharCount = statCharCount(null);
		List<String> allLine = cheakDocument.getAllLine(statCharCount);
		int charCount = 0;
		for (String s : allLine) {
			String[] subString = cheakDocument.subString(s, "\t");
			if (!subString[1].isEmpty())
				charCount += Integer.valueOf(subString[1]);
		}
		getBMessageBox("多文档字数统计", "<b>有" + allLine.size() + "个文档纳入了统计范围：</b>\n<i>" + statCharCount + "</i>\n<b>共计"
				+ charCount + "个字符</b>");
	}

	String statCharCount(fileInfo in) {
		StringBuilder sb = new StringBuilder();
		if (in == null) {
			for (int i = 0; i < this.filesList.size(); i++) {
				fileInfo fileInfo = (fileInfo) this.filesList.get(i);
				if (fileInfo.getShowName().indexOf("+") == 0) {
					sb.append(fileInfo.getShowName() + "\t" + fileInfo.charCount + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(statCharCount(fileInfo));
				}
			}
		} else {
			for (int i = 0; i < in.subfiles.size(); i++) {
				fileInfo fileInfo = (fileInfo) in.subfiles.get(i);
				if (fileInfo.getShowName().indexOf("+") == 0) {
					sb.append(fileInfo.getShowName() + "\t" + fileInfo.charCount + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(statCharCount(fileInfo));
				}
			}
		}
//		if(sb.length() > 0 && sb.charAt(sb.length()-1) == '\n') {
//			return sb.substring(0, sb.length()-1);
//		}else 
		return sb.toString();
	}

	String clearEditPoint(fileInfo in) {
		StringBuilder sb = new StringBuilder();
		if (in == null) {
			for (int i = 0; i < this.filesList.size(); i++) {
				fileInfo fileInfo = (fileInfo) this.filesList.get(i);
				if (fileInfo.fileName != null && !fileInfo.fileName.equals(currentEditing.getName())
						&& fileInfo.editPoints != null && !fileInfo.editPoints.isEmpty()) {
					fileInfo.editPoints.clear();
					sb.append(fileInfo.getShowName() + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(clearEditPoint(fileInfo));
				}
			}
		} else {
			for (int i = 0; i < in.subfiles.size(); i++) {
				fileInfo fileInfo = (fileInfo) in.subfiles.get(i);
				if (fileInfo.fileName != null && !fileInfo.fileName.equals(currentEditing.getName())
						&& fileInfo.editPoints != null && !fileInfo.editPoints.isEmpty()) {
					fileInfo.editPoints.clear();
					sb.append(fileInfo.getShowName() + "\n");
				}

				if (fileInfo.subfiles != null) {
					sb.append(clearEditPoint(fileInfo));
				}
			}
		}

		return sb.toString();
	}

	int getFileInfoCount(fileInfo in) {
		int count = 0;
		if (in == null) {
			for (int i = 0; i < this.filesList.size(); i++) {
				count++;
				fileInfo fileInfo = (fileInfo) this.filesList.get(i);
				if (fileInfo.subfiles != null) {
					count += getFileInfoCount(fileInfo);
				}
			}
		} else {
			for (int i = 0; i < in.subfiles.size(); i++) {
				count++;
				fileInfo fileInfo = (fileInfo) in.subfiles.get(i);
				if (fileInfo.subfiles != null) {
					count += getFileInfoCount(fileInfo);
				}
			}
		}
		return count;
	}

	void applySettingsToAllTreeWidget(QTreeWidgetItem qt) {
		if (qt == null) {
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				fileInfo in = (fileInfo) topLevelItem.data(1, 0);
				topLevelItem.setExpanded(in.expaned);
				if (in.isFile) {
					if (in.charCount > 0) {
						topLevelItem.setIcon(0, this.ico_fileOfHasText);
					} else {
						topLevelItem.setIcon(0, this.ico_file);
					}
				}
				if (topLevelItem.childCount() > 0) {
					applySettingsToAllTreeWidget(topLevelItem);
				}
			}
		} else {
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				fileInfo in = (fileInfo) child.data(1, 0);
				if (in.isFile) {
					if (in.charCount > 0) {
						child.setIcon(0, this.ico_fileOfHasText);
					} else {
						child.setIcon(0, this.ico_file);
					}
				}
				child.setExpanded(in.expaned);
				if (child.childCount() > 0) {
					applySettingsToAllTreeWidget(child);
				}
			}
		}
	}

	Menu listMenuWithTreeWidget(QTreeWidgetItem qt, String methodname, boolean noselected) {
		Menu menu = null;
		if (qt == null) {
			menu = new Menu();
			for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(i);
				QAction QAction = new QAction(menu);
				if (noselected) {
					List<QTreeWidgetItem> checkedItems = null;
					if (isCheackable(this.draft)) {
						checkedItems = getCheckedItems();
					} else {
						checkedItems = this.tree.selectedItems();
					}
					for (QTreeWidgetItem currentItem : checkedItems) {
						if ((currentItem != null) && (topLevelItem.equals(currentItem))) {
							QAction.setDisabled(true);
						}
					}
				}
				QAction.setData(topLevelItem);
				QAction.setText(topLevelItem.text(0));
				QAction.setIcon(topLevelItem.icon(0));
				menu.addAction(QAction);
				if (topLevelItem.childCount() > 0) {
					Menu listMenuWithTreeWidget = listMenuWithTreeWidget(topLevelItem, methodname, noselected);
					QAction.setMenu(listMenuWithTreeWidget);
				}
			}
		} else if (qt.childCount() > 0) {
			menu = new Menu();
			for (int i = 0; i < qt.childCount(); i++) {
				QTreeWidgetItem child = qt.child(i);
				QAction action = new QAction(menu);
				if (noselected) {
					List<QTreeWidgetItem> checkedItems = null;
					if (isCheackable(this.draft)) {
						checkedItems = getCheckedItems();
					} else {
						checkedItems = this.tree.selectedItems();
					}
					for (QTreeWidgetItem currentItem : checkedItems) {
						if ((currentItem != null) && (child.equals(currentItem))) {
							action.setDisabled(true);
						}
					}
				}
				action.setData(child);
				action.setText(child.text(0));
				action.setIcon(child.icon(0));
				menu.addAction(action);
				if (child.childCount() > 0) {
					Menu listMenuWithTreeWidget = listMenuWithTreeWidget(child, methodname, noselected);
					action.setMenu(listMenuWithTreeWidget);
				}
			}
		}
		if (menu != null) {
			menu.triggered.connect(this, methodname);
			QFont font = menu.font();
			int size = ba.getUIFontSize(fontSize.menu);
			font.setPointSize(size);
			menu.setFont(font);
		}
		return menu;
	}

	void doubleClicked() {
		this.isDoubleClickedOnTreeItem = true;
	}

	void editFinished(QTreeWidgetItem qt, Integer col) {
//		p("testttt: "+qt.text(col));
		if (this.isDoubleClickedOnTreeItem) {
			this.isDoubleClickedOnTreeItem = false;
//			openFileByTreeItem(qt);
			fileInfo in = (fileInfo) qt.data(1, 0);
			if ((col.intValue() == 0) && (in != null) && (!qt.text(0).equals(in.getShowName()))) {
				in.setShowName(qt.text(col.intValue()));
				if (qt.equals(this.TreeWidgetItemOfCurrentEditing)) {
					this.textTitle.setText(in.getShowName());
				}
				this.mustSaveFileListFile = true;
			}
		}
		if (this.mustSaveFileListFile) {
			saveFileListFile();
			this.mustSaveFileListFile = false;
		}
	}

	public void reOpenProject() {
		String lastpro = (String) this.settings.value("app/lastUsedProject", "");
		try {
			openProject(lastpro);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void whenNoProjectOpend() {
		hideAllWidget();
		menubar.show();
		ba.blackShow(this, 0);
		setWindowTitle(appInfo.appName);
		findProject();
	}

	void findProject() {
		if (appInfo.mode == 0)
			showOpenProjectDialog();
		else
			findProject(null);
	}

	void findProject(keyWords k) {
		ArrayList<TextRegion> al = new ArrayList<>();
		ArrayList<TextRegion> al_ = new ArrayList();

		String finddir1 = "Files" + File.separator + "Black";
		String finddir2 = "BlackBackups";
		File[] roots = File.listRoots();
		for (File r : roots) {
			String find1 = r.getPath() + File.separator + finddir1;
			File dir1 = new File(find1);
			if (dir1.exists() && dir1.isDirectory()) {
				File[] files = dir1.listFiles();
				for (File f : files) {
					if (f.isDirectory()) {
						File[] ls = f.listFiles();
						for (File l : ls) {
							if (l.toString().indexOf(".blackpro") != -1) {
								TextRegion tr = cheakDocument.subString(l.getName(), 0, ".blackpro");
								tr.filename = l.toString();
								tr.showname = l.lastModified() + "";
								al.add(tr);
//								System.out.println(time.msToTime(t));
							}
						}
					}
				}
			}

			String find2 = r.getPath() + File.separator + finddir2;
			File dir2 = new File(find2);
			if (dir2.exists() && dir2.isDirectory()) {
				File[] files = dir2.listFiles();
				for (File f : files) {
					if (f.isDirectory()) {
						File[] ls = f.listFiles();
						for (File l : ls) {
							if (l.toString().indexOf(".blackpro") != -1) {
								TextRegion tr = cheakDocument.subString(l.getName(), 0, ".blackpro");
								tr.filename = l.toString();
								tr.showname = l.lastModified() + "";
								al.add(tr);
							}
						}
					}
				}
			}
		}

		// 根据最后的修改时间重新排序
		while (al.size() > 0) {
			int maxindex = 0;
			long max = 0;
			for (int i = 0; i < al.size(); i++) {
				TextRegion tr = al.get(i);
				long time = Long.valueOf(tr.showname);
				if (time > max) {
					max = time;
					maxindex = i;
				}
			}
			al_.add(al.get(maxindex));
			al.remove(maxindex);
		}
		ArrayList<String> older = null;
		// 列出项目条目
		if (k == null) {
			k = new keyWords(this, false) {

				@Override
				public void whenWindowSizeChanged(QSize paramQSize) {
					// TODO Auto-generated method stub

				}

				@Override
				public void whenSubmit(QTreeWidgetItem paramQTreeWidgetItem) {
					// TODO Auto-generated method stub
					TextRegion tr = (TextRegion) paramQTreeWidgetItem.data(4, 4);
					if (tr.text.equals("$open")) {
						this.close();
						showOpenProjectDialog();
					} else if (tr.text.equals("$refind"))
						findProject(this);
					else {
						this.close();
						try {
							openProject(tr.filename);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

				@Override
				public void whenNumberTwoPressed(QTreeWidgetItem paramQTreeWidgetItem) {
					// TODO Auto-generated method stub

				}

				@Override
				public void whenNumberThreePressed(QTreeWidgetItem paramQTreeWidgetItem) {
					// TODO Auto-generated method stub

				}

				@Override
				public void whenHide() {
					// TODO Auto-generated method stub

				}

				@Override
				public void whenDelPressed(QTreeWidgetItem paramQTreeWidgetItem) {
					// TODO Auto-generated method stub

				}

				@Override
				public void selectionChanged(QTreeWidgetItem paramQTreeWidgetItem) {
					// TODO Auto-generated method stub

				}
			};
			k.tree.UsedToProjectPanelOrKeywordsList = 2;
			findview = 3;
			k.setMinimumWidth(width() / 3 * 2);
			setDialogAtCenter(k);
		} else {
			older = new ArrayList();
			for (int i = 0; i < k.tree.topLevelItemCount(); i++) {
				Object data = k.tree.topLevelItem(i).data(4, 4);
				if (data != null) {
					TextRegion tr = (TextRegion) data;
					if (!tr.text.equals("$open") && !tr.text.equals("$refind")) {
						older.add(tr.filename);
					}
				}
			}
			k.tree.clear();
		}
		String currentProjectPath = null;
		if (projectFile != null)
			currentProjectPath = projectFile.getPath();

		for (TextRegion tr : al_) {
			QTreeWidgetItem ti = new QTreeWidgetItem();
			boolean isNew = true;
			if (older != null)
				for (String s : older) {
					if (s.equals(tr.filename)) {
						isNew = false;
						break;
					}
				}
			else
				isNew = false;
			if (currentProjectPath != null && currentProjectPath.equals(tr.filename)) {
				QFont f = ti.font(0);
				f.setUnderline(true);
				ti.setFont(0, f);
			}
			ti.setText(0, tr.text + " - (" + tr.filename + ")");
			if (isNew) {
				QFont f = ti.font(0);
				f.setItalic(true);
				f.setBold(true);
				ti.setFont(0, f);
				ti.setForeground(0, new QBrush(new QColor(Qt.GlobalColor.blue)));
			}
			ti.setData(4, 4, tr);
			long t = System.currentTimeMillis() - Long.valueOf(tr.showname);
			ti.setData(3, 3, languageTool.getString(666,time.intTimeToString(time.msToTimeSimple(t))));
			k.tree.addTopLevelItem(ti);
		}
		QTreeWidgetItem ti_refind = new QTreeWidgetItem();
		ti_refind.setForeground(0, new QBrush(new QColor(Qt.GlobalColor.blue)));
		ti_refind.setText(0, languageTool.getString(667));
		ti_refind.setData(4, 4, new TextRegion("$refind", 0, 0));
		QFont f = ti_refind.font(0);
		f.setPointSize(f.pointSize() + 2);
		f.setBold(true);
		f.setItalic(true);
		ti_refind.setFont(0, f);
		k.tree.addTopLevelItem(ti_refind);

		QTreeWidgetItem ti_openProject = new QTreeWidgetItem();
		ti_openProject.setForeground(0, new QBrush(new QColor(Qt.GlobalColor.darkYellow)));
		ti_openProject.setText(0, languageTool.getString(668));
		ti_openProject.setData(4, 4, new TextRegion("$open", 0, 0));
		ti_openProject.setFont(0, f);
		k.tree.addTopLevelItem(ti_openProject);

		QTreeWidgetItem topLevelItem = k.tree.topLevelItem(0);
		if (topLevelItem != null)
			k.tree.setCurrentItem(topLevelItem);
		k.setWindowTitle(languageTool.getString(669));
	}

	public void setDialogAtCenter(QWidget w) {
		QRect g = rect();
		int x = g.x() + (g.width() - w.width()) / 2;
		int y = g.y() + (g.height() - w.height()) / 2;
		QPoint mapToGlobal = mapToGlobal(new QPoint(x, y));
		w.setGeometry(mapToGlobal.x(), mapToGlobal.y(), w.width(), w.height());
		w.show();
	}
	public void closeAllDialog() {
		p(languageTool.getString(670));
		if(logsBox != null) {
			logsBox.close();
			logsBox = null;
		}
		if(finddialog != null) {
			finddialog.close();
			finddialog = null;
		}
		if(settingsDialog != null) {
			settingsDialog.close();
			settingsDialog = null;
		}
		if(keywords != null) {
			keywords.close();
			keywords = null;
		}
		if(keywordsForFindLine != null) {
			keywordsForFindLine.close();
			keywordsForFindLine = null;
		}
	}
	public void closeProject() {
		if ((this.projectFile != null) && (this.projectInfo != null)) {
			//关闭项目前先将所有子对话框关闭，防止主线程被挂起后调用p()方法输出日志因为log对话框不为null而无法返回
			//保险起见关闭所有对话框
			closeAllDialog();
			ba.scanMarkstatFile();
			p(languageTool.getString(671));
			saveHistoryOfFileEditing();
			saveFindHistory();
			this.settings.setValue(appInfo.lastUsedProject, this.projectFile.getAbsolutePath());
			if (this.markstatIsChanged) {
				p(languageTool.getString(672));
				writeToMarkStatFile();
			}
			if (this.marktextIsChanged) {
				p(languageTool.getString(673));
				writeToMarkFile();
			}
			this.markstat = null;
			this.marktext = null;
			this.markTextData = null;

			if (this.lastEditFile != null) {
				this.projectInfo.setProperty(appInfo.lastEditFile, this.lastEditFile.getName());
				this.lastEditFile = null;
			}
			if (this.currentEditing != null) {
				this.projectInfo.setProperty(appInfo.editing, this.currentEditing.getName());
				//下面的方法不仅会关闭当前文件，还会保存全部未保存文档的内容到磁盘
				closeCurrentEditing();
			}else saveAllDocuments();
			
			saveProjectFile();
			
			if (this.fileListChanged) {
				p(languageTool.getString(674));
				saveFileListFile();
			}
			p(languageTool.getString(675));
			clearProjectRuntimeData();
			p(languageTool.getString(676));
		}
		disposeOpenedFile();
		resetTree();
		ba.keyboard.removeProjectKeyData();
		findLine.clear();
		findBox.clear();
		setSaved(true);
	}
	void clearProjectRuntimeData() {
		suspendMainThreadForWriteBlackFileThread();
		this.projectFile = null;
		this.projectInfo = null;
		this.filesList = null;
		filesListFile = null;
		lastBackUpTime = 0L;
		this.countmessage.clear();
		hideAllWidget();
		menubar.show();
		des_doc = null;
		ba.clearLockStatus();
	}

	void saveHistoryOfFileEditing() {
		File history = new File(
				this.projectFile.getParent() + File.separator + "Settings" + File.separator + "HistoryOfFileEditing");
		io.writeObjFile(history, this.moveList);
		this.projectInfo.setProperty(appInfo.moveIndex, String.valueOf(this.moveIndex));
	}

	void readHistoryOfFileEditing() {
		File history = new File(
				this.projectFile.getParent() + File.separator + "Settings" + File.separator + "HistoryOfFileEditing");
		if (history.exists()) {
			this.moveList = ((ArrayList) io.readObjFile(history));
			// 如果反序列化出错
			if (moveList == null)
				moveList = new ArrayList<>();
			for (int i = 0; i < this.moveList.size(); i++) {
				if (findFileShowName((String) this.moveList.get(i)) == null) {
					this.moveList.remove(i);
				}
			}
			this.moveIndex = Integer.valueOf(this.projectInfo.getProperty(appInfo.moveIndex, "0")).intValue();
			if (this.moveIndex >= this.moveList.size()) {
				this.moveIndex = (this.moveList.size() - 1);
			}
		} else {
			this.moveList = new ArrayList();
			this.moveIndex = 0;
		}
	}

	public void exit() {
		if ((text != null) && (text.isVisible())) {
			text.show();
		}
		closeEvent(null);
	}

	private void closeAct(QEvent event) {
		saveWritingViewState();
		if (writingView > 0) {
			// exitwritingView(Boolean.valueOf(false));
			super.geometry = saveGeometry;
		}
		System.out.println("geometry is "+geometry());
		hide();
		if (brunnableForOSD != null)
			brunnableForOSD.stop();
		closeProject();
		settings.setValue(appInfo.appVersionKey, appInfo.appVersion);


		p(languageTool.getString(677));
		if (event != null) {
			event.ignore();
		}
		
		this.settings.setValue(appInfo.windowOpacity, this.windowOpacity);
		this.settings.setValue(appInfo.saveMode, this.saveMode);
		this.settings.setValue(appInfo.yellowForceColor, this.yellowForceColor);
		this.settings.setValue(appInfo.alpha_windowBackground, this.alpha_windowBackground);
		this.settings.setValue(appInfo.quietMode, quietMode);
		this.settings.setValue(appInfo.lineAndDocFirst, this.LineAndDocFirst_keywords);
		settings.setValue(appInfo.withoutBlueValue, withoutBuleValue + "");
		super.whenClose();
		this.settings.sync();
		//此处校验cfg文件，防止被篡改
		try {
			String md5Checksum = MD5.getMD5Checksum(super.cfgFile);
			String encrypt = des.encrypt(md5Checksum);
			File f = new File(super.cfgFile);
			File data = new File(f.getParent()+File.separator+"data");
			if(!data.exists()) data.createNewFile();
			io.writeTextFile(data, encrypt, "utf-8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void closeEvent(QCloseEvent event) {
		closeAct(event);
		bAction.whenBlackClose(this);
		suspendMainThreadForWriteBlackFileThread();
		//因为event被忽略了，所以需要手动退出虚拟机
		System.exit(0);
	}
	/**
	 * 阻塞main线程，直到所有保存black文件的线程都执行完毕
	 */
	void suspendMainThreadForWriteBlackFileThread() {
		while(writeBlackFileThreadCount != 0) {
			System.out.println(languageTool.getString(678)+writeBlackFileThreadCount);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void openfile(fileInfo info, boolean resetView) {
		if (this.isLoadFile) {
			p(languageTool.getString(679));
			return;
		}
		String parent = this.projectFile.getParent();
		final File file = new File(parent + File.separator + "Files" + File.separator + info.fileName);
		if (file.exists()) {
			this.infoOfCurrentEditing = info;
			afterLoadFileActions.add(new action() {
				public void action() {
//					if (!black.this.isVisible()) {
//						ba.blackShow(black.this, 3);
//					}
					if(ba.tempData.get(appInfo.tempName.firstOpenDocument.name()) == null) {
						ba.tempData.put(appInfo.tempName.firstOpenDocument.name(), "");
						ba.blackShow(b, 3);
					}
					if (!black.this.addToMoveListEnd) {
						black.this.addMoveInfo(file.getName());
					} else {
						black.this.addMoveInfoOnEnd(file.getName());
					}
				}
			});
			openBlackFile(file);
		}
	}

	public void resetEditorView(fileInfo info) {
		int cursorPos = info.cursorPos;
		int scrollbarValue = info.scrollbarValue;
		QTextCursor cursor = b.btext.text.textCursor();
		if (info.selectionStart == -1) {
			cursor.setPosition(cursorPos);
		}
		else {
			cursor.setPosition(info.selectionStart);
			cursor.setPosition(cursorPos, MoveMode.KeepAnchor);
		}
		this.btext.text.setTextCursor(cursor);
		this.btext.text.verticalScrollBar().setValue(scrollbarValue);
	}

	public void openFileByTreeItem(QTreeWidgetItem currentItem) {
		if (this.isLoadFile) {
			p(languageTool.getString(679));
			return;
		}
		if (currentItem != null) {
			fileInfo in = (fileInfo) currentItem.data(1, 0);
			// 有时in会为空，下面这行只为了不报错而已
			if (in == null)
				return;

			if (!in.isDir) {
				if (in.isRoot == -1) {
					if (in.isFiles) {
						if ((this.currentEditing != null) && (this.currentEditing.getName().equals(in.fileName))) {
							return;
						}
						changedFileOfCurrentEdit();
						this.TreeWidgetItemOfCurrentEditing = currentItem;
						this.infoOfCurrentEditing = in;
						this.textTitle.setText(currentItem.text(0));
						this.textTitle.setFileIcon(currentItem.icon(0));
						openfile(in, true);
					} else if (in.isFile) {
						if ((this.currentEditing != null) && (this.currentEditing.getName().equals(in.fileName))) {
							return;
						}
						changedFileOfCurrentEdit();
						this.TreeWidgetItemOfCurrentEditing = currentItem;
						this.infoOfCurrentEditing = in;
						this.textTitle.setText(currentItem.text(0));
						this.textTitle.setFileIcon(currentItem.icon(0));
						openfile(in, true);
					} else if (in.isKeyWordsList) {
						if ((this.currentEditing != null) && (this.currentEditing.getName().equals(in.fileName))) {
							return;
						}
						changedFileOfCurrentEdit();
						this.TreeWidgetItemOfCurrentEditing = currentItem;
						this.infoOfCurrentEditing = in;
						this.textTitle.setText(currentItem.text(0));
						this.textTitle.setFileIcon(currentItem.icon(0));
						openfile(in, true);
					}
				}
			}
		}
	}

	public void openfile() {
		Qt.MouseButtons mouseButtons = QApplication.mouseButtons();
		if (mouseButtons.value() == Qt.MouseButton.LeftButton.value()) {
			QTreeWidgetItem currentItem = this.tree.currentItem();
			openFileByTreeItem(currentItem);
		}
	}

	/**
	 * 读取文件，如果文件已经程序缓存，则从缓存中获取文件，如果没有被缓存，则从磁盘读取文件
	 * 
	 * @param file
	 * @return
	 */
	public String readBlackFile(File file) {
		String text = "";
		fileInfo fi = findFileInfoByFileName(file.getName(), null);
		String showName = fi.getShowName();
		if (showName == null) {
			showName = "";
		}
		dataForOpenedFile openedfile = findInOpenedFiles(file.getName());
		if (openedfile != null) {
			if (openedfile.editor != null) {
				p(languageTool.getString(681,showName));
				text = openedfile.editor.text.toPlainText();
			} else {
				p(languageTool.getString(683,showName));
				text = openedfile.content;
				if(text == null) {
					if(fi.fileName.equals(file.getName())) {
						p(languageTool.getString(685,showName));
						text = this.text.toPlainText();
					}
				}
			}
		} else {
			long readfilea = System.currentTimeMillis();
			text = io.readBlackFileByLine(file);

			long readfileb = System.currentTimeMillis();
			p(languageTool.getString(687,(readfileb - readfilea),showName));
			addFileToOpenedFilesData(new dataForOpenedFile(file.getName(), text, null, true));
		}
		return text;
	}

	public void openBlackFile(File file) {
		if(finddialog != null && finddialog.isVisible()) finddialog.close();
//		if(text!=null && text.caret!=null && text.caret.isVisible())text.caret.hide();
		if (se != null && se.isEnabled()) {
			se.setEnabled(false);
			timeMessage.setGraphicsEffect(se);
		}

		this.loadFileTime_start = System.currentTimeMillis();
		boolean isSaved = true;
		String showName = findFileInfoByFileName(file.getName(), null).getShowName();
		if (showName == null) {
			showName = "";
		}
		final dataForOpenedFile openedfile = findInOpenedFiles(file.getName());
		if (openedfile != null) {
			isSaved = openedfile.isSaved;
			openedfile.isSaved = true;
			if (openedfile.editor != null) {
				p(languageTool.getString(690,showName));
				if (writingView == 0) {
//					this.effectForTextTitle.setOpacity(0.0D);
//					this.textTitle.setGraphicsEffect(this.effectForTextTitle);
				}
				long a = System.currentTimeMillis();
				setLoadFileMessage(showName + "\n0%");
				isLoadFile = true;
				bRunnable bt = new bRunnable(1, false, false, true, true) {
					public void run() {
						textLayout.addWidget(openedfile.editor.text);
						black.this.btext = openedfile.editor;
						black.text = openedfile.editor.text;
					
						openedfile.editor.text.setVisible(true);
						black.text.setEnabled(true);

						File file = (File) Data("file");
						boolean isSaved = ((Boolean) Data("isSaved")).booleanValue();
						long starttime = ((Long) Data("startTime")).longValue();
						String showName = (String) Data("showName");

						black.this.whenLoadFileDone(file, isSaved, starttime, showName, true);

						black.this.setLoadFileMessage(showName + "\n100%");
					}
				};
				bt.setData("file", file);
				bt.setData("isSaved", Boolean.valueOf(isSaved));
				bt.setData("startTime", Long.valueOf(a));
				bt.setData("showName", showName);
				bt.start();
			} else {
				p(languageTool.getString(692,showName));
				this.isLoadFile = true;

				initEditor();

				text.setEnabled(true);
				this.textTitle.setEnabled(true);
				setTextStyles.tools.setEnabled(true);

				String text = openedfile.content;

				String str = text;

				long a = System.currentTimeMillis();
				int part = text.length() / 100;
//				hideAllWidget();
				new loadFile(this, str, showName, part, file, isSaved, a, false);
			}
			this.textTitle.setEnabled(true);
			setTextStyles.tools.setEnabled(true);
		} else {
			String text = null;
			long readfilea = System.currentTimeMillis();
			text = io.readBlackFileByLine(file);

			long readfileb = System.currentTimeMillis();
			p(languageTool.getString(687,(readfileb - readfilea),showName));
			if (text == null) {
				return;
			}
			this.isLoadFile = true;

			initEditor();

			addFileToOpenedFilesData(new dataForOpenedFile(file.getName(), null, this.btext, true));
			this.text.setEnabled(true);
			this.textTitle.setEnabled(true);
			setTextStyles.tools.setEnabled(true);
			String str = text;
			long a = System.currentTimeMillis();
			this.doNotSet_UnSave = true;
			int part = text.length() / 100;
//			int part = 1;
//			hideAllWidget();

			new loadFile(this, str, showName, part, file, isSaved, a, false);

		}
	}

	void hideAllWidget() {
		if (this.menubar != null) {
			this.menubar.hide();
		}
		if (this.dock != null) {
			this.dock.hide();
		}
		if (this.toolbar != null) {
			this.toolbar.hide();
		}
		if (this.textTitle != null) {
			this.textTitle.hide();
		}
		if(setTextStyles != null) {
			setTextStyles.tools.hide();
		}
		if (textWidget != null) {
			textWidget.hide();
		}
		if (text != null) {
			text.hide();
			if(text.verticalScrollBar() != null) {
				text.verticalScrollBar().hide();;
			}
			if(text.horizontalScrollBar() != null) {
				text.horizontalScrollBar().hide();;
			}
		}
		if (statusBar() != null) {
			statusBar().hide();
		}
		new setMenus(this);
		synTime();
	}

	void setTextVScrollBarLocation() {
		if(text == null) return;
		text.verticalScrollBar().adjustSize();
		QRect g = text.verticalScrollBar().geometry();
		if (writingView == 0) {
			text.verticalScrollBar().setParent(textWidget);
			text.verticalScrollBar().setGeometry(textWidget.width() - g.width(), 0, g.width(), textWidget.height());
		} else {
			text.verticalScrollBar().setParent(this);
//			QPoint map = b.mapFrom(b.textWidget, b.textWidget.pos());
			text.verticalScrollBar().setGeometry(width() - g.width(), 0, g.width(), height());
		}
	}

	void whenLoadFileDone(File fileOfLoading, boolean isSaved, long a, String showName, boolean opened) {
		new setMenus(this);
		long b = System.currentTimeMillis();
		if (!opened) {
			if (writingView == 0) {
				this.effectForTextTitle.setOpacity(1.0D);
				this.textTitle.show();
				if (this.btext != null) {
					text.verticalScrollBar().show();
				}
			}
		} else {
			if (writingView == 0) {
				this.effectForTextTitle.setOpacity(1.0D);
			}
		}

//		setTextMargins();

		applyColorChange();
		p(languageTool.getString(697,(b - a),showName));
		
		debugPrint("whenload1");
		this.doNotSet_UnSave = false;
		if (keywords != null) {
			keywords.text = text;
		}
		this.btext.text.setFocus();
		this.currentEditing = fileOfLoading;
		synCharCount();
		this.doNotSet_UnSave = true;
		if (!opened) {
			//此方法可能会导致text控件延迟显示，因为默认文档并没有完全加载，当需要还原的光标位置靠近文档末尾时，会导致界面卡死
			resetEditorView(findFileInfoByFileName(fileOfLoading.getName(), null));
//			showAllWidget();
		}
		debugPrint("whenload2");


		documentTextChanged();
		//必须在documentTextChanged后执行
		synTextChange();
		this.doNotSet_UnSave = false;
		if (this.btext.charCountAtToday == -1) {
			String charCountOfLastInput = this.infoOfCurrentEditing.charCountOfLastInput;
			if (charCountOfLastInput != null) {
				int index = charCountOfLastInput.indexOf(" ");
				String date = charCountOfLastInput.substring(0, index);
				String charCount = charCountOfLastInput.substring(index + 1, charCountOfLastInput.length());
				if (date.equals(time.getCurrentDate("-"))) {
					this.btext.charCountAtToday = (this.charCountWithoutEnter - Integer.valueOf(charCount).intValue());
				} else {
					this.btext.charCountAtToday = this.charCountWithoutEnter;
				}
			} else {
				this.btext.charCountAtToday = this.charCountWithoutEnter;
			}
		}
		setSaved(isSaved);
		debugPrint("whenload3");

		if (writingView == 0) {
			text.verticalScrollBar().show();
		} else {
			text.verticalScrollBar().hide();
		}
		updateOSDMessages(-1);
		this.textChanged = true;
		text.setFocus();

		debugPrint("whenload4");

		if (rootIs(TreeWidgetItemOfCurrentEditing, reserach))
			inReserach = true;
		else
			inReserach = false;
//		btext.cursorPosChanged();

		btext.keywordListFile = findKeyWordsList(TreeWidgetItemOfCurrentEditing);

		btext.vScrollBarMaxValue = text.verticalScrollBar().maximum();
		
		//因为afterloadFile前后设置多个后设置的会覆盖前面设置的，所以引入了action数组，该数组内的acton会执行一次，然后被全部销毁
		for(action act:afterLoadFileActions) {
			act.action();
		}
		afterLoadFileActions.clear();
		
		debugPrint("whenload5");
		update();
		
		
		//缩放到全局缩放值
		ba.zoom(-1);
		
		text.rangeChanged();
		text.setUndoRedoEnabled(true);
		
		//有时文档加载完成后，如果光标没有移动过，输入的文字不会继承光标前面的格式，所以添加下面的代码进行调整
		QTextCursor tc = this.text.textCursor();
		tc.movePosition(MoveOperation.PreviousCharacter,MoveMode.KeepAnchor);
		QTextCharFormat cf = tc.charFormat();
		text.setCurrentCharFormat(cf);
		
		//还原自动滚屏数据
		execCommand(languageTool.getString(700,infoOfCurrentEditing.autoscrollvalue));
		debugPrint("whenload6");
		//必须放到最后
		this.isLoadFile = false;

	}

	/**
	 * 为整个文档设定格式
	 */
	public void setStyleForCurrentDocument() {
		System.out.println("charcount: "+text.charCountOfDoc());
		if(text.charCountOfDoc() > 1) return;
		
		needResetStyleOfDoc = false;
		doNotSet_UnSave = true;

		// 为非关键词文档中的无格式文本设定默认格式
		QTextCursor c = text.textCursor();
		c.select(QTextCursor.SelectionType.Document);
		c.beginEditBlock();
		bAction.setDocumentStyle(this, c);
		c.endEditBlock();

	
		doNotSet_UnSave = false;

	}

	public int getOnly() {
		return Only++;
	}

	public void saveDocumentByUser() {
		if (isHasSaveTimer()) {
			removeAllSaveTimer();
		}
		saveProjectChanged();
	}

	public void setSaved(boolean saved) {
		if (saved) {
			String title = null;
			if ((this.projectFile != null) && (this.projectInfo != null)) {
				title = getProjectName() + " - " + appInfo.appName;
			} else {
				title = appInfo.appName;
			}
			setWindowTitleB(title);
			QFont font = this.textTitle.ui.lineEdit.font();
			font.setItalic(false);
			this.textTitle.ui.lineEdit.setFont(font);
		} else {
			String title = null;
			if ((this.projectFile != null) && (this.projectInfo != null)) {
				title = getProjectName() + "* - " + appInfo.appName;
			} else {
				title = appInfo.appName;
			}
			setWindowTitleB(title);
			QFont font = this.textTitle.ui.lineEdit.font();
			font.setItalic(true);
			this.textTitle.ui.lineEdit.setFont(font);
			if ((getAutoSave() != -1) && (!isHasSaveTimer())) {
				addSaveTimer();
			}
		}
		this.saved = saved;
	}

	void synCharCount() {
		int charCount = this.btext.text.charCountOfDoc();
		this.countmessage.setText(languageTool.getString(701,charCount));
		update();
	}

	void addEditPoint() {
		if (donotAddEditPoint || text.preeditStringPos != -1) {
			return;
		}
		QTextCursor tcc = text.textCursor();
		editPoint lastEditPoint = infoOfCurrentEditing.getLastEditPoint();
		if(lastEditPoint != null)System.out.println("oldPos: "+lastEditPoint.oldPos+ "当前光标位置："+tcc.position()+" "+lastEditPoint);
		if(lastEditPoint != null && lastEditPoint.getPos()+text.contentsChangePos[3] == tcc.position()) {
			infoOfCurrentEditing.resetPosChanged(tcc.position(),lastEditPoint);
			//更新最后的编辑点是不需要显式设置oldpos，因为setPos方法会自动将前一个pos设置为oldpos
			lastEditPoint.setPos(tcc.position());
			debugPrint(languageTool.getString(705));
		}
		else {
			//新增编辑点时，因为没有储存pos，所以需要手动设定一个oldpos
			infoOfCurrentEditing.addEditPoint(tcc.position(),btext.lastpos);
			debugPrint(languageTool.getString(706));
		}
	}

	ArrayList<TextRegion> resetMarkTextData() {
		ArrayList<TextRegion> al = new ArrayList();
		for (TextRegion tr : this.markTextData) {
			String[] subb = cheakDocument.subString(tr.text, appInfo.keywordsSeparator);
			String[] sub = cheakDocument.subString(subb[0], "·");

			TextRegion r = null;
			TextRegion r2 = null;
			if (!subb[1].equals("")) {
				r = new TextRegion(sub[0] + appInfo.keywordsSeparator + subb[1], 0, 0);
				r.filename = subb[1];
				if (!sub[1].equals("")) {
					r2 = new TextRegion(sub[1] + appInfo.keywordsSeparator + subb[1], 0, 0);
					r2.filename = subb[1];
					r.describe = tr.text;
					r2.describe = tr.text;
				}
			} else {
				r = new TextRegion(sub[0], 0, 0);
				if (!sub[1].equals("")) {
					r.describe = tr.text;
					r2 = new TextRegion(sub[1], 0, 0);
					r2.describe = tr.text;
				}
			}
			r.showname = sub[0];
			al.add(r);
			if (!sub[1].equals("")) {
				r2.showname = sub[1];
				al.add(r2);
			}
		}
		return al;
	}

	void setAutoFindInKeywords() {
		findKeywordsByPinyin = !getBooleanValueFromSettings(appInfo.usePinyinFindKeywords, "true");
		settings.setValue(appInfo.usePinyinFindKeywords, findKeywordsByPinyin);
		setLoadFileMessage(languageTool.getString(707,findKeywordsByPinyin));
	}

	/**
	 * 
	 * @param fullPY全拼编码
	 * @param doublePY双拼编码，如果没有双拼编码，此参数为null
	 */
	void findMarkString(String fullPY, String doublePY) {
		if (findKeywordsByPinyin)
			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					String pinyin = fullPY;
//					if (markTextData == null) {
//						return;
//					}
					ArrayList<TextRegion> all = (ArrayList<TextRegion>) ba.tempData.get("document_lastPinyinSeg");
					if (all == null) {
						all = ba.getAnsjResult(false);
						ba.tempData.put("document_lastPinyinSeg", all);
					}

					if (all.size() == 0)
						all = resetMarkTextData();

					if (!cheakDocument.isAllNoChineseString(pinyin)) {
						String allchars = "";
						boolean inlineChinese = false;
						for (int i = 0; i < pinyin.length(); i++) {
							char charAt = pinyin.charAt(i);
							String[] hanyuPinyinStringArray = PinyinHelper.toHanyuPinyinStringArray(charAt);
							if (hanyuPinyinStringArray != null) {
								String substring = hanyuPinyinStringArray[0].substring(0,
										hanyuPinyinStringArray[0].length() - 1);
								if (allchars.equals(""))
									allchars = substring;
								else
									allchars = allchars + '\'' + substring;
								inlineChinese = true;
							}
						}
						if (inlineChinese) {
							pinyin = allchars;
						}
					}
					// System.out.println(pinyin);
					
					//判断输入法输出的拼音串使用的分割符号，现阶段只遇到了使用分号或空格来分割拼音的输入法，所以只判断这两种情况
					char spChar = ' ';
					
					if(pinyin.indexOf("\'") != -1) spChar = '\'';
					else if(pinyin.indexOf(' ') != -1) spChar = ' ';
					//编码中的每个拼音
					ArrayList<String> args = cheakDocument.checkCommandArgs(pinyin, spChar);
					
					ArrayList<TextRegion> al = new ArrayList();

					for (TextRegion r : all) {
						String[] subString = cheakDocument.subString(r.text, appInfo.keywordsSeparator);
						//每个关键词去除关键词描述后的词条
						String s = subString[0];
						int index = -1;
						int count = 0;
						//指示关键词中是否都是中文
						//如果关键词包含英文等可能需要特殊处理权重
						boolean isAllChinese = true;
						A: for (int i = 0; i < s.length(); i++) {
							//关键词中的每一个字符
							char c = s.charAt(i);
							//编码中如果包含这个字符，就表示这个关键词中含有英文字符
							//针对包含英文的关键词的简易算法
							if(pinyin.indexOf(c) != -1) {
								isAllChinese = false;
								count++;
								continue;
							}
							ArrayList<String> arrayList = (ArrayList) args.clone();
							String[] p = PinyinHelper.toHanyuPinyinStringArray(c);
							if (p != null) {
								int j = p.length;
								for (int a = 0; a < j; a++) {
									String str = p[a];
									// 截取不带声调的拼音
									String pinyin_marktext = str.substring(0, str.length() - 1);
									for (int x = 0; x < arrayList.size(); x++) {
										String s_pinyin = (String) arrayList.get(x);
										if ((s_pinyin.equals(pinyin_marktext)) // 整个拼音全部匹配
												|| // 或者
													// 是输入的拼音串中包含的最后一个拼音，且这个拼音长度小于3，例如li，且声母匹配
										((x == arrayList.size() - 1) && (s_pinyin.length() < 3)
												&& (pinyin_marktext.indexOf(s_pinyin) == 0))) {
											if ((count == 0) && (x > 0)) {
												break A;
											}
											count++;
											if (index == -1) {
												index = a;
											}
											arrayList.remove(x);
											break;
										}
//									else if(count > 0) {
//										count=0;
//									}
									}
								}
							}
						}
						if (count > 0) {
							if (isAllChinese) {
								if(count < args.size()) {
									// 匹配到的数量小于输入数量，表示有字没有匹配到，将匹配度降为0
									r.start = index;
									r.end = 0;
								}else {
									//全汉字的关键词的权重需要考虑匹配次数和关键词长度
									float aa = count;
									float bb = s.length();
									float f = aa / bb;
									r.start = index;
									r.end = ((int) (f * 1000.0F));
								}
							} else {
								//对于包含英文的关键词，权重不考虑关键词的长度，只考虑匹配次数
								r.start = index;
								r.end = count;
							}
//						System.out.println(s+"匹配数："+"输入数："+args.size()+"匹配度："+r.end);
							al.add(r);
						}
					}
					ArrayList<TextRegion> resetIndex = resetIndex(al);
					uiRun(black.this, new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							initKeyWordsDialog();
							keywords.tree.UsedToProjectPanelOrKeywordsList = 1;
							findview = 0;
							keywords.tree.setFrameShape(QFrame.Shape.NoFrame);
							if (keywords.tree.topLevelItemCount() > 0) {
								keywords.tree.clear();
							}
							int index = 0;
							if (!getBooleanValueFromSettings(appInfo.moreFindMarkWithPinyin, "false")) {
								if (resetIndex.size() > 0) {
									TextRegion tr = (TextRegion) resetIndex.get(0);
									QTreeWidgetItem ti = getTreeItem(keywords.tree);
									String str = null;
									if (tr.filename == null) {
										str = tr.showname;
									} else {
										str = tr.showname + " (" + tr.filename + ")";
									}
									ti.setText(0, str);
									ti.setData(1, 0, tr);
									ti.setData(1, 1, Integer.valueOf(index));
									if (doublePY != null)
										tr.setData(doublePY);
									else
										tr.setData(fullPY);
									text.tr = tr;
								}
							} else {
//							keywords.tree.setFont();
								for (TextRegion tr : resetIndex) {
									if (index > 10)
										break;
//								TextRegion tr = (TextRegion) resetIndex.get(0);
									QTreeWidgetItem ti = getTreeItem(keywords.tree);
									String str = null;
									String charByNumber = getCharByNumber(index);
									if (tr.filename == null) {
										str = charByNumber + tr.showname;
									} else {
										str = charByNumber + tr.showname + " (" + tr.filename + ")";
									}
									ti.setText(0, str);
									ti.setData(1, 0, tr);
									ti.setData(1, 1, Integer.valueOf(index));
									index++;
								}
								if (index != 0) {
									TextRegion tr = (TextRegion) keywords.tree.topLevelItem(0).data(1, 0);
									if (doublePY != null)
										tr.setData(doublePY);
									else
										tr.setData(fullPY);
									text.tr = tr;
								}
							}

							keywords.hideStatusBar = true;
							keywords.donotShowMoreText = true;

							keywords.show();
							if (keywords.tree.topLevelItemCount() > 0) {
//								keywords.message.setText("输入大写字母序号可选中项目 | 输入Z可切换成全名");
								if (!getBooleanValueFromSettings(appInfo.moreFindMarkWithPinyin, "false")) {
									showDialogAtEditorCaretPosTop(text, keywords);
									keywords.tree.setCurrentItem(
											keywords.tree.topLevelItem(keywords.tree.topLevelItemCount() - 1));
									keywords.tree.scrollToItem(
											keywords.tree.topLevelItem(keywords.tree.topLevelItemCount() - 1));
								} else {
									showDialogAtLeftBottom(text, keywords);
									keywords.tree.setCurrentItem(keywords.tree.topLevelItem(0));
									keywords.tree.scrollToItem(keywords.tree.topLevelItem(0));
								}

							} else {
								keywords.hide();
							}
						}
					});

				}
			}).start();
	}

	public void documentTextChanged() {
		if (text.preeditStringPos != -1) {
			return;
		}
		ba.showKeywordsListByCurrentChar();
		if (!this.doNotSet_UnSave) {
			
//			if(text.hasFocus()) {
//				//文本更改后自动隐藏鼠标指针
//				QCursor oc = QApplication.overrideCursor();
//				if(oc == null)
//					QApplication.setOverrideCursor(new QCursor(CursorShape.BlankCursor));
//			}
			
			
			if (this.saved) {
				setSaved(!this.saved);
			}
			
			removeAllTimer(appInfo.timerInfoType.projectAllChanageSaved.value);
			
			addEditPoint();

			long currentTime = System.currentTimeMillis();
			long t = currentTime - infoOfCurrentEditing.lastTextChangeTime;
			if (t < 300000) {
				infoOfCurrentEditing.editTime_today += t;
				infoOfCurrentEditing.editTime+=t;
			}
			infoOfCurrentEditing.lastTextChangeTime = currentTime;

			this.textChanged = true;
			if (!isLoadFile && keywordsForFindLine != null && keywordsForFindLine.isVisible()) {
				int needReSerach = (int) ba.tempData.getOrDefault("needReSerach", 0);
				if(needReSerach == 0) {
//					keywordsForFindLine.tree.clear();
					int messageBoxWithYesNO = getMessageBoxWithYesNO(languageTool.getString(714), languageTool.getString(715), languageTool.getString(716), languageTool.getString(717), null, 0,
							true);
					if (messageBoxWithYesNO == 0) {
						keywordsForFindLine.setWindowTitle(languageTool.getString(718));
						ba.tempData.put("needReSerach", 1);
//						keywordsForFindLine.hide();
					} else {
						testReFind();
					}
				}


			}
		}
	}

	void synTextChange() {
		if (text == null || text.preeditStringPos != -1) {
			return;
		}
		int a = plusCharCount;
		if (text == null) {
			return;
		}
		this.textChanged = false;
		uiRun(black.this, new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(text != null && !text.isDisposed())
				charCountWithoutEnter = text.charCountOfDoc();
			}
		});

		updateOSDMessages(2);
		uiRun(black.this, new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				countmessage.setText(languageTool.getString(719,charCountWithoutEnter));
				if (TreeWidgetItemOfCurrentEditing != null) {
					if (infoOfCurrentEditing.charCount != charCountWithoutEnter) {
						infoOfCurrentEditing.charCount = charCountWithoutEnter;
						fileListChanged = true;
					}
					if (infoOfCurrentEditing.isFile) {
						Object info = TreeWidgetItemOfCurrentEditing.data(99, 99);

						if (charCountWithoutEnter > 0) {
							if (info == null || !info.equals(languageTool.getString(720))) {
								textTitle.setFileIcon(ico_fileOfHasText);
								TreeWidgetItemOfCurrentEditing.setIcon(0, ico_fileOfHasText);
								TreeWidgetItemOfCurrentEditing.setData(99, 99, languageTool.getString(720));
							}
						} else if (info == null || !info.equals(languageTool.getString(722))) {
							textTitle.setFileIcon(ico_file);
							TreeWidgetItemOfCurrentEditing.setIcon(0, ico_file);
							TreeWidgetItemOfCurrentEditing.setData(99, 99, languageTool.getString(722));
						}
					}
				}
			}
		});

	}

	static String c(int v, int v2, int value) {
		int x = v / value * value;
		int x_ = v2 / value * value;
		if (x != x_)
			return String.valueOf(x_);
		else
			return null;
	}

	void selectionChanged() {
		showFind = false;
		if (text != null && !text.isAccicesable())
			return;
		if(setTextStyles != null)
			setTextStyles.cursorPositionChanged();

		int charCount = this.text.charCountOfDoc();
		int length = this.text.charCountOfSelection();
		if (length > 0) {
			monitorOff = true;
			String mes = languageTool.getString(724,length,charCount);
			countmessage.setText(mes);
			if (writingView > 0) {
				ArrayList<timerInfo> timer = getAllTimer(appInfo.timerInfoType.showCharCount.value);
				timerInfo ti = null;
				if (timer.size() > 0) {
					ti = timer.get(0);
					ti.timerName = mes + " | " + caretPos.text();
				} else {
					ti = new timerInfo(true, mes + " | " + caretPos.text(), null);
					ti.showProgress = false;
					ti.type = appInfo.timerInfoType.showCharCount.value;
					ti.isNew = true;
					addTimer(ti);
				}
				//选中文本后不会立即提示字符数，因为如果立即提示会有性能损失，可能阻塞UI线程
//				if (brunnableForOSD != null) {
//					new Thread(new Runnable() {
//						
//						@Override
//						public void run() {
//							// TODO Auto-generated method stub
//							synTimeAction(brunnableForOSD);
//						}
//					}).start();
//				}
			}
		} else {
			countmessage.setText(languageTool.getString(726,charCount));
			monitorOff = false;
			removeAllTimer(appInfo.timerInfoType.showCharCount.value);
		}
		repaint();
	}

	public void saveBlackFile(final File file, final String text) {
		writeBlackFileThreadCount++;
		System.out.println("设置写入文件线程计数。写入文件线程数量："+writeBlackFileThreadCount);
		new Thread(new Runnable() {
			public void run() {
				if(io.writeBlackFile(file, text, null)) {
					System.out.println("写入文件"+file.getName()+"成功");
				}else System.out.println("写入文件"+file.getName()+"成功");
//				int i=0;
//				while(i<=10) {
//					System.out.println("等待"+i);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					i++;
//				}
				writeBlackFileThreadCount--;
				System.out.println("清除写入文件线程计数。写入文件线程数量："+writeBlackFileThreadCount);
			}
		}).start();
	}

	/**
	 * 保存所有文件，包括当前所编辑的文件 如果要保存全部文件应该使用此方法，saveAllFile方法不会保存正在编辑的文件
	 */
	public void saveAllDocuments() {
		saveDocuments(true);
	}

	public void changedFileOfCurrentEdit() {
		if (this.currentEditing == null) {
			return;
		}
		
		if(infoOfCurrentEditing.getShowName().isEmpty()) {
			String title = text.document().findBlockByNumber(0).text();
			infoOfCurrentEditing.setShowName(title);
			textTitle.setText(title);
			TreeWidgetItemOfCurrentEditing.setText(0, title);
		}
		
		this.lastEditFile = this.currentEditing;

		dataForOpenedFile find = findInOpenedFiles(this.currentEditing.getName());
		if (find != null) {
			find.editor = this.btext;
			find.isSaved = this.saved;
		} else {
			addFileToOpenedFilesData(
					new dataForOpenedFile(this.currentEditing.getName(), null, this.btext, this.saved));
		}
		if (text.textCursor().selectedText().length() == 0) {
			int position = this.btext.text.textCursor().position();
			this.infoOfCurrentEditing.cursorPos = position;
			this.infoOfCurrentEditing.selectionStart = -1;
		} else {
			QTextCursor tc = text.textCursor();
			int selectionStart = tc.selectionStart();
			int selectionEnd = tc.selectionEnd();
			this.infoOfCurrentEditing.cursorPos = selectionEnd;
			this.infoOfCurrentEditing.selectionStart = selectionStart;
		}
		saveCharCountOfLastInput();
		int value = this.btext.text.verticalScrollBar().value();
		this.infoOfCurrentEditing.scrollbarValue = value;
		this.fileListChanged = true;

		this.infoOfCurrentEditing = null;
		this.TreeWidgetItemOfCurrentEditing = null;
		deleteEditor();

		this.textTitle.clearTextTitle();
		this.textTitle.setEnabled(false);
		setTextStyles.tools.setEnabled(false);
		this.currentEditing = null;
	}

	String findFileShowName(String filename) {
		fileInfo findFileInfoByFileName = findFileInfoByFileName(filename, null);
		if (findFileInfoByFileName != null) {
			return findFileInfoByFileName.getShowName();
		}
		return null;
	}

	/**
	 * 保存所有文件，但不包括当前文件
	 */
	public void saveAllFile() {
		for (dataForOpenedFile opened : this.openedFiles) {
			if (opened != null && opened.editor != null && opened.editor.text != null && !opened.isSaved) {
				p(languageTool.getString(734,opened.filename,findFileShowName(opened.filename)));
				saveBlackFile(getFile(opened.filename), opened.editor.text.toHtml());
				opened.isSaved = true;
			}
		}
	}

	public void clearTempFiles() {
		closeCurrentEditing();
		for (dataForOpenedFile opened : this.openedFiles) {
			if (!opened.isSaved) {
				p(languageTool.getString(734,opened.filename,findFileShowName(opened.filename)));
				saveBlackFile(getFile(opened.filename), opened.editor.text.toHtml());
			}
		}
		disposeOpenedFile();
		p(languageTool.getString(738,this.openedFiles.size()));
	}

	void saveCharCountOfLastInput() {
		this.infoOfCurrentEditing.charCountOfLastInput = (time.getCurrentDate("-") + " "
				+ (this.charCountWithoutEnter - this.btext.charCountAtToday));
	}

	public void saveDocuments(boolean saveView) {
		if ((this.currentEditing != null) && (!this.saved)) {
			String str = text.toHtml();
			
			p(languageTool.getString(739,findFileShowName(this.currentEditing.getName())));
			
			saveBlackFile(this.currentEditing, str);
			setSaved(true);
		}
		saveAllFile();
		if (saveView) {
			if (text.textCursor().selectedText().length() == 0) {
				int position = this.btext.text.textCursor().position();
				this.infoOfCurrentEditing.cursorPos = position;
				this.infoOfCurrentEditing.selectionStart = -1;
			} else {
				QTextCursor tc = text.textCursor();
				int selectionStart = tc.selectionStart();
				int selectionEnd = tc.selectionEnd();
				this.infoOfCurrentEditing.cursorPos = selectionEnd;
				this.infoOfCurrentEditing.selectionStart = selectionStart;
			}
			int value = this.btext.text.verticalScrollBar().value();
			this.infoOfCurrentEditing.scrollbarValue = value;
			saveCharCountOfLastInput();
			this.fileListChanged = true;
		}
	}

	public void closeCurrentEditing() {
		if (this.currentEditing != null) {
			if(writingView > 0) {
				exitWritingView();
			}
			this.lastEditFile = this.currentEditing;
			saveDocuments(true);
			disposeOpenedFile(currentEditing.getName());
			this.infoOfCurrentEditing = null;
			this.TreeWidgetItemOfCurrentEditing = null;
			bTextEdit backup = deleteEditor();
			//关闭并delete编辑器，以便释放所占用的内存
			if(backup != null && !backup.isDisposed()) {
//				backup.close();
				backup.dispose();
			}
			this.textTitle.clearTextTitle();
			this.textTitle.setEnabled(false);
			setTextStyles.tools.setEnabled(false);
			this.currentEditing = null;
			
			if(!ba.isDockVisible()) {
				hideFilesTree();
			}
		}
	}

	public void findInGoldenDict() {
		findInGoldenDict(null);
	}

	/**
	 * 如果在主线程被挂起后调用此方法，执行动作将在主线程恢复运行后继续执行
	 * black参数必须提供
	 * @param run
	 */
	static void uiRun(black b, Runnable run) {
//		debugPrint("uiRunAction start");
		hasUIRunnable = true;
		try {
			QApplication.staticMetaObject.invokeMethod(() -> b.run(run), ConnectionType.AutoConnection);
		} catch (QUnsuccessfulInvocationException e) {
			e.printStackTrace();
		}
//		System.out.println("-----------");
		while (hasUIRunnable) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
//				e.printStackTrace();
			}
		}
//		debugPrint("uiRunAction end");
	}
	/**
	 * 此方法不能为static
	 * @param run
	 */
	void run(Runnable run) {
		hasUIRunnable = true;
		run.run();
		hasUIRunnable = false;
	}

	public void findInGoldenDict(String find) {
		boolean canFind = false;
//		String user = "golden";
//		if (userName.equals("Administrator")) {
//			canFind = true;
//			user = "Administrator";
//		} else {
//			String timeServer = "http://www.ntsc.ac.cn";// 中国科学院国家授时中心服务器地址
//			String hourOfDay = time.getWebsiteDateHourOfDay(timeServer);
//			if (hourOfDay.equals("@@")) {
//				p("不允许启动GoldenDict，因为无法获取网络时间！");
//				return;
//			} else if (Integer.valueOf(hourOfDay) < 22) {
//				p(""不允许启动GoldenDict，因为不在允许的时间段！);
//				return;
//			}
//		}

		String path = getGoldenDictPath();
		if ((path != null) && (new File(path).exists())) {
			canFind = true;
		} else {
			String filepath = getFileDialog(languageTool.getString(743), languageTool.getString(744));
			if (!filepath.equals("")) {
				setGoldenDictPath(filepath);
				findInGoldenDict(find);
				return;
			}
		}
		if (canFind) {
//			DesUtils des = new DesUtils("black"); // 自定义密钥
//			String key = null;
//			String value = getStringValueFromSettings(appInfo.additionalInfo, "");
//			if (value.isEmpty()) {
//				p("不允许启动GoldenDict，因为尚未设定管理员加密密码！");
//				return;
//			}
//			try {
//				key = des.decrypt(value);
//			} catch (Exception e1) {
//				// TODO Auto-generated catch block
//				p("对加密密码解密时出现错误！");
//				return;
//			}

			String findtext = null;
			String str;
			if (find == null) {
				str = text.textCursor().selectedText();
				if (str.length() > 0) {
					findtext = str;
				} else {
					findtext = seclectText(text, false);
				}
				if (findtext != null) {
				}
			} else {
				findtext = find;
			}
			try {
//				Runtime.getRuntime().exec("./Tools/RunAs/lsrunas.exe /user:"+user+" /password:"+key+" /domain: /command:\""+path+ " \"" + findtext + "\"\" /runpath:c:");
				Runtime.getRuntime().exec(path + " \"" + findtext + "\"");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	void showLogs() {
		File file = new File("./Logs/log.txt");
		if (file.exists()) {
			String readTextFile = io.readTextFile(file, "gbk");
			getBMessageBox(" WinRun4J日志 | " + file.length() / 1024 + "KB", readTextFile).show();
		} else {
			getMessageBox("文件不存在", "WinRun4J Logs文件不存在\\n文件路径：./Logs/log.txt");
		}
	}

	void clearWinRun4jLogs() {
		File file = new File("./Logs/log.txt");
		if (file.exists()) {
			boolean isclear = io.writeTextFile(file, "", "gbk");
			if (isclear)
				getMessageBox("清理成功", "已成功清理WinRun4J日志");
			else
				getMessageBox("清理不成功", "文件可能正在使用中，WinRun4J可能正在运行");
		} else {
			getMessageBox("文件不存在", "WinRun4J Logs文件不存在\\n文件路径：./Logs/log.txt");
		}
	}

	public static String seclectText(bTextEdit text, boolean isSelection) {
		QTextCursor tc = text.textCursor();
		int pos = tc.position();
		int pos_start = -1;
		int pos_end = -1;
		String[] syls = new String[] { "，", "。", ",", ".", "？", "?", "！", "!", "“", "”" };
		do {
			if (tc.atBlockStart()) {
				pos_start = pos;
				break;
			}
			tc.movePosition(QTextCursor.MoveOperation.PreviousCharacter);
			int position = tc.position();
			tc.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
			String str = tc.selectedText();
			char charAt = str.charAt(0);
			if (cheakDocument.cheakOnly(charAt, syls)) {
				pos_start = position + 1;
				break;
			}
			tc.setPosition(position);
		} while (!tc.atBlockStart());
		pos_start = tc.position();

		tc.setPosition(pos);
		for (;;) {
			if (tc.atBlockEnd()) {
				pos_end = pos;
				break;
			}
			tc.movePosition(QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor);
			String str = tc.selectedText();
			char charAt = ' ';
			if (!str.equals("")) {
				charAt = str.charAt(0);
			}
			if (cheakDocument.cheakOnly(charAt, syls)) {
				pos_end = tc.position() - 1;
				break;
			}
			if (tc.atBlockEnd()) {
				pos_end = tc.position();
				break;
			}
			tc.clearSelection();
		}
		tc.clearSelection();
		tc.setPosition(pos_start);
		tc.setPosition(pos_end, QTextCursor.MoveMode.KeepAnchor);
		if (isSelection) {
			text.setTextCursor(tc);
		}
		return tc.selectedText();
	}

	public void setGoldenDictPath(String path) {
		DesUtils desUtils = new DesUtils("black");
		try {
			this.settings.setValue(appInfo.goldenDictPath, desUtils.encrypt(path));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getGoldenDictPath() {
		DesUtils desUtils = new DesUtils("black");
		String value = null;
		String path = (String) settings.value(appInfo.goldenDictPath);
		if (path == null)
			return null;
		try {
			value = desUtils.decrypt(path);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	public String getDirDialog(String title) {
		String dir = QFileDialog.getExistingDirectory(this, title);
		return dir;
	}

	public String getFileDialog(String title, String filter) {
		String openFileName = QFileDialog.getOpenFileName(this, title, "", filter).result;
		return openFileName;
	}

	public String getFileDialog() {
		String openFileName = QFileDialog.getOpenFileName(this, "", "", "Images (*.png *.xpm *.jpg)").result;

		return openFileName;
	}

	void createProject() {
		Result<String> names = QFileDialog.getSaveFileName(this, languageTool.getString(1297,appInfo.appName), "",
				appInfo.appName + languageTool.getString(758));
		String saveFileName = null;
		if(names != null) saveFileName = names.result;
		
		if ((saveFileName != null) && (!saveFileName.equals(""))) {
			File f = new File(saveFileName);
			int lastIndexOf = f.getName().lastIndexOf('.');
			if (lastIndexOf == -1)
				lastIndexOf = f.getName().length();
			String projectName = f.getName().substring(0, lastIndexOf);
			createAndOpenProject(f.getParent(), projectName);
		}
	}

	QTreeWidgetItem findTreeItemByFileInfo(fileInfo fileinfo, QTreeWidgetItem in) {
		QTreeWidgetItem i = null;
		if (in == null) {
			for (int a = 0; a < this.tree.topLevelItemCount(); a++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(a);
				QTreeWidgetItem findTreeItemByFileName = findTreeItemByFileInfo(fileinfo, topLevelItem);
				if (findTreeItemByFileName != null) {
					i = findTreeItemByFileName;
					break;
				}
			}
		} else {
			fileInfo info = (fileInfo) in.data(1, 0);
			if (info.equals(fileinfo)) {
				i = in;
			} else if (in.childCount() > 0) {
				for (int a = 0; a < in.childCount(); a++) {
					QTreeWidgetItem child = in.child(a);
					i = findTreeItemByFileInfo(fileinfo, child);
					if (i != null) {
						break;
					}
				}
			}
		}
		return i;
	}

	QTreeWidgetItem findTreeItemByFileName(String filename, QTreeWidgetItem in) {
		QTreeWidgetItem i = null;
		if (in == null) {
			for (int a = 0; a < this.tree.topLevelItemCount(); a++) {
				QTreeWidgetItem topLevelItem = this.tree.topLevelItem(a);
				QTreeWidgetItem findTreeItemByFileName = findTreeItemByFileName(filename, topLevelItem);
				if (findTreeItemByFileName != null) {
					i = findTreeItemByFileName;
					break;
				}
			}
		} else {
			fileInfo info = (fileInfo) in.data(1, 0);
			if (filename.equals(info.fileName)) {
				i = in;
			} else if (in.childCount() > 0) {
				for (int a = 0; a < in.childCount(); a++) {
					QTreeWidgetItem child = in.child(a);
					i = findTreeItemByFileName(filename, child);
					if (i != null) {
						break;
					}
				}
			}
		}
		return i;
	}

	fileInfo findFileInfoByFileName(String filename, fileInfo in) {
		fileInfo i = null;
		if (in == null) {
			for (fileInfo info : this.filesList) {
				fileInfo findFileInfoByFileName = findFileInfoByFileName(filename, info);
				if (findFileInfoByFileName != null) {
					i = findFileInfoByFileName;
					break;
				}
			}
		} else if (filename.equals(in.fileName)) {
			i = in;
		} else if (in.subfiles != null) {
			for (fileInfo info : in.subfiles) {
				i = findFileInfoByFileName(filename, info);
				if (i != null) {
					break;
				}
			}
		}
		return i;
	}

	void createAndOpenProject(String dirPath, String projectName) {
		File prodir = new File(dirPath + File.separator + projectName);
		boolean ok = prodir.mkdir();
		if (ok) {
			File profile = new File(prodir.getAbsolutePath() + File.separator + projectName + ".blackpro");
			Properties pro = new Properties();
			pro.setProperty("fileindex", "0");
			pro.setProperty(appInfo.projectName, projectName);
			cfg_read_write.cfg_write(pro, profile);

			File settingsdir = new File(profile.getParent() + File.separator + "Settings");
			File filesdir = new File(profile.getParent() + File.separator + "Files");
			if (!settingsdir.exists()) {
				settingsdir.mkdir();
			}
			if (!filesdir.exists()) {
				filesdir.mkdir();
			}
			File listFile = new File(profile.getParent() + File.separator + "Settings" + File.separator + "fileslist");
			ArrayList<Object> list = new ArrayList();

			fileInfo draft_info = new fileInfo(languageTool.getString(759), null);
			draft_info.isRoot = 0;
			draft_info.initFloder();

			fileInfo reserach_info = new fileInfo(languageTool.getString(760), null);
			reserach_info.isRoot = 1;
			reserach_info.initFloder();

			fileInfo recycle_info = new fileInfo(languageTool.getString(761), null);
			recycle_info.isRoot = 2;
			recycle_info.initFloder();

			list.add(draft_info);
			list.add(reserach_info);
			list.add(recycle_info);

			io.writeObjFile(listFile, list);
			closeProject();
			try {
				openProject(profile.getAbsolutePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// 在草稿箱内添加一个新文件
			tree.setCurrentItem(draft);
			addFile();
			QTreeWidgetItem currentItem = this.tree.currentItem();
			openFileByTreeItem(currentItem);
		}
	}

	void resetTree() {
		this.tree.clear();
		if (keywordsForFindLine != null)
			keywordsForFindLine.tree.clear();
	}

	void showOpenProjectDialog() {
		Result r = QFileDialog.getOpenFileName(this, languageTool.getString(762), "", languageTool.getString(764,appInfo.appName));
		if(r == null)return;
		String openFileName = r.result.toString();
		if (!openFileName.equals("")) {
			try {
				openProject(openFileName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			showAllWidget();
		} else {
			if (projectFile != null)
				return;

			File file = new File("./Pros/默认项目/默认项目.blackpro");
			if (file.exists())
				try {
					openProject(file.getPath());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
	}

	void checkProjectFile() {
		File filedir = new File(this.projectFile.getParent() + File.separator + "Files" + File.separator);
		if ((filedir.exists()) && (filedir.isDirectory())) {
			String[] list = filedir.list();
			this.superfluousFiles = new ArrayList();
			String[] arrayOfString1;
			int j = (arrayOfString1 = list).length;
			for (int i = 0; i < j; i++) {
				String s = arrayOfString1[i];
				fileInfo info = findFileInfoByFileName(s, null);
				if (info == null) {
					p(languageTool.getString(766,s));
					this.superfluousFiles.add(s);
				}
			}
			String filenames = "";
			for (String s : this.superfluousFiles) {
				filenames = filenames + s + "\n";
			}
			if ((this.superfluousFiles != null) && (this.superfluousFiles.size() > 0)) {
				QMessageBox message = new QMessageBox(this);
				QPushButton cancel = message.addButton(QMessageBox.StandardButton.Cancel);
				cancel.setText(languageTool.getString(768));
				QPushButton ok = message.addButton(QMessageBox.StandardButton.Ok);
				ok.setText(languageTool.getString(769));
				ok.clicked.connect(this, "deleteSuperfluousFiles()");

				message.setText(languageTool.getString(770,filenames));
				message.setWindowTitle(languageTool.getString(771));
				message.setIconPixmap(this.ico_warning.pixmap(48, 48));
				message.show();
			}
		}
	}

	void deleteSuperfluousFiles() {
		if ((this.superfluousFiles != null) && (this.superfluousFiles.size() > 0)) {
			StringBuilder sb = new StringBuilder();
			for (String filename : this.superfluousFiles) {
				File file = getFile(filename);
				if (file.exists()) {
					String isD = null;
					boolean isDelete = file.delete();

					if (isDelete) {
						isD = languageTool.getString(772);
					} else {
						isD = languageTool.getString(773);
						file.deleteOnExit();
					}
					if (dbm) {
						p(languageTool.getString(774) + filename + " " + isD);
						sb.append(languageTool.getString(776) + filename + " " + isD + "\n");
					}
				}
			}
			this.superfluousFiles = null;
			if (!dbm)
				return;
			bmessageBox bMessageBox = getBMessageBox(languageTool.getString(779), sb.toString());
			bMessageBox.show();
		}
	}
	void disposeOpenedFile(String filename) {
		p(languageTool.getString(780,openedFiles.size(),filename));
		Iterator<dataForOpenedFile> it = openedFiles.iterator();
		while(it.hasNext()) {
			dataForOpenedFile opened = it.next();
			if(opened.filename.equals(filename)) {
				p(languageTool.getString(783));
				blacktext editor = opened.editor;
				if (editor != null) {
					bTextEdit te = editor.text;
					editor.text = null;
					te.dispose();
					editor = null;
					opened.content = null;
				}
				
				it.remove();
			}
			
		}	
		p(languageTool.getString(784,this.openedFiles.size()));
	}
	void disposeOpenedFile() {
		p(languageTool.getString(785));
		for (dataForOpenedFile opened : this.openedFiles) {
			blacktext editor = opened.editor;
			if (editor != null) {
				bTextEdit te = editor.text;
				editor.text = null;
				te.dispose();
				editor = null;
			}
			opened.content = null;
		}
		this.openedFiles.removeAll(this.openedFiles);
		p(languageTool.getString(784,this.openedFiles.size()));
	}

	void synFindHistoryToCombox() {
		this.findBox.clear();
		if (this.finddialog != null) {
			this.finddialog.ui.findText.clear();
		}
		for (int i = this.findHistory.size() - 1; i >= 0; i--) {
			this.findBox.insertItem(this.findHistory.size() - 1 - i, (String) this.findHistory.get(i));
			if (this.finddialog != null) {
				this.finddialog.ui.findText.insertItem(this.findHistory.size() - 1 - i,
						(String) this.findHistory.get(i));
			}
		}
	}

	/**
	 * 打开项目 如果已经打开了一个项目，则先关闭项目
	 * 
	 * @param projcetFilePath
	 * @throws IOException
	 */
	void openProject(String projcetFilePath) throws IOException {
		ba.tempData.put(appInfo.tempName.openingProject.name(), "1");
		File profile = new File(projcetFilePath);
		if (projectFile != null && (projectFile.getCanonicalPath().equals(profile.getCanonicalPath()))) {
			p(languageTool.getString(787));
			return;
		}
		if (projectFile != null && projectInfo != null) {
			closeProject();
		}
		if (profile.exists()) {
			this.projectInfo = cfg_read_write.cfg_read(profile);
			if (profile.length() == 0 || projectInfo == null || projectInfo.isEmpty()) {
//				userName = "Administrator";
				menubar.show();
				ba.blackShow(this, 0);
				getMessageBox(languageTool.getString(788), languageTool.getString(789));

//				getMessageBox(languageTool.getString(788), "载入项目时出现错误\n\n已切换到管理员模式，以便恢复数据");
			}
			String lastBackUpTime_string = projectInfo.getProperty(appInfo.lastBackUpTime, "0");
			lastBackUpTime = Long.valueOf(lastBackUpTime_string);

			this.filesListFile = new File(
					profile.getParent() + File.separator + "Settings" + File.separator + "fileslist");
			Object readObjFile = io.readObjFile(this.filesListFile);
			if (readObjFile != null) {
				this.filesList = ((ArrayList) readObjFile);
				this.projectFile = profile;
				//调用blackShow会检查是否启用了访问控制，如果启用了访问控制就会弹出密码输入框
				//在密码输入框关闭前，此行代码之后的代码不会被执行
				show();
				ba.blackShow(this, 3);
				//检查是否点击了密码输入框中的打开其他项目或关闭当前项目按钮
				if(ba.tempData.get(appInfo.tempName.stopOpenProject.name()) != null) {
					ba.tempData.remove(appInfo.tempName.stopOpenProject.name());
					clearProjectRuntimeData();
					//必须放在上一行代码后面remove
					ba.tempData.remove(appInfo.tempName.openingProject.name());
					return;
				}
				if(ba.autoLockIsEnabled() && des_doc == null) {
					ba.tempData.remove(appInfo.tempName.openingProject.name());
					getMessageBox(languageTool.getString(792), languageTool.getString(793));
					ba.blackShow(this, 0);
					hideAllWidget();
					menubar.show();
					return;
				}
				ba.blackShow(this, 3);

				readFindHistory();
				readHistoryOfFileEditing();
				if (this.moveList.size() > 0) {
					this.doNotAddToMoveList = true;
				}
				String editing = this.projectInfo.getProperty(appInfo.editing);

				checkProjectFile();
				repearFileInfos(null);
				ListProjectFiles();
				setGitMenu();
				ba.keyboard.readProjectKeyData();
				if (editing != null) {
					File file = getFile(editing);
					if (file.exists()) {
						QTreeWidgetItem findTreeItemByFileName = findTreeItemByFileName(file.getName(), null);
						if (findTreeItemByFileName != null) {
							this.TreeWidgetItemOfCurrentEditing = findTreeItemByFileName;
							this.infoOfCurrentEditing = ((fileInfo) findTreeItemByFileName.data(1, 0));
							this.tree.setCurrentItem(findTreeItemByFileName);

							openFileByTreeItem(this.TreeWidgetItemOfCurrentEditing);
						}
					} else
						ba.blackShow(this, 0);
				} else
					ba.blackShow(this, 0);
				String lastEditFile = this.projectInfo.getProperty(appInfo.lastEditFile);
				if (lastEditFile != null) {
					File lasteditfile = getFile(lastEditFile);
					if (lasteditfile.exists()) {
						this.lastEditFile = lasteditfile;
					}
				}
				setSaved(true);
				this.toolbar.setEnabled(true);
				statusBar().setEnabled(true);
				if (this.moveList.size() > 0) {
					this.doNotAddToMoveList = false;
				}
				showAllWidget();

				readMarkFile();
				if (marktext != null) {
					getMarkFileText();
				}
				
			} else {
				projectFile = null;
				projectInfo = null;
				menubar.show();
				ba.blackShow(this, 0);
				getMessageBox(languageTool.getString(792), languageTool.getString(795));
				whenNoProjectOpend();
			}
		} else {
			whenNoProjectOpend();
		}
//		showAllWidget();
		ba.tempData.remove(appInfo.tempName.openingProject.name());
	}

	ArrayList<QTreeWidgetItem> getFolderFiles(fileInfo info) {
		ArrayList<fileInfo> subfiles = info.subfiles;
		ArrayList<QTreeWidgetItem> al = new ArrayList();
		if (subfiles == null) {
			return al;
		}
		for (fileInfo in : subfiles) {
			if (in.isDir) {
				QTreeWidgetItem qt = new QTreeWidgetItem();
				Qt.ItemFlags flags = qt.flags();
				flags.set(new Qt.ItemFlag[] { Qt.ItemFlag.ItemIsEditable });
				qt.setFlags(flags);
				qt.setText(0, in.getShowName());
				qt.setData(1, 0, in);
				qt.setIcon(0, this.ico_folder);
				ArrayList<QTreeWidgetItem> folderFiles = getFolderFiles(in);
				qt.addChildren(folderFiles);

				al.add(qt);
			} else if (in.isFiles) {
				QTreeWidgetItem qt = new QTreeWidgetItem();
				Qt.ItemFlags flags = qt.flags();
				flags.set(new Qt.ItemFlag[] { Qt.ItemFlag.ItemIsEditable });
				qt.setFlags(flags);
				qt.setText(0, in.getShowName());
				qt.setData(1, 0, in);
				qt.setIcon(0, this.ico_files);
				ArrayList<QTreeWidgetItem> folderFiles = getFolderFiles(in);
				qt.addChildren(folderFiles);

				al.add(qt);
			} else if (in.isKeyWordsList) {
				QTreeWidgetItem qt = new QTreeWidgetItem();
				Qt.ItemFlags flags = qt.flags();
				flags.set(new Qt.ItemFlag[] { Qt.ItemFlag.ItemIsEditable });
				qt.setFlags(flags);
				qt.setText(0, in.getShowName());
				qt.setData(1, 0, in);
				qt.setIcon(0, this.ico_keywordsList);
				al.add(qt);
			} else if (in.isFile) {
				QTreeWidgetItem qt = new QTreeWidgetItem();
				Qt.ItemFlags flags = qt.flags();
				flags.set(new Qt.ItemFlag[] { Qt.ItemFlag.ItemIsEditable });
				qt.setFlags(flags);
				qt.setText(0, in.getShowName());
				qt.setData(1, 0, in);
				qt.setIcon(0, this.ico_file);
				al.add(qt);
			}
		}
		return al;
	}

	void ListProjectFiles() {
		if (this.filesList != null) {
			resetTree();
			for (int i = 0; i < this.filesList.size(); i++) {
				fileInfo fi = (fileInfo) this.filesList.get(i);
				if (fi.isRoot != -1) {
					if (fi.isRoot == 0) {
						this.draft = new QTreeWidgetItem(this.tree);
						this.draft.setIcon(0, this.ico_draft);
						this.draft.setText(0, fi.getShowName());
						this.draft.setData(1, 0, fi);
						this.draft.addChildren(getFolderFiles(fi));
						setEditable(this.draft, false);
					} else if (fi.isRoot == 1) {
						this.reserach = new QTreeWidgetItem(this.tree);
						this.reserach.setIcon(0, this.ico_reserach);
						this.reserach.setText(0, fi.getShowName());
						this.reserach.setData(1, 0, fi);
						this.reserach.addChildren(getFolderFiles(fi));
						setEditable(this.reserach, false);
					} else if (fi.isRoot == 2) {
						this.recycle = new QTreeWidgetItem(this.tree);
						this.recycle.setIcon(0, this.ico_recycle);
						this.recycle.setText(0, fi.getShowName());
						this.recycle.setData(1, 0, fi);
						this.recycle.addChildren(getFolderFiles(fi));
						setEditable(this.recycle, false);
					}
				} else if (fi.isDir) {
					QTreeWidgetItem qt = new QTreeWidgetItem(this.tree);
					qt.addChildren(getFolderFiles(fi));
					qt.setText(0, fi.getShowName());
					qt.setIcon(0, this.ico_folder);
					qt.setData(1, 0, fi);
					setEditable(qt, false);
				} else if (fi.isFiles) {
					QTreeWidgetItem qt = new QTreeWidgetItem(this.tree);
					qt.addChildren(getFolderFiles(fi));
					qt.setText(0, fi.getShowName());
					qt.setIcon(0, this.ico_files);
					qt.setData(1, 0, fi);
					setEditable(qt, false);
				} else if (fi.isKeyWordsList) {
					QTreeWidgetItem qt = new QTreeWidgetItem(this.tree);
					qt.setText(0, fi.getShowName());
					qt.setIcon(0, this.ico_keywordsList);
					qt.setData(1, 0, fi);
					setEditable(qt, false);
				} else if (fi.isFile) {
					QTreeWidgetItem qt = new QTreeWidgetItem(this.tree);
					qt.setText(0, fi.getShowName());
					qt.setIcon(0, this.ico_file);
					qt.setData(1, 0, fi);
					setEditable(qt, false);
				}
			}
			applySettingsToAllTreeWidget(null);
		}
	}

	QTreeWidgetItem getTreeItem(QTreeWidgetItem parent) {
		return new QTreeWidgetItem(parent);
	}

	QTreeWidgetItem getTreeItem(QTreeWidget parent) {
		return new QTreeWidgetItem(parent);
	}

	QTreeWidgetItem findKeyWordsList(QTreeWidgetItem current) {
		if(current == null)return null;
		QTreeWidgetItem parent = current.parent();
		if (parent != null) {
			for (int i = 0; i < parent.childCount(); i++) {
				QTreeWidgetItem child = parent.child(i);
				fileInfo in = (fileInfo) child.data(1, 0);
				if (in.isKeyWordsList) {
					return child;
				}
			}
			return findKeyWordsList(parent);
		}
		for (int i = 0; i < this.tree.topLevelItemCount(); i++) {
			QTreeWidgetItem child = this.tree.topLevelItem(i);
			fileInfo in = (fileInfo) child.data(1, 0);
			if (in.isKeyWordsList) {
				return child;
			}
		}
		return null;
	}

	void addKeyWordsListToProject(String showname) {
		String showName = null;
		if (showname != null) {
			showName = showname;
		} else {
			showName = languageTool.getString(796);
		}
		int fileindex = Integer.valueOf(this.projectInfo.getProperty("fileindex", "0")).intValue();
		File newfile = new File(
				this.projectFile.getParent() + File.separator + "Files" + File.separator + fileindex + ".black");
		if (!newfile.exists()) {
			io.writeBlackFile(newfile, "", null);
			QTreeWidgetItem parent = this.tree.currentItem();
			if (parent != null) {
				fileInfo fi = (fileInfo) parent.data(1, 0);
				if ((fi.isDir) || (fi.isRoot != -1) || (fi.isFiles)) {
					fileInfo in = new fileInfo(showname, newfile.getName());
					in.isKeyWordsList = true;
					fi.subfiles.add(in);
					QTreeWidgetItem item = new QTreeWidgetItem(parent);
					item.setData(1, 0, in);
					item.setIcon(0, this.ico_keywordsList);
					item.setText(0, showName);
					parent.setExpanded(true);

					this.mustSaveFileListFile = true;
					setEditable(item, true);
				} else if (fi.isFile) {
					fi.isFiles = true;
					fi.isFile = false;
					fi.initFloder();
					parent.setIcon(0, this.ico_files);
					fileInfo in = new fileInfo(showname, newfile.getName());
					in.isKeyWordsList = true;
					fi.subfiles.add(in);
					QTreeWidgetItem treeItem = getTreeItem(parent);
					treeItem.setData(1, 0, in);
					treeItem.setText(0, showName);
					treeItem.setIcon(0, this.ico_keywordsList);
					parent.setExpanded(true);

					this.mustSaveFileListFile = true;
					setEditable(treeItem, true);
				}
			} else {
				fileInfo in = new fileInfo(showname, newfile.getName());
				in.isKeyWordsList = true;

				this.filesList.add(in);
				QTreeWidgetItem item = new QTreeWidgetItem(this.tree);
				item.setData(1, 0, in);
				item.setIcon(0, this.ico_keywordsList);
				item.setText(0, showName);

				this.mustSaveFileListFile = true;
				setEditable(item, true);
			}
			this.projectInfo.setProperty("fileindex", String.valueOf(fileindex + 1));
			cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
		}
	}

	void addFile() {
		addFileToProject(null);
	}

	QTreeWidgetItem addFileToProject(String showname) {
		String showName = null;
		QTreeWidgetItem newItem = null;
		if (showname != null) {
			showName = showname;
		} else {
			showName = languageTool.getString(796);
		}
		int fileindex = Integer.valueOf(this.projectInfo.getProperty("fileindex", "0")).intValue();
		File newfile = new File(
				this.projectFile.getParent() + File.separator + "Files" + File.separator + fileindex + ".black");
		// 检查文件指针可用性，如果不可用则自动修复index错误，并再次获取文件指针
		if (newfile.exists()) {
			resetProjectFileIndex(false);
		}

		if (!newfile.exists()) {
			QTreeWidgetItem parent = this.tree.currentItem();
			if (parent != null) {
				fileInfo fi = (fileInfo) parent.data(1, 0);
				if ((fi.isDir) || (fi.isRoot != -1) || (fi.isFiles)) {
					fileInfo in = new fileInfo(showname, newfile.getName());
					in.isFile = true;
					fi.subfiles.add(in);
					QTreeWidgetItem item = new QTreeWidgetItem(parent);
					item.setData(1, 0, in);
					item.setIcon(0, this.ico_file);
					item.setText(0, showName);
					newItem = item;
					parent.setExpanded(true);

					this.mustSaveFileListFile = true;
					setEditable(item, true);
					io.writeBlackFile(newfile, "", null);
					this.projectInfo.setProperty("fileindex", String.valueOf(fileindex + 1));
					cfg_read_write.cfg_write(this.projectInfo, this.projectFile);

				} else if (fi.isKeyWordsList) {
					getMessageBox(languageTool.getString(798), languageTool.getString(799));
				} else if (fi.isFile) {
					fi.isFiles = true;
					fi.isFile = false;
					fi.initFloder();
					parent.setIcon(0, this.ico_files);
					fileInfo in = new fileInfo(showname, newfile.getName());
					in.isFile = true;
					fi.subfiles.add(in);
					QTreeWidgetItem treeItem = getTreeItem(parent);
					treeItem.setData(1, 0, in);
					treeItem.setText(0, showName);
					treeItem.setIcon(0, this.ico_file);
					newItem = treeItem;
					parent.setExpanded(true);

					this.mustSaveFileListFile = true;
					setEditable(treeItem, true);
					io.writeBlackFile(newfile, "", null);
					this.projectInfo.setProperty("fileindex", String.valueOf(fileindex + 1));
					cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
				}
			} else {
				fileInfo in = new fileInfo(showname, newfile.getName());
				in.isFile = true;
				this.filesList.add(in);
				QTreeWidgetItem item = new QTreeWidgetItem(this.tree);
				item.setData(1, 0, in);
				item.setIcon(0, this.ico_file);
				item.setText(0, showName);
				newItem = item;

				this.mustSaveFileListFile = true;
				io.writeBlackFile(newfile, "", null);
				this.projectInfo.setProperty("fileindex", String.valueOf(fileindex + 1));
				cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
//				openFileByTreeItem(item);
				setEditable(item, true);

			}
		} else {
			getMessageBox(languageTool.getString(800), languageTool.getString(801,newfile.getName(),appInfo.appName));
		}
		return newItem;
	}

	void setEditable(QTreeWidgetItem qt, boolean andEditing) {
		Qt.ItemFlags flags = qt.flags();
		flags.set(new Qt.ItemFlag[] { Qt.ItemFlag.ItemIsEditable });
		qt.setFlags(flags);
		if (andEditing) {
			this.isDoubleClickedOnTreeItem = andEditing;
			this.tree.editItem(qt, 0);
		}
	}

	void addFolder() {
		addFolderToProject(languageTool.getString(804));
	}

	void addFolderToProject(String showname) {
		int fileindex = Integer.valueOf(this.projectInfo.getProperty("fileindex", "0")).intValue();

		QTreeWidgetItem parent = this.tree.currentItem();
		if (parent != null) {
			fileInfo fi = (fileInfo) parent.data(1, 0);
			if ((fi.isDir) || (fi.isRoot != -1) || (fi.isFiles)) {
				fileInfo in = new fileInfo(showname, String.valueOf(fileindex));
				in.isDir = true;
				in.initFloder();
				fi.subfiles.add(in);
				QTreeWidgetItem item = new QTreeWidgetItem(parent);

				item.setData(1, 0, in);
				item.setIcon(0, this.ico_folder);
				item.setText(0, showname);
				parent.setExpanded(true);

				this.mustSaveFileListFile = true;
				setEditable(item, true);
			} else if (!fi.isKeyWordsList) {
				if (fi.isFile) {
					fileInfo in = new fileInfo(showname, String.valueOf(fileindex));
					in.isDir = true;
					in.initFloder();
					fi.initFloder();
					fi.isFiles = true;
					fi.isFile = false;
					parent.setIcon(0, this.ico_files);
					fi.subfiles.add(in);
					QTreeWidgetItem item = new QTreeWidgetItem(parent);

					item.setData(1, 0, in);
					item.setIcon(0, this.ico_folder);
					item.setText(0, showname);

					this.mustSaveFileListFile = true;
					setEditable(item, true);
				}
			}
		} else {
			fileInfo in = new fileInfo(showname, String.valueOf(fileindex));
			in.isDir = true;
			in.initFloder();
			this.filesList.add(in);
			QTreeWidgetItem item = new QTreeWidgetItem(this.tree);

			item.setData(1, 0, in);
			item.setIcon(0, this.ico_folder);
			item.setText(0, showname);
			this.mustSaveFileListFile = true;
			setEditable(item, true);
		}
		this.projectInfo.setProperty("fileindex", String.valueOf(fileindex + 1));
		cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
	}

	void saveProjectFile() {
		cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
	}

	void saveFileListFile() {
		io.writeObjFile(this.filesListFile, this.filesList);
	}

	boolean isHas(QTreeWidgetItem src, QTreeWidgetItem to) {
		QTreeWidgetItem parent = src.parent();
		if ((parent == null) && (to == null)) {
			return true;
		}
		if (parent != null) {
			return parent.equals(to);
		}
		if (to != null) {
			return false;
		}
		return false;
	}

	void moveFileToRecyle() {
		List<QTreeWidgetItem> selectedItems = null;
		if (isCheackable(this.draft)) {
			selectedItems = getCheckedItems();
		} else {
			selectedItems = this.tree.selectedItems();
		}
		for (QTreeWidgetItem qt : selectedItems) {
			if ((!qt.equals(this.draft)) && (!qt.equals(this.reserach)) && (!qt.equals(this.recycle))
					&& (!isHas(qt, this.recycle))) {
				fileInfo fi = (fileInfo) qt.data(1, 0);
				QTreeWidgetItem parent = qt.parent();
				if (parent != null) {
					fileInfo parent_info = (fileInfo) parent.data(1, 0);
					if (parent_info != null) {
						parent_info.subfiles.remove(fi);
						fileInfo recycle_info = (fileInfo) this.recycle.data(1, 0);

						qt.parent().removeChild(qt);
						qt.setData(1, 0, fi);
						this.recycle.addChild(qt);
						recycle_info.subfiles.add(fi);
						if ((parent_info.isFiles) && (parent_info.subfiles.size() == 0)) {
							if (parent_info.charCount > 0) {
								parent.setIcon(0, this.ico_fileOfHasText);
							} else {
								parent.setIcon(0, this.ico_file);
							}
							parent_info.isFiles = false;
							parent_info.subfiles = null;
							parent_info.isFile = true;
						}
					}
				} else {
					this.filesList.remove(fi);
					fileInfo recycle_info = (fileInfo) this.recycle.data(1, 0);
					this.tree.takeTopLevelItem(this.tree.indexOfTopLevelItem(qt));
					qt.setData(1, 0, fi);
					this.recycle.addChild(qt);
					recycle_info.subfiles.add(fi);
				}
			}
		}
		io.writeObjFile(this.filesListFile, this.filesList);
	}

	void resetDefaultFolder() {
		fileInfo info = new fileInfo(languageTool.getString(805), "0");
		info.isRoot = 0;
		info.initFloder();
		this.filesList.add(info);
		fileInfo info1 = new fileInfo(languageTool.getString(807), "0");
		info1.isRoot = 1;
		info1.initFloder();
		this.filesList.add(info1);
		fileInfo info2 = new fileInfo(languageTool.getString(809), "0");
		info2.isRoot = 2;
		info2.initFloder();
		this.filesList.add(info2);
	}

	void resetProject() {
		this.filesList.removeAll(this.filesList);
		resetDefaultFolder();
		String filesdir = this.projectFile.getParent() + File.separator + "Files";
		File f = new File(filesdir);
		File[] listFiles = f.listFiles();
		File[] arrayOfFile1;
		int j = (arrayOfFile1 = listFiles).length;
		for (int i = 0; i < j; i++) {
			File file = arrayOfFile1[i];
			if (!file.delete()) {
				file.deleteOnExit();
			}
		}
		this.projectInfo.setProperty("fileindex", String.valueOf(0));
		cfg_read_write.cfg_write(this.projectInfo, this.projectFile);
		io.writeObjFile(this.filesListFile, this.filesList);
		ListProjectFiles();
	}

	void clearRecyleFiles() {
		boolean isRemove = false;
		fileInfo fi = (fileInfo) this.recycle.data(1, 0);
		ArrayList<String> allFiles = getAllFiles(fi);
		p(languageTool.getString(811,allFiles.size()));
		ArrayList<dataForOpenedFile> deleteFiles = new ArrayList();
		StringBuilder sb = new StringBuilder();
		File f;
		for (String file : allFiles) {
			f = new File(file);
			for (dataForOpenedFile opened : this.openedFiles) {
				if (opened.filename.equals(f.getName())) {
					deleteFiles.add(opened);
				}
			}
			if (f.equals(this.currentEditing)) {
				p(languageTool.getString(813,f.getName()));
				closeCurrentEditing();
			}
			if (f.exists()) {
				boolean isDelete = f.delete();
				String isD = null;
				if (isDelete) {
					String string = languageTool.getString(816,f.getName());
					p(string);
					sb.append(string+"\n");
					isRemove = true;
				} else {
					f.deleteOnExit();
					String string = languageTool.getString(817,f.getName());
					p(string);
					sb.append(string+"\n");
					isRemove = true;
				}
				
			}else {
				String string = languageTool.getString(822,f.getName());
				p(string);
				sb.append(string+"\n");
			}
		}
		for (dataForOpenedFile opened : deleteFiles) {
			p(languageTool.getString(825,opened.filename));
			this.openedFiles.remove(opened);
		}
		List<QTreeWidgetItem> takeChildren = this.recycle.takeChildren();
		for (QTreeWidgetItem qt : takeChildren) {
			fileInfo in = (fileInfo) qt.data(1, 0);
			fi.subfiles.remove(in);
			this.recycle.removeChild(qt);
			isRemove = true;
		}
		if (isRemove) {
			io.writeObjFile(this.filesListFile, this.filesList);
		}
		bmessageBox bMessageBox = getBMessageBox(languageTool.getString(826), sb.toString());
		bMessageBox.show();
	}

	void clearRecyle() {
		if (this.recycle.childCount() == 0) {
			return;
		}
		QMessageBox message = getMessageBoxNotShow("", "");
		QPushButton cancel = message.addButton(QMessageBox.StandardButton.Cancel);
		cancel.setText(languageTool.getString(827));
		QPushButton ok = message.addButton(QMessageBox.StandardButton.Ok);
		ok.setText(languageTool.getString(828));
		ok.clicked.connect(this, "clearRecyleFiles()");
		message.setText(languageTool.getString(829));
		message.setWindowTitle(languageTool.getString(830));
		message.setIconPixmap(this.ico_warning.pixmap(48, 48));
		message.show();
	}

	/**
	 * 获取目录和文件集中的全部文件 返回储存了文件全路径的数组，返回结果中不包含给定的info自身
	 * 
	 * @param dirInfo
	 * @return
	 */
	ArrayList<String> getAllFiles(fileInfo info) {
		ArrayList<String> files = new ArrayList();
		ArrayList<fileInfo> subfiles = info.subfiles;
		String rootPath = projectFile.getParent() + File.separator + "Files" + File.separator;
		if(subfiles != null)
		for (fileInfo in : subfiles) {
			//只要文件名不是空的，且其后面有.black后缀，就认为磁盘中存在该文件。目录的文件名后面没有.black后缀
			if(in.fileName != null && !in.fileName.isEmpty() && in.fileName.indexOf(".black") != -1) {
				files.add(rootPath+in.fileName);
			}
			
			if(in.subfiles != null) {
				ArrayList<String> allFiles = getAllFiles(in);
				files.addAll(allFiles);
			}
		}
		return files;
	}
	
	/**
	 * 返回给定的info中的所有子fileInfo,返回结果中不包含给定的info自身
	 * @param info
	 * @return
	 */
	ArrayList<fileInfo> getAllFileInfo(fileInfo info) {
		ArrayList<fileInfo> files = new ArrayList();
		ArrayList<fileInfo> subfiles = info.subfiles;
		if(subfiles != null)
		for (fileInfo in : subfiles) {
			files.add(in);
			if(in.subfiles != null) {
				ArrayList<fileInfo> allFileInfo = getAllFileInfo(in);
				files.addAll(allFileInfo);
			}
		}
		return files;
	}

	boolean rootIs(QTreeWidgetItem item, QTreeWidgetItem rootItem) {
		QTreeWidgetItem parent = item.parent();
		if (parent != null) {
			while (parent.parent() != null) {
				parent = parent.parent();
			}
			if (parent.equals(rootItem)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 获取当前文档所在的文件集(父文件集)，如果没有则返回空
	 * 
	 * @param item
	 * @param rootItem
	 * @return
	 */
	fileInfo getFilesWhichCurrentIn(QTreeWidgetItem item) {
		QTreeWidgetItem parent = item.parent();
		while (parent != null) {
			fileInfo fi = getFileInfoByQTreeItem(parent);
			if (fi.isFiles) {
				return fi;
			}
			parent = parent.parent();

		}

		return null;
	}

	void setExpanded(QTreeWidgetItem qt, boolean expand) {
		qt.setExpanded(expand);
		QTreeWidgetItem parent = qt.parent();
		if (parent != null) {
			parent.setExpanded(expand);
			while (parent.parent() != null) {
				parent = parent.parent();
				parent.setExpanded(expand);
			}
		}
	}

	public String getShowNameOfCurrentEditingFile() {
		if(infoOfCurrentEditing != null)
			return this.infoOfCurrentEditing.getShowName();
		else return "";
	}
	public void setShowNameOfCurrentEditingFile(String showname) {
		infoOfCurrentEditing.setShowName(showname);
	}
	public boolean isDoNotShowShadow() {
		return this.doNotShowShadow;
	}

	public void setDoNotShowShadow(boolean doNotShowShadow) {
		this.doNotShowShadow = doNotShowShadow;
	}
}
