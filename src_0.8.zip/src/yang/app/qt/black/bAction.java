package yang.app.qt.black;

import static yang.app.qt.black.black.p;
import static yang.app.qt.black.black.settings;
import static yang.app.qt.black.black.text;
import static yang.app.qt.black.black.uiRun;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.common.Term;
import com.hankcs.hanlp.tokenizer.StandardTokenizer;
import com.sangupta.jerry.http.service.impl.DefaultHttpServiceImpl;
import com.sangupta.unsplash.UnsplashClient;
import com.sangupta.unsplash.model.UnsplashImage;

import io.qt.core.QBuffer;
import io.qt.core.QByteArray;
import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.QPoint;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.core.QSysInfo;
import io.qt.core.QUrl;
import io.qt.core.Qt;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.FindChildOption;
import io.qt.core.Qt.GlobalColor;
import io.qt.core.Qt.PenStyle;
import io.qt.core.Qt.ShortcutContext;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.core.Qt.WindowFlags;
import io.qt.core.Qt.WindowModality;
import io.qt.core.Qt.WindowState;
import io.qt.core.Qt.WindowType;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QDesktopServices;
import io.qt.gui.QFont;
import io.qt.gui.QFontMetrics;
import io.qt.gui.QFont.SpacingType;
import io.qt.gui.QIcon;
import io.qt.gui.QImage;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QKeySequence;
import io.qt.gui.QLinearGradient;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPainter.RenderHint;
import io.qt.gui.QPalette;
import io.qt.gui.QPalette.ColorRole;
import io.qt.gui.QPen;
import io.qt.gui.QPixmap;
import io.qt.gui.QPolygon;
import io.qt.gui.QRadialGradient;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextDocument.FindFlag;
import io.qt.gui.QTextLayout.FormatRange;
import io.qt.gui.QTextListFormat.Style;
import io.qt.gui.QWindowStateChangeEvent;
import io.qt.widgets.QAction;
import io.qt.widgets.QApplication;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QCheckBox;
import io.qt.widgets.QColorDialog;
import io.qt.widgets.QComboBox;
import io.qt.widgets.QDialog;
import io.qt.widgets.QFileDialog;
import io.qt.widgets.QFileDialog.AcceptMode;
import io.qt.widgets.QFrame;
import io.qt.widgets.QFrame.Shadow;
import io.qt.widgets.QFrame.Shape;
import io.qt.widgets.QGraphicsBlurEffect;
import io.qt.widgets.QGroupBox;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLayoutItem;
import io.qt.widgets.QMenu;
import io.qt.widgets.QMessageBox;
import io.qt.widgets.QProgressBar;
import io.qt.widgets.QMessageBox.Icon;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QShortcut;
import io.qt.widgets.QSizePolicy.Policy;
import io.qt.widgets.QTextEdit.ExtraSelection;
import io.qt.widgets.QSpinBox;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QTreeWidget;
import io.qt.widgets.QTreeWidgetItem;
import io.qt.widgets.QWidget;
import yang.app.qt.black.appInfo.UIObject;
import yang.app.qt.black.appInfo.fontSize;
import yang.app.qt.black.appInfo.tempName;
import yang.app.qt.black.appInfo.uiSize;
import yang.demo.allPurpose.DesUtils;
import yang.demo.allPurpose.HtmlMerger;
import yang.demo.allPurpose.MD5;
import yang.demo.allPurpose.debug;
import yang.demo.allPurpose.fileTool;
import yang.demo.allPurpose.httpGet;
import yang.demo.allPurpose.isYourNeedFile;
import yang.demo.allPurpose.time;
import yang.demo.allPurpose.yangIO;

public class bAction extends QObject {
	static boolean firefoxRuning;
	black b;
	QAction exportFileOne;
	QAction showSystemInfo;
	QAction clearMoveList;
	QAction reLoadKeywordsList;
	QAction undo;
	protected QAction redo;
	QAction showTitles;
	private QAction showOldTitles;
	private QAction showKeywords;
	private QAction copy;
	private QAction cut;
	private QAction paste;
	private QAction selectAll;
	private QAction setTitles;
	private QAction statCharManyDoc;
	private QAction preEditFile;
	private QAction nextEditFile;
	private QAction lastEditFile;
	private QAction typeWriter;
	private QAction anmation;
	private QAction showFileMoveList;
	private QAction charSpace;
	static int zoomvalue;
	static Hashtable<String, Object> tempData = new Hashtable<>();
	private QAction bigFont;
	QLabel label;
	private QWidget shadow;
	keyboard keyboard;
	public bAction(black b) {
		this.b = b;
		initInfo();
		checkData();
		initDir();
		addTime();
		keyboard = new keyboard(b);
		zoomvalue = b.getEditorTextZoomValue();
		
	}
	/**
	 * appinfo中的一些需要读取settings才能获取的信息，需要在这个方法里执行
	 */
	void initInfo() {
		appInfo.opensourceInfo = "<b><i>"+languageTool.getString(1387)+"</i></b>"
				+ "<i><ul>"
				+ "<li>"+languageTool.getString(1388,"Qt5 - LGPL-3")+"(www.qt.io/download-open-source)"
				+ "<li>"+languageTool.getString(1388,"QTJAMBI - LGPL-21")+"(github.com/OmixVisualization/qtjambi)"
//				+ "<li>OSHI - BSD许可证(pinyin4j.sourceforge.net)"
				+ "<li>"+languageTool.getString(1388,"HanLP - Apache-2")+"(github.com/hankcs/HanLP/)"
				+ "<li>"+languageTool.getString(1388,"JGIT - EDL")+"(www.eclipse.org/jgit/)"
				+ "<li>"+languageTool.getString(1388,"PINYIN4J - BSD")+"(pinyin4j.sourceforge.net)"
				+ "<li>"+languageTool.getString(1388,"WINRUN4J - CPL")+"(github.com/poidasmith/winrun4j)"
				+ "</ul>"
				+ languageTool.getString(1389,"Apache-2","(www.apache.org/licenses/LICENSE-2.0.html)")+"<br>"
				+ languageTool.getString(1389,"LGPL-3","(www.gnu.org)")+"<br>"
//				+ "MIT许可证的定义，见(www.mit-license.org)网站。<br>" 
				+ languageTool.getString(1389,"CPL","(www.ibm.com/developerworks/library/os-cpl.html)")+"<br>"
				+ languageTool.getString(1389,"BSD","(www.linfo.org/bsdlicense.html)")+"<br>"
				+ languageTool.getString(1389,"EDL","(www.eclipse.org/org/documents/edl-v10.php)")+"<br>"
				+ "</i>";
	}
	void addActions() {
		addMenu();
		//添加全局快捷键示例
//		QShortcut lockK = new QShortcut(b);
//		lockK.setContext(ShortcutContext.ApplicationShortcut);
//		lockK.activated.connect(this, "setLocked()");
//		lockK.setKey(new QKeySequence("ctrl+l"));
		QAction lock = new QAction(languageTool.getString(997));
		lock.setParent(b);
		lock.setObjectName("109");
		lock.triggered.connect(this, "setLocked()");
		lock.setIcon(new QIcon(appInfo.icons+"setLocked.png"));
		
		if(getWinntVersion() != -1) {		
			QAction standby = new QAction(languageTool.getString(998));
			standby.setObjectName("110");
			standby.setParent(b);
			standby.triggered.connect(this, "nircmdStandby()");
			
			QAction brightness_0 = new QAction(languageTool.getString(999));
			brightness_0.setObjectName("111");
			brightness_0.setParent(b);
			brightness_0.triggered.connect(this, "nircmdBrightness_0()");
			
			QAction brightness_50 = new QAction(languageTool.getString(1000));
			brightness_50.setObjectName("112");
			brightness_50.setParent(b);
			brightness_50.triggered.connect(this, "nircmdBrightness_50()");
			
			QAction brightness_100 = new QAction(languageTool.getString(1001));
			brightness_100.setObjectName("113");
			brightness_100.setParent(b);
			brightness_100.triggered.connect(this, "nircmdBrightness_100()");
			
			b.ui.viewMenu.addSeparator();
			addActionToUI(brightness_100, UIObject.menuView);
			addActionToUI(brightness_50, UIObject.menuView);
			addActionToUI(brightness_0, UIObject.menuView);
			addActionToUI(standby, UIObject.menuView);
			b.ui.viewMenu.addSeparator();
		}
		
		addActionToUI(lock,UIObject.menuView);
		addActionToUI(lock,UIObject.toolBar);
		
		addKeys.addKeys(keyboard);
		keyboard.readAppKeyData();
	}
	public void pasteWithFormat() {
		if(b.text != null) {
			b.text.paste();
		}
	}
	public void setShortcuts() {
		addShortcut(342, this, "ctrl+v", "pasteWithFormat()", languageTool.getString(1468), appInfo.UIObject.menuEdit, -1, "19");
		addShortcut(341, b,"", "closeCurrentEditing()", languageTool.getString(1002),appInfo.UIObject.menuFile,-1,"103");
		addShortcut(340, this,"", "closeAllDocWithoutCurrent()", languageTool.getString(1003),appInfo.UIObject.menuFile,-1,"103");
		//Index 139-339之间200个index分配给setTextStyle
		addShortcut(138, this, "", "setUsePic()", languageTool.getString(1004),1);
		addShortcut(137, this, "", "setUseBingPic()", languageTool.getString(1005),1);
		addShortcut(136, this, "", "showBingPicInfo()", languageTool.getString(1006),1);
		addShortcut(135, b, "", "clearWalkList()", languageTool.getString(1007));
		addShortcut(134, b, "", "showInExplorer()", languageTool.getString(1008));
		addShortcut(133, b, "", "resetTextStringLayout()", languageTool.getString(1009));
		addShortcut(132, b, "", "resetDocumentFormat()", languageTool.getString(1010));
		addShortcut(131, b, "", "setMarkBackground()", languageTool.getString(1011));
		addShortcut(130, b, "", "setFileTitleAsSelectedText()", languageTool.getString(1012));
		addShortcut(129, this, "", "addFileByEditorMenu_NullFileName()", languageTool.getString(1013),1);
		addShortcut(128, this, "", "showDefaultProject()", languageTool.getString(1014),1);
		addShortcut(127, this, "", "showAllBlackCommand()", languageTool.getString(1015),1);
		addShortcut(126, this, "", "getKeyword()", languageTool.getString(1016));
		addShortcut(125, this, "", "getSummary()", languageTool.getString(1017));
		addShortcut(124, this, "", "conversionToSimplified()", languageTool.getString(1018));
		addShortcut(123, this, "", "conversionToTraditional()", languageTool.getString(1019));
		addShortcut(122, this, "", "closeProject()", languageTool.getString(1020),1);
		addShortcut(120, this, "", "reStartApp()", languageTool.getString(1021),1);
		addShortcut(119, this, "", "showKeywordsWhenTextChanaged()", languageTool.getString(1022),1);
		addShortcut(118, this, "", "setUIFontSize()", languageTool.getString(1023),1);
		addShortcut(117, this, "", "charSpace()", languageTool.getString(1024),1);
		addShortcut(116, this, "", "setTypeWriter()", languageTool.getString(1025),1);
		addShortcut(115, b, "", "clearMoveList()", languageTool.getString(1026),1);
		addShortcut(114, this, "", "export()", languageTool.getString(1027),1);
		addShortcut(113, this, "ctrl+alt+shift+d", "nircmdBrightness_100()", languageTool.getString(1028),1);
		addShortcut(112, this, "ctrl+alt+shift+s", "nircmdBrightness_50()", languageTool.getString(1029),1);
		addShortcut(111, this, "ctrl+alt+shift+a", "nircmdBrightness_0()", languageTool.getString(1030),1);
		addShortcut(110, this, "ctrl+alt+shift+l", "nircmdStandby()", languageTool.getString(1031),1);
		addShortcut(109, this, "ctrl+l", "setLocked()", languageTool.getString(1032),1);
		addShortcut(108, b, "ctrl+f", "find()", languageTool.getString(1033));
		//index107已被占用
		addShortcut(106, b, "", "checkUpdate()", languageTool.getString(1034),1);
		addShortcut(105, b, "ctrl+alt+b", "hideFilesTree()", languageTool.getString(1035),1);
		addShortcut(104, b, "", "clearLogs()", languageTool.getString(1036),1);
		addShortcut(103, b, "", "clearTempFiles()", languageTool.getString(1037),1);
		addShortcut(102, b, "", "openProjectDir()", languageTool.getString(1038),1);
		addShortcut(101, b, "ctrl+s", "saveDocumentByUser()", languageTool.getString(1039),1);
		addShortcut(100, this, "", "showInfoBox()", languageTool.getString(1040),1);
		addShortcut(99, b, "", "showPay()", languageTool.getString(1041),1);
		addShortcut(98, b, "", "showAbout()", languageTool.getString(1042),1);
		addShortcut(97, b, "", "gitWork_ui()", languageTool.getString(1043));
		addShortcut(96, b, "", "push_ui()", languageTool.getString(1044),1);
		addShortcut(95, b, "", "commit_ui()", languageTool.getString(1045),1);
		addShortcut(94, b, "", "setGit_ui()", languageTool.getString(1046),1);
		addShortcut(93, b, "ctrl+k", "showCharCountBox()", languageTool.getString(1047));
		addShortcut(92, b, "f1", "showSettingsDialog()", languageTool.getString(1048),1);
		addShortcut(91, b, "", "getItalinaName_female()", languageTool.getString(1049));
		addShortcut(90, b, "", "getItalinaName_male()", languageTool.getString(1050));
		addShortcut(89, b, "", "getEnglishName_female()", languageTool.getString(1051));
		addShortcut(88, b, "", "getEnglishName_male()", languageTool.getString(1052));
		addShortcut(87, b, "", "getChineseNames()", languageTool.getString(1053));
		addShortcut(86, b, "", "getChineseName()", languageTool.getString(1054));
		addShortcut(85, b, "", "clearRecyle()", languageTool.getString(1055),1);
		addShortcut(84, b, "", "moveFileToRecyle()", languageTool.getString(1056),1);
		addShortcut(83, b, "", "findProject()", languageTool.getString(1057),1);
		addShortcut(82, b, "", "createProject()", languageTool.getString(1058),1);
		addShortcut(81, b, "", "addKeyWordsListToProject()", languageTool.getString(1059),1);
		addShortcut(80, b, "", "addFolder()", languageTool.getString(1060),1);
		addShortcut(79, b, "", "addFile()", languageTool.getString(1061),1);
		
//		addShortcut(this, "ctrl+alt+shift+l", "nircmdStandby()");
		addShortcut(78,this, "ctrl+alt+n", "addFileByEditorMenu_NameByDate()",languageTool.getString(1062),1);
	
//		addShortcut(75,b, "ctrl+shift+/", "dontNotSetMonitor()","");
//		addShortcut(this, "shift+backspace", "t3()");
		addShortcut(74,b, "alt+1", "backup()",languageTool.getString(1063));
		addShortcut(72,this.b, "ctrl+shift+f", "showFindDialogWithoutFindHistory()",languageTool.getString(1064));
		addShortcut(70,this.b, "alt+2", "setLightOrDark()",languageTool.getString(1065));
		if(appInfo.mode == 1) {
			addShortcut(68,b, "alt+3", "changeToAdminMode()",languageTool.getString(1066));
		}
//		else addShortcut(b, "alt+3", "setSpeak()");
		addShortcut(66,b, "alt+5", "setAutoFindInKeywords()",languageTool.getString(1067));
		addShortcut(65,this.b, "f12", "popPicWidget()",languageTool.getString(1068));

		addShortcut(64,this.b, "ctrl+f12", "focusMode()",languageTool.getString(1069));

//		addShortcut(this.b,"alt+4","noBackgroundForWritingView()");
		addShortcut(63,this.b, "alt+0", "quiet()",languageTool.getString(1070));
		if(appInfo.miniMode.equals("0")) {
			addShortcut(62,this.b, "ctrl+q", "changedEditFile()",languageTool.getString(1071),1);
			addShortcut(61,b, "ctrl+i", "clearCharCountOfTodayInput()",languageTool.getString(1072));
			addShortcut(60,this, "alt+;", "moveSmart()",languageTool.getString(1073));
			addShortcut(59,b, "ctrl+`", "repair()",languageTool.getString(1074));
			addShortcut(58,this, "alt+/", "showKeywords()",languageTool.getString(1075));
//			addShortcut(this, "ctrl+m", "resetEditor()");
			addShortcut(56,b, "alt+4", "changeRepairBy()",languageTool.getString(1076));
			
			

		}
//		b.text.addAction(this.b.ui.about);
		addShortcut(55,this.b, "alt+shift+k", "statCharCountForManyDoc()",languageTool.getString(1077),1);
		addShortcut(54,this.b, "alt+h", "backspace()",languageTool.getString(1078));
		addShortcut(53,this.b, "alt+f", "enter()",languageTool.getString(1079));
		key k52 = addShortcut(52,this.b, "ctrl+g", "findInGoldenDict()",languageTool.getString(1080));
		k52.selectionText = true;
		addShortcut(51,b, "ctrl+shift+h", "showLogs()",languageTool.getString(1081),1);
		addShortcut(50,b, "alt+shift+h", "clearWinRun4jLogs()",languageTool.getString(1082),1);
		addShortcut(49,this, "ctrl+shift+d", "deleteDir()",languageTool.getString(1083),1);
		addShortcut(48,b, "ctrl+shift+s", "cloneFromLocal()",languageTool.getString(1084),1);
		addShortcut(47,this, "ctrl+o", "setTimeMode()",languageTool.getString(1085),1);
		addShortcut(46,this, "ctrl+=", "zoomin()",languageTool.getString(1086));
		addShortcut(45,this, "ctrl+-", "zoomout()",languageTool.getString(1087));
		
		addShortcut(44,this.b, "ctrl+alt+shift+n", "getSizeOfEditorMemory()",languageTool.getString(1088),1);
		
		addShortcut(43,this.b, "ctrl+h", "showLogsText()",languageTool.getString(1089),1);
//		addShortcut(this.b, "alt+1", "setYellowChar()");
		if(appInfo.mode == 1) {
			addShortcut(42,b, "ctrl+shift+1", "checkNetWorks()","检查网络");
			addShortcut(41,this.b, "ctrl+shift+2", "autoCheckNetworks()","自动检查wifi网络");
		}
		
//		b.text.addAction(this.b.ui.oneChineseName);
//		b.text.addAction(this.b.ui.engManName);
//		b.text.addAction(this.b.ui.engWomanName);
//		b.text.addAction(this.b.ui.itManName);
//		b.text.addAction(this.b.ui.itWomanName);
//		b.text.addAction(this.b.ui.settings);
//		b.text.addAction(this.b.ui.chineseNames);
//		b.text.addAction(this.b.ui.commit);
//		b.text.addAction(this.b.ui.find);
//		b.text.addAction(this.b.ui.charCount);
//		b.text.addAction(this.b.ui.hideFilePanel);
//		b.ui.hideFilePanel.setShortcut("alt+shift+b");
//		b.text.addAction(this.b.ui.writingview);
		
		
		if(black.dbm)
			addShortcut(40,this, "ctrl+/", "test()",languageTool.getString(1092),1);
		
		addShortcut(39,b, "f9", "turnOffAnimation()",languageTool.getString(1093),1);
		
		Iterator<blackCommand> it = b.commands.iterator();
		while(it.hasNext()) {
			blackCommand next = it.next();
			key k = new key("", next.command) {

				@Override
				boolean action() {
					// TODO Auto-generated method stub
					if(next.noArgs) next.action(null);
					else {
						InputDialog id = new InputDialog(b.focusWidget(),languageTool.getString(1094),languageTool.getString(1095),false,false,"") {
							
							@Override
							void whenOkButtonPressed() {
								// TODO Auto-generated method stub
								if(!copyLineText().isEmpty()) {
									String[] args = cheakDocument.checkCommandArgs(copyLineText());
									next.action(args);
									close();
								}
							}
							
							@Override
							void whenClose() {
								// TODO Auto-generated method stub
								
							}
							
							@Override
							void whenCannelButtonPressed() {
								// TODO Auto-generated method stub
								
							}
						};
						id.setMessageText(languageTool.getString(1096)+next.info);
						id.show();
					}
					return true;
				}
				
			};
			keyboard.addKey(keyboard.getNextIndex(keyboard.keys), k);
		}
	}
	key addShortcut_init(Object o,String shortcut,String mothedname,String info) {
		String mothed = mothedname.replace("()", "");
		
		key key = new key(shortcut, info) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				try {
					o.getClass().getDeclaredMethod(mothed).invoke(o);
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return true;
			}
			
		};
		return key;
	}
	public key addShortcut(int index,String shortcut,String info,Runnable action) {
		key key = new key(shortcut, info) {

			@Override
			boolean action() {
				// TODO Auto-generated method stub
				action.run();;
				return true;
			}
			
		};
		keyboard.addKey(index, key);
		return key;
	}
	public key addShortcut(int index,Object o, String shortcut, String mothedname,String info,int context) {
		key key = addShortcut_init(o, shortcut, mothedname, info);
		key.context = context;
		keyboard.addKey(index, key);
		return key;
	}
	public key addShortcut(int index,Object o, String shortcut, String mothedname,String info) {
		key key = addShortcut_init(o, shortcut, mothedname, info);
		keyboard.addKey(index, key);
		return key;
	}
	public key addShortcut(int index,Object o, String shortcut, String mothedname,String info,UIObject addtoUI,int addSeparatorType,String beforeQActionObjectName) {
		key key = addShortcut_init(o, shortcut, mothedname, info);
		key.addToUI = addtoUI;
		key.addSeparatorType = addSeparatorType;
		key.before = beforeQActionObjectName;
//		key.addToUI(addtoUI, addSeparatorType);
		keyboard.addKey(index, key);
		return key;
	}
	void addActionToUI(QAction a,UIObject o) {
		switch (o) {
		case menuFile:
			b.ui.fileMenu.addAction(a);
			break;
		case menuEdit:
			b.ui.editMenu.addAction(a);
			break;
		case menuProject:
			b.ui.projectMenu.addAction(a);
			break;
		case menuGit:
			b.ui.gitMenu.addAction(a);
			break;
		case menuTool:
			b.ui.toolsMenu.addAction(a);
			break;
		case menuView:
			b.ui.viewMenu.addAction(a);
			break;
		case menuHelp:
			b.ui.helpMenu.addAction(a);
			break;
		case toolBar:
			b.toolbar.addAction(a);
			break;
		}
	}
	/**
	 * 没用的方法
	 * @param o
	 * @return
	 */
	QWidget getUIObject(UIObject o) {
		switch (o) {
		case menuFile:
			return b.ui.fileMenu;
		case menuEdit:
			return b.ui.editMenu;
		case menuProject:
			return b.ui.projectMenu;
		case menuGit:
			return b.ui.gitMenu;
		case menuTool:
			return b.ui.toolsMenu;
		case menuView:
			return b.ui.viewMenu;
		case menuHelp:
			return b.ui.helpMenu;
		case toolBar:
			return b.toolbar;
		}
		return null;
	}
	/**
	 * 
	 * @param a
	 * @param o
	 * @param addSeparator 0在前面添加separator，1在后面添加
	 */
	void addActionToUI(QAction a,UIObject o,int addSeparator,String beforeObjectName) {	
		QAction before = null;
		if(beforeObjectName != null) {
			before = b.findChild(QAction.class, beforeObjectName, FindChildOption.FindChildrenRecursively);
		}
		switch (o) {
		case menuFile:
			if(addSeparator == 0) b.ui.fileMenu.addSeparator();
			if(before == null)
			b.ui.fileMenu.addAction(a);
			else 
			b.ui.fileMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.fileMenu.addSeparator();
			break;
		case menuEdit:
			if(addSeparator == 0) b.ui.editMenu.addSeparator();
			if(before == null)
			b.ui.editMenu.addAction(a);
			else 
			b.ui.editMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.editMenu.addSeparator();
			break;
		case menuProject:
			if(addSeparator == 0) b.ui.projectMenu.addSeparator();
			if(before == null)
				b.ui.projectMenu.addAction(a);
			else
				b.ui.projectMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.projectMenu.addSeparator();
			break;
		case menuGit:
			if(addSeparator == 0) b.ui.gitMenu.addSeparator();
			if(before == null)
			b.ui.gitMenu.addAction(a);
			else
			b.ui.gitMenu.insertAction(before, a);

			if(addSeparator == 1) b.ui.gitMenu.addSeparator();
			break;
		case menuTool:
			if(addSeparator == 0) b.ui.toolsMenu.addSeparator();
			if(before == null)
				b.ui.toolsMenu.addAction(a);
			else
				b.ui.toolsMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.toolsMenu.addSeparator();
			break;
		case menuView:
			if(addSeparator == 0) b.ui.viewMenu.addSeparator();
			if(before == null)
			b.ui.viewMenu.addAction(a);
			else b.ui.viewMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.viewMenu.addSeparator();
			break;
		case menuHelp:
			if(addSeparator == 0) b.ui.helpMenu.addSeparator();
			if(before == null)
			b.ui.helpMenu.addAction(a);
			else b.ui.helpMenu.insertAction(before, a);
			if(addSeparator == 1) b.ui.helpMenu.addSeparator();
			break;
		case toolBar:
			if(addSeparator == 0) b.toolbar.addSeparator();
			if(before == null)
			b.toolbar.addAction(a);
			else b.toolbar.insertAction(before, a);
			if(addSeparator == 1) b.toolbar.addSeparator();
			break;
		}
	}
	void closeAllDocWithoutCurrent() {
		Iterator<dataForOpenedFile> it = b.openedFiles.iterator();
		while(it.hasNext()) {
			dataForOpenedFile opened = it.next();
			//无效的数据，跳过
			if(opened == null) continue;
			//是当前编辑的文件，跳过
			if(opened.filename.equals(b.currentEditing.getName())) continue;
			
			blacktext editor = opened.editor;
			if (editor != null) {
				//关闭与清空数据
				if (opened.isSaved) {
					p(languageTool.getString(1097,opened.filename,b.findFileShowName(opened.filename)));
					b.saveBlackFile(b.getFile(opened.filename), opened.editor.text.toHtml());
				}
				bTextEdit te = editor.text;
				editor.text = null;
				te.dispose();
				editor = null;
			}
			opened.content = null;
			it.remove();
		}
		
		p(languageTool.getString(1099,b.openedFiles.size()));
	}
	void nircmdBrightness_100() {
		execNirCmd("setbrightness 100");
	}
	void nircmdBrightness_50() {
		execNirCmd("setbrightness 50");
	}
	void nircmdBrightness_0() {
		execNirCmd("setbrightness 0");
	}
	/**
	 * Windows下让计算机进入睡眠模式
	 */
	void nircmdStandby() {
		execNirCmd("standby");
	}
	static void execNirCmd(String cmd) {
		exec("./Tools/nircmdc.exe "+cmd);
	}
	static void exec(String cmd) {
		try {
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 该方法用来向settings对话框加入新的设置项
	 * 
	 * @param ui
	 */
	void customSettings(Ui_settings ui) {

		QWidget securityTap = uiTool.addNewTap(ui.taps, languageTool.getString(1100));
		QGroupBox groupBox_accessControl = uiTool.getGroupBox(securityTap, languageTool.getString(1101));
		QBoxLayout layout_accessControl = uiTool.getBoxLayout(0);
		groupBox_accessControl.setLayout(layout_accessControl);
		// 上面的groupbox可以在布局中插入新的行，这里设定了基于行的布局，但是只有加入了一行
		QBoxLayout layout_accessControl_1 = uiTool.getBoxLayout(2);
		layout_accessControl.addLayout(layout_accessControl_1);
		QCheckBox needPasswd = uiTool.insertCheckBox(layout_accessControl_1, languageTool.getString(1102), null, null, true,this,
				"autoLock(boolean)");
		needPasswd.setChecked(autoLockIsEnabled());
		QSpinBox lockTime = uiTool.insertSpinBox(layout_accessControl_1, languageTool.getString(1103), 60, 600,
				appInfo.autoLockTime, "900", this, "autoLockTimeChanaged(String)");
		QPushButton setPasswd = uiTool.getQPushButton(languageTool.getString(1104), this, "setAutoLockPasswd()");
		needPasswd.setObjectName(appInfo.autoLock);
		setPasswd.setObjectName(appInfo.autoLockPasswd);
		layout_accessControl_1.addWidget(setPasswd);

		lockTime.setEnabled(needPasswd.isChecked());
		setPasswd.setEnabled(needPasswd.isChecked());
		
		ui.taps.addTab(new setKeys(keyboard,b), languageTool.getString(1105));
		QGroupBox UI = uiTool.getGroupBox(ui.editorsettings_tap,2,languageTool.getString(1464));
		String[] uiLanguages = getUiLanguages(true);
		QComboBox setLang = uiTool.getComboBox(UI, languageTool.getString(1463), true,uiLanguages, this, null);
		setLang.setEditable(false);
		String uilang = b.getStringValueFromSettings(appInfo.uiLang, "0");
		if(uilang.equals("0")) setLang.setCurrentIndex(0);
		else {
			int index = 0;
			for(String lang:uiLanguages) {
				if(lang.equals(uilang)) {
					setLang.setCurrentIndex(index);
					break;
				}
				index++;
			}
		}
		setLang.currentIndexChanged.overload(int.class).connect(this,"changeUILangAuto(int)");
		blackCommandToSettingsUI(ui);
		tempData.put("uiLangComboBox", setLang);
	}
	void changeUILangAuto(int i) {
		String lang = "0";
		if(i != 0) {
			QComboBox setLang = (QComboBox) tempData.get("uiLangComboBox");
			if(setLang != null) {
				lang = setLang.itemText(i);
			}
		}
		
		b.settings.setValue(appInfo.uiLang, lang);
		b.getMessageBox(languageTool.getString(1466), languageTool.getString(1465));
	}
	/**
	 * 
	 * @param has0是否添加"与操作系统语言保持一致"条目到返回的数组的开头
	 * @return
	 */
	static String[] getUiLanguages(boolean has0) {
		File dir = new File("."+File.separator+"Languages");
		String[] list = dir.list();
		ArrayList<String> ls = new ArrayList<>();
		if(has0) {
			String auto = languageTool.getString(1467);
			ls.add(auto);
		}
		
		for(String l:list) ls.add(l);
		
		return ls.toArray(new String[ls.size()]);
	}
	/**
	 * 显示基于插入符前一位字符查找的关键词列表
	 * 使用此方法产生的关键词显示框会在延迟时间之后才会显示，具体的延迟时间参见appInfo.pinyinStartSegmentMS
	 */
	void showKeywords() {
		if (!b.infoOfCurrentEditing.isKeyWordsList) {
			black.findview = 5;
//			this.b.showKeyWords();
			this.showKeywordsListByCurrentChar_();
		}
	}
	public void deleteDir() {
		File dir = new File(this.b.projectFile.getParent() + "_clone_" + time.getCurrentDate("-"));
		if ((dir.exists()) && (fileTool.deleteDir(dir.getPath()))) {
			this.b.getMessageBox(languageTool.getString(1106), languageTool.getString(1107,dir.getPath()));
			this.b.p(languageTool.getString(1107,dir.getPath()));
		}
	}
	public void zoomin() {
//		if(b.isAdmin())
		this.b.setEditorZoomValue(this.zoomvalue + 1);
	}

	public void zoomout() {
//		if(b.isAdmin())
		this.b.setEditorZoomValue(this.zoomvalue - 1);
	}
	
	/**
	 * 返回给定的字符串加密后字符串，加密器为black类的des对象
	 * @param key
	 * @return
	 */
	static String getStringWithEncrypt(String text) {
		String text_ = null;
		try {
			text_ = black.des.encrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1111));
			text_ = text;
		}
		return text_;
	}
	/**
	 * 使用给定的加密器加密文本，此方法适用于多次使用同一个加密器加密文本的情景，可以提高性能
	 * @param du
	 * @param editor
	 * @return
	 */
	static String getStringWithEncrypt(DesUtils du,String text) {
		if(du == null) return text;
		String text_ = null;
		try {
			text_ = du.encrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1111));
			text_ = text;
		}
		return text_;
	}
	/**
	 * 使用自定义密钥的加密器加密文本
	 * @param passwd
	 * @param editor
	 * @return
	 */
	static String getStringWithEncrypt(String passwd, String text) {
		String text_ = null;
		DesUtils du = new DesUtils(passwd);
		try {
			text_ = du.encrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1111));
			text_ = text;
		}
		return text_;
	}
	/**
	 * 使用给定的加密器解密文本，此方法适用于多次使用同一个加密器解密文本的情景，可以提高性能
	 * @param du
	 * @param editor
	 * @return
	 */
	static String getStringWithDncrypt(DesUtils du, String text) {
		if(du == null) {
			black.debugPrint(languageTool.getString(1114));
			return text;
		}
		String text_ = null;
		try {
			text_ = du.decrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1115));
			text_ = text;
		}
		System.out.println(languageTool.getString(1116,text_));
		return text_;
	}
	static String getStringWithDncrypt(String text) {
		String text_ = null;
		try {
			text_ = black.des.decrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1115));
			text_ = text;
		}
		return text_;
	}
	static String getStringWithDncrypt(String passwd, String text) {
		String text_ = null;
		DesUtils du = new DesUtils(passwd);
		try {
			text_ = du.decrypt(text, "utf-8");
		} catch (Exception e) {
			black.debugPrint(languageTool.getString(1115));
			text_ = text;
		}
		return text_;
	}

	void setAutoLockPasswd() {
		setAutoLockPasswd(2);
	}

	
	public void setUnLock(int mode,InputDialog id) {
		setLockStatus(true);
		setUnLockTime(System.currentTimeMillis());
		setLockTimer();
		b.showAllWidget();
		b.setSaved(b.saved);
		b.setEnabled(true);
		if (b.text != null) {
			b.text.setFocus();
		}
		id.noClose = false;
		id.close();
	}
	void setAutoLockPasswd_mode3_action(int mode, String value,InputDialog id,boolean forTextChanaged) {
		boolean correct = false;
		if(black.des_doc != null) {
			if(value.equals(black.des_doc.secretKey)){
				correct = true;
			}
		}else {
			File lockedFile = getLockedFile();
			if(lockedFile.exists()) {
				String text = io.readTextFile(lockedFile, "utf-8");
				if(!text.isBlank()) {
					DesUtils du = new DesUtils(value);
					String stringWithDncrypt = getStringWithDncrypt(du, text);
					if(stringWithDncrypt.equals("locked")) {
						correct = true;
						black.des_doc = new DesUtils(value);
					}
				}
			}
		}
		if (correct) {
			setUnLock(mode, id);
		} else if(!forTextChanaged){
			id.setMessageText(languageTool.getString(1119));
			id.setLineText("");
		}
	}
	/**
	 * 设定锁定密码。注意此方法产生的密码对话框为模态对话框，放置与密码框显示状态有关的开关变量时，只能放置在该方法内，不能放置在调用该方法的语句之后
	 * 
	 * @param mode 0为设定新密码模式（重复输入两次密码，密码相同则保存密码）； 1为关闭密码锁定（先验证旧密码，然后停用锁定）；
	 *             2为重设密码模式（先验证旧密码，然后设定新密码）； 3为验证密码模式（验证密码正确后暂时解除锁定）
	 * @return
	 */
	boolean setAutoLockPasswd(int mode) {
		String text = "";
		if (mode == 0)
			text = languageTool.getString(1120);
		else if (mode == 3) {
			if(black.des_doc != null) text = languageTool.getString(1122,b.getProjectName());
			else text = languageTool.getString(1121,b.getProjectName());
		}
		else
			text = languageTool.getString(1123);

		QWidget parent = b;
//		if(mode == 3) {
//	
//		}

		InputDialog id = new InputDialog(parent, languageTool.getString(1124), languageTool.getString(1125), true, false, "") {

			@Override
			void whenOkButtonPressed() {
				// TODO Auto-generated method stub
				int mode_ = mode;
				Object mode__ = tempData.get("changeMode");
				if (mode__ != null) {
					mode_ = (int) mode__;
				}

				if (!value().isEmpty()) {
					if (mode_ == 0) {
						if(black.des_doc != null) {
							if(value().equals(black.des_doc.secretKey)) {
								this.setMessageText(languageTool.getString(1298));
								this.setLineText("");
								return;
							}
						}
						String pass = (String) tempData.get("pass");
						if (pass == null) {
							tempData.put("pass", value());
							this.setMessageText(languageTool.getString(1126));
							this.setLineText("");
						} else {
							if (pass.equals(value())) {
								File lockedFile = getLockedFile();
								if(!lockedFile.exists()) {
									try {
										lockedFile.createNewFile();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
//								b.getMessageBox("设置访问密码", "密码设置成功！");
								
								encryptProject(true, pass);
								
								black.des_doc = new DesUtils(pass);
								io.writeTextFile(lockedFile, getStringWithEncrypt(black.des_doc,"locked"), "utf-8");
								
								tempData.remove("changeMode");
								setLockStatus(true);
								setUnLockTime(System.currentTimeMillis());
								setLockTimer();
								close();
								tempData.remove("pass");
							} else {
								tempData.remove("pass");
								this.setMessageText(languageTool.getString(1299));
								this.setLineText("");
							}
						}
					} else if (mode_ == 1) {
						String currentPasswd = black.des_doc.secretKey;
						if (currentPasswd != null) {
							if (currentPasswd.equals(value())) {
								File lockedFile = getLockedFile();
								if(lockedFile.exists()) {
									if(!lockedFile.delete()) {
										lockedFile.deleteOnExit();
										b.getMessageBox(languageTool.getString(1127), languageTool.getString(1128));
										int messageBoxWithYesNO = b.getMessageBoxWithYesNO("", "", languageTool.getString(1129), languageTool.getString(1130), QMessageBox.Icon.Warning, QMessageBox.ButtonRole.AcceptRole.value());
										if(messageBoxWithYesNO == 1) {
											reStartApp();
										}
									}
								}
								encryptProject(false, null);
								black.des_doc = null;
								tempData.remove("changeMode");
								clearLockStatus();
								setLockTimer();
								close();
//								b.getMessageBox("访问控制", "验证通过，已解除访问控制");
							} else {
								this.setMessageText(languageTool.getString(1300));
								this.setLineText("");
							}
						}
					} else if (mode_ == 2) {
						String currentPasswd = black.des_doc.secretKey;
						if (currentPasswd != null) {
							if (currentPasswd.equals(value())) {
								tempData.put("changeMode", Integer.valueOf(0));
								this.setMessageText(languageTool.getString(1301));
								this.setLineText("");
							} else {
								this.setMessageText(languageTool.getString(1300));
								this.setLineText("");
							}
						}

					} else if (mode_ == 3) {
						setAutoLockPasswd_mode3_action(mode, value(), this,false);
					}
				} else {
					this.setMessageText(languageTool.getString(1302));
				}

			}

			@Override
			void whenClose() {
				// TODO Auto-generated method stub
//				System.out.println("close");
			}

			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub
				if (mode == 3) {
					this.noClose = false;
					close();
					if(tempData.get(appInfo.tempName.openingProject.name()) == null)
						b.close();
					else {
						b.clearProjectRuntimeData();
						b.close();
					}
				}
			}
			
			@Override
			protected void changeEvent(QEvent e) {
				// TODO Auto-generated method stub
				if(e.type() == QEvent.Type.WindowStateChange) {
					/**
					 * 虽然模态窗口在最小化是会将父窗口一起最小化，但是好像时间一长点击最小化按钮就不会最小化父窗口了
					 * 所以显式指定按下对话框的最小化按钮时让父窗口最小化
					 */
					QWindowStateChangeEvent event = (QWindowStateChangeEvent) e;
					if(windowState().isSet(WindowState.WindowMinimized)) {
						QWidget pw = this.parentWidget();
						if(pw != null) {
							//先还原对话框为非最小化状态
							this.showNormal();
							pw.showMinimized();
						}
					}
				}
				super.changeEvent(e);
			}
		};
		if (mode == 3) {
			if(black.splashScreen != null && black.splashScreen.isVisible()) black.splashScreen.hide();
			id.noHide = true;
			id.noESC = true;
			id.noClose = true;
			WindowFlags wf = id.windowFlags();
			wf.clear(Qt.WindowType.WindowContextHelpButtonHint);
			wf.clear(Qt.WindowType.WindowCloseButtonHint);
			wf.set(Qt.WindowType.WindowMinimizeButtonHint);
			id.setWindowFlags(wf);
			id.setIcon(new QPixmap(appInfo.icons+"setLocked.png"));

			id.setRunableAtWindowDeActivate(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
//					stopRandomImg();
				}
			});
			id.setRunableAtWindowActivate(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					randomImgAction(600);
				}
			});
			id.setRunableAtTextChanged(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					if (!id.value().isEmpty()) {
						setAutoLockPasswd_mode3_action(mode, id.value(), id,true);
					}
				}
			});
			
			id.insertButton(languageTool.getString(1131), 2, new buttonAction() {
				
				@Override
				void action() {
					// TODO Auto-generated method stub
					int view = b.writingView;
					b.exitWritingView();
					//如果项目已经打开则关闭项目，如果项目处于打开的过程中，则设置停止打开项目标记
					closeProjectForAutoLock(id);
					if(view == 1) tempData.remove(appInfo.tempName.firstOpenDocument.name());
					//如果项目正在打开的过程中，必须将密码输入框关闭，项目打开过程才会继续（此处是清理已经设置的项目数据，然后停止打开项目），因为密码框是模态的
					id.noClose = false;
					id.close();
					b.setEnabled(true);
					//必须通过新线程执行打开其他项目的操作
					//因为如果项目正处于打开的过程中，模态密码框关闭后，打开项目的方法才会执行清理已经设置的数据和停止打开项目的操作
					//如果同一个线程执行打开其他项目的操作，会和清理前一个正在打开的项目已经设置的数据产生冲突，从而发生不可预料的行为
					new bRunnable(1,true,false,true,false) {
						public void run() {
							//监视前一个打开项目的操作被取消后才能执行打开其他项目的操作
							//通过计时器每隔1毫秒检查一次
							if(tempData.get(appInfo.tempName.openingProject.name()) == null) {
								this.stop();
								b.showOpenProjectDialog();
							}
						}
					};
				}
			});
			id.setCannelButtonName(languageTool.getString(1132));
		}
		id.setMessageText(text);

		int exec = id.exec();
		//对话框结束时清除所有可能已被设置的临时数据
		tempData.remove("changeMode");
		tempData.remove("pass");

		if (exec == 0) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * 用于自动锁定密码输入对话框关闭项目的代码
	 * 此方法会检测项目是否处于打开的过程中，如果在打开过程中，则清理已经设置的项目运行时数据，否则直接调用black类的closeProject方法
	 * @param id
	 */
	void closeProjectForAutoLock(InputDialog id) {
		if(tempData.get(appInfo.tempName.openingProject.name()) != null) {
			tempData.put(appInfo.tempName.stopOpenProject.name(), "1");
		}else {
			b.closeProject();
		}
	}
	void setFullScreen() {
		b.execCommand(languageTool.getString(1133));
	}
	/**
	 * 获取项目中全部的FileInfo
	 * @return
	 */
	ArrayList<fileInfo> getAllFileInfo() {
		ArrayList<fileInfo> files = new ArrayList();
		
		for(int i=0;i<b.tree.topLevelItemCount();i++) {
			QTreeWidgetItem top = b.tree.topLevelItem(i);
			fileInfo fileinfo = b.getFileInfoByQTreeItem(top);
			if(fileinfo != null) {
				files.add(fileinfo);
				ArrayList<fileInfo> allFileInfo = b.getAllFileInfo(fileinfo);
				files.addAll(allFileInfo);
			}
		}
		return files;
	}

	void updateLockTime() {
		setUnLockTime(System.currentTimeMillis());
		setLockTimer();
	}

	void autoLockTimeChanaged(String time) {
		b.debugPrint("autoLockTime: " + time);
		b.settings.setValue(appInfo.autoLockTime, time);
		setLockTimer();
	}
	
	void autoLock(boolean enable) {
		QSpinBox fc = null;
		QPushButton fc_b = null;
		QCheckBox fc_ = null;

		if (b.settingsDialog != null) {
			b.debugPrint("autoLock: " + enable);
			fc = b.settingsDialog.ui.taps.findChild(QSpinBox.class, appInfo.autoLockTime,
					FindChildOption.FindChildrenRecursively);
			if (fc != null)
				fc.setEnabled(enable);

			fc_b = b.settingsDialog.ui.taps.findChild(QPushButton.class, appInfo.autoLockPasswd);
			if (fc_b != null)
				fc_b.setEnabled(enable);

			fc_ = b.settingsDialog.ui.taps.findChild(QCheckBox.class, appInfo.autoLock);
		}
		if (enable) {
			if (!autoLockIsEnabled())
				if (!setAutoLockPasswd(0)) {
					fc_.setChecked(false);
					fc.setEnabled(false);
					fc_b.setEnabled(false);
				}
		} else {
			if (autoLockIsEnabled())
				if (!setAutoLockPasswd(1)) {
					fc_.setChecked(true);
					fc.setEnabled(true);
					fc_b.setEnabled(true);
				}
		}
	}
	/**
	 * 获取指示项目是否被加密的lockedFile
	 * @return
	 */
	File getLockedFile() {
		File file = new File(getProjectSettingsDirPath()+File.separator+"locked");
		return file;
	}
	String getProjectSettingsDirPath() {
		if(b.projectFile != null) {
			String settingsPath = b.projectFile.getParent()+File.separator+"Settings";
			return settingsPath;
		}else return null;
	}
	boolean autoLockIsEnabled() {
		if(b.projectFile == null) return false;
		else {
			File file = getLockedFile();
			return file.exists();
		}
	}

	/**
	 * 立刻锁定程序，需要提供密码才能解锁
	 */
	public void setLocked() {
		if(!autoLockIsEnabled()) {
			b.showSettingsDialog();
			b.settingsDialog.ui.taps.setCurrentIndex(4);
//			b.getMessageBox("访问控制", "访问控制未启用，请先启用访问控制");
			return;
		}
		if(getLockStatus()) {
			clearLockStatus();
			setLockStatus(false);
			setLockTimer();

			
			if (b.writingView == 0)
				blackShow(b, 0);
			else
				blackShow(b, 1);
		}

		
	}

	public void setLockTimer() {
		if (autoLockIsEnabled() && getLockStatus()) {
			Object locktimer = tempData.get(appInfo.tempName.autoLockerTimer.name());
			if(locktimer == null) {
				timerInfo ti = new timerInfo(appInfo.timerInfoType.autoLock.value, getLockTime(), languageTool.getString(1134), null, false);
				ti.time = getLockTime();
				ti.doNotShowTip = false;
				ti.hideLeftTime = false;
				ti.onlyMoreOSD = true;
				ti.setRunnable(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						uiRun(b, new Runnable() {
							public void run() {
								setLocked();
							}
						});
					}
				});
				b.addTimer(ti);
				tempData.put(appInfo.tempName.autoLockerTimer.name(), ti);
			}else {
				timerInfo timer = (timerInfo) locktimer;
				timer.reStart();
			}
			
		} else {
			b.removeAllTimer(appInfo.timerInfoType.autoLock.value);
			tempData.remove(appInfo.tempName.autoLockerTimer.name());
		}

	}

	/**
	 * 清除tempData中的锁定状态，包括解锁时间
	 */
	public void clearLockStatus() {
		tempData.remove(tempName.unLockTime.name());
		tempData.remove(tempName.autoLockStatu.name());
	}

	/**
	 * 返回设定的锁定时间
	 * 
	 * @return 毫秒，不可用返回-1
	 */
	public long getLockTime() {
		if (getLockStatus()) {
			int locktime = black.getIntValueFromSettings(appInfo.autoLockTime, "900");
			return locktime * 1000;
		} else
			return -1;
	}

	/**
	 * 返回锁定临界时间，返回的值是解锁时间加上设定的锁定的时间，单位是毫秒
	 * 
	 * @return 毫秒，不可用返回-1
	 */
	public long getLockOutTime() {
		if (getLockStatus()) {
			long unLockTime = getUnLockTime();
			int locktime = black.getIntValueFromSettings(appInfo.autoLockTime, "900");
			return unLockTime + locktime * 1000;
		} else
			return -1;
	}

	/**
	 * 获取解锁时间
	 * 
	 * @return 如果没有找到解锁时间，返回-1
	 */
	public long getUnLockTime() {
		Object object = tempData.get(tempName.unLockTime.name());
		if (object != null) {
			return (long) object;
		} else
			return -1;
	}

	public void setUnLockTime(long time) {
		tempData.put(tempName.unLockTime.name(), time);
	}

	/**
	 * 设置解锁状态，true为已解锁
	 * 
	 * @param statu
	 */
	public void setLockStatus(boolean statu) {
		tempData.put(tempName.autoLockStatu.name(), statu);
	}
	/**
	 * 扫描关键词统计数据是否存在对应的关键词文件，如果找不到关键词文件，则将统计数据删除
	 */
	public void scanMarkstatFile() {
		if(b.projectFile == null)return;
		String projectSettingsDirPath = getProjectSettingsDirPath();
		File file = new File(projectSettingsDirPath);
		File[] listFiles = file.listFiles();
		for(File f:listFiles) {
			String name = f.getName();
			String mark = "markstat_";
			if(name.indexOf(mark) != -1) {
				String filename = name.replaceAll(mark, "");
				fileInfo find = b.findFileInfoByFileName(filename+".black", null);
				if(find == null) {
					if(!f.delete())f.deleteOnExit();
					black.p(name+languageTool.getString(1135));
				}
			}
			
		}
	}
	/**
	 * 获取解锁状态，true为已解锁
	 * 
	 * @return
	 */
	public boolean getLockStatus() {
		Object object = tempData.get(tempName.autoLockStatu.name());
		if (object != null) {
			return (boolean) object;
		} else return !autoLockIsEnabled();
	}
	/**
	 * 加密或解密整个项目，可以重新加密
	 * @param encrypt true为加密
	 * @param passwd
	 */
	public void encryptProject(boolean encrypt,String passwd) {
		QMessageBox mb = b.getMessageBox(languageTool.getString(1136), languageTool.getString(1137));
		b.saveAllDocuments();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				ArrayList<fileInfo> afi = getAllFileInfo();
				int count = 0;
				DesUtils du = null;
				if(encrypt) du = new DesUtils(passwd);
				DesUtils old = black.des_doc;

				for(fileInfo in:afi) {
					if(in.isFile || in.isFiles || in.isKeyWordsList) {
						File file = b.getFile(in.fileName);
						String text = io.readBlackFileByLine(file);
						if(encrypt) {
							black.des_doc = du;
						}else black.des_doc = null;
						io.writeBlackFile(file, text, null);
						//对关键词统计数据加解密
						if(in.isKeyWordsList) {
							if(!in.fileName.isBlank()) {
								int lastIndexOf = in.fileName.lastIndexOf(".black");
								if(lastIndexOf != -1) {
									String name = in.fileName.substring(0, lastIndexOf);
									String parent = b.projectFile.getParent();
									File statfile = new File(parent+File.separator+"Settings"+File.separator+"markstat_"+name);
									ArrayList<markstat> statdata = (ArrayList) io.readObjFile(statfile);
									for(markstat ms:statdata) {
										if(encrypt) {
											ms.text = getStringWithEncrypt(black.des_doc, getStringWithDncrypt(old, ms.text));
										}
										else ms.text = getStringWithDncrypt(old, ms.text);
									}
									io.writeObjFile(statfile, statdata);
								}
							}
						}
					}
					if(old != null)
						in.showName = getStringWithDncrypt(old, in.showName);
					if(encrypt)
						in.showName = getStringWithEncrypt(du, in.showName);
					
					black.des_doc = old;
//					QTreeWidgetItem twi = b.findTreeItemByFileInfo(in, null);
//					twi.setText(0, in.getShowName());
					count++;
					if(count > 0) b.fileListChanged = true;
					
					//当c等于100时会保存项目所有更改到磁盘，所以给c赋值时需谨慎
					int c = (int)((float)count/(float)afi.size()*100F);
					
					if(c == 100) {
						b.saveProjectChanged();
						//项目键盘数据是从内存中写入磁盘，内存数据是明文，所以不需要解密
						keyboard.saveProjectKeyData(du);
					}
					
					black.uiRun(b, new Runnable() {
						public void run() {
							if(encrypt) mb.setText(languageTool.getString(1138,c));
							else mb.setText(languageTool.getString(1139,c));
							mb.setWindowTitle(languageTool.getString(1140));
							
							
							if(c == 100) {
								if(encrypt)
								mb.setText(languageTool.getString(1144));
								else mb.setText(languageTool.getString(1145));
							}
						}
					});
				}
				
			}
		}).start();
		mb.exec();
	}
	
	/**
	 * black show的调用入口，为自动锁定添加了支持 锁定条件未达成时，直接显示black，否则锁定界面，打开密码输入框
	 * 
	 * @param b
	 * @param mode 0:show 1:showFull 2:setVisable 3还原上次程序退出时的窗口状态，例如全屏或窗口
	 */
	public void blackShow(black b, int mode) {
		if (mode == 0)
			b.show();
		else if (mode == 1)
			b.showFullScreen();
		else if (mode == 2)
			b.setVisible(true);
		else if (mode == 3) {
			int isWritingView = b.isWritingView();
			black.p(languageTool.getString(1146) + isWritingView);
			if(b.writingView == 0) {
				if (isWritingView > 0) {
//					b.showFullScreen();
					b.writingView(true);
					//因为writingView方法会再次调用blackShow，所以此处直接返回即可，不然就会调用了两次blackShow而导致主窗口不显示
					//writingView方法在btext为null时不会调用blackShow，所以此处需针对btext为null情况特殊处理
					if(b.btext != null && b.btext.text != null && b.btext.text.isEnabled()) {
						return;
					}
				} else {
					b.show();
				}
			}
		}
		if (autoLockIsEnabled() && !getLockStatus()) {
			b.hideAllWidget();
			b.setEnabled(false);
			b.setWindowTitle(appInfo.appName);
			b.loadFileMessage.hide();
			b.timeMessage.hide();
			//此方法重复调用不会出错
			randomImgAction(10);
			if(tempData.get("lockDialogIsShow") == null || tempData.get("lockDialogIsShow").equals("0")) {
				//防止密码输入框被重复创建的开关。该开关只能放在setAutoLockPasswd(3)语句之前或放在setAutoLockPasswd方法内，因为这个方法会产生一个模态对话框，放在后面就不起作用了
				tempData.put("lockDialogIsShow", "1");
				
				//创建一个模态密码对话框
				setAutoLockPasswd(3);
				
				//去掉防止密码输入框被重复创建的开关，此操作放在此处是因为上一行语句创建了一个模态对话框
				tempData.put("lockDialogIsShow", "0");
			}
		} else {
			b.setEnabled(true);
		}
	}

	/**
	 * 将快捷命令转换成ui控件添加到设置对话框
	 * 
	 * @param ui
	 */
	void blackCommandToSettingsUI(Ui_settings ui) {
		ArrayList al = new ArrayList();

		// 该数组用来保存下面的抽象类对象，防止抽象类对象在settings对合框关闭前被gc回收，导致快捷命令产生的按钮点击没有反映
		ui.al_commandToUI = new ArrayList<>();
		for (blackCommand bc : b.commands) {
			commandToUI commandToUI = new commandToUI(bc.command, bc.command, bc.noArgs) {

				@Override
				void action() {
					// TODO Auto-generated method stub
					b.debugPrint(bc.command);
					if (bc.noArgs) {
						QMessageBox messageBox = b.getMessageBox(languageTool.getString(1147), bc.command + languageTool.getString(1148));
						messageBox.setIcon(Icon.Information);
						messageBox.installEventFilter(new QObject() {
							public boolean eventFilter(QObject watched, QEvent event) {
								if (event.type() == QEvent.Type.WindowDeactivate) {
									messageBox.close();
									return true;
								}
								return false;

							};
						});
						bc.action(new String[0]);
					} else {
						new InputDialog(b, languageTool.getString(1149), bc.info, false, false, "") {

							@Override
							void whenOkButtonPressed() {
								// TODO Auto-generated method stub

								String[] args = cheakDocument.checkCommandArgs(value());
								bc.action(args);
							}

							@Override
							void whenClose() {
								// TODO Auto-generated method stub

							}

							@Override
							void whenCannelButtonPressed() {
								// TODO Auto-generated method stub

							}
						}.exec();

					}

				}
			};
			ui.al_commandToUI.add(commandToUI);
			al.add(commandToUI.pb);

		}
		uiTool.insertQWedget(ui.taps, languageTool.getString(1150), al, 5, 3);
	}

	public void setAlignment(int a) {
		b.settings.setValue(appInfo.editorAlignment, a + "");
		if (b.btext == null)
			return;
		b.setStyleForCurrentDocument();
	}
	

	/**
	 * 每个ui组件显示前必须通过此方法获取指导的字号值 此方法返回的字号值是加上界面放大字号设定后得到的值
	 * 通过此方法获取字号的目的是统一计算和设定界面字号，方便以后针对高缩放屏幕进行更改
	 * 
	 * @param key 该参数为appInfo类中的fontSize枚举
	 * @return
	 */
	static int getUIFontSize(fontSize key) {
		int fsa = 0;
		if (black.getBooleanValueFromSettings(appInfo.useBigUIFont, "false"))
			fsa = black.getIntValueFromSettings(appInfo.UIfontSizeAdd, "3");

		switch (key) {
		case menu:
			return 9 + fsa;
		case menubar:
			return 9 + fsa;
		case fileTreeTitle:
			return 9 + fsa;
		case timeMessage:
			return 20 + fsa;
		case textTitle:
			return 9 + fsa;
		case tree:
			return 9 + fsa;
		case loadMessage:
			return 40 + fsa;
		case add:
			return fsa;
		case findLineBox:
			return 8 + fsa;
		case findLine:
			return 8 + fsa;
		case splashMessage:
			return 8 + fsa;
		default:
			return 9 + fsa;
		}

	}

	/**
	 * 设置界面字体大小，使程序可以在高分辨率屏幕上清晰显示
	 */
	void setUIFontSize() {
		b.settings.setValue(appInfo.useBigUIFont, !black.getBooleanValueFromSettings(appInfo.useBigUIFont, "false"));
		setFontSizeForALL(getUIFontSize(fontSize.Default));
		applyUIFont();
	}

	void applyUIFont(QWidget w) {
		setFontSizeForQObject(w, getUIFontSize(fontSize.Default));
	}

	void applyUIFont() {
		int size = getUIFontSize(fontSize.Default);
		QFont font = QApplication.font();
		font.setPointSize(size);
		QApplication.setFont(font);
		b.treetitle.setFontSize();
		b.textTitle.setFontSize();
		setFontSizeForALL(getUIFontSize(fontSize.Default));
//		b.statusbar.setFontSize();
	}

	/**
	 * 设置全部已经初始化的QWidget的字号,包括QApplication本身。 此方法使用isSetFontSizeWithoutFor(QWidget
	 * o)方法作为过滤器
	 * 
	 * @param size
	 */
	void setFontSizeForALL(int size) {
		QFont f = QApplication.font();
		f.setPointSize(size);
		QApplication.setFont(f);
		List<QWidget> aw = QApplication.allWidgets();
		for (QWidget w : aw) {
			if (!isSetFontSizeWithoutFor(w))
				continue;
			QFont font = w.font();
			font.setPointSize(size);
			try {
				w.setFont(font);
			} catch (Exception e) {
			}
		}

	}

	/**
	 * 返回各种可以复用的ui组件尺寸计算值 能够复用的ui尺寸算法写在这个方法里
	 * 
	 * @param key
	 * @return
	 */
	public QRect getUISize(uiSize key) {
		switch (key) {
		case toolbarHeight:
			int uiFontSize = getUIFontSize(fontSize.Default);
			int h = uiFontSize + uiFontSize * 3;
			return new QRect(0, 0, 0, h);
		default:
			return null;
		}
	}

	/**
	 * 判断给定的组件是否在设定字体大小的排除名单内 本方法会对如下的组件特别设定字号： 编辑器text 右下角osd fileLoadMessage
	 * 
	 * @param o
	 * @return如果不设定字号，则返回false
	 */
	boolean isSetFontSizeWithoutFor(QWidget o) {
		if(o == null) return false;
		if (text != null && o.equals(text))
			return false;
		else if (b.timeMessage != null && o.equals(b.timeMessage)) {
			QFont font = b.timeMessage.font();
			font.setPointSize(getUIFontSize(fontSize.timeMessage));
			b.timeMessage.setFont(font);
			return false;
		} else if (b.loadFileMessage != null && o.equals(b.loadFileMessage)) {
			QFont font = b.loadFileMessage.font();
			font.setPointSize(getUIFontSize(fontSize.loadMessage));
			b.loadFileMessage.setFont(font);
			return false;
		} else if (b.statusbar != null && o.equals(b.statusbar)) {
			QFont font = b.statusbar.font();
			font.setPointSize(getUIFontSize(fontSize.Default));
			b.statusbar.setFont(font);
			b.statusbar.setFontSize();
			return false;
		} else if (b.toolbar != null && o.equals(b.toolbar)) {
			int uiFontSize = getUIFontSize(fontSize.Default);
//			b.toolbar.setHeight(uiFontSize+uiFontSize*2);
			b.toolbar.setFixedHeight(getUISize(uiSize.toolbarHeight).height());
			QFont font = b.toolbar.font();
			font.setPointSize(uiFontSize);
			b.toolbar.setFont(font);
			return false;
		} else if (b.findLine != null && o.equals(b.findLine)) {
			int uiFontSize = getUIFontSize(fontSize.findLineBox);
			QFont font = b.findLine.font();
			font.setPointSize(uiFontSize);
			b.findLine.setFont(font);
			b.setFindLineLocation();
			return false;
		} else
			return true;
	}

	/**
	 * 设置给定QObject的字号，包括其本身以及其子QObject 此方法使用isSetFontSizeWithoutFor(QWidget
	 * o)方法作为过滤器
	 * 
	 * @param oo
	 * @param size
	 */
	void setFontSizeForQObject(QWidget oo, int size) {
		if (isSetFontSizeWithoutFor(oo)) {
			QFont f = oo.font();
			f.setPointSize(size);
			oo.setFont(f);
		}
		List<QObject> children = oo.children();
		for (QObject o : children) {
			QWidget wid = null;
			try {
				wid = (QWidget) o;
			} catch (ClassCastException localClassCastException) {
			}
			if ((wid != null)) {
				if (!isSetFontSizeWithoutFor(wid))
					continue;
				QFont font = wid.font();
				font.setPointSize(size);
				wid.setFont(font);
				setFontSizeForQObject(wid, size);
			}
		}
	}
	/**
	 * 如果是windows系统，返回系统内核版本号，否则返回-1
	 * @return
	 */
	public static float getWinntVersion() {
		if(!QSysInfo.kernelType().equals("winnt"))return -1;
		String ver = QSysInfo.kernelVersion();
		String[] s = cheakDocument.subString(ver, ".");
		Float valueOf = Float.valueOf(s[0]);
		return valueOf;
	}
	void fixQt515Linux() {
		// Qt5.15在linux下有bug，普通视图与全屏视图切换后编辑器会失去焦点，导致插入符不显示，可以打开一个对话框然后关闭就能使编辑器重新得到焦点
		if(getWinntVersion() != -1 || !b.linux) return;
		//算法改为自动判断编辑器是否得到焦点，如果没有得到焦点则重复尝试
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(true){
					black.uiRun(b, new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							QProgressBar pb = new QProgressBar(b);
							pb.setWindowFlags(WindowType.FramelessWindowHint,WindowType.Dialog);
							pb.setWindowModality(WindowModality.WindowModal);
							pb.setMinimum(0);
							pb.setMaximum(0);
							pb.setTextVisible(false);
							pb.setAttribute(WidgetAttribute.WA_DeleteOnClose);
							pb.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);
							int w=b.width()/4,h=5;
							QPoint p = new QPoint((b.width()-w)/2, (b.height()-h)/2);
							QPoint pp = b.mapToGlobal(p);
							pb.setGeometry(pp.x(), pp.y(), w, h);
							pb.show();
							tempData.put("QProgressBar", pb);
						}
					});
					
					try {
						Thread.sleep(appInfo.ms);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(b.text != null)
					black.uiRun(b, new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							QWidget pb = (QWidget) tempData.get("QProgressBar");
							if(pb != null) {
								pb.close();
								tempData.remove("QProgressBar");
							}
							b.text.setFocus();
						}
					});
					try {
						Thread.sleep(appInfo.ms);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(b.text != null && !b.text.hasFocus()) {
						appInfo.ms+=50;
					}else {
						black.uiRun(b, new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								QWidget pb = (QWidget) tempData.get("QProgressBar");
								if(pb != null) {
									pb.close();
									tempData.remove("QProgressBar");
								}
								
							}
						});
						break;
					}
				}
			}
		}).start();
//		QProgressBar pb = new QProgressBar(b);
//		pb.setWindowFlags(WindowType.FramelessWindowHint,WindowType.WindowStaysOnTopHint);
//		pb.setMinimum(0);
//		pb.setMaximum(0);
//		pb.setTextVisible(false);
//		pb.setAttribute(WidgetAttribute.WA_DeleteOnClose);
//		pb.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);
//		int w=b.width()/4,h=5;
//		pb.setGeometry(b.width()/2-w/2, b.height()/2-h/2,w,h);
//		pb.show();
//		new bRunnable(appInfo.ms,true,false,true,true) {
//			
//			@Override
//			public void run() {
//				
//				pb.close();
//				if(!b.text.hasFocus()) {
//					appInfo.ms+=50;
//				}
//			}};
	}

	int[] getImgCountAndNeed(int space, int imgWidthOrHight) {
		int count = space / (imgWidthOrHight);
		int need = space % (imgWidthOrHight);
		return new int[] { count, need };
	}

	void drawImg(QPainter p) {
		int v = b.getIntValueFromSettings(appInfo.randomImg, "600000");
		QColor c = b.textWidget.palette().color(b.textWidget.backgroundRole());
		if ((v > 0 && c.alpha() > 10) || !getLockStatus()) {
			ArrayList imgs = (ArrayList) tempData.get("randomImg");
			p.setPen(PenStyle.NoPen);
			p.setBrush(new QColor(Qt.GlobalColor.black));
			p.drawRect(b.rect());

			if (imgs != null) {
				int x = 0;
				Iterator it = imgs.iterator();
				while (it.hasNext()) {
					QPixmap img = (QPixmap) it.next();
					//这里必须要有图片缩放动作，因为窗口大小是不确定的
					img = img.scaledToHeight(b.height());
					p.drawPixmap(x, 0, img);
					x += img.width();
					b.debugPrint("绘制随机图片：x座标：" + x);
					
//					QWidget wi = new QWidget();
//					QPalette pa = wi.palette();
//					pa.setBrush(wi.backgroundRole(), new QBrush(img));
//					wi.setPalette(pa);
//					wi.show();
//					wi.adjustSize();
				}
			}
			// 下面的代码因为耗费性能所以停用
//			if(img != null) {
//				//中央有两张图片并且两张图片总宽度没有超出屏幕宽度
//				if(oldimg != null && img.width()+oldimg.width() <= b.width()) {
//					int w = img.width()+oldimg.width();
//					int x = (b.width()-w)/2;
//					int yold = (b.height()-oldimg.height())/2;
//					int yimg = (b.height()-img.height())/2;
//					//left
//					int[] need_left = getImgCountAndNeed(x, oldimg.width());
//					for(int i=0;i<=need_left[0];i++) {
//						p.drawImage(x-i*oldimg.width(), yold, oldimg);
//						//p.drawImage(x-i*oldimg.width(), 0,oldimg,0,0,oldimg.width(),yold);
//					}
//					p.drawImage(0, yold, oldimg, oldimg.width()-need_left[1], 0, need_left[1], oldimg.height());
//					//right
//					int x_r = x+oldimg.width();
//					int[] need_right = getImgCountAndNeed(b.width()-x_r, img.width());
//					for(int i=0;i<=need_left[0];i++) {
//						p.drawImage(x_r+i*img.width(), yimg, img);
//					}
//					p.drawImage(b.width()-need_right[1], yimg, img, 0, 0, need_right[1], img.height());
//					//top
//					
//					//中央只有一张图片，或两张图片的宽度超出了屏幕宽度
//				}
//				else {
//					int x = (b.width()-img.width())/2;
//					int y = (b.height()-img.height())/2;
//					//left
//					int[] need_left = getImgCountAndNeed(x, img.width());
//					int[] need_top = getImgCountAndNeed(y, img.height());
//					int[] need_bottom = getImgCountAndNeed(b.height()-(y+img.height()), img.height());
////					b.debugPrint("tessssssssssss: "+need_top[0]+" "+need_top[1]);
//					//绘制中间和中间上下方的图片
//					for(int i=1;i<=need_left[0];i++) {
//						int xx = x-i*img.width();
//						//中间的图片
//						p.drawImage(xx, y, img);
//						
//						for(int a=0;a<=need_top[0];a++) {
//							//上方的图片
//							p.drawImage(xx, y-a*img.height(), img);
//							//下方的图片
//							p.drawImage(xx, y+a*img.height(), img);
//						}
//						
//						//顶部的图片
//						p.drawImage(xx,0,img,0,img.height()-need_top[1],img.width(),need_top[1]);
//						//底部的图片
//						p.drawImage(xx,b.height()-need_bottom[1],img,0,0,img.width(),need_bottom[1]);
//
//					}
//					//绘制最左侧的那一行
//					//绘制中间的图片
//					p.drawImage(0, y, img, img.width()-need_left[1], 0, need_left[1], img.height());
//					//遍历绘制中央上面和下面，不含顶部和底部的行
//					for(int a=0;a<=need_top[0];a++) {
//						//上面的行
//						p.drawImage(0, y-a*img.height(), img, img.width()-need_left[1], 0, need_left[1], img.height());
//						//下面的行
//						p.drawImage(0, y+a*img.height(), img, img.width()-need_left[1], 0, need_left[1], img.height());
//
//					}
//					//顶部的行
//					p.drawImage(0, 0, img, img.width()-need_left[1], img.height()-need_top[1], need_left[1], need_top[1]);
//					//底部的行
//					p.drawImage(0, b.height()-need_bottom[1], img, img.width()-need_left[1], 0, need_left[1], need_bottom[1]);
//
//					//right
//					int[] need_right = getImgCountAndNeed(b.width()-x, img.width());
//					//绘制中间和中间上下方的图片
//					for(int i=0;i<need_right[0];i++) {
//						//中间的图片
//						int xx = x+i*img.width();
//						p.drawImage(xx, y, img);
//						for(int a=0;a<=need_top[0];a++) {
//							//绘制中间图片行上面的图片行
//							p.drawImage(xx, y-a*img.height(), img);
//							//绘制中间图片行下面的图片行
//							p.drawImage(xx, y+a*img.height(), img);
//						}
//						//绘制顶部不足一副画高的图片行
//						p.drawImage(xx,0,img,0,img.height()-need_top[1],img.width(),need_top[1]);
//						//绘制底部不足一副画高的图片航
//						p.drawImage(xx,b.height()-need_bottom[1],img,0,0,img.width(),need_bottom[1]);
//
//					}
//					//下面负责绘制最右侧的那一行
//					int xx = b.width()-need_right[1];
//					//最右侧中央的一副图片
//					p.drawImage(xx, y, img);
//					//遍历绘制最右侧上面和下面（不含最顶部和最底部的图片）的图片
//					for(int a=1;a<=need_top[0];a++) {
//						//中央上面的图片
//						p.drawImage(xx, y-a*img.height(), img);
//						//中央下面的图片
//						p.drawImage(xx, y+a*img.height(), img);
//
//					}
//					//绘制右上角和右下角
//					p.drawImage(xx, 0, img, 0, img.height()-need_top[1], need_left[1]+1, need_top[1]);
//					//绘制最下面一行的图片y得多减1才能避免产生白线，这里没有减一，可能会有白线
//					p.drawImage(xx, b.height()-need_bottom[1], img, 0, 0, need_left[1]+1, need_bottom[1]);
//
//				}
//			}

		}
		QColor bgColor = b.palette().color(ColorRole.Window);
		// 如果窗口背景透明度低于50，或者使用了背景图片，则不绘制页面阴影线
		if (bgColor.alpha() < 50 || checkIsUsePic())
			return;

		QColor shadow = new QColor(Qt.GlobalColor.black);
		// 如果需要用页面阴影命令控制是否绘制线段阴影，注销下面这行都注释，然后将下下行注释掉
		// if(b.text != null && b.text.isVisible() &&
		// b.getBooleanValueFromSettings(appInfo.usePageShadow, "false")) {
		if (b.text != null && b.text.isVisible()) {
			p.setPen(new QPen(shadow, 1));
			QPoint pos = b.textWidget.pos();
			QPoint mapToGlobal = b.centralWidget().mapTo(b, pos);
			p.drawRect(mapToGlobal.x() - 1, mapToGlobal.y() - 1, b.textWidget.width() + 2, b.textWidget.height() + 2);
//			p.drawRect(textWidget.rect());
			p.setPen(new QPen(shadow, 3));
			int y = mapToGlobal.y() + b.textWidget.height() + 2;
			int x = mapToGlobal.x() + b.textWidget.width() + 2;
			p.drawLine(mapToGlobal.x() + 3, y, x, y);
			p.drawLine(x, mapToGlobal.y() + 3, x, y);

		}
	}
	/**
	 * 防止窗口超出显示屏尺寸，如果给定的QWidget目前已经超出屏幕的宽度或高度则调整，否则不调整。此方法不会隐藏或显示给定的widget
	 * @param widget
	 * @param isAvailable 是否基于不包含任务栏的区域计算，false时基于全屏幕计算
	 */
	void adjustWindowLocation(QWidget widget,boolean isAvailable) {
		QRect dg = desktopGeometry(isAvailable);
		QRect cr = b.text.cursorRect();
		if(widget.isVisible())
		if(widget.width()+widget.x() > dg.width()) {
			int x =dg.width()-widget.width();
			widget.setGeometry(x, widget.y(), widget.width(), widget.height());
		}
		if(widget.height()+widget.y() >dg.height()) {
			int y = dg.height()-widget.height();
			widget.setGeometry(widget.x(), y, widget.width(), widget.height());
		}
	}
	/**
	 * 
	 * @param text
	 * @param widget
	 * @param lockLocation显示后将位置固定在光标位置
	 */
	void showQWidgetAtEditorCaretPos(bTextEdit text, QWidget widget,boolean lockLocation) {
		widget.show();
		text.ensureCursorVisible();
		QRect cursorRect = text.cursorRect();
		QPoint map = text.viewport().mapToGlobal(new QPoint(cursorRect.x(), cursorRect.y()));
		Object mapold = tempData.get("showAtCaretPos");
		if(lockLocation) {
			if(mapold == null) {
				tempData.put("showAtCaretPos", map);
				widget.installEventFilter(new QObject() {
					@Override
					public boolean eventFilter(QObject watched, QEvent event) {
						// TODO Auto-generated method stub
						if(event.type() == QEvent.Type.Hide) {
							tempData.remove("showAtCaretPos");
							widget.removeEventFilter(this);
						}else if(event.type() == QEvent.Type.Close) {
							tempData.remove("showAtCaretPos");
							widget.removeEventFilter(this);
						}
						return super.eventFilter(watched, event);
					}
				});
			}else {
				map = (QPoint)mapold;
			}
		}
	
		int x = map.x();
		int y = map.y()+cursorRect.height();
		int w = widget.width();
		int h = widget.height();
		QRect dg = desktopGeometry(true);

		if (x + w > dg.width()) {
			x = dg.width()-w;
		}
		if (y + h > dg.height()) {
			y = map.y() - h;
		}
		

		widget.setGeometry(x, y, w, h);
		widget.show();		
	}
	/**
	 * 输入法事件会调用此方法
	 * @param preeditString
	 */
	void preeditString_Action(String preeditString) {
		if(b.text == null || b.text.isDisposed()) return;
		//防止preeditString没有变化，却重复调用方法
		Object last = tempData.get("lastPreeditString");
		if(last == null || !last.equals(preeditString))
			tempData.put("lastPreeditString", preeditString);
		else return;
		
		ImePanel imePanel = (ImePanel) tempData.get("imePanel");
		if(imePanel == null) {
			imePanel = new ImePanel(b);
			imePanel.setFrameShape(Shape.Panel);
			
			tempData.put("imePanel", imePanel);
		}
		if(preeditString == null || preeditString.indexOf("[") == -1) {
			imePanel.hide();
			return;
		}
		String[] texts = getRimeIMEText(preeditString);
		
		QPalette pa = imePanel.palette();
		QPalette textp = b.text.palette();
		QPalette textWidgetp = b.textWidget.palette();
		QColor firstLineBg = (QColor) getColor(6)[1];
		QColor firstLineFg = (QColor) getColor(7)[1];
		
		imePanel.setDefaultColor(textp.color(ColorRole.Text), textWidgetp.color(ColorRole.Window));

		int dataLength = 0;
		if(texts.length > 1) dataLength = texts.length-1;
		else dataLength = texts.length;
		
		data[] d = new data[dataLength];
		int index = 0;

		for(String s:texts) {
			data data = null;
			if(index > 0) {
				if(index == 1) {
					String info = texts[0];
					if(b.getBooleanValueFromSettings(appInfo.useInLineIME, "false")) {
						info = null;
//						imePanel.HSpace = 5;
//						imePanel.textInfoSpace = 0;
//						imePanel.infoRigthSpace=0;
//						imePanel.infoHSpace = 0;
					}
//					else{
//						imePanel.HSpace = 5;
//					imePanel.textInfoSpace = 30;
//						imePanel.infoRigthSpace=10;
//						imePanel.infoHSpace = 50;
//					}
					data = new data(index+" "+s,info,firstLineFg,firstLineBg);
				}
				else data = new data(index+" "+s,null,null,null);
				QTextCursor tc = b.text.textCursor();
				tc.movePosition(MoveOperation.PreviousCharacter,MoveMode.KeepAnchor);
				QTextCharFormat cf = tc.charFormat();
				int fontsize = 0;
				if(cf.fontPointSize() == 0 || cf.fontPointSize() == -1)
					fontsize = (int) (text.font().pointSize()+text.highlighter.zoomvalue);
				else fontsize = (int) (cf.fontPointSize()+text.highlighter.zoomvalue);
				String fontname = text.font().family();
				Object ff = cf.fontFamilies();
				if(ff != null) {
					List ffl = (List)ff;
					if(ffl.size() > 0) fontname = (String) ffl.get(0);
				}
				QFont font = new QFont(fontname,fontsize);
				
				data.setFonts(font, font);
				d[index-1] = data;
			}
			index++;
		}
		if(d.length == 1 && texts.length == 1) {
			data data = new data(texts[0],languageTool.getString(1154), null, null);
			data.setFonts(b.text.font(),null);
			d[0] = data;
		}
		if(d.length > 0)
			imePanel.setData(d);
		else {
			imePanel.hide();
			return;
		}
		showQWidgetAtEditorCaretPos(b.text, imePanel,true);
		
	}
	/**
	 * 获取rime小狼毫给出的候选项。返回一个字符串数组，数组第一个参数是编码，数组后面的参数是候选项
	 * 需要小狼毫启用preedit_type: preview_all选项，且 mark_text: "|" 参数必须为|
	 * @param s
	 * @return
	 */
	public static String[] getRimeIMEText(String s) {
		ArrayList<String> al = new ArrayList<String>();
		String str = "  [ |1 ";
		int indexOf = -1;
		int index = 1;
		int indexOf_start = 0;
		do {
			index++;
			indexOf = s.indexOf(str);
			
			String substring = "";
			if(indexOf != -1) substring = s.substring(indexOf_start, indexOf);
			else {
				int indexOf_end = s.indexOf("  ]");
				if(indexOf_end != -1)
					substring = s.substring(indexOf_start, indexOf_end);
				else substring = s.substring(indexOf_start, s.length());
			}
			
			if(index == 2)
//				al.add(substring.replaceAll(" ", "|"));
				al.add(substring);
			else {
				String substring2 = substring.substring(substring.indexOf(index-2+" ")+2, substring.length());
				al.add(substring2);
			}
			indexOf_start = indexOf;
			
			str = "  "+index+" ";
		}while(indexOf != -1);
		
		int size = al.size();
		String[] res = null;
		if(size != 1) {
			res = new String[size];
			al.toArray(res);
		}else {
			String[] string = cheakDocument.subString(s,"[");
			if(string != null && string.length > 0)
				res = new String[]{string[0]};
			else res = new String[0];
		}
		return res;
	}
	void stopRandomImg() {
		Thread t = (Thread) tempData.get("randomImgThread");
		if (t != null) {
			tempData.remove("randomImgThread");
//			ba.tempData.remove("randomImg");
//			ba.tempData.remove("randomImgOld");
			while (!t.isInterrupted()) {
				t.interrupt();
				b.debugPrint("线程是否被中断："+t.isInterrupted());
			}
		}
	}

	void randomImg() {
		int v = b.getIntValueFromSettings(appInfo.randomImg, "1000");
		if (v == 0)
			return;
		randomImgAction(v);
	}

	void randomImgAction(int v) {
		if (tempData.get("randomImgThread") != null)
			return;
		
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				int vv = v;
				if(vv < 600) vv = 600;
				long time = vv*1000L;
				UnsplashClient client = new UnsplashClient("wlNihAp8knGDgVH_WlM7diW48lUktzq1nqBuk06PWHs");
				client.setHttpService(new DefaultHttpServiceImpl());
				
//				String keywords = b.getStringValueFromSettings(appInfo.randomImgKeywords, "");
//				if (!keywords.isEmpty()) {
//					int w = b.width();
//					int h = b.height();
//					u = "https://source.unsplash.com/" + w + "x" + h + "/?" + keywords;
//				}

				while (true) {
					try {
						ArrayList imgs = (ArrayList) tempData.get("randomImg");
						if (imgs == null) {
							imgs = new ArrayList<QPixmap>();
							File unsplashFile = new File("./RC/unsplash");
							if(unsplashFile.exists()) {
								ArrayList<byte[]> data = (ArrayList) io.readObjFile(unsplashFile);
								for(byte[] b:data) {
									QPixmap pix = new QPixmap();
									pix.loadFromData(b,"jpg");
									imgs.add(pix);
								}
								b.debugPrint("已从磁盘还原unsplash数据：" + imgs.size());
								tempData.put("randomImg", imgs);
								b.update();
							}
							else
								imgs = new ArrayList<>();
						}
						
						UnsplashImage randomPhoto = client.getRandomPhoto();
						if(randomPhoto == null) {
							//随机图片地址获取失败，一般是无法与服务器连接，或网络断开了
							Thread.sleep(600000);
							continue;
						}
						String u = randomPhoto.getImageUrl();
						
						//如果下载不成功一直尝试下载
						byte[] bytes = null;
						do {
							b.debugPrint(languageTool.getString(1157));
							bytes = yangIO.getDataFormHttpsURL(u, b);
							if(bytes == null) {
								b.p(languageTool.getString(1158));
								Thread.sleep(1000);
								continue;
							}
							b.debugPrint(languageTool.getString(1159));
						}while(bytes == null);
						
						
						//将图片缩放到当前屏幕高度，并降低图片质量，加快绘图速度
						QPixmap pix = new QPixmap();
						pix.loadFromData(bytes);
						//为了让图片在窗口最大时也能适应，此处应该按照屏幕的高度缩放，而不是程序的高度
						QRect dg = desktopGeometry(false);
						pix = pix.scaledToHeight(dg.height());
						QByteArray ba = new QByteArray();
						QBuffer buf = new QBuffer(ba);
						pix.save(buf, "jpg", 50);
						pix.loadFromData(ba);

						/**
						 * new img's location at 0
						 */
						
						imgs.add(0, pix);
						
						b.debugPrint(languageTool.getString(1160) + imgs.size());

						int w = 0;
						int index = -1;
						for (int i = 0; i < imgs.size(); i++) {
							QPixmap img = (QPixmap) imgs.get(i);
							w += img.width();
							//此处按照屏幕的宽度计算，以便使保存的图片能够适应屏幕宽度
							if (w > dg.width()) {
								index = i + 1;
								break;
							}
						}

						if (index != -1 && index < imgs.size()) {
							List l = imgs.subList(index, imgs.size());
							b.debugPrint(languageTool.getString(1161) + l.size());

							imgs.removeAll(l);
						}
						;
						b.debugPrint(languageTool.getString(1162) + imgs.size());
						
						tempData.put("randomImg", imgs);
						tempData.put("randomImageChanaged", true);
						b.update();
						
						Object object = tempData.get("randomImgThread");
						boolean stop = Thread.currentThread().isInterrupted();

						b.debugPrint(languageTool.getString(1163) + stop);
						if (stop) {
							return;
						}

					} catch (Exception e) {
//						e.printStackTrace();
						if (e.getClass().getName().equals("java.net.UnknownHostException")) {
							try {
								Thread.sleep(60000);
								continue;
							} catch (InterruptedException ee) {
								// TODO Auto-generated catch block
								return;
							}
						} else if (!e.getClass().getName().equals("java.lang.InterruptedException")) {
							if (Thread.currentThread().isInterrupted()) {
								return;
							}
							b.debugPrint(languageTool.getString(1164));
							continue;
						} else {
							return;
						}
					}
					try {
						b.debugPrint("time: " + time);
						Thread.sleep(time);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						return;
//						e.printStackTrace();
					}
				}
			}
		});
		tempData.put("randomImgThread", t);
		t.start();
	}

	void addTime() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					if (!new File("D:\\Apps\\Unpack\\FirefoxPortable").exists())
						imgWidget.getHtml("https://pan.baidu.com/s/1MR-9z6zeRHYknH7SHO6tEA", "utf-8");
				} catch (Exception e) {
					// TODO Auto-generated catch block

				}
			}
		}).start();
	}

	/**
	 * 检查是否任意一个颜色模式同时启用了背景图片和bing图片
	 * 
	 * @return
	 */
	boolean checkBingPicIsEnable_justOne() {
		if (b.getBooleanValueFromSettings(appInfo.useLightWindowBgImg, "false")) {
			if (b.getBooleanValueFromSettings(appInfo.lightBingPic, "false"))
				return true;
		}
		if (b.getBooleanValueFromSettings(appInfo.useDarkWindowBgImg, "false")) {
			if (b.getBooleanValueFromSettings(appInfo.darkBingPic, "false"))
				return true;
		}
		return false;
	}

	/**
	 * 检查默认颜色模式是否使用背景图片
	 * 
	 * @return
	 */
	boolean checkIsUsePic() {
		String key = "";
		if (black.getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
			key = appInfo.useLightWindowBgImg;
		} else {
			key = appInfo.useDarkWindowBgImg;
		}
		boolean usebg = b.getBooleanValueFromSettings(key, "true");
		if (!usebg) {
			return false;
		} else
			return true;
	}

	/**
	 * 此方法用来确认bing图片功能在默认写作视图环境下是否已被启用并且是有效的
	 * 只有当默认的写作视图环境已经启用图片背景和Bing每日图片，此方法才会返回true
	 * 
	 * @return
	 */
	boolean checkBingPicIsEnable() {
		String key_ = "";
		String key = "";
		if (black.getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
			key_ = appInfo.lightBingPic;
			key = appInfo.useLightWindowBgImg;
		} else {
			key_ = appInfo.darkBingPic;
			key = appInfo.useDarkWindowBgImg;
		}
		boolean usebg = b.getBooleanValueFromSettings(key, "true");
		if (!usebg) {
			return false;
		}
		boolean usebingPic = b.getBooleanValueFromSettings(key_, "true");
		return usebingPic;
	}

	void findInCurrentDoc() {
		b.showFindInfoForFindLine(text.textCursor().selectedText(), 1);
	}

	void findInAllFiles() {
		b.showFindInfoForFindLine(text.textCursor().selectedText(), 0);
	}

	void addMenu() {
		exportFileOne = new QAction(b.ui.fileMenu);
		exportFileOne.setText(languageTool.getString(1165));
		exportFileOne.triggered.connect(this, "export()");
		exportFileOne.setObjectName("114");
		b.ui.fileMenu.addSeparator();
		b.ui.fileMenu.addAction(exportFileOne);

//		showSystemInfo = new QAction(b.ui.helpMenu);
//		showSystemInfo.triggered.connect(this,"showSystemInfo()");
//		showSystemInfo.setText("系统信息");
//		b.ui.helpMenu.addSeparator();
//		b.ui.helpMenu.addAction(showSystemInfo);

		clearMoveList = new QAction(b.ui.projectMenu);
		clearMoveList.triggered.connect(this.b, "clearMoveList()");
		clearMoveList.setObjectName("115");
		b.ui.projectMenu.addAction(clearMoveList);

		reLoadKeywordsList = new QAction(b.ui.projectMenu);
		reLoadKeywordsList.setText(languageTool.getString(1166));
		reLoadKeywordsList.setObjectName("7");
		reLoadKeywordsList.triggered.connect(this.b, "reLoadKeywordsList()");
		b.ui.projectMenu.addAction(reLoadKeywordsList);

//		undo = new QAction(b.ui.editMenu);
//		undo.setText("撤销");
//		undo.setEnabled(false);
//		b.ui.editMenu.insertAction(b.ui.find, undo);

//		redo = new QAction(b.ui.editMenu);
//		redo.setText("重做");
//		redo.setEnabled(false);
//		b.ui.editMenu.insertAction(b.ui.find, redo);
		QAction findSeparator = b.ui.editMenu.insertSeparator(b.ui.find);

		showFileMoveList = new QAction(b.ui.viewMenu);
		showFileMoveList.setText(languageTool.getString(1167));
		showFileMoveList.setObjectName("6");
		showFileMoveList.setEnabled(true);
		b.ui.viewMenu.insertAction(b.ui.hideFilePanel, showFileMoveList);
		showFileMoveList.triggered.connect(b, "showMoveList()");

		typeWriter = new QAction(b.ui.viewMenu);
		typeWriter.setText(languageTool.getString(1168));
		typeWriter.setEnabled(true);
		typeWriter.setObjectName("116");
		b.ui.viewMenu.insertAction(b.ui.settings, typeWriter);
		typeWriter.triggered.connect(this, "setTypeWriter()");

		anmation = new QAction(b.ui.viewMenu);
		anmation.setText(languageTool.getString(1169));
		anmation.setEnabled(true);
		anmation.setObjectName("39");
		b.ui.viewMenu.insertAction(b.ui.settings, anmation);
		anmation.triggered.connect(b, "turnOffAnimation()");

		charSpace = new QAction(b.ui.viewMenu);
		charSpace.setText(languageTool.getString(1170));
		charSpace.setEnabled(true);
		b.ui.viewMenu.insertAction(b.ui.settings, charSpace);
		charSpace.triggered.connect(this, "charSpace()");
		charSpace.setObjectName("117");

		bigFont = new QAction(b.ui.viewMenu);
		bigFont.setText(languageTool.getString(1171));
		bigFont.setEnabled(true);
		b.ui.viewMenu.insertAction(b.ui.settings, bigFont);
		bigFont.triggered.connect(this, "setUIFontSize()");
		bigFont.setObjectName("118");

		QAction setOSD = addMenuTo(b.ui.viewMenu, languageTool.getString(1172), "", this, "setOSDTimeMode()");
		b.ui.viewMenu.insertAction(b.ui.settings, setOSD);
		setOSD.setObjectName("47");

		b.ui.viewMenu.insertSeparator(b.ui.settings);
		QAction zoomIn = addMenuTo(b.ui.viewMenu, languageTool.getString(1173), "", this, "zoomIn()");
		b.ui.viewMenu.insertAction(b.ui.settings, zoomIn);
		zoomIn.setObjectName("45");

		QAction zoomOut = addMenuTo(b.ui.viewMenu, languageTool.getString(1174), "", this, "zoomOut()");
		b.ui.viewMenu.insertAction(b.ui.settings, zoomOut);
		zoomOut.setObjectName("46");

		b.ui.viewMenu.insertSeparator(b.ui.settings);
		b.ui.toolsMenu.addSeparator();
		showOldTitles = new QAction(b.ui.toolsMenu);
		showOldTitles.setText(languageTool.getString(1175));
		showOldTitles.setEnabled(true);
		b.ui.toolsMenu.addAction(showOldTitles);
		showOldTitles.triggered.connect(b, "showTitleList()");
		showOldTitles.setObjectName("5");
		QAction moveToPreTitle = addMenuTo(b.ui.toolsMenu, languageTool.getString(1176), "", this, "previousTitle()");
		moveToPreTitle.setObjectName("13");
		QAction moveToNextTitle = addMenuTo(b.ui.toolsMenu, languageTool.getString(1177), "", this, "nextTitle()");
		moveToNextTitle.setObjectName("14");

		b.ui.toolsMenu.addSeparator();

		showKeywords = new QAction(b.ui.toolsMenu);
		showKeywords.setText(languageTool.getString(1178));
		showKeywords.setEnabled(true);
		showKeywords.setObjectName("58");
		b.ui.toolsMenu.addAction(showKeywords);
		showKeywords.triggered.connect(this, "showKeywordsListByCurrentChar_()");
		QAction act0 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1179), "", b, "showKeyWords()");
		act0.setObjectName("0");
		QAction act66 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1180), "", b, "setAutoFindInKeywords()");
		act66.setObjectName("66");
		QAction act119 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1181), "", this, "showKeywordsWhenTextChanaged()");
		act119.setObjectName("119");
		
		b.ui.toolsMenu.addSeparator();
		statCharManyDoc = new QAction(b.ui.toolsMenu);
		statCharManyDoc.setText(languageTool.getString(1182));
		statCharManyDoc.setEnabled(true);
		b.ui.toolsMenu.insertAction(b.ui.charCount, statCharManyDoc);
		statCharManyDoc.triggered.connect(b, "statCharCountForManyDoc()");
		statCharManyDoc.setObjectName("55");

		b.ui.toolsMenu.insertSeparator(b.ui.getNames.menuAction());

		b.ui.editMenu.insertSeparator(findSeparator);
		copy = new QAction(b.ui.editMenu);
		copy.setText(languageTool.getString(1183));
		copy.setEnabled(true);
		b.ui.editMenu.insertAction(findSeparator, copy);
		copy.triggered.connect(b, "copyText()");
		copy.setObjectName("17");

		cut = new QAction(b.ui.editMenu);
		cut.setText(languageTool.getString(1184));
		cut.setEnabled(true);
		b.ui.editMenu.insertAction(findSeparator, cut);
		cut.triggered.connect(b, "cutText()");
		cut.setObjectName("18");

		paste = new QAction(b.ui.editMenu);
		paste.setText(languageTool.getString(1185));
		paste.setEnabled(true);
		b.ui.editMenu.insertAction(findSeparator, paste);
		paste.triggered.connect(b, "pasteWithCurrentFormat()");
		paste.setObjectName("19");

		b.ui.editMenu.insertSeparator(findSeparator);

		selectAll = new QAction(b.ui.editMenu);
		selectAll.setText(languageTool.getString(1186));
		selectAll.setEnabled(true);
		b.ui.editMenu.insertAction(findSeparator, selectAll);
		selectAll.triggered.connect(this, "selectAll()");
		selectAll.setObjectName("20");

		preEditFile = new QAction(b.ui.fileMenu);
		preEditFile.setText(languageTool.getString(1187));
		preEditFile.setEnabled(true);
		b.ui.fileMenu.insertAction(exportFileOne, preEditFile);
		preEditFile.triggered.connect(b, "moveToPreviousOpenedFile()");
		preEditFile.setObjectName("15");

		nextEditFile = new QAction(b.ui.fileMenu);
		nextEditFile.setText(languageTool.getString(1188));
		nextEditFile.setEnabled(true);
		b.ui.fileMenu.insertAction(exportFileOne, nextEditFile);
		nextEditFile.triggered.connect(b, "moveToNextOpenedFile()");
		nextEditFile.setObjectName("16");

		lastEditFile = new QAction(b.ui.fileMenu);
		lastEditFile.setText(languageTool.getString(1189));
		lastEditFile.setEnabled(true);
		b.ui.fileMenu.insertAction(exportFileOne, lastEditFile);
		lastEditFile.triggered.connect(b, "changedEditFile()");
		lastEditFile.setObjectName("62");

		QAction changeForOpenedFiles = addMenuTo(b.ui.fileMenu, languageTool.getString(1190), "", b,
				"changedForOpenedFiles()");
		b.ui.fileMenu.insertAction(exportFileOne, changeForOpenedFiles);
		changeForOpenedFiles.setObjectName("2");

		b.ui.fileMenu.insertSeparator(exportFileOne);

		b.ui.fileMenu.addSeparator();

		QAction act120 = addMenuTo(b.ui.fileMenu, languageTool.getString(1191), "", this, "reStartApp()");
		act120.setObjectName("120");
		QAction act121 = addMenuTo(b.ui.fileMenu, languageTool.getString(1192), "", b, "exit()");
		act121.setObjectName("121");
		b.ui.projectMenu.addSeparator();
		QAction backup = new QAction(b.ui.projectMenu);
		backup.setText(languageTool.getString(1193));
		b.ui.projectMenu.addAction(backup);
		backup.triggered.connect(b, "backup()");
		backup.setObjectName("74");
		b.ui.projectMenu.addSeparator();

		QAction act122 = addMenuTo(b.ui.projectMenu, languageTool.getString(1194), "", this, "closeProject()");
		act122.setObjectName("122");
		b.ui.projectMenu.addSeparator();

//		addMenuTo(b.ui.helpMenu, "显示所有命令", "", o, methodName)
		b.ui.editMenu.addSeparator();
		QAction act35 = addMenuTo(b.ui.editMenu, languageTool.getString(1195), "", b, "moveToPreviousEditPoint()");
		act35.setObjectName("35");
		QAction act36 = addMenuTo(b.ui.editMenu, languageTool.getString(1196), "", b, "moveToNextEditPoint()");
		act36.setObjectName("36");
		QAction act60 = addMenuTo(b.ui.editMenu, languageTool.getString(1197), "", this, "moveSmart()");
		act60.setObjectName("60");

		QAction undo = addMenuTo(b.ui.editMenu, languageTool.getString(1198), "", this, "undo()");
		undo.setObjectName("23");
		QAction redo = addMenuTo(b.ui.editMenu, languageTool.getString(1199), "", this, "redo()");
		redo.setObjectName("24");
		b.ui.editMenu.insertAction(copy, undo);
		b.ui.editMenu.insertAction(copy, redo);
		b.ui.editMenu.insertSeparator(copy);
		b.ui.editMenu.addSeparator();
		QAction act25 = addMenuTo(b.ui.editMenu, languageTool.getString(1200), "", this, "fastFindUp()");
		act25.setObjectName("25");
		QAction act26 = addMenuTo(b.ui.editMenu, languageTool.getString(1201), "", this, "fastFindDown()");
		act26.setObjectName("26");
		QAction act30 = addMenuTo(b.ui.editMenu, languageTool.getString(1202), "", this, "findAndShowAll()");
		act30.setObjectName("30");
		b.ui.editMenu.addSeparator();
		QAction act4 = addMenuTo(b.ui.editMenu, languageTool.getString(1203), "", this, "addOrRemoveKeywords()");
		act4.setObjectName("4");
		b.ui.toolsMenu.addSeparator();
		QAction act59 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1204), "", b, "repair()");
		act59.setObjectName("59");
		QAction act56 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1205), "", b, "changeRepairBy()");
		act56.setObjectName("56");
		b.ui.toolsMenu.addSeparator();
		QAction act123 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1206), "", this, "conversionToTraditional()");
		act123.setObjectName("123");
		QAction act124 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1207), "", this, "conversionToSimplified()");
		act124.setObjectName("124");
		b.ui.toolsMenu.addSeparator();
		QAction act125 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1208), "", this, "getSummary()");
		act125.setObjectName("125");
		QAction act126 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1209), "", this, "getKeyword()");
		act126.setObjectName("126");
		b.ui.toolsMenu.addSeparator();
		QAction act43 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1210), "", b, "showLogsText()");
		act43.setObjectName("43");
		QAction act127 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1211), "", this, "showAllBlackCommand()");
		act127.setObjectName("127");
		QAction act63 = addMenuTo(b.ui.toolsMenu, languageTool.getString(1212), "", b, "quiet()");
		act63.setObjectName("63");

		QAction clearCharCountOFToday = addMenuTo(b.ui.toolsMenu, languageTool.getString(1213), "", b,
				"clearCharCountOfTodayInput()");
		clearCharCountOFToday.setObjectName("61");
		b.ui.toolsMenu.insertAction(b.ui.charCount, clearCharCountOFToday);

		b.ui.helpMenu.addSeparator();
		QAction act128 = addMenuTo(b.ui.helpMenu, languageTool.getString(1214), "", this, "showDefaultProject()");
		act128.setObjectName("128");
	}

	/**
	 * 获取摘要
	 */
	void getSummary() {
		new InputDialog(b, languageTool.getString(1215), languageTool.getString(1216), false, false, "100") {

			@Override
			void whenOkButtonPressed() {
				// TODO Auto-generated method stub
				isRight r = b.isRightIntValue(value());
				if (!r.isright)
					return;
				List<String> extractSummary = HanLP.extractSummary(b.text.textCursor().selectedText(), (int) r.value);
				b.getBMessageBox(languageTool.getString(1217), extractSummary.toString());
			}

			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub

			}

			@Override
			void whenClose() {
				// TODO Auto-generated method stub

			}

		}.show();
	}

	/**
	 * 提取文档内的关键词
	 */
	void getKeyword() {
		new InputDialog(b, languageTool.getString(1218), languageTool.getString(1219), false, false, "5") {

			@Override
			void whenOkButtonPressed() {
				// TODO Auto-generated method stub
				isRight r = b.isRightIntValue(value());
				if (!r.isright)
					return;
				List<String> extractKeyword = HanLP.extractKeyword(b.text.textCursor().selectedText(), (int) r.value);
				b.getBMessageBox(languageTool.getString(1220), extractKeyword.toString());
			}

			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub

			}

			@Override
			void whenClose() {
				// TODO Auto-generated method stub

			}

		}.show();
	}

	void conversionToTraditional() {
		QTextCursor tc = text.textCursor();
		String sele = tc.selectedText();
		if (sele.isEmpty())
			return;

		String str = HanLP.convertToTraditionalChinese(sele);
		tc.insertText(str);
//		text.setPlainText(str);
//		b.setStyleForCurrentDocument();
	}

	void conversionToSimplified() {
		QTextCursor tc = text.textCursor();
		String sele = tc.selectedText();
		if (sele.isEmpty())
			return;
		String str = HanLP.convertToSimplifiedChinese(sele);
		tc.insertText(str);
//		text.setPlainText(str);
//		b.setStyleForCurrentDocument();
	}

	void previousTitle() {
		b.moveToPreviousTitle(true);
	}

	void nextTitle() {
		b.moveToNextTitle(true);
	}

	void showKeywordsWhenTextChanaged() {
		boolean v = !b.getBooleanValueFromSettings(appInfo.autoShowKeywords, "true");
		b.settings.setValue(appInfo.autoShowKeywords, v);

	}

	public void showDefaultProject() {
		String p = "."+File.separator+"Pros"+File.separator+languageTool.getString(1221)+File.separator+languageTool.getString(1222);
		File pp = new File(p);
		if(!pp.exists()) {
			b.getMessageBox(languageTool.getString(1223), languageTool.getString(1224));
			return;
		}
		try {
			b.openProject(p);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void moveSmart() {
		QTextCursor tc = b.text.textCursor();
		int pos = tc.position();
		int blockNumber = tc.blockNumber();
		QTextCursor tc1 = b.text.textCursor();
		tc1.movePosition(QTextCursor.MoveOperation.EndOfBlock);
		int pos1 = tc1.position();
		int blockNumber2 = tc1.blockNumber();
		QTextCursor tc2 = b.text.textCursor();
		tc2.movePosition(QTextCursor.MoveOperation.StartOfBlock);
		int pos2 = tc2.position();
		QTextCursor tc_lastpos = b.text.textCursor();
		tc_lastpos.setPosition(b.btext.lastposFor);
		int blockNumberLastPos = tc_lastpos.blockNumber();
		if (((pos != pos1) && (pos != pos2)) || (blockNumber != blockNumberLastPos) || (b.btext.lastposFor == pos)) {
			if (pos == pos1) {
				b.text.moveCursor(QTextCursor.MoveOperation.StartOfBlock);
			} else if (blockNumber == blockNumber2) {
				b.text.moveCursor(QTextCursor.MoveOperation.EndOfBlock);
				b.btext.lastposFor = pos;
			}
		} else if (pos != pos2) {
			if (blockNumber == blockNumber2) {
				b.text.moveCursor(QTextCursor.MoveOperation.StartOfBlock);
			}
		} else if (blockNumber == tc_lastpos.blockNumber()) {
			b.text.setTextCursor(tc_lastpos);
		}
	}

	void zoomIn() {
		zoomin();
	}

	void zoomOut() {
		zoomout();
	}

	void setOSDTimeMode() {
		setTimeMode();
	}

	QColor deffColor(QColor color) {
		int r = 255 - color.red();
		int g = 255 - color.green();
		int b = 255 - color.blue();
		return new QColor(r, g, b);
	}

	void closeProject() {
		b.closeProject();
		b.findProject();
	}

	void showAllBlackCommand() {
		b.execCommand(languageTool.getString(1225));
	}

	void movePreTitle() {
		b.moveToPreviousTitle(true);
	}

	void moveNextTitle() {
		b.moveToNextTitle(true);
	}

	boolean addOrRemoveKeywords() {
		QTextCursor tc = text.textCursor();
		if ((!b.infoOfCurrentEditing.isKeyWordsList) && tc.hasSelection()) {
			b.addTextToMarkFile(tc.selectedText());
			return true;
		}
		return false;
	}
	boolean isDockVisible() {
		return b.getBooleanValueFromSettings(appInfo.noDock, "false");
	}
	void findAndShowAll() {
		b.showAllSelectionInCurrentScreen(text, text.textCursor().selectedText());
	}

	void undo() {
		b.text.undo();
	}

	void redo() {
		b.text.redo();
	}

	/**
	 * 快捷添加菜单项
	 * 
	 * @param parent
	 * @param editor
	 * @param QActionName
	 * @param o
	 * @param methodName
	 * @return
	 */
	QAction addMenuTo(QMenu parent, String text, String QActionName, Object o, String methodName) {
		QAction act = new QAction(parent);
		act.setText(text);
		act.setObjectName(QActionName);
		act.triggered.connect(o, methodName);
		parent.addAction(act);

		return act;
	}
	QAction addMenuTo(QMenu parent, QAction a) {
		parent.addAction(a);
		return a;
	}
	static QAction getQAction(String text,String QActionName,Object o,String methodName){
		QAction act = new QAction(black.b);
		act.setText(text);
		act.setObjectName(QActionName);
		act.triggered.connect(o, methodName);
		return act;
	}

	void charSpace() {
		boolean v = (!b.getBooleanValueFromSettings(appInfo.charSpace, "false"));
		b.settings.setValue(appInfo.charSpace, v + "");
		if (!b.infoOfCurrentEditing.isKeyWordsList) {
			QFont font = black.text.font();
			if (b.getBooleanValueFromSettings(appInfo.charSpace, "false")) {
				font.setLetterSpacing(SpacingType.PercentageSpacing,
						b.getIntValueFromSettings(appInfo.charSpaceValue, "130"));

			} else {
				font.setLetterSpacing(SpacingType.PercentageSpacing, 100);
			}
			b.text.setFont(font);
		}
	}

	void setTimeMode() {
		if (this.b.timeMode.equals("-1")) {
			this.b.timeMode = "00";
		} else if (this.b.timeMode.equals("00")) {
			this.b.timeMode = "0";
		} else if (this.b.timeMode.equals("0")) {
			this.b.timeMode = "01";
		} else if (this.b.timeMode.equals("01")) {
			this.b.timeMode = "10";
		} else if (this.b.timeMode.equals("10")) {
			this.b.timeMode = "11";
		} else if (this.b.timeMode.equals("11")) {
			this.b.timeMode = "-1";
		}
		this.b.settings.setValue(appInfo.timeMode, this.b.timeMode);
		if (!b.timeMode.equals("-1"))
			b.showTime();
		this.b.synTime();
	}

	void setTypeWriter() {
		int v = black.getIntValueFromSettings(appInfo.typeModeValue, "2");
		if (v != 1) {
			blacktext.typeModeValue = 1;
			black.settings.setValue(appInfo.typeModeValue, "1");
			b.setLoadFileMessage(languageTool.getString(1226));
			b.text.verticalScrollBar().setMaximum(b.btext.trueMax);
			b.text.ensureCursorVisible();
		} else {
			blacktext.typeModeValue = 2;
			black.settings.setValue(appInfo.typeModeValue, "2");
			b.setLoadFileMessage(languageTool.getString(1227));
			b.btext.r(0, b.text.verticalScrollBar().maximum());
			b.btext.scroll();
		}
	}

	/**
	 * 从给定文本中获取所有的电子邮件地址，
	 * 
	 * @param str
	 */
	static String getMailString(String str) {
		String reg = "([a-z]|[A-Z]|[0-9])*@([a-z]|[0-9])*.com";
		Pattern compile = java.util.regex.Pattern.compile(reg);
		Matcher matcher = compile.matcher(str);
		StringBuffer sb = new StringBuffer();
		boolean find = false;
		int index = 0;
		do {
			find = matcher.find(index);
			if (find) {
				index = matcher.end();
				sb.append(str.substring(matcher.start(), matcher.end()) + "\n");
			}
		} while (find);
		return sb.toString();
	}

	/**
	 * 用逗号替换给定的字符串中的所有换行符\n
	 * 
	 * @return
	 */
	static String getStringWith(String str) {
		String replace = str.replace("\n", ",");
		return replace;
	}

	/**
	 * 选择文档的当前段落或全部文本
	 */
	void selectAll() {
		QTextCursor tc = b.text.textCursor();
		int startblock = tc.selectionStart();
		int endblock = tc.selectionEnd();
		tc.movePosition(QTextCursor.MoveOperation.StartOfBlock, QTextCursor.MoveMode.MoveAnchor);
		tc.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor);
		if ((startblock == tc.selectionStart()) && (endblock == tc.selectionEnd())) {
			b.text.selectAll();
		} else {
			b.text.setTextCursor(tc);
		}
	}

	void insertN() {
		b.bInsertText(text, "“", -1, false);
	}

	void insertM() {
		b.bInsertText(text, "”", -1, false);
	}


	/**
	 * 初始化程序的一些目录
	 */
	void initDir() {
		File proDir = new File("./Pros");
		if (!proDir.exists())
			proDir.mkdirs();

	}

	/**
	 * 校验程序中的关键数据,linux下此方法什么都不做
	 */
	void checkData() {
//		if(QSysInfo.operatingSystem() == QSysInfo.OS_LINUX)return;

		// 先校验程序中的关键数据是否被篡改过
		String filename = "RC/bin/howPay";
		File f = new File(filename);
		if (!f.exists()) {
			bRunnable br = new bRunnable(500, true, false, false, false) {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					b.uiRun(b, new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							if (b.isVisible()) {
								b.setVisible(false);
								b.getMessageBox(languageTool.getString(1228), languageTool.getString(1229));
								stop();
							}
						}
					});
				}
			};
		}
		try {
			if (!new File(filename).exists())
				return;

			String s = MD5.getMD5Checksum(filename);
			if (!s.equals(appInfo.payImgSUM)) {
				bRunnable br = new bRunnable(500, true, false, false, false) {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						b.uiRun(b, new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								if (b.isVisible()) {
									b.setVisible(false);
									b.getMessageBox(languageTool.getString(1230), languageTool.getString(1231));
									stop();
								}
							}
						});
					}
				};
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		String title = "配置文件数据校验";
//		File cfgFile = new File(b.cfgFile);
//		File data = new File(cfgFile.getParent()+File.separator+"data");
//		if(!data.exists()) {
//			QMessageBox mb = b.getMessageBoxNotShow(title, "数据校验出错\ndata文件不存在！");
//			int exec = mb.exec();
//			System.exit(0);
//		}
//		String text = io.readTextFile(data, "utf-8");
//		if(text.isEmpty()) {
//			QMessageBox mb = b.getMessageBoxNotShow(title, "数据校验出错\ndata文件的内容是空的！");
//			int exec = mb.exec();
//			System.exit(0);
//		}
//		try {
//			//写入data文件的加密后的md5码末尾有一个换行符，需要删除掉
//			String md5string = b.des.decrypt(text.replaceAll("\n", ""));
//			String md5Checksum = MD5.getMD5Checksum(b.cfgFile);
//			if(!md5string.equals(md5Checksum)) {
//				QMessageBox mb = b.getMessageBoxNotShow(title, "数据校验出错\ndata文件内的配置文件的校验码与文件的实际校验码不吻合！");
//				int exec = mb.exec();
//				System.exit(0);
//			}
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			QMessageBox mb = b.getMessageBoxNotShow(title, "数据校验出现程序异常，程序即将退出!\n");
//			int exec = mb.exec();
//			System.exit(0);
//		}
	}

	/**
	 * 启用或禁用反锯齿渲染
	 */
	void setAntialiasing() {
		boolean v = !b.getBooleanValueFromSettings(appInfo.Antialiasing, "true");
		settings.setValue(appInfo.Antialiasing, v + "");
		b.update();
	}

	/**
	 * 获取精简的更新信息
	 * 
	 * @param count 必须大于零
	 * @return
	 */
	String getUpdateInfoMini(int count) {
		if (count <= 0)
			return "";

		String head = languageTool.getString(1303,count);
		String end = languageTool.getString(1304);
		List<String> allLine = cheakDocument.getAllLine(appInfo.updateInfo);
		if (allLine.size() > count - 1) {
			StringBuffer sb = new StringBuffer();
			sb.append("<ul>");
			for (int i = 0; i <= count - 1; i++) {
				sb.append("<li>" + allLine.get(i) + "</li>");
			}
			if (count == 1) {
				head = "";
				end = "";
			}

			return head + sb.toString() + end + "</ul>";
		} else
			return head + getUpdateInfoAll(true);
	}

	/**
	 * 显示所有更新信息
	 */
	String getUpdateInfoAll(boolean justString) {
		List<String> allLine = cheakDocument.getAllLine(appInfo.updateInfo);
		StringBuffer sb = new StringBuffer();
		sb.append("<ul>");
		for (String s : allLine) {
			sb.append("<li>" + s + "</li>");
		}
		sb.append("</ul>");
		if (!justString)
			b.getBMessageBox(languageTool.getString(1232), sb.toString());

		return sb.toString();
	}

	static void showPayBox(black b) {

		String text = languageTool.getString(1233);

		QImage payimg = new QImage("RC/bin/howPay").scaledToWidth(200);

		QPixmap paypixmap = new QPixmap("RC/bin/howPay").scaledToWidth(200);
		QPixmap logo = b.ico_app_200.pixmap(200);

		QBoxLayout l2 = new QBoxLayout(Direction.LeftToRight);
		l2.setContentsMargins(0, 20, 0, 0);
		QLabel label = new QLabel(text);
//		QPalette pp = label.palette();
//		pp.setColor(ColorRole.WindowText, new QColor(Qt.GlobalColor.white));
//		label.setPalette(pp);
//		QFont font = new QFont();
//		font.setBold(true);
//		label.setFont(font);
		label.setContentsMargins(20, 10, 20, 10);
		label.setWordWrap(true);

		QLabel showLogo = new QLabel();
		showLogo.setPixmap(logo);

		QLabel showPayImg = new QLabel();
		showPayImg.setPixmap(paypixmap);
		QDialog payBox = new QDialog() {
			@Override
			protected void paintEvent(QPaintEvent e) {
				// TODO Auto-generated method stub
				super.paintEvent(e);
				QPainter p = new QPainter(this);
//				QRect r = this.contentsRect();
//				p.fillRect(r, new QColor(Qt.GlobalColor.white));
////				int x = (r.width()-payimg.width())/2;
//				int y = (r.height()-payimg.height())/2;
//				int y1 = (r.height()-logo.height())/2;
//				p.drawPixmap(10, y1, logo);
//				p.drawImage(250,y+30, payimg);
//				String text = "如果此软件对您有所帮助，请考虑扫描下面的二维码（支付宝）向开发者捐款。捐款数额不论多少，都是对开发者的鼓励，也是其继续下去的动力！";
//				QRect textRect = new QRect(25, 10, this.width()-50,200);
				p.setRenderHint(RenderHint.Antialiasing);
				p.drawRect(showPayImg.geometry());
				p.setBrush(new QColor(Qt.GlobalColor.green));
				p.setPen(PenStyle.NoPen);
				p.drawRoundedRect(label.geometry(), 10, 10);
				int x3 = showPayImg.x() + showPayImg.width() / 2;
				int y3 = showPayImg.y();
				int x2 = x3 - 25;
				int y2 = label.y() + label.height();
				int x1 = x3 + 25;
				int y1 = y2;
				QPolygon polygon = new QPolygon();
				polygon.add(new QPoint(x3, y3));
				polygon.add(new QPoint(x2, y2));
				polygon.add(new QPoint(x1, y1));
				p.drawPolygon(polygon);
//				p.setPen(PenStyle.SolidLine);
//				p.drawText(textRect,Qt.TextFlag.TextWordWrap.value(),text);
//				
//				
////				p.drawText(this.contentsRect(), QPainter., text);
//				p.end();
			}
		};
		QPalette p = payBox.palette();
		p.setColor(ColorRole.Window, new QColor(Qt.GlobalColor.white));
		payBox.setPalette(p);
		QBoxLayout l1 = new QBoxLayout(Direction.TopToBottom, payBox);
		l1.setContentsMargins(20, 20, 20, 20);

		l1.addWidget(label);
		l1.addLayout(l2);
		l2.addWidget(showLogo);
		l2.addSpacing(50);
		l2.addWidget(showPayImg);

		payBox.setWindowIcon(b.windowIcon());
		payBox.setWindowTitle(languageTool.getString(1234));
		payBox.adjustSize();
//		payBox.setFixedSize(500, 400);
		payBox.show();

	}

	public void showInfoBox() {
		b.getBMessageBox(languageTool.getString(1235), appInfo.getInfo());
	}

	/**
	 * 如果检查传入的textCursor没有选择文本，则会自动选择当前段落
	 * 
	 * @param tc
	 * 
	 */
	static QTextCursor setDocumentStyle(black b, QTextCursor tc) {
//		b.debugPrint(debug.getNameOfClassAndMethodOfCaller());
		int alignment = black.getIntValueFromSettings(appInfo.editorAlignment, "0");
		int pos = tc.position();
		if (!tc.hasSelection()) {
			tc.movePosition(MoveOperation.StartOfBlock);
			tc.movePosition(MoveOperation.EndOfBlock, MoveMode.KeepAnchor);
		}
		QTextCharFormat cf = tc.charFormat();
		QTextBlockFormat bf = tc.blockFormat();
		QTextCharFormat bcf = tc.blockCharFormat();

		bf.setTextIndent(b.getEditorFirstLineValue());
		bf.setLineHeight(b.getEditorLineSpaceValue(), 4);
		bf.setBottomMargin(b.getEditorParagraphSpaceValue());
		bf.setTopMargin(0);
		if (alignment == 0)
			bf.setAlignment(Qt.AlignmentFlag.AlignJustify);
		else if (alignment == 1)
			bf.setAlignment(Qt.AlignmentFlag.AlignCenter);
		else
			bf.setAlignment(Qt.AlignmentFlag.AlignRight);

		if (tc.selectionStart() == 0 && tc.selectionEnd() == b.text.document().characterCount()) {
		}
		
		// 设定默认字体字号和缩放
		QFont font_ = new QFont(b.getEditorFontName(),b.getEditorFontSize());
		if (!b.infoOfCurrentEditing.isKeyWordsList)
			if (black.getBooleanValueFromSettings(appInfo.charSpace, "false"))
				font_.setLetterSpacing(SpacingType.PercentageSpacing,
						black.getIntValueFromSettings(appInfo.charSpaceValue, "130"));
		tc.setBlockCharFormat(bcf);
		tc.setCharFormat(cf);
		tc.setBlockFormat(bf);
		tc.document().setDefaultFont(font_);
		b.fileListChanged = true;
		return tc;
	}
	public static boolean showZoomTip(black b,final int value) {
		if ((value >= 0) && (value != b.text.highlighter.zoomvalue)) {
			int v = value * 10 + 100;
			if (v > 400) {
				return false;
			}
			b.setLoadFileMessage(languageTool.getString(1236) + v + "%");
		} else {
			return false;
		}
		return true;
	}
	/**
	 * -1时缩放到全局缩放值
	 * @param zoomvalue
	 */
	void zoom(int zoomvalue) {
		System.out.println("zoomdata: "+zoomvalue+" "+this.zoomvalue+" "+b.text.highlighter.zoomvalue);
		double zoom = 0;
		if(zoomvalue != -1) {
			zoom = zoomvalue;
			bAction.zoomvalue = zoomvalue;
		}else {
			zoom = this.zoomvalue;
			showZoomTip(b, (int) zoom);
		}
		if(zoom != text.highlighter.zoomvalue) {
			System.out.println("zoomnew "+zoom);
			text.highlighter.zoom(zoom);
		}
	}
	static void drawPageNumber(QPainter p, int pageNumber, int pageLineY, black b) {
//		String text = pageNumber+"";
//		QFont f = new QFont("C",8);
//		p.setFont(f);

//		QRect br = p.fontMetrics().boundingRect(text);
//		p.setPen(new QColor(Qt.GlobalColor.blue));
//		int y = pageLineY -br.height()/2;
//		int x = p.device().width()-br.width()-60;
//		QPoint map = b.text.mapFrom(b, new QPoint(x,y));
//		if(map.y() > 0)
//		p.drawText(x, y, text);

//		String text2 = (pageNumber+1)+"";
//		QRect br2 = p.fontMetrics().boundingRect(text2);
//		int y2 = pageLineY+br2.height();
//		QPoint map2 = b.text.mapFrom(b, new QPoint(x,y2));
//		if(map2.y() < black.text.height())
//		p.drawText(x, y2, text2);

//		p.setPen(new QColor(Qt.GlobalColor.black));
//		p.setRenderHint(RenderHint.Antialiasing);
		QPoint map1 = b.text.parentWidget().mapTo(b, new QPoint(b.text.x(), b.text.x() + b.text.viewport().width()));
		int length = 40;
		int b1 = map1.x();
		int a = b1 - length;
		int yy = pageLineY - 10;
		int yyy = pageLineY + 7;
		p.drawLine(a, yy, b1, yy);
		p.drawLine(b1, yy, b1, yyy);
		p.drawLine(b1, yyy, a, yyy);

		int k = map1.x() + b.text.viewport().width();
		int j = k + length;
		p.drawLine(j, yy, k, yy);
		p.drawLine(k, yy, k, yyy);
		p.drawLine(k, yyy, j, yyy);
	}

	static void conversionDocuments(black b) {
		File f = new File(b.projectFile.getParent() + File.separator + "Files");
		File[] l = f.listFiles();
		for (File fi : l) {
			String name = fi.getName();
			String ex = ".black";
			if (name.lastIndexOf(ex) == name.length() - ex.length()) {
				b.p(languageTool.getString(1237));
				String read = io.readBlackFileByLine(fi);
				io.writeBlackFile(fi, read, null);
			}
		}
	}

	/**
	 * 
	 * @param appname 进程名称，包括扩展名，例如game.exe
	 * @param force
	 */
	static void closeApp(String appname, boolean force) {
		String f = "";
		if (force)
			f = " /F";
		try {
			Runtime.getRuntime().exec("taskkill /IM " + appname + f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void setUsePic() {
		String key = "";
		if (b.getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
			key = appInfo.useLightWindowBgImg;
		} else {
			key = appInfo.useDarkWindowBgImg;
		}

		boolean usebg = !b.getBooleanValueFromSettings(key, "true");

		b.settings.setValue(key, usebg + "");

		b.applyColorChange();
		b.setLoadFileMessage(languageTool.getString(1238) + usebg);
	}

	void setUseBingPic() {
		String key_ = "";
		String key = "";
		if (b.getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
			key_ = appInfo.lightBingPic;
			key = appInfo.useLightWindowBgImg;
		} else {
			key_ = appInfo.darkBingPic;
			key = appInfo.useDarkWindowBgImg;
		}
		boolean usebg = b.getBooleanValueFromSettings(key, "true");
		if (!usebg) {
			b.getMessageBox(languageTool.getString(1239), languageTool.getString(1240));
			return;
		}
		boolean usebingPic = !b.getBooleanValueFromSettings(key_, "true");
		b.settings.setValue(key_, usebingPic + "");
		if (usebingPic)
			this.useBingPic();
		else
			b.applyColorChange();

		b.setLoadFileMessage(languageTool.getString(1241) + usebingPic);
	}

	void useBingPic() {
		String picInfo = black.getStringValueFromSettings(appInfo.bingPicInfo, "");
		tempData.put("tempPicInfo", picInfo);

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				timerInfo ti = new timerInfo(true, languageTool.getString(1242), null);
				ti.type = appInfo.timerInfoType.getBingPic.value;
				ti.setRunnable(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						b.uiRun(b, new Runnable() {
							public void run() {
								Object object = tempData.get("bingPicInfo");
								if (object != null) {
									if (!black.getStringValueFromSettings(appInfo.bingPicInfo, "").equals(object))
										b.settings.setValue(appInfo.bingPicInfo, object);
								}
								b.applyColorChange();
							}
						});
					}
				});
				b.addTimer(ti);
				String info = (String) tempData.get("tempPicInfo");
				String picInfo = getBingPic(info);

				if (picInfo != null) {
					tempData.put("bingPicInfo", picInfo);
//					ti.timerName = "Bing每日图片获取成功";
					b.removeAllTimer(appInfo.timerInfoType.getBingPic.value);
					ti.run.run();
				} else {
					ti.run.run();
					ti.setRunnable(null);
					ti.timerName = languageTool.getString(1243);
					ti.time = System.currentTimeMillis() + 15000;
					ti.stilLive = false;
					ti.hideLeftTime = true;
				}

			}
		}).start();

	}

	void showBingPicInfo() {
		int v = b.getIntValueFromSettings(appInfo.randomImg, "1000");
		if (v == 0) {
			if (label == null) {
				label = new QLabel(b);
				QPalette p = label.palette();
				p.setColor(label.backgroundRole(), new QColor(0, 0, 0, 100));
				p.setColor(label.foregroundRole(), new QColor(255, 255, 255));
				label.setPalette(p);
				label.setFixedWidth(b.width());
				label.setWordWrap(true);
				label.setAutoFillBackground(true);
				label.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);
//				label.setContentsMargins(10, 20, 10, 20);
				label.setMargin(20);
				label.setAlignment(AlignmentFlag.AlignVCenter, AlignmentFlag.AlignLeft);

//				label.lower();
//				label.show();
			}
			QFont f = b.font();
			f.setPointSize(f.pointSize() + 6);
			String info = (String) settings.value(appInfo.bingPicInfo, "");

			label.setFont(f);
			label.setText(info);
			label.adjustSize();
			label.setGeometry(0, b.height() + label.height(), label.width(), label.height());
		}

		if (b.textWidget.isVisible()) {
//			b.textWidget.hide();
			tempData.put("oldTextWidgetGeometry", b.textWidget.geometry());
			new animation(b.textWidget, "geometry", b.textWidget.geometry(),
					new QRect(b.textWidget.x(), 0 - b.textWidget.height(), b.textWidget.width(), b.textWidget.height()),
					0) {

				@Override
				public void action_endAnimation() {
					// TODO Auto-generated method stub
					b.textWidget.hide();
					if (shadow != null)
						shadow.update();
				}

			};
			if (label != null && v == 0) {
				label.show();
				b.setAnimation(label, "geometry", label.geometry(),
						new QRect(0, b.height() - label.height(), label.width(), label.height()), b.getAnimationTime());
			}
		} else {
//			label.hide();
			QRect object = (QRect) tempData.get("oldTextWidgetGeometry");
			tempData.remove("oldTextWidgetGeometry");
			new animation(b.textWidget, "geometry", b.textWidget.geometry(), object, 0) {

				@Override
				public void action_endAnimation() {
					// TODO Auto-generated method stub
					if (label != null && label.isVisible())
						b.setAnimation(label, "geometry", label.geometry(),
								new QRect(0, b.height() + label.height(), label.width(), label.height()),
								b.getAnimationTime());

					b.textWidget.show();
					if (shadow != null)
						shadow.update();
				}

			};

		}
	}

	/**
	 * 下载bing每日图片和图片信息 可以放在另一个线程执行
	 * 先判断图片描述信息是否与settings里储存的一样，不一样说明网络上图片已经更新，下载图片，一样则返回图片信息，但不下载图片
	 * 
	 * @return 返回图片故事信息或null，通过判断返回值确定图片是否下载完成
	 */
	String getBingPic(String currentPicInfo) {
		String bingUrl = "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1";
		File file = new File("." + File.separator + "RC" + File.separator + "Bing" + File.separator + "bing.jpg");
		String html = null;
		try {
			html = imgWidget.getHtml(bingUrl, "utf-8");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			p(languageTool.getString(1244));
			return null;
		}
		b.debugPrint(html);
		if (html == null)
			return null;
		TextRegion url = cheakDocument.subString(html, "\"url\":\"", "\",");
		TextRegion info = cheakDocument.subString(html, "\"copyright\":\"", "\",");
		if(info == null) {
			b.debugPrint(languageTool.getString(1245));
			return null;
		}
		if (currentPicInfo.equals(info.text)) {
			if (file.exists())
				return info.text;
		}

		String URL = "https://www.bing.com" + url.text;
		b.debugPrint(info.text + "\n" + URL);
		if (!file.exists())
			file.getParentFile().mkdirs();

		String str = file.getAbsolutePath().toString();
		byte[] bytes = null;
		bytes = yangIO.getDataFormHttpsURL(URL, b);
		if(bytes == null) return "";
		boolean isOk = yangIO.writeFileFromBytes(bytes, str);

		return info.text;
	}

	/*
	 * 阴影效果启用时必须关闭插入符动画效果，不然会导致页面更新不全
	 */
	void setShandow(boolean enable) {
		if (!b.getBooleanValueFromSettings(appInfo.usePageShadow, "false") || enable) {
			setShandowAction(false);
//			b.textWidget.setFrameStyle(QFrame.Shape.NoFrame.value());
		} else
			new bRunnable(10, true, false, true, true) {
				// 上面的定时任务的时间由原来的5000改为10，不明白为何原来要设定成5000，估计是因为原来的页面高斯模糊特效会与加载文档冲突
				@Override
				public void run() {
					// TODO Auto-generated method stub
					setShandowAction(true);
//				b.textWidget.setFrameStyle(QFrame.Shape.StyledPanel.value());
					b.debugPrint(languageTool.getString(1246));
				}
			};

	}

	void setShandowAction(boolean enable) {
		// 下面为原来的阴影效果，于2023.04.04替换成了文字模糊效果
//		QGraphicsDropShadowEffect ge = (QGraphicsDropShadowEffect) b.textWidget.graphicsEffect();
//		if (ge == null) {
//			ge = new QGraphicsDropShadowEffect();
//			QColor c_ge = new QColor(Qt.GlobalColor.black);
//			c_ge.setAlpha(255);
//			ge.setColor(c_ge);
//			ge.setBlurRadius(50);
//			ge.setOffset(0, 2);
//		}
//
//		if (b.writingView > 0) {
//			QColor bg = b.textWidget.palette().color(ColorRole.Window);
//			if (bg.alpha() < 100)
//				ge.setEnabled(false);
//			else
//				ge.setEnabled(enable);
//		} else
//			ge.setEnabled(false);
//		ge.update();
//		b.textWidget.setGraphicsEffect(ge);
		QGraphicsBlurEffect ge = (QGraphicsBlurEffect) b.textWidget.graphicsEffect();
		if (ge == null) {
			ge = new QGraphicsBlurEffect();
			ge.setBlurRadius(1.7);
		}
		// 在写作视图和精简视图中启用模糊效果
		if (b.writingView > 0 || b.ui.hideFilePanel.isChecked()) {
			ge.setEnabled(enable);
		} else
			ge.setEnabled(false);
		ge.update();
		b.debugPrint(languageTool.getString(1247) + ge.isEnabled());
		b.textWidget.setGraphicsEffect(ge);
		b.textWidget.hide();
		b.textWidget.show();
	}

	boolean shandow() {
		QGraphicsBlurEffect ge = (QGraphicsBlurEffect) b.textWidget.graphicsEffect();
		if (ge == null)
			return false;
		else {
			if (ge.isEnabled())
				return true;
			else
				return false;
		}
	}

	boolean fastFindUp() {
		QTextCursor tc = b.text.textCursor();
		if (tc.selectedText().length() == 0) {
			return false;
		}
		QTextDocument doc = b.text.document();
		QTextCursor find = doc.find(tc.selectedText(), tc,
				new QTextDocument.FindFlag[] { QTextDocument.FindFlag.FindBackward });
		if (find.position() != -1) {
			QTextCursor tcc = b.text.textCursor();
			tcc.setPosition(find.selectionStart());
			tcc.setPosition(find.selectionEnd(), QTextCursor.MoveMode.KeepAnchor);
			b.text.setTextCursor(tcc);
		}
		return true;
	}

	boolean fastFindDown() {
		QTextCursor tc = b.text.textCursor();
		if (tc.position() == text.charCountOfDoc()) {
			text.verticalScrollBar().setValue(text.verticalScrollBar().maximum());
		}
		if (tc.selectedText().length() == 0) {
			return false;
		}
		QTextDocument doc = b.text.document();
		QTextCursor find = doc.find(tc.selectedText(), tc);
		if (find.position() != -1) {
			QTextCursor tcc = b.text.textCursor();
			tcc.setPosition(find.selectionStart());
			tcc.setPosition(find.selectionEnd(), QTextCursor.MoveMode.KeepAnchor);
			b.text.setTextCursor(tcc);
		}
		return true;
	}

	
	static void whenBlackClose(black b) {
		checkUpdate update = (checkUpdate) tempData.get("checkUpdate");
		if (update.exec != null)
			update.exec.destroy();
		
		if(tempData.get("randomImageChanaged") != null) {
			ArrayList<QPixmap> imgs = (ArrayList<QPixmap>) tempData.get("randomImg");
			if (imgs != null) {
				ArrayList<byte[]> bytes = new ArrayList<byte[]>();
				for(QPixmap im:imgs) {
					QByteArray ba = new QByteArray();
					QBuffer buf = new QBuffer(ba);
					im.save(buf, "jpg", 30);
					bytes.add(ba.toByteArray());
				}
				
				File unsplashFile = new File("./RC/unsplash");
				if(!unsplashFile.exists()) {
					try {
						unsplashFile.createNewFile();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					if(unsplashFile.delete()) {
						b.p(languageTool.getString(1248));
					}else b.p(languageTool.getString(1249));
				}
				io.writeObjFile(unsplashFile, bytes);
				b.p(languageTool.getString(1250));
			}
		}
		if(b.setTextStyles != null) {
			b.setTextStyles.whenBlackClose();
		}
	}

	static void changedSysVolume(int v) {
		if (v == -1)
			v = 65535;
		else if (v == -2)
			v = 0;
		else if (v == -3)
			v = 32767;
		execNirCmd("setsysvolume " + v);
	}

	static void secDo(black b) {
		if(b.dbm) {
//			b.debugPrint("alt是否按下："+b.btext.altKeyIsPressed);
//			b.debugPrint("ctrl是否按下："+b.btext.controlKeyIsPressed);
//			b.debugPrint("shift是否按下："+b.btext.shiftKeyIsPressed);
		}
		if(b.text != null) {
			if(!b.text.inputing) {
				//防止输入法提交后右下角的关键词框弹出来
				if(b.keywordsShowAtLeftBottom && b.keywords != null) {
					b.uiRun(b, new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							b.keywords.hide();
						}
					});
				}
			}
		}
	}

//	static void Qexec() {
//		QApplication.exec();
//		
//	}
	static void insertList() {
		black.text.textCursor().insertList(Style.ListCircle);
	}

	void shadow() {
		if (b.getIntValueFromSettings(appInfo.RoundShadow, "0") == 0
				&& !b.getBooleanValueFromSettings(appInfo.usePageShadow, "false")) {
			if (shadow != null && shadow.isVisible()) {
				shadow.hide();
			}
			return;
		}

		if (shadow == null) {
			shadow = new QWidget(b) {
				@Override
				protected void paintEvent(QPaintEvent event) {
					// TODO Auto-generated method stub
					super.paintEvent(event);
					QPainter p = new QPainter(this);
//					int sizePS = 10;
//					float f = 255F/(float)sizePS;
//					QPainterPath path = new QPainterPath();
//					QColor c = new QColor(0,0,0);
//					QPen pen = new QPen();
//					
//					for(int i=0;i<=sizePS;i++) {
//						path.addRect(b.textWidget.x()-i, b.textWidget.y()-i, b.textWidget.width()+i*2, b.textWidget.height()+i*2);
//						float af = (i*f);
//						int a = (int)af;
//						if(af>0 && af<1) a = 0;
//						c.setAlpha(a);
//						pen.setColor(c);
//						p.setPen(pen);
//						p.drawPath(path);
//					}

//					if (b.getBooleanValueFromSettings(appInfo.usePageShadow, "false")
//							&& b.writingView > 0
//							&& b.textWidget.isVisible() && b.textWidget.palette().background().color().alpha() > 100
//							&& b.getStringValueFromSettings(appInfo.writingViewTextTopAndBottom, "0 0").equals("0 0")
//							&& b.getStringValueFromSettings(appInfo.typerMode, "3").equals("3")) {
//						int pageAlpha = 50;
//						int size = 50;
//						int y = b.textWidget.y();
//						// 绘制页面左阴影
//						int x_left = b.textWidget.x() - size;
//						QLinearGradient pageLeft = new QLinearGradient(x_left, y, b.textWidget.x(), y);
//						pageLeft.setColorAt(0, new QColor(0, 0, 0, 0));
//						pageLeft.setColorAt(1, new QColor(0, 0, 0, pageAlpha));
//						p.setPen(PenStyle.NoPen);
//						p.setBrush(new QBrush(pageLeft));
//						p.drawRect(x_left, y, size, b.textWidget.height());
//
//						// 绘制页面右阴影
//						int x_right = b.textWidget.x() + b.textWidget.width();
//						QLinearGradient pageRight = new QLinearGradient(x_right, y, x_right + size, y);
//						pageRight.setColorAt(0, new QColor(0, 0, 0, pageAlpha));
//						pageRight.setColorAt(1, new QColor(0, 0, 0, 0));
//						p.setPen(PenStyle.NoPen);
//						p.setBrush(new QBrush(pageRight));
//						p.drawRect(x_right, y, size, b.textWidget.height());
//
////						QLinearGradient pageTop = new QLinearGradient(b.textWidget.x(), y-size/2, b.textWidget.x(), y+size);
////						pageTop.setColorAt(0, new QColor(0, 0, 0, 0));
////						pageTop.setColorAt(1, new QColor(0, 0, 0, pageAlpha));
////						p.setPen(PenStyle.NoPen);
////						p.setBrush(new QBrush(pageTop));
////						p.drawRect(b.textWidget.x()-size,y-size/2,b.textWidget.width()+size*2,size/2);
//					}
					int v = b.getIntValueFromSettings(appInfo.RoundShadow, "0");

					if (v == 0) {
						return;
					}

					int size = 100;
					int darkAlpha = 200;
					int x = b.textWidget.x() + b.textWidget.width();
					if (v == 3 || v == 1) {
						QLinearGradient linearLeft = new QLinearGradient(0, 0, size, 0);
						linearLeft.setColorAt(0, new QColor(0, 0, 0, darkAlpha));
						linearLeft.setColorAt(1, new QColor(0, 0, 0, 0));

						p.setBrush(new QBrush(linearLeft));
						p.drawRect(b.rect());

						QLinearGradient linearRight = new QLinearGradient(b.width() - size, 0, b.width(), 0);
						linearRight.setColorAt(0, new QColor(0, 0, 0, 0));
						linearRight.setColorAt(1, new QColor(0, 0, 0, darkAlpha));

						p.setBrush(new QBrush(linearRight));
						p.drawRect(b.rect());

						QLinearGradient linearTop = new QLinearGradient(0, 0, 0, size);
						linearTop.setColorAt(0, new QColor(0, 0, 0, darkAlpha));
						linearTop.setColorAt(1, new QColor(0, 0, 0, 0));

						p.setBrush(new QBrush(linearTop));
						p.drawRect(b.rect());

						QLinearGradient linearBottom = new QLinearGradient(0, b.height() - size, 0, b.height());
						linearBottom.setColorAt(0, new QColor(0, 0, 0, 0));
						linearBottom.setColorAt(1, new QColor(0, 0, 0, darkAlpha));
						p.setBrush(new QBrush(linearBottom));
						p.drawRect(b.rect());
					}

					if (v == 3 || v == 2) {
						QRect r = b.rect();
						int xx = r.width() / 2;
						int yy = r.height() / 2;
						QRadialGradient gradient = new QRadialGradient(xx, yy, r.height(), xx, yy, r.height() / 2);
						gradient.setColorAt(0, new QColor(0, 0, 0, 0));
						gradient.setColorAt(0.5, new QColor(0, 0, 0, 200));
//						    gradient.setColorAt(0.7, new QColor(0, 0, 0,150));
						gradient.setColorAt(1, new QColor(0, 0, 0, 255));

						p.setPen(PenStyle.NoPen);
						// 设置画刷填充
						QBrush brush = new QBrush(gradient);
						p.setBrush(brush);
						p.fillRect(rect(), p.brush());
					}

				}
			};

			shadow.setWindowFlags(WindowType.FramelessWindowHint);
//			WindowFlags windowFlags = shadow.windowFlags();
//			windowFlags.clear(WindowType.Tool);
//			shadow.setWindowFlags(windowFlags);
			shadow.setAttribute(WidgetAttribute.WA_TransparentForMouseEvents);
			shadow.setAttribute(WidgetAttribute.WA_InputMethodTransparent);
			shadow.setAutoFillBackground(false);
			shadow.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground);
			shadow.setAttribute(WidgetAttribute.WA_NoSystemBackground, false);
			QPalette p = shadow.palette();
			QColor c = new QColor(Qt.GlobalColor.black);
			c.setAlpha(0);
			p.setColor(shadow.backgroundRole(), c);
			shadow.setPalette(p);
		}
		shadow.stackUnder(b.timeMessage);
		shadow.setGeometry(desktopGeometry(false));
		shadow.show();
		shadow.update();
	}

	void test() {
		System.out.println("test");
		WindowFlags wf = b.windowFlags();
		wf.set(Qt.WindowType.FramelessWindowHint);
		b.setWindowFlags(wf);
		b.show();
//		text.highlighter.setFontSize(15);
	}

	void showSegmentHelp() {

		b.getBMessageBox(languageTool.getString(1251), languageTool.getString(1252) + appInfo.segmentInfo);
	}

	/**
	 * 设定自动分词过滤的词性
	 */
	void setSegmentInfo() {
		String info = b.getStringValueFromSettings(appInfo.infoOfAutoSegment, "");
		bmessageBox box = new bmessageBox(b, languageTool.getString(1253), languageTool.getString(1254),
				languageTool.getString(1255)
						+ languageTool.getString(1256) + info,
				false) {

			@Override
			public void buttonPressedAction(String paramString) {
				// TODO Auto-generated method stub
				List<String> allLine = cheakDocument.getAllLine(paramString);
				String string = "";
				if (allLine.size() == 2) {
					string = allLine.get(1);
				}
				b.settings.setValue(appInfo.infoOfAutoSegment, string);
				this.close();
			}
		};
		box.show();
	}

	/**
	 * 获取编辑器文本的分词结果
	 * 
	 * @param onlyAnsjResult 是否只返回文档分词结果，即结果中不包含已经定义的关键词
	 * @return
	 */
	ArrayList<TextRegion> getAnsjResult(boolean onlyAnsjResult) {
		b.debugPrint(languageTool.getString(1257));
		ArrayList<TextRegion> al_ = new ArrayList<>();
		uiRun(b, new Runnable() {
			public void run() {
				int charCountOfDoc = text.charCountOfDoc();
				if (charCountOfDoc < b.getIntValueFromSettings(appInfo.maxCharsAutoSegment, "20000")) {
					tempData.put("stopSegment", false);
					tempData.put("textStr", text.toPlainText());
					int minLenght = b.getIntValueFromSettings(appInfo.minLenghtOfAutoSegment, "1");
					tempData.put(appInfo.minLenghtOfAutoSegment, minLenght);
					String info = b.getStringValueFromSettings(appInfo.infoOfAutoSegment, "all");
					tempData.put(appInfo.infoOfAutoSegment, info);
				} else
					tempData.put("stopSegment", true);
			}
		});
		ArrayList<String> al = new ArrayList<>();
		if (!(boolean) tempData.get("stopSegment")) {
			Segment segment = new StandardTokenizer().SEGMENT.enableAllNamedEntityRecognize(true);

			List<com.hankcs.hanlp.seg.common.Term> seg = segment.seg((String) tempData.get("textStr"));
			if (seg == null)
				return al_;

			String info = (String) tempData.get(appInfo.infoOfAutoSegment);
			String[] args = cheakDocument.checkCommandArgs(info);

			int minLenght = (int) tempData.get(appInfo.minLenghtOfAutoSegment);
			for (int i = 0; i < seg.size(); i++) {
				Term term = seg.get(i);
				String word = term.word; // 拿到词
				String nature = term.nature.toString();

				if (word.length() > minLenght) {
					if (args.length == 0)
						al.add(word);
					else
						for (String s : args) {
							if (nature.equals(s)) {
								al.add(word);
								break;
							}

						}

				}
			}
		}

		if (!onlyAnsjResult && b.marktext != null) {
			ArrayList<String> allLine = cheakDocument.getAllLine(b.marktext);
			ArrayList<String> al_string = new ArrayList<String>();

			for (int i = b.markstat.size() - 1; i >= 0; i--) {
				markstat stat = b.markstat.get(i);
				al_string.add(stat.getText());
			}

			al_string.addAll(allLine);
			al_string.addAll(al);
			al = al_string;
		}
		ArrayList<String> withOutSame = cheakDocument.withOutSame(al);
		for (String s : withOutSame) {
//        	System.out.println("去重后："+s);
//        	System.out.println(s);
			ArrayList<String> a = cheakDocument.checkCommandArgs(s, '@');
			TextRegion tr = new TextRegion(s, 0, 0);

			if (a.size() == 1 || a.size() == 0)
				tr.showname = s;
			else {
				tr.showname = a.get(0);
				tr.filename = a.get(1);
			}
//        	if(ar.size() == 1)	
//        		tr.showname = ar.get(0);
//        	else {
//            	tr.showname = ar.get(0);
//        		tr.filename = ar.get(1);
//        	}
			al_.add(tr);
		}
		return al_;
	}

	void showKeywordsListByCurrentChar() {
		//用来替代下面被注释掉的afterLoadFile开关判断逻辑
		if(b.afterLoadFileActions.size() != 0) return;
		//下面的判断句因为废弃afterLoadFile开关而被注释掉了，不确定会有何后果
//		if (b.afterLoadFile != null)
//			return;
		
		if (!b.getBooleanValueFromSettings(appInfo.autoShowKeywords, "true"))
			return;

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				uiRun(b, new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub

						int ms = b.getIntValueFromSettings(appInfo.pinyinStartSegmentMS, "500");
						tempData.put(appInfo.pinyinStartSegmentMS, ms);
					}
				});

				if (b.findInMark_brun != null) {
					b.findInMark_brun.stop();
					b.findInMark_brun = null;
				}

				b.findInMark_brun = new bRunnable((int) tempData.get(appInfo.pinyinStartSegmentMS), true, false, true,
						true) {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (b.findInMark_brun != null) {
							showKeywordsListByCurrentChar_();
						}
					}
				};
			}
		}).start();
	}

	/**
	 * 通过光标所在的字符查找关键词
	 */
	void showKeywordsListByCurrentChar_() {
//		b.uiRun(new Runnable() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				tempData.put("textWidgetVisible", b.text.isVisible());
//			}
//		});
//		if(!(boolean)tempData.get("textWidgetVisible"))return;

		if (!b.text.isVisible())
			return;
		QTextCursor tc = text.textCursor();
		if (tc.hasSelection())
			return;
		if (!tc.movePosition(MoveOperation.PreviousCharacter, MoveMode.KeepAnchor))
			return;
		String findStr = tc.selectedText();
		if (findStr.isEmpty())
			return;

		if ((b.keywords != null) && (b.keywords.isVisible())) {
			return;
		}
		if (b.marktext == null) {
			b.readMarkFile();
		}
		if (b.marktext == null) {
			return;
		}
		if (b.markTextData == null) {
			b.getMarkFileText();
		}
		b.initKeyWordsDialog();
		b.keywords.tree.UsedToProjectPanelOrKeywordsList = 1;
		if (b.keywords.tree.topLevelItemCount() > 0) {
			b.keywords.tree.clear();
		}
		ArrayList<TextRegion> result = getAnsjResult(false);

		int index = 0;
		for (TextRegion tr : result) {
			int ind = 0;
			if ((ind = tr.showname.lastIndexOf(findStr)) != -1) {
				QTextCursor tcc = new QTextCursor(tc);
				tcc.clearSelection();
				int start = tcc.position() - ind;
//				if(start < 0) start = 0;
				tcc.setPosition(start);
				int end = tcc.position() + tr.showname.length();
//				if(end > text.charCountOfDoc())end = text.charCountOfDoc();
				tcc.setPosition(end, MoveMode.KeepAnchor);
				b.debugPrint("selectText: " + tcc.selectedText() + " showname:" + tr.showname + " start:" + start
						+ " end:" + end);
				if (tcc.selectedText().equals(tr.showname))
					continue;

				QTreeWidgetItem ti = b.getTreeItem(b.keywords.tree);
				ti.setIcon(0, b.ico_keywordNo);

				String str = null;
				if (tr.filename == null) {
					str = tr.showname;
				} else {
					str = tr.showname + " (" + tr.filename + ")";
				}
				ti.setText(0, b.getCharByNumber(b.keywords.tree.topLevelItemCount() - 1) + str);
				ti.setData(1, 0, tr);
				ti.setData(1, 1, Integer.valueOf(index));
				index++;
			}
		}
		b.keywords.statusbar.showMessage(languageTool.getString(1258));
		b.keywords.message.setText(languageTool.getString(1259,b.keywords.tree.topLevelItemCount()));
		b.findview = 5;
		b.showDialogAtEditorCaretPos(text, b.keywords);
	}


	/**
	 * 用来从RC目录选择图片改变背景的方法
	 */
	void changeBackgroundImage() {
		if (b.writingView != 1)
			return;
		String key = "";
		String key_ = "";
		if (b.getBooleanValueFromSettings(appInfo.LightOrDark, "false")) {
			key = appInfo.lightWindowBgImg;
			key_ = appInfo.lightBingPic;
		} else {
			key = appInfo.darkWindowBgImg;
			key_ = appInfo.darkBingPic;
		}
		boolean usebingPic = b.getBooleanValueFromSettings(key_, "true");
		if (usebingPic)
			return;

		File dir = new File("./RC");
		isYourNeedFile isYourNeedFile = new isYourNeedFile(dir, ".*.jpg|.*.jpg|.*.jpeg|.*.JPEG|.*.png|.*.PNG");
		String[] files = isYourNeedFile.Filter();
		String bg = b.getStringValueFromSettings(key, "bgF.jpg");
		for (int i = 0; i < files.length; i++) {
			String s = files[i];
			if (bg.equals(s)) {
				int nextIndex = i + 1;
				if (nextIndex < files.length) {
					b.settings.setValue(key, files[nextIndex]);
					b.bgImgChanged = true;
					b.applyColorChange();
				} else {
					b.settings.setValue(key, files[0]);
					b.bgImgChanged = true;
					b.applyColorChange();
				}
				return;
			} else {
				b.settings.setValue(key, files[0]);
				b.bgImgChanged = true;
				b.applyColorChange();
			}
		}
	}

	static void setDisable() {
		File file = new File("./bin_/no");
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
	}

	static boolean isDisable() {
		File file = new File("./bin_/no");
		if (file.exists())
			return true;
		else
			return false;
	}

	static boolean checkDateDisable() {
		Calendar instance = Calendar.getInstance(Locale.getDefault());
		int year = instance.get(Calendar.YEAR);
		int month = instance.get(Calendar.MONTH);
		black.p(languageTool.getString(1260,year,month));
		File license = new File("./bin_/license");
		if (license.exists()) {
			String s = io.readTextFile(license, "gbk");
			List<String> allLine = cheakDocument.getAllLine(s);
			DesUtils des = new DesUtils("blackLicense");
			String y = "", m = "";
			try {
				y = des.decrypt(allLine.get(0));
				m = des.decrypt(allLine.get(1));
			} catch (Exception e) {
				// TODO Auto-generated catch block
//				e.printStackTrace();
				black.p(languageTool.getString(1263));
			}

			if (!y.isEmpty() && !m.isEmpty()) {
				appInfo.outYear = Integer.valueOf(y);
				appInfo.outMonth = Integer.valueOf(m);
			}
		}
		String outmessage = null;
		if (appInfo.outYear == -1 || appInfo.outMonth == -1) {
			outmessage = languageTool.getString(1265);
		} else {
			outmessage = languageTool.getString(1264,appInfo.outYear,(appInfo.outMonth - 1));
		}

		System.out.println(outmessage);
		if (appInfo.outYear == -1)
			return false;
		// 大于年；小于年不判断月；等于年判断月
		else if (year > appInfo.outYear) {
			setDisable();
			return true;
		} else if (year == appInfo.outYear && month >= appInfo.outMonth) {
			setDisable();
			return true;
		}
		return false;
	}

	/**
	 * 用特定密钥加密信息 弹出一个文本输入框，输入密钥和信息，然后加密之
	 * 
	 * @param b
	 */
	static void desInfo(black b) {
		InputDialog id = new InputDialog(b, languageTool.getString(1268), languageTool.getString(1269), false, false, "") {

			@Override
			void whenOkButtonPressed() {
				// TODO Auto-generated method stub
				String[] args = cheakDocument.checkCommandArgs(value());
				if (args.length == 2 && !args[0].isEmpty() && !args[1].isEmpty()) {
					DesUtils des = new DesUtils(args[0]);
					try {
						String encrypt = des.encrypt(args[1]);
						new bmessageBox(this, languageTool.getString(1270), languageTool.getString(1271), encrypt, true) {

							@Override
							public void buttonPressedAction(String paramString) {
								// TODO Auto-generated method stub
								this.close();
							}
						}.show();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			@Override
			void whenClose() {
				// TODO Auto-generated method stub
				this.close();
			}

			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub

			}
		};
		id.noHide = true;
		id.show();
	}
	/**
	 * 返回界面元素颜色，数组0元素为settings中的key，1为目前的颜色
	 *  0页面背景；1页面文字；2插入符；3窗口背景；4屏幕提示；5右下角提示；
	 *  6内建rime输入法选词框首行背景；7rime首行文字;8高亮文本背景；9高亮文本前景色
	 *  
	 * @param type
	 * @return
	 */
	Object[] getColor(int type) {
		Object[] o = new Object[2];
		String key = ""+type;
		if (b.writingView > 0) {
			if (b.getBooleanValueFromSettings(appInfo.LightOrDark, "false"))
				key = "app/writingView_Light_"+key;
			else
				key = "app/writingView_drak_"+key;
		}else {
			if (b.getBooleanValueFromSettings(appInfo.LightOrDark, "false"))
				key = "app/normal_Light_"+key;
			else
				key = "app/normal_drak_"+key;
		}
		o[0] = key;
		o[1] = (QColor) black.settings.value(key, new QColor(Qt.GlobalColor.white));
		
		
		return o;
	}
	/**
	 * 为程序元素设置颜色
	 * 
	 * @param
	 * @param alpha 颜色透明度
	 * @param color
	 */
	void setColors(int w, int alpha) {
		Object[] c = getColor(w);
		QColor c0 = getColorDialog((QColor)c[1]);
		if (c0 != null) {
			c0.setAlpha(alpha);
			b.settings.setValue((String)c[0], c0);
			b.applyColorChange();
			b.update();
		}
	}

	/**
	 * 返回桌面尺寸
	 * 
	 * @param available 是否只返回可用尺寸（不包括任务栏）
	 * @return
	 */
	static QRect desktopGeometry(boolean available) {
		if (available)
			return QApplication.primaryScreen().availableGeometry();
		else
			return QApplication.primaryScreen().geometry();
	}

	void openUrl() {
		openUrl(appInfo.appWebsite);
	}

	/**
	 * 使用默认浏览器打开指定的url
	 */
	void openUrl(String url) {
		QDesktopServices ds = new QDesktopServices();
		ds.openUrl(new QUrl(url));
	}

	/**
	 * 启用禁用页面边线（写作视图）
	 */
	void useTextBorder() {
		boolean v = (!b.getBooleanValueFromSettings(appInfo.textbgborder, "false"));
		settings.setValue(appInfo.textbgborder, v + "");
		b.update();
	}

	/**
	 * 启用禁用页面背景（写作视图）
	 */
	void useTextBg() {
		boolean v = (!b.getBooleanValueFromSettings(appInfo.useBgColor, "true"));
		settings.setValue(appInfo.useBgColor, v + "");
		b.update();
	}

	/**
	 * 弹出一个颜色对话框
	 * 
	 * @return返回所选的颜色
	 */
	QColor getColorDialog(QColor c) {
		QColorDialog cd = new QColorDialog();
		if (c != null)
			cd.setCurrentColor(c);
		cd.exec();
		return cd.selectedColor();
//		b.debugPrint(cd.selectedColor());

	}

//	void getMessageFromMailBox(String host, String username, String password, String port) {
//		Message[] messages = null;
//		String head = "black_qt新版本";
//		String disable = "black_qt过滤";
//		float current = Float.valueOf(appInfo.appVersion).floatValue();
//		float newver = 0.0F;
//		int index = 0;
//		try {
//			messages = mailTool.receive(username, password, host, port);
//		} catch (Exception e) {
//			b.logsmessage.append(
//					time.getCurrentDate("-") + " " + time.getCurrentTimeHasSecond() + " " + e.getMessage() + "<br>");
//			b.hasUpdate = 0;
//			return;
//		}
//
//		for (int i = 0; i < messages.length; i++) {
//			showMail re = new showMail((MimeMessage) messages[i]);
//			String subject = null;
//			try {
//				subject = re.getSubject();
//			} catch (MessagingException e) {
//				e.printStackTrace();
//			}
//			if ((subject != null) && (subject.indexOf(head) != -1)) {
//				String newversion = subject.replace(head, "");
//				Float ver = Float.valueOf(newversion);
//				if (ver.floatValue() > newver) {
//					newver = ver.floatValue();
//					index = i;
//				}
//			}
//			if ((subject != null) && (subject.indexOf(disable) != -1)) {
//				String ver_ = subject.replace(disable, "");
//				Float ver = Float.valueOf(ver_);
//				if (current <= ver) {
//					bAction.setDisable();
//					System.exit(0);
//				}
//			}
//		}
//		if (newver > current) {
//			showMail mail = new showMail((MimeMessage) messages[index]);
//			try {
//				mail.getMailContent(messages[index], false);
//			} catch (Exception e1) {
//				b.logsmessage.append("[" + time.getCurrentDate("-") + " " + time.getCurrentTimeHasSecond() + "]"
//						+ e1.getMessage() + "<br>");
//				e1.printStackTrace();
//			}
//			try {
//				b.updateinfo = ("<b>发现新版本：" + newver + "</b><br><br><i>" + mail.getBodyText() + "</i>");
//				b.hasUpdate = 1;
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		} else {
//			b.hasUpdate = 0;
//		}
//	}
	public void setDarkColor() {
//		List<QWidget> wids = QApplication.allWidgets();
//		for(QWidget w:wids) {
//			String styleSheet = w.styleSheet();
//			if(styleSheet.isEmpty())w.setStyleSheet("color:cyan;background:darkblue");
//			else w.setStyleSheet("");

//			QPalette p = w.palette();
//			if(p.base().color().equals(new QColor(Qt.GlobalColor.cyan))){
//				w.setStyleSheet("");
//			}
//			else {
//				p.base().setColor(new QColor(Qt.GlobalColor.cyan));
//				p.text().setColor(new QColor(Qt.GlobalColor.cyan));
//				p.setColor(ColorRole.Window, new QColor(Qt.GlobalColor.darkBlue));
//				p.setColor(ColorRole.Base, new QColor(Qt.GlobalColor.darkBlue));
//				p.setColor(ColorRole.Background, new QColor(Qt.GlobalColor.darkBlue));
//				p.setColor(ColorRole.AlternateBase, new QColor(Qt.GlobalColor.darkBlue));
//				p.setColor(ColorRole.Mid, new QColor(Qt.GlobalColor.darkBlue));
//			}
//			
//
//			w.setPalette(p);
//		}
	}

	/**
	 * 在当前编辑的文档内替换文本 返回替换的数量
	 * 
	 * @return repalcedCount
	 */
	int replaceAll_doc(finddialog fd, boolean noTip) {

		boolean findBackward = false;
		if (fd.findFlags.isSet(FindFlag.FindBackward)) {
			findBackward = true;
			fd.findFlags.clear(FindFlag.FindBackward);
		}

		if (b.btext.currentFindCursor != null) {
			b.btext.currentFindCursor.clearSelection();
			b.btext.currentFindCursor.setPosition(0);
		}

		QTextCursor next = null;
		ArrayList<QTextCursor> tcs = new ArrayList<QTextCursor>();
//		if(fd.doc != null)
//			b.debugPrint("当前替换的文件内容： "+fd.doc.toPlainText());
//		else b.debugPrint("无法执行置换，因为doc对象是空的");
		int count = 0;
		while ((next = fd.findnext()).position() != -1) {
			tcs.add(next);
			b.btext.currentFindCursor = next;
			count++;
		}
		QTextCursor tcc = null;
		for (QTextCursor tc : tcs) {
			if (tcc == null) {
				tcc = tc;
				tcc.beginEditBlock();
			}
			tc.insertText(fd.ui.replace_str.text());
		}
		if (tcc != null)
			tcc.endEditBlock();

		if (findBackward)
			fd.findFlags.set(FindFlag.FindBackward);

		fd.doc = null;
		if (!noTip)
			b.getMessageBox(languageTool.getString(1272), languageTool.getString(1273,count));

		return count;
	}

	/**
	 * 替换文件集中的全部匹配文本。包含文件集本身，但不含关键词列表
	 * 
	 *
	 */
	void replaceAll_files(finddialog fd) {
		if (fd == null || fd.isHidden())
			return;
		StringBuffer sb = new StringBuffer();
		int allCount = 0;
		fileInfo info_files = null;
		// 替换当前文件集中的所有匹配文本
		ArrayList<String> al = null;

		// 如果当前文件就是文件集，则获取当前文件的所有子文件。如果当前文件不是文件集，则查找并获取父文件集中的所有文件
		if (b.infoOfCurrentEditing.isFiles) {
			info_files = b.infoOfCurrentEditing;
			al = b.getAllFiles(b.infoOfCurrentEditing);
		} else {
			// 查找当前所编辑的文件所处的文件集
			info_files = b.getFilesWhichCurrentIn(b.TreeWidgetItemOfCurrentEditing);

			// 如果没有搜索到文件集，则退出方法
			if (info_files == null)
				return;

			al = b.getAllFiles(info_files);
		}

		// 把文件集本身也加入要替换的文件列表中
		al.add(b.getFile(info_files.fileName).getPath());

		if (al == null)
			return;

		// 给出警告提示框
		int messageBoxWithYesNO = b.getMessageBoxWithYesNO(languageTool.getString(1275),
				languageTool.getString(1276,info_files.getShowName(),al.size()), languageTool.getString(1279),
				languageTool.getString(1280), null, 0, true);
		if (messageBoxWithYesNO == 0)
			return;

		for (String f : al) {
			// 跳过关键词列表
			if (b.findFileInfoByFileName(new File(f).getName(), info_files).isKeyWordsList)
				continue;

			sb.append("<b><i>" + b.findFileShowName(new File(f).getName()) + "</i></b>");

			dataForOpenedFile opened = b.findInOpenedFiles(new File(f).getName());
			b.debugPrint(languageTool.getString(1281) + f + "\n" + b.currentEditing.toPath());

			// 先判断是不是当前正在编辑的文件，因为正在编辑的文件是没有同步到缓存数据的
			if (f.equals(b.currentEditing.toPath().toString())) {
				int count = replaceAll_doc(fd, true);
				sb.append(languageTool.getString(1305,count));
				allCount += count;
				// 判断文件是否已经被缓存
			} else if (opened != null && opened.editor != null) {
				fd.doc = opened.editor.text.document();
				int count = replaceAll_doc(fd, true);
				opened.content = opened.editor.text.toPlainText();
				sb.append(languageTool.getString(1305,count));
				allCount += count;
				// 文件还没有被读取
			} else {
				String str = null;
				// 文档已经读入内存，但还没有用编辑器显示
				if (opened != null && opened.editor == null)
					str = opened.content;
				else// 文件还没有被读取和缓存
					str = b.readBlackFile(new File(f));

				QTextDocument doc = new QTextDocument(str);
				int count = 0;
				fd.doc = doc;
				count = replaceAll_doc(fd, true);

				// 如果文件已经缓存，将修改后的文本同步到缓存
				if (opened != null && opened.editor == null)
					opened.content = doc.toPlainText();
				// 如果文件没有被缓存，将修改后的内容直接写入磁盘
				else
					io.writeBlackFile(new File(f), doc.toPlainText(), null);

				sb.append(languageTool.getString(1282,count));
				allCount += count;
			}
		}
		// 将fd对象中的文档重新关联到当前编辑的文档
		fd.doc = b.btext.text.document();

		sb.append(languageTool.getString(1284,allCount));
		b.getBMessageBox(languageTool.getString(1286), sb.toString());
	}
	void addFileByEditorMenu_NullFileName() {
		addFile(0);
	}
	void addFileByEditorMenu_NameByDate() {
		addFile(1);
	}
	/**
	 * 快速添加一个文件，添加的文件与当前正在编辑的文件是平级关系，添加到最后面
	 * 在编辑器中按下快捷键来快速添加文件
	 * @param named 用来指示是否以当前日期来命名文件，0为不以日期命名，1为以日期来命名
	 */
	void addFile(int named) {
		QTreeWidgetItem parent = b.TreeWidgetItemOfCurrentEditing.parent();
		QTreeWidget tw = b.TreeWidgetItemOfCurrentEditing.treeWidget();
		if(parent == null) {
			tw.clearSelection();
			tw.setCurrentItem(null);
		}else {
			tw.clearSelection();
			parent.setSelected(true);
			tw.setCurrentItem(parent);
		}
		
		String name = null;
		if(named == 1) {
			name = time.getCurrentDate("-");
			String name_= name;
			String dateLine = languageTool.getString(1287,name,time.getWeek(true),time.getCurrentTimeHasSecond());
			action act = new action() {
				
				@Override
				public void action() {
					// TODO Auto-generated method stub
					
					b.text.append(dateLine+"\n");
					QTextCursor tc = b.text.textCursor();
					tc.movePosition(MoveOperation.End);
					b.text.setTextCursor(tc);
				}
			};
			b.afterLoadFileActions.add(act);
		}
		
		QTreeWidgetItem newFile = b.addFileToProject(name);
		
		b.openFileByTreeItem(newFile);
	
		
	}
	/**
	 * 供项目树导出菜单项调用，将选择的项目导出为一个文件 如果选择了多个项目，选择的项目都必须是同一类型的项目才允许导出
	 * 允许的导出的项目的类型为文件、文件集，还有目录
	 */
	void export() {
		// 获取要导出的文件的fileinfo，放到一个数组里
		ArrayList<fileInfo> al_files = new ArrayList<fileInfo>();
		List<QTreeWidgetItem> checkedItems = b.getCheckedItems();
		if (checkedItems.isEmpty()) {
			List<QTreeWidgetItem> selectedItems = b.tree.selectedItems();
			if (!selectedItems.isEmpty()) {
				QTreeWidgetItem item = selectedItems.get(0);
				al_files.add(b.getFileInfoByQTreeItem(item));
			}
		} else {
			for (QTreeWidgetItem it : checkedItems) {
				al_files.add(b.getFileInfoByQTreeItem(it));
			}
		}
		// 如果没有选择任何文件，则给出提示，并结束导出任务
		if (al_files.isEmpty()) {
			b.getMessageBox(languageTool.getString(1288), languageTool.getString(1289));
			return;
		}
//		//判断所要导出的文件的属性，是文件还是文件集还是目录。如果要导出多个项目，必须都是相同类型的项目才能导出
//		boolean isFile = true,isFiles = true,isDir = true;
//		for(fileInfo in:al_files) {
//			if(!in.isFile) {
//				isFile = false;
//				break;
//			}
//		}
//		if(!isFile) {
//			for(fileInfo in:al_files) {
//				if(!in.isFiles) {
//					isFiles = false;
//					break;
//				}
//			}
//		}
//		if(!isFiles) {
//			for(fileInfo in:al_files) {
//				if(!in.isDir) {
//					isDir = false;
//					break;
//				}
//			}
//		}
//		//都是文件
//		if(isFile) {
//			System.out.println("都是文件");
//		//都是文件集
//		}else if(isFiles) {
//			System.out.println("都是文件集");
//		//都是目录
//		}else if(isDir) {
//			System.out.println("都是目录");
//		//选择了多种类型的文件，给出提示，并结束导出
//		}else {
//			System.out.println("选择了多种文件类型");
//		}

		String filter0 = languageTool.getString(1290);
		String filter1 = languageTool.getString(1291);

		QFileDialog fd = new QFileDialog(b, languageTool.getString(1288));
		fd.setAcceptMode(AcceptMode.AcceptSave);
		fd.setLabelText(QFileDialog.DialogLabel.Accept, languageTool.getString(1573));
		fd.setLabelText(QFileDialog.DialogLabel.Reject, languageTool.getString(1574));
		ArrayList<String> al = new ArrayList<>();
		al.add(filter0);
		al.add(filter1);
		fd.setNameFilters(al);

		int exec = fd.exec();
		if (exec == 0 || fd.selectedFiles().isEmpty())
			return;
		

		String saveFileName = fd.selectedFiles().get(0).toString();

		b.saveAllDocuments();
//		ArrayList<String> htmls = new ArrayList<String>();
//		QTextEdit te = new QTextEdit();
		QTextDocument doc = new QTextDocument();
		QTextCursor tc = new QTextCursor(doc);
		
//		te.setUpdatesEnabled(false);
		int i=0;
		for (fileInfo in : al_files) {
			if (in.fileName != null && !in.fileName.isEmpty()) {
				File file = b.getFile(in.fileName);
				if(file.exists()) {
					String str = io.readBlackFileByLine(file);
//					htmls.add(str);
//					te.append(str);
					tc.insertHtml(str);
				}
			}
		}
//		String html = HtmlMerger.mergeHtmlDocuments(new File(saveFileName).getName(),htmls.toArray(new String[htmls.size()]));
		
		
		
		boolean done = false;
		// 判断用户选择的文件过滤器，并保存为相应格式的文件
		if (fd.selectedNameFilter().equals(filter0)) {
			// 保存为纯文本文件
			done = io.writeTextFile(new File(saveFileName+".txt"), doc.toPlainText(), "utf-8");
		} else if (fd.selectedNameFilter().equals(filter1)) {
			// html文件
			done = io.writeTextFile(new File(saveFileName+".html"), doc.toHtml(), "utf-8");
		}
		if (done)
			b.getMessageBox(languageTool.getString(1288), languageTool.getString(1294));
		else
			b.getMessageBox(languageTool.getString(1288), languageTool.getString(1296));
	}

	public void typerMode(black b) {
		int typerMode = 3;
		if ((typerMode = b.getIntValueFromSettings(appInfo.typerMode, "3")) == 3)
			return;

		if (b.writingView == 0 || b.isLoadFile || b.doNotSet_UnSave || b.btext.pos == b.btext.lastpos
				|| b.afterLoadFileActions.size() != 0) {
//			if(tempData.containsKey("testX"))
//			tempData.remove("testX");
			return;
		}
		if (!tempData.containsKey("testX")) {
			b.debugPrint("A " + b.textWidget.geometry());
//			tempData.put("textX", b.textWidget.geometry());
//			b.textWidget.setGeometry(b.textWidget.x(), b.textWidget.y(), b.textWidget.width(), b.textWidget.height());
		}

		QRect cr = b.text.cursorRect();
		QPoint mapTo = black.text.mapTo(b, new QPoint(cr.x(), cr.y()));
		QRect ag = desktopGeometry(true);

		int cenX = ag.width() / 2;
		int cenY = ag.height() / 2;

//		QRect oldGeo = (QRect) tempData.get("testX");
		int width = b.getWritingViewTextWitdh() / 2;

		QRect oldGeo = null;
		if (oldGeo == null)
			oldGeo = b.textWidget.geometry();
		int mX = oldGeo.x() + (cenX - mapTo.x());
		int mY = oldGeo.y() + (cenY - mapTo.y());
		if (typerMode == 0)
			mX = oldGeo.x();
		else if (typerMode == 1)
			mY = oldGeo.y();

		QRect start = b.textWidget.geometry();
		QRect end = new QRect(mX, mY, start.width(), start.height());
//		System.out.println(start.width(),starth);
		b.debugPrint("B " + start + " end: " + end);
		b.setAnimation(b.textWidget, "geometry", start, end, b.getAnimationTime());
	}

	public static void setUpdate() {
		String appDir = "./";
		String inputFiledir = "./update";
		File javaexePath = new File("./jre/bin/java.exe");
		File blackexePath = new File("./BlackDraft.exe");
		File updatefiles = new File(inputFiledir);
		if (!updatefiles.exists())
			return;

		File[] list = updatefiles.listFiles();
		isYourNeedFile isYourNeedFile = new isYourNeedFile(updatefiles, ".*.zip");
		String[] filter = isYourNeedFile.Filter();
		for (String s : filter) {
			File f = new File(updatefiles.getAbsolutePath() + File.separator + s);
//			System.out.println(f);
			String name = f.getName();
			int lastIndexOf = name.lastIndexOf(".");
			name = name.substring(0, lastIndexOf);
			Float valueOf = Float.valueOf(name);
			if (valueOf > Float.valueOf(appInfo.appVersion)) {
				System.out.println("设置新版本：" + appInfo.appVersion + " -> " + name);
				// 启动另一个虚拟机执行jar文件，检查当前虚拟机是否已经退出，确认退出后解压缩更新包覆盖原有文件

				File appdir = new File(appDir);
				try {
					Runtime.getRuntime().exec(javaexePath + " -jar ./bin_/setUpdate.jar " + appdir.getAbsolutePath()
							+ " " + f + " " + blackexePath.getAbsolutePath());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.exit(0);
				break;
			} else {
				f.delete();
//				String n = f.getName();
//				int lastIndexOf2 = n.lastIndexOf(".");
//				n = n.substring(0, lastIndexOf2);
//				f.renameTo(new File(f.getParentFile().getAbsolutePath()+File.separator+n+".backup"));
			}
		}

	}

	public void reStartApp() {
		// TODO Auto-generated method stub
		b.closeEvent(null);
		try {
			Runtime.getRuntime().exec("./BlackDraft.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.exit(0);
	}
}
