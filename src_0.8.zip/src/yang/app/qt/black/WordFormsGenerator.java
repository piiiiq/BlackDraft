package yang.app.qt.black;
import simplenlg.framework.*;
import simplenlg.lexicon.*;
import simplenlg.phrasespec.*;
import simplenlg.features.*;
import simplenlg.realiser.english.*;
import java.util.*;

/**
 * 英文单词变形工具类
 * 返回简化的变形结果数组（不包含原始词汇，合并重复变形）
 */
public class WordFormsGenerator {
    private static WordFormsGenerator instance;
    private Lexicon lexicon;
    private NLGFactory factory;
    private Realiser realiser;
    
    // 特殊单词列表：这些单词不应该有变形
    private static final Set<String> NO_INFLECTION_WORDS = Set.of(
        "during", "the", "a", "an", "and", "or", "but", "if", "when", 
        "where", "why", "how", "what", "which", "who", "whom", "whose",
        "this", "that", "these", "those", "my", "your", "his", "her", 
        "its", "our", "their", "some", "any", "all", "every", "each"
    );

    private WordFormsGenerator() {
        try {
            this.lexicon = Lexicon.getDefaultLexicon();
            this.factory = new NLGFactory(lexicon);
            this.realiser = new Realiser();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize SimpleNLG components", e);
        }
    }

    public static synchronized WordFormsGenerator getInstance() {
        if (instance == null) {
            instance = new WordFormsGenerator();
        }
        return instance;
    }

    /**
     * 获取单词的所有常见变形形式（不包含原始词汇）
     * @param word 要查询的单词
     * @return 字符串数组，每个元素格式：变形词汇,词性（合并重复的变形词汇）
     */
    public String[] getWordForms(String word) {
        if (word == null || word.trim().isEmpty()) {
            return new String[0];
        }
        
        String lowerWord = word.toLowerCase().trim();
        
        // 检查是否为不应该变形的特殊单词
        if (NO_INFLECTION_WORDS.contains(lowerWord)) {
            return new String[0]; // 特殊单词不返回任何变形
        }
        
        // 使用Map来存储变形词汇和对应的词性列表
        Map<String, Set<String>> inflectionMap = new LinkedHashMap<>();
        
        // 收集所有变形形式
        collectVerbForms(inflectionMap, lowerWord);
        collectNounForms(inflectionMap, lowerWord);
        collectAdjectiveForms(inflectionMap, lowerWord);
        
        // 移除原始词汇
        inflectionMap.remove(lowerWord);
        
        // 将Map转换为结果数组
        return convertMapToArray(inflectionMap);
    }

    /**
     * 收集动词变形形式
     */
    private void collectVerbForms(Map<String, Set<String>> inflectionMap, String verb) {
        try {
            if (!isValidVerb(verb)) return;
            
            VPPhraseSpec verbPhrase = factory.createVerbPhrase(verb);
            
            // 过去式
            resetVerbFeatures(verbPhrase);
            verbPhrase.setFeature(Feature.TENSE, Tense.PAST);
            String pastTense = extractSingleWord(realiser.realise(verbPhrase).getRealisation());
            if (isValidVerbForm(pastTense) && !pastTense.equals(verb)) {
                addInflection(inflectionMap, pastTense, "verb_past");
            }
            
            // 过去分词
            resetVerbFeatures(verbPhrase);
            verbPhrase.setFeature(Feature.FORM, Form.PAST_PARTICIPLE);
            String pastParticiple = extractSingleWord(realiser.realise(verbPhrase).getRealisation());
            if (isValidVerbForm(pastParticiple) && !pastParticiple.equals(verb)) {
                addInflection(inflectionMap, pastParticiple, "verb_past_participle");
            }
            
            // 现在分词
            resetVerbFeatures(verbPhrase);
            verbPhrase.setFeature(Feature.PROGRESSIVE, true);
            String presentParticiple = extractSingleWord(realiser.realise(verbPhrase).getRealisation());
            if (isValidPresentParticiple(presentParticiple) && !presentParticiple.equals(verb)) {
                addInflection(inflectionMap, presentParticiple, "verb_present_participle");
            }
            
            // 第三人称单数现在式
            resetVerbFeatures(verbPhrase);
            verbPhrase.setFeature(Feature.PERSON, Person.THIRD);
            String thirdPerson = extractSingleWord(realiser.realise(verbPhrase).getRealisation());
            if (isValidVerbForm(thirdPerson) && !thirdPerson.equals(verb)) {
                addInflection(inflectionMap, thirdPerson, "verb_third_person");
            }
            
        } catch (Exception e) {
            // 静默处理异常
        }
    }

    /**
     * 收集名词变形形式
     */
    private void collectNounForms(Map<String, Set<String>> inflectionMap, String noun) {
        try {
            NPPhraseSpec nounPhrase = factory.createNounPhrase(noun);
            
            // 复数形式
            nounPhrase.setFeature(Feature.NUMBER, NumberAgreement.PLURAL);
            String plural = extractSingleWord(realiser.realise(nounPhrase).getRealisation());
            if (!plural.equals(noun)) {
                addInflection(inflectionMap, plural, "noun_plural");
            }
            
            // 所有格形式（单数）
            nounPhrase.setFeature(Feature.NUMBER, NumberAgreement.SINGULAR);
            nounPhrase.setFeature(Feature.POSSESSIVE, true);
            String possessive = extractSingleWord(realiser.realise(nounPhrase).getRealisation());
            if (!possessive.equals(noun)) {
                addInflection(inflectionMap, possessive, "noun_possessive");
            }
            
        } catch (Exception e) {
            // 静默处理异常
        }
    }

    /**
     * 收集形容词变形形式
     */
    private void collectAdjectiveForms(Map<String, Set<String>> inflectionMap, String adjective) {
        try {
            AdjPhraseSpec adjPhrase = factory.createAdjectivePhrase(adjective);
            
            // 比较级
            adjPhrase.setFeature(Feature.IS_COMPARATIVE, true);
            String comparative = extractSingleWord(realiser.realise(adjPhrase).getRealisation());
            if (!comparative.equals(adjective)) {
                addInflection(inflectionMap, comparative, "adjective_comparative");
            }
            
            // 最高级
            adjPhrase.setFeature(Feature.IS_COMPARATIVE, false);
            adjPhrase.setFeature(Feature.IS_SUPERLATIVE, true);
            String superlative = extractSingleWord(realiser.realise(adjPhrase).getRealisation());
            if (!superlative.equals(adjective)) {
                addInflection(inflectionMap, superlative, "adjective_superlative");
            }
            
        } catch (Exception e) {
            // 静默处理异常
        }
    }

    /**
     * 添加变形形式到Map中
     */
    private void addInflection(Map<String, Set<String>> inflectionMap, String word, String pos) {
        if (word == null || word.isEmpty()) return;
        
        String lowerWord = word.toLowerCase();
        inflectionMap.computeIfAbsent(lowerWord, k -> new LinkedHashSet<>()).add(pos);
    }

    /**
     * 将Map转换为结果数组
     */
    private String[] convertMapToArray(Map<String, Set<String>> inflectionMap) {
        List<String> result = new ArrayList<>();
        
        for (Map.Entry<String, Set<String>> entry : inflectionMap.entrySet()) {
            String word = entry.getKey();
            Set<String> posSet = entry.getValue();
            
            // 合并所有词性，用斜杠分隔
            String mergedPos = String.join("/", posSet);
            result.add(word + "," + mergedPos);
        }
        
        return result.toArray(new String[0]);
    }

    /**
     * 验证是否为有效的动词
     */
    private boolean isValidVerb(String word) {
        return !NO_INFLECTION_WORDS.contains(word);
    }

    /**
     * 验证是否为有效的动词形式
     */
    private boolean isValidVerbForm(String word) {
        return word != null && !word.isEmpty() && !word.contains(" ") && 
               !isAuxiliaryVerb(word) && word.matches("[a-zA-Z]+");
    }

    /**
     * 从短语中提取单个词汇
     */
    private String extractSingleWord(String phrase) {
        if (phrase == null || phrase.trim().isEmpty()) {
            return "";
        }
        
        String cleaned = phrase.replaceAll("[^a-zA-Z\\s]", "").trim();
        
        if (cleaned.contains(" ")) {
            String[] words = cleaned.split("\\s+");
            for (int i = words.length - 1; i >= 0; i--) {
                String word = words[i].toLowerCase();
                if (!isAuxiliaryVerb(word) && !word.isEmpty()) {
                    return word;
                }
            }
            return words[0].toLowerCase();
        }
        
        return cleaned.toLowerCase();
    }

    /**
     * 检查是否为辅助动词
     */
    private boolean isAuxiliaryVerb(String word) {
        String[] auxiliaries = {"be", "been", "being", "am", "is", "are", "was", "were", "have", "has", "had"};
        for (String aux : auxiliaries) {
            if (aux.equalsIgnoreCase(word)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 验证是否为有效的现在分词
     */
    private boolean isValidPresentParticiple(String word) {
        return word != null && !word.isEmpty() && word.endsWith("ing") && 
               !isAuxiliaryVerb(word) && word.matches("[a-zA-Z]+");
    }

    /**
     * 重置动词特征到默认状态
     */
    private void resetVerbFeatures(VPPhraseSpec verbPhrase) {
        verbPhrase.setFeature(Feature.TENSE, Tense.PRESENT);
        verbPhrase.setFeature(Feature.FORM, Form.NORMAL);
        verbPhrase.setFeature(Feature.PROGRESSIVE, false);
        verbPhrase.setFeature(Feature.PERSON, Person.FIRST);
        verbPhrase.setFeature(Feature.NUMBER, NumberAgreement.PLURAL);
    }

    /**
     * 测试方法
     */
    public static void main(String[] args) {
        WordFormsGenerator tool = WordFormsGenerator.getInstance();
        
        // 测试不同类型的单词
        String[] testWords = {"ourselves", "book", "run", "good", "fast", "during", "sheep","swim"};
        
        for (String word : testWords) {
            System.out.println("Input: " + word);
            String[] forms = tool.getWordForms(word);
            if (forms.length == 0) {
                System.out.println("  No inflections found");
            } else {
                for (String form : forms) {
                    System.out.println("  " + form);
                }
            }
            System.out.println();
        }
    }
}