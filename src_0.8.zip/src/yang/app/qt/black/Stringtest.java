package yang.app.qt.black;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.*;

public class Stringtest {
    private static int currentKey = 1418;

        private static Map<Integer, String> languageMap = new LinkedHashMap<>();
        
        private static final Pattern CHINESE_PATTERN = Pattern.compile("[\\u4e00-\\u9fa5]");
        private static final Pattern HTML_TAG_PATTERN = Pattern.compile("<[^>]+>");
        private static final Pattern PURE_STRING_PATTERN = 
            Pattern.compile("\"(?:[^\"]|\\\\\")*\"(\\s*\\+\\s*\"(?:[^\"]|\\\\\")*\")*+");
        private static final Pattern SINGLE_LINE_COMMENT = Pattern.compile("^\\s*//");
        private static final Pattern MULTI_LINE_COMMENT_START = Pattern.compile("/\\*");
        private static final Pattern MULTI_LINE_COMMENT_END = Pattern.compile("\\*/");

        public static void main(String[] args) throws IOException {
            if (args.length != 1) {
                System.out.println("Usage: java Stringtest <input_file.java>");
                return;
            }

            String inputFile = args[0];
            String outputFile = inputFile.replace(".java", ".modified");
            String langFile = inputFile.replace(".java", ".lang");

            List<String> lines = Files.readAllLines(Paths.get(inputFile));
            List<String> modifiedLines = new ArrayList<>();
            boolean inCommentBlock = false;
            
            for (String line : lines) {
                // 处理多行注释
                if (inCommentBlock) {
                    modifiedLines.add(line);
                    if (MULTI_LINE_COMMENT_END.matcher(line).find()) {
                        inCommentBlock = false;
                    }
                    continue;
                }
                
                if (MULTI_LINE_COMMENT_START.matcher(line).find()) {
                    inCommentBlock = !MULTI_LINE_COMMENT_END.matcher(line).find();
                    modifiedLines.add(line);
                    continue;
                }
                
                // 跳过单行注释
                if (SINGLE_LINE_COMMENT.matcher(line).find()) {
                    modifiedLines.add(line);
                    continue;
                }
                
                modifiedLines.add(processLine(line));
            }

            Files.write(Paths.get(outputFile), modifiedLines);
            saveLanguageFile(langFile);
        }

        private static String processLine(String line) {
            // 跳过包含HTML标签的行
            if (HTML_TAG_PATTERN.matcher(line).find()) {
                return line;
            }
            
            // 跳过不含中文的行
            if (!CHINESE_PATTERN.matcher(line).find()) {
                return line;
            }

            Matcher matcher = PURE_STRING_PATTERN.matcher(line);
            StringBuffer sb = new StringBuffer();
            
            while (matcher.find()) {
                String fullExpr = matcher.group();
                String processed = processPureString(fullExpr);
                if (processed != null) {
                    matcher.appendReplacement(sb, processed);
                }
            }
            matcher.appendTail(sb);
            
            return sb.toString();
        }

        private static String processPureString(String expr) {
            // 提取所有非空字符串字面量
            List<String> literals = new ArrayList<>();
            Matcher strMatcher = Pattern.compile("\"((?:[^\"]|\\\\\")*)\"").matcher(expr);
            while (strMatcher.find()) {
                String literal = strMatcher.group(1);
                // 跳过空字符串和包含HTML标签的字符串
                if (!literal.isEmpty() && !HTML_TAG_PATTERN.matcher(literal).find()) {
                    // 检查是否包含中文字符
                    if (CHINESE_PATTERN.matcher(literal).find()) {
                        literals.add(literal);
                    }
                }
            }

            if (literals.isEmpty()) {
                return null;
            }

            // 合并所有符合条件的字符串
            StringBuilder merged = new StringBuilder();
            for (String literal : literals) {
                merged.append(literal);
            }

            // 生成替换
            currentKey++;
            languageMap.put(currentKey, merged.toString());
            return "languageTool.getString(" + currentKey + ")";
        }

        private static void saveLanguageFile(String filename) throws IOException {
            try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
                for (Map.Entry<Integer, String> entry : languageMap.entrySet()) {
                    writer.println(entry.getKey() + " " + entry.getValue());
                }
            }
        }
    }