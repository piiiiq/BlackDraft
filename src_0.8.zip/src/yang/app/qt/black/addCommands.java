package yang.app.qt.black;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.widgets.QApplication;
import io.qt.widgets.QMessageBox;
import yang.demo.allPurpose.DesUtils;
import yang.demo.allPurpose.MD5;
import yang.demo.allPurpose.time;

public class addCommands {
	static bRunnable br00;
	static bRunnable autoScroll;

	public static void addCommands(final black b) {
		b.addCommand(new blackCommand(languageTool.getString(57), languageTool.getString(58), true) {
			public void action(String[] args) {
				b.LineAndDocFirst_keywords = (!b.LineAndDocFirst_keywords);
				if (b.LineAndDocFirst_keywords) {
					b.getMessageBox(languageTool.getString(59), languageTool.getString(60));
				} else {
					b.getMessageBox(languageTool.getString(59), languageTool.getString(61));
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(62), languageTool.getString(63)) {
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				if (((Integer) right.value).intValue() <= 0) {
					b.getMessageBox(languageTool.getString(64), languageTool.getString(65));
					return;
				}
				int value = ((Integer) right.value).intValue();
				String message = languageTool.getString(62)+" ";
				String timerName = "";
				if (args.length > 1) {
					timerName = args[1];
				} else {
					timerName = time.msToTimeMoreLang(value * 1000,black.day,black.hour,black.min,black.sec);
				}
				message = message + "(" + timerName + "|" + right.value + languageTool.getString(66)+")";

				QMessageBox messageBox = b.getMessageBox(languageTool.getString(67), message + languageTool.getString(68), false, b.ico_timer);
				String message_ = message;
				addCommands.addTimerAction(b, value, timerName, messageBox, message_);
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(69), languageTool.getString(70)) {
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				if (((Integer) right.value).intValue() < 0) {
					b.getMessageBox(languageTool.getString(64), languageTool.getString(71));
					return;
				}
				int value = ((Integer) right.value).intValue();
				b.setAnimationTime(value);
				b.getMessageBox(languageTool.getString(72), languageTool.getString(73,value));
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(75), languageTool.getString(76)) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				if (((Integer) right.value).intValue() <= 0) {
					b.getMessageBox(languageTool.getString(64), languageTool.getString(77));
					return;
				}
				int value = ((Integer) right.value).intValue();
				b.btext.typeModeValue = value;
				b.settings.setValue(appInfo.typeModeValue, value + "");
			}
		});
		if (appInfo.mode == 1)
			b.addCommand(new blackCommand(languageTool.getString(832), languageTool.getString(833)) {

				@Override
				public void action(String[] args) {
					// TODO Auto-generated method stub
					isRight right = b.isRightIntValue(args[0]);
					if (!right.isright) {
						return;
					}
					if (((Integer) right.value).intValue() < 0) {
						b.getMessageBox(languageTool.getString(834), languageTool.getString(835));
						return;
					}
					int value = ((Integer) right.value).intValue();
					b.settings.setValue(appInfo.voiceRate, value + "");
					if (b.speech != null)
						b.speech.setRate(value);
					;
				}
			});
// 	b.addCommand(new blackCommand(languageTool.getString(836),languageTool.getString(837),true) {
//
//		@Override
//		public void action(String[] args) {
//			// TODO Auto-generated method stub
//			MSTTSSpeech speech = new MSTTSSpeech();
//			String[] voices = speech.getVoices();
//			StringBuilder sb = new StringBuilder();
//			for(int i=0;i<voices.length;i++) {
//				sb.append(i+" "+voices[i]+"\n");
//			}
//			sb.append("\n<b>当前语音："+voices[b.getIntValueFromSettings(appInfo.voice, "0")]+"</b>");
//			b.getBMessageBox(languageTool.getString(838), sb.toString());
//		}
// 	
// });
//   

		b.addCommand(new blackCommand(languageTool.getString(839), languageTool.getString(840)
				+ languageTool.getString(841), false) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				String v = (!Boolean.valueOf((String) b.settings.value(appInfo.conversionToFullPinyin, "false"))) + "";
				b.settings.setValue(appInfo.conversionToFullPinyin, v);
				if (v.equals("true")) {
					isRight r = b.isRightIntValue(args[0]);
					int value = (int) r.value;
					if (r.isright) {
						if (value == 0)
							b.settings.setValue(appInfo.useSpiltCharForPinyin, "false");
						else if (value == 1)
							b.settings.setValue(appInfo.useSpiltCharForPinyin, "true");
						else
							b.getMessageBox(languageTool.getString(842), languageTool.getString(843));
					}
				}
				b.setLoadFileMessage(languageTool.getString(844) + v);
			}
		});

		b.addCommand(new blackCommand(languageTool.getString(845), languageTool.getString(846), true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				String v = (!Boolean.valueOf((String) b.settings.value(appInfo.moreFindMarkWithPinyin, "false"))) + "";
				b.settings.setValue(appInfo.moreFindMarkWithPinyin, v);
				b.setLoadFileMessage(languageTool.getString(847) + v);
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(848), languageTool.getString(849), true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				String clearEditPoint = b.clearEditPoint(null);
				b.getBMessageBox(languageTool.getString(1352), languageTool.getString(1353,cheakDocument.getAllLine(clearEditPoint).size(),clearEditPoint));
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(850),
				languageTool.getString(851),
				true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				String clearPlusInShowName = b.clearPlusInShowName(null);
				List<String> allLine = cheakDocument.getAllLine(clearPlusInShowName);
				b.getBMessageBox("", languageTool.getString(1354,allLine.size(),clearPlusInShowName));
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(852),
				languageTool.getString(853), true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				b.resetProjectFileIndex(true);
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(854), languageTool.getString(855), true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				boolean hide = !b.getBooleanValueFromSettings(appInfo.hideIMEPanel, "true");
				b.settings.setValue(appInfo.hideIMEPanel, hide + "");
				b.setLoadFileMessage(languageTool.getString(856));
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(857), languageTool.getString(858),
				true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				boolean pagesha = !b.getBooleanValueFromSettings(appInfo.usePageShadow, "false");
				b.settings.setValue(appInfo.usePageShadow, pagesha + "");
				b.setLoadFileMessage(languageTool.getString(859) + pagesha);
				b.repaint();
				b.ba.shadow();
				b.ba.setShandow(pagesha);
				b.ba.setShandowAction(pagesha);
			}

		});

		b.addCommand(new blackCommand(languageTool.getString(860), languageTool.getString(861)) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				int value = ((Integer) right.value).intValue();
				b.backupTime = value * 60000;
				b.settings.setValue(appInfo.backUpTime, b.backupTime);
				if (value > 0)
					b.getMessageBox(languageTool.getString(862), languageTool.getString(863,time.msToTime(value * 60 * 1000)));
				else
					b.getMessageBox(languageTool.getString(862), languageTool.getString(865));
			}

		});
		b.addCommand(new blackCommand(languageTool.getString(866), languageTool.getString(867), true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				b.backupDir = b.getDirDialog(languageTool.getString(868));
				if (!b.backupDir.isEmpty() && new File(b.backupDir).isDirectory())
					b.projectInfo.setProperty(appInfo.backUpDir, b.backupDir);
			}

		});
		if (appInfo.mode == 1)
			b.addCommand(new blackCommand(languageTool.getString(869), languageTool.getString(870)) {

				@Override
				public void action(String[] args) {
					// TODO Auto-generated method stub
					isRight right = b.isRightIntValue(args[0]);
					if (!right.isright) {
						return;
					}
					int value = ((Integer) right.value).intValue();
					String message = "";
					if (b.writingView == 0)
						message = languageTool.getString(871);
					else if (value >= 0 && value <= 100) {
						b.withoutBuleValue = value;
						if (b.getIntValueFromSettings(appInfo.editorColor, "0") != 1) {
							b.settings.setValue(appInfo.editorColor, "1");
						}
						b.applyColorChange();
					} else
						message = languageTool.getString(872);
					if (!message.isEmpty())
						b.getMessageBox(languageTool.getString(869), message);
				}

			});
		b.addCommand(new blackCommand(languageTool.getString(874), languageTool.getString(875) + appInfo.appName, true) {

			@Override
			public void action(String[] args) {
				// TODO Auto-generated method stub
				b.ba.reStartApp();
			}

		});
		

//  b.addCommand(new blackCommand(languageTool.getString("插入列表"),languageTool.getString(""),true) {
//
//		@Override
//		public void action(String[] args) {
//			bAction.insertList();
//	}});
		

		
		b.addCommand(new blackCommand(languageTool.getString(878), languageTool.getString(879), true) {

			@Override
			public void action(String[] args) {
				b.ba.charSpace();

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(880), languageTool.getString(881), true) {

			@Override
			public void action(String[] args) {
				b.ba.desInfo(b);

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(882), languageTool.getString(883), true) {

			@Override
			public void action(String[] arg) {
				String topAndBottom = b.getStringValueFromSettings(appInfo.writingViewTextTopAndBottom, "0 0");
				String[] args = cheakDocument.checkCommandArgs(topAndBottom);
				int top = 0, bottom = 0;
				isRight isTop = b.isRightIntValue(args[0]);
				if (isTop.isright) {
					top = (int) isTop.value;
				}
				isRight isBottom = b.isRightIntValue(args[1]);
				if (isBottom.isright) {
					bottom = (int) isBottom.value;
				}
				new InputDialog(b, languageTool.getString(884), languageTool.getString(885), false, false, top + " " + bottom) {

					@Override
					void whenOkButtonPressed() {
						// TODO Auto-generated method stub
						b.settings.setValue(appInfo.writingViewTextTopAndBottom, value());
						if (b.writingView > 0) {
							int width = b.getWritingViewTextWitdh() / 2;
							b.setTextLocationForWritingView(width);
						}

					}

					@Override
					void whenClose() {
						// TODO Auto-generated method stub

					}

					@Override
					void whenCannelButtonPressed() {
						// TODO Auto-generated method stub

					}
				}.exec();

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(887), languageTool.getString(888), true) {

			@Override
			public void action(String[] args) {
				String mailString = bAction.getMailString(black.text.toPlainText());
				b.getBMessageBox(languageTool.getString(887), mailString);
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(890), languageTool.getString(891), true) {

			@Override
			public void action(String[] args) {
				String stringWith = bAction.getStringWith(black.text.toPlainText());
				b.getBMessageBox(languageTool.getString(887), stringWith);
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(893), languageTool.getString(894), true) {

			@Override
			public void action(String[] args) {
				try {
					String md5 = MD5.getMD5ChecksumOfString(black.text.toPlainText());
					b.getBMessageBox(languageTool.getString(895), md5);
				} catch (Exception e) {
				}
				
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(896),
				appInfo.textToHtml(languageTool.getString(897))) {

			@Override
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					b.getMessageBox(languageTool.getString(903), languageTool.getString(904));
					return;
				}
				int alpha = 255;
				if (args.length > 1) {
					isRight right1 = b.isRightIntValue(args[1]);
					alpha = (int) right1.value;
				}
				b.ba.setColors((int) right.value, alpha);

			}
		});
//    b.addCommand(new blackCommand(languageTool.getString(905),languageTool.getString(906),true) {
//
//		@Override
//		public void action(String[] args) {
//			b.ba.useTextBorder();
//	}});
//    b.addCommand(new blackCommand(languageTool.getString(907),languageTool.getString(908),true) {
//
//		@Override
//		public void action(String[] args) {
//			b.ba.useTextBg();
//	}});
//    b.addCommand(new blackCommand(languageTool.getString(909),languageTool.getString(910),true) {
//
//		@Override
//		public void action(String[] args) {
//			b.ba.setAntialiasing();
//	}});
		b.addCommand(new blackCommand(languageTool.getString(911), languageTool.getString(912), true) {

			@Override
			public void action(String[] args) {
				b.ba.getUpdateInfoAll(false);
			}
		});
//    b.addCommand(new blackCommand(languageTool.getString(913),languageTool.getString(914)) {
//
//		@Override
//		public void action(String[] args) {
//			isRight right = b.isRightIntValue(args[0]);
//	        if (!right.isright) {
//	          return;
//	        }
//	        int value = (int) right.value;
//			if(value >= 50) {
//				b.settings.setValue(appInfo.pageHeght, right.value+"");
//				b.repaint();
//			}
//	}});
		b.addCommand(new blackCommand(languageTool.getString(915),
				languageTool.getString(916)) {

			@Override
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				int value = (int) right.value;
				if (value >= 0 && value <= 3) {
					b.settings.setValue(appInfo.typerMode, value + "");
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(917), languageTool.getString(918), false) {

			@Override
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				int value = (int) right.value;
				if (value >= 1 && value <= 20) {
					b.settings.setValue(appInfo.UIfontSizeAdd, value + "");
					b.ba.applyUIFont();
				} else
					b.getMessageBox(languageTool.getString(919), languageTool.getString(920));

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(921), languageTool.getString(922)
				+ languageTool.getString(923)
				+ languageTool.getString(924), true) {

			@Override
			public void action(String[] args) {
				b.ba.setUsePic();
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(925),
				languageTool.getString(926), true) {

			@Override
			public void action(String[] args) {
				b.ba.setUseBingPic();
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(927), languageTool.getString(928)
				+ languageTool.getString(929), false) {

			@Override
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				int value = (int) right.value;
				if (value >= 0) {
					b.settings.setValue(appInfo.maxCharsAutoSegment, value + "");
				}

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(930),
				languageTool.getString(931), false) {

			@Override
			public void action(String[] args) {
				isRight right = b.isRightIntValue(args[0]);
				if (!right.isright) {
					return;
				}
				int value = (int) right.value;
				if (value >= 0) {
					b.settings.setValue(appInfo.minLenghtOfAutoSegment, value + "");
				}

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(932), languageTool.getString(933), true) {

			@Override
			public void action(String[] args) {
				b.ba.showSegmentHelp();

			}
		});
		b.addCommand(
				new blackCommand(languageTool.getString(934), languageTool.getString(935), true) {

					@Override
					public void action(String[] args) {
						b.ba.setSegmentInfo();

					}
				});
		b.addCommand(
				new blackCommand(languageTool.getString(936), languageTool.getString(937), false) {

					@Override
					public void action(String[] args) {
						isRight right = b.isRightIntValue(args[0]);
						if (!right.isright) {
							return;
						}
						int value = (int) right.value;
						if (value >= 100) {
							b.settings.setValue(appInfo.pinyinStartSegmentMS, value + "");
						}

					}
				});
		b.addCommand(new blackCommand(languageTool.getString(938), languageTool.getString(939), true) {

			@Override
			public void action(String[] args) {
				boolean v = !b.getBooleanValueFromSettings(appInfo.autoSaveInputOfAutoSegment, "true");
				b.settings.setValue(appInfo.autoSaveInputOfAutoSegment,
						v);

			}
		});
		b.addCommand(
				new blackCommand(languageTool.getString(940),
						languageTool.getString(941)
								+ languageTool.getString(942),
						true) {

					@Override
					public void action(String[] args) {
						b.ba.showKeywordsWhenTextChanaged();

					}
				});
		b.addCommand(new blackCommand(languageTool.getString(943), languageTool.getString(944), true) {

			@Override
			public void action(String[] args) {
				boolean v = !b.getBooleanValueFromSettings(appInfo.useInLineIME, "false");
				b.settings.setValue(appInfo.useInLineIME,
						v);

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(945), languageTool.getString(946), true) {

			@Override
			public void action(String[] args) {
				boolean v = !b.getBooleanValueFromSettings(appInfo.fullScreen, "true");
				b.settings.setValue(appInfo.fullScreen,
						v);
				if(b.writingView == 1) {
					//必须采用先退出写作视图再重新进入写作视图的方法才能避免窗口异常
					//如果不退出写作视图，而是直接在写作试图中修改窗口几何形状，会导致退出写作视图后窗口没有边框
					b.exitWritingView();
//					if (v) {
//						b.setGeometry(b.ba.desktopGeometry(false));
//					} else {
//						b.setGeometry(b.ba.desktopGeometry(true));
//					}
					b.writingView(true);
//					b.ba.blackShow(b, 0);
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(947), languageTool.getString(948), false) {

			@Override
			public void action(String[] args) {
				isRight r = b.isRightIntValue(args[0]);
				if(!r.isright)return;
				b.settings.setValue(appInfo.RoundShadow,
						r.value+"");
				b.ba.shadow();
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(951), languageTool.getString(952), true) {

			@Override
			public void action(String[] args) {
				boolean v = !b.getBooleanValueFromSettings(appInfo.fixedCaretPosWhenInput, "false");
				b.settings.setValue(appInfo.fixedCaretPosWhenInput,
						v);
				
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(953), languageTool.getString(954), false) {

			@Override
			public void action(String[] args) {
				isRight r = b.isRightIntValue(args[0]);
				if(!r.isright)return;
				int v = (int) r.value;
				if(v<0)return;
				Thread t = (Thread) b.ba.tempData.get("randomImgThread");
				if(t != null) {
					b.ba.tempData.remove("randomImgThread");
					if(v == 0) {
						b.ba.tempData.remove("randomImg");
						b.ba.tempData.remove("randomImgOld");
					}
					b.debugPrint(languageTool.getString(959));
//					t.interrupt();
//					t.stop();
					while(!t.isInterrupted()) {
						t.interrupt();
						b.debugPrint(languageTool.getString(960,t.isInterrupted()));
					}
				}
				b.settings.setValue(appInfo.randomImg,
						v+"");
				if(args.length > 1) {
					b.settings.setValue(appInfo.randomImgKeywords, args[1]);
				}else {
					b.settings.remove(appInfo.randomImgKeywords);
				}
				b.applyColorChange();

			}
		});
		b.addCommand(new blackCommand(languageTool.getString(961), languageTool.getString(962), false) {

			private isRight right;

			@Override
			public void action(String[] args) {
				if(args.length < 1)return;
				
				right = b.isRightIntValue(args[0]);
				if(!right.isright) {
					return;
				}
				showRandomImg random = (showRandomImg) b.ba.tempData.get("randomImgWindow");
				if(random != null) {
					random.close();
					b.ba.tempData.remove("randomImgWindow");
				}
				
				int v = (int) right.value;
				if(v < 1) v = 1;
				String url = "0";
				String keywords = null;
				if(args.length > 1) url = args[1]; 
				if(args.length > 2) keywords = args[2];
				showRandomImg showRandomImg = new showRandomImg(v,url,keywords);
				b.ba.tempData.put("randomImgWindow", showRandomImg);
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(967), languageTool.getString(968), true) {

			@Override
			public void action(String[] args) {
				String message = null;
				if(b.dbm) message = languageTool.getString(969);
				else message = languageTool.getString(970);
				
				b.dbm = !b.dbm;
				
				b.getMessageBox(languageTool.getString(971), message);
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(972), languageTool.getString(973), true) {

			@Override
			public void action(String[] args) {
				boolean v = !b.getBooleanValueFromSettings(appInfo.noCaretWhenInput, "false");
				b.settings.setValue(appInfo.noCaretWhenInput, v);
			}
		});
		
		b.addCommand(new blackCommand(languageTool.getString(974), languageTool.getString(975), false) {



			@Override
			public void action(String[] args) {
				if(args.length < 1)return;
				
				isRight right = b.isRightIntValue(args[0]);
				if(!right.isright) {
					return;
				}
				b.infoOfCurrentEditing.autoscrollvalue = (int) right.value;

				if(autoScroll != null) {
					autoScroll.stop();
					autoScroll = null;
				}
				if((int)right.value > 0) {
					autoScroll = new bRunnable((int)right.value) {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							if(b.isActiveWindow())
							b.text.verticalScrollBar().setValue(b.text.verticalScrollBar().value()+1);
							
						}
					};
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(976), languageTool.getString(977), false) {



			@Override
			public void action(String[] args) {
				if(args.length < 1)return;
				
				isRight right = b.isRightIntValue(args[0]);
				if(!right.isright && (int)right.value > 0 && (int)right.value <= 100) {
					return;
				}
				b.settings.setValue(appInfo.charSpaceValue, (100+(int)right.value)+"");
				if(b.getBooleanValueFromSettings(appInfo.charSpace, "false"))
					b.setStyleForCurrentDocument();
				else {
					b.getMessageBox(languageTool.getString(978), languageTool.getString(979));
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(980), languageTool.getString(981), true) {
			
			@Override
			public void action(String[] args) {
				StringBuffer sb = new StringBuffer();
				String t = b.text.toPlainText();
				ArrayList<String> allLine = cheakDocument.getAllLine(t);
				int c=0;
				for(String s:allLine) {
					String current = null;
					//编码
					String[] a1 = cheakDocument.subString(s, "=");
					//词频
					TextRegion a2 = cheakDocument.subString(s, "=", ",");
					//汉字
					String[] a3 = cheakDocument.subString(s, ",");
//					sb.append(a3[1]+"\t"+a1[0]+"\t"+a2.text+"\n");
					sb.append(a1[0]+"\t"+a3[1]+"\n");
					c++;
				}
				QTextCursor tc = b.text.textCursor();
				tc.select(SelectionType.Document);
				tc.insertText(sb.toString());
				b.getMessageBox(languageTool.getString(982), languageTool.getString(983,c));
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(985), languageTool.getString(986), true) {

			@Override
			public void action(String[] args) {
				boolean useQtCaret = !b.getBooleanValueFromSettings(appInfo.useQtCaret, "false");
				b.settings.setValue(appInfo.useQtCaret, useQtCaret+"");
				b.text.useQtCaret = useQtCaret;
				for(dataForOpenedFile of:b.openedFiles) {
					if(of.editor != null) {
						of.editor.text.useQtCaret = useQtCaret;
						if(useQtCaret) {
							of.editor.text.deleteCaret();
						}else {
							of.editor.text.initCaret();
						}
						
					}
				}
				if(!useQtCaret) {
					b.text.initCaret();
					b.applyColorChange();
				}else {
					b.text.deleteCaret();
				}
			}
		});
		b.addCommand(new blackCommand(languageTool.getString(987), languageTool.getString(988), true) {

			@Override
			public void action(String[] args) {
				b.getBMessageBox(languageTool.getString(989), appInfo.argsHelpInfo);
			}
		});
		if (b.dbm) {
			b.addCommand(new blackCommand("test", "", true) {

				@Override
				public void action(String[] args) {
					b.ba.test();
				}
			});
			
		}
	}

	static void addTimerAction(final black b, final int value, final String timerName, QMessageBox messageBox,
			final String message_) {
		final String messageEnd = time.getCurrentTimeHasSecond();
		b.addTimer(new timerInfo(appInfo.timerInfoType.timer.value, value * 1000, timerName, new Runnable() {
			public void run() {
				b.uiRun(b, new Runnable() {
					public void run() {
						if ((messageBox != null) && (messageBox.isVisible())) {
							messageBox.hide();
						}
						black.startBeepSound(-1);
						int mb = b.getMessageBoxWithYesNO(languageTool.getString(991),
								 languageTool.getString(992,message_,messageEnd,time.getCurrentTimeHasSecond()), languageTool.getString(994),
								languageTool.getString(995), b.ico_timer, 0, true);
						black.stopBeepSound();
						if (mb == 1) {
							//必须新开线程执行，否则会导致messagebox不关闭
							new bRunnable(100,true,false,false,true) {
								
								@Override
								public void run() {
									// TODO Auto-generated method stub
									addCommands.addTimerAction(b, value, timerName, messageBox, message_);
								}
							};
						}
					}
				});
			}
		}, true));
	}
}
