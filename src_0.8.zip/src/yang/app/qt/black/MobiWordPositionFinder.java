package yang.app.qt.black;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class MobiWordPositionFinder {

    public static String findWordPositions(String mobiHtml, String wordList) {
        // 将词汇列表转换为Set以便快速查找
        Set<String> targetWords = new HashSet<>();
        for (String word : wordList.split("\\r?\\n")) {
            if (!word.trim().isEmpty()) {
                targetWords.add(word.trim().toLowerCase());
            }
        }
        
        if (targetWords.isEmpty()) {
            return "";
        }

        List<String> results = new ArrayList<>();
        
        try {
            // 将HTML字符串转换为字节数组以便进行字节级操作
            byte[] htmlBytes = mobiHtml.getBytes(StandardCharsets.UTF_8);
            
            // 匹配所有的<body>标签内容
            Pattern bodyPattern = Pattern.compile("<body[^>]*>(.*?)</body>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
            Matcher bodyMatcher = bodyPattern.matcher(mobiHtml);
            
            while (bodyMatcher.find()) {
                String bodyContent = bodyMatcher.group(1);
                int bodyStartOffset = bodyMatcher.start(1); // body内容在原始HTML中的字符位置
                
                // 匹配body中的所有文本内容（位于>和<之间）
                Pattern textPattern = Pattern.compile(">([^<]{2,})<");
                Matcher textMatcher = textPattern.matcher(bodyContent);
                
                while (textMatcher.find()) {
                    String textSegment = textMatcher.group(1);
                    int segmentStartInBody = textMatcher.start(1); // 文本段在body中的字符位置
                    
                    // 计算文本段在原始HTML中的起始字符位置
                    int segmentStartInHtml = bodyStartOffset + segmentStartInBody;
                    
                    // 处理HTML转义字符
                    String unescapedText = unescapeHtml(textSegment);
                    
                    // 在当前文本段中查找目标词汇
                    findWordsInSegment(unescapedText, segmentStartInHtml, htmlBytes, targetWords, results);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
        
        return String.join("\n", results);
    }
    
    private static void findWordsInSegment(String text, int segmentStartChar, byte[] htmlBytes, 
                                         Set<String> targetWords, List<String> results) {
        // 简单的分词逻辑：按空格分割单词
        String[] words = text.split("\\s+");
        int currentPos = 0;
        
        for (String word : words) {
            if (word.isEmpty()) continue;
            
            String cleanWord = cleanWord(word);
            if (cleanWord.isEmpty()) continue;
            
            // 检查是否是目标词汇（不区分大小写）
            if (targetWords.contains(cleanWord.toLowerCase())) {
                // 找到单词在文本段中的起始字符位置
                int wordStartInSegment = text.indexOf(word, currentPos);
                if (wordStartInSegment == -1) continue;
                
                // 计算单词在原始HTML中的字符位置
                int wordStartInHtml = segmentStartChar + wordStartInSegment;
                
                // 计算字节偏移量
                try {
                    // 获取从开始到单词起始位置的子字符串
                    String htmlSubstring = new String(htmlBytes, 0, wordStartInHtml, StandardCharsets.UTF_8);
                    int byteOffset = htmlSubstring.getBytes(StandardCharsets.UTF_8).length;
                    
                    // 添加到结果列表
                    results.add(cleanWord + "," + byteOffset);
                } catch (Exception e) {
                    // 忽略编码错误
                }
                
                // 更新当前位置
                currentPos = wordStartInSegment + word.length();
            } else {
                // 更新当前位置
                currentPos += word.length() + 1; // +1 for space
            }
        }
    }
    
    private static String cleanWord(String word) {
        // 移除单词两端的标点符号
        return word.replaceAll("^[^\\w]+|[^\\w]+$", "");
    }
    
    private static String unescapeHtml(String html) {
        // 简单的HTML转义字符处理
        return html.replace("&amp;", "&")
                  .replace("&lt;", "<")
                  .replace("&gt;", ">")
                  .replace("&quot;", "\"")
                  .replace("&apos;", "'")
                  .replace("&nbsp;", " ");
    }
    
    // 测试用例
    public static void main(String[] args) {
        String mobiHtml = "<html><body><p>This is a test paragraph with important words.</p>" +
                         "<div>Another section with test words here.</div></body></html>";
        
        String wordList = "test\nwords\nparagraph";
        
        String result = findWordPositions(mobiHtml, wordList);
        System.out.println("Found word positions:");
        System.out.println(result);
        
        // 预期输出类似：
        // test,XX
        // words,XX
        // paragraph,XX
        // test,XX
        // words,XX
    }
}