package yang.app.qt.black;

import io.qt.core.Qt;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.widgets.QAction;
import io.qt.widgets.QApplication;
import io.qt.widgets.QMainWindow;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QToolBar;

public class MainWindow extends QMainWindow {
    private QTextEdit textEdit;
    private FontSizeHighlighter highlighter;

    public MainWindow() {
        textEdit = new QTextEdit(this);
        setCentralWidget(textEdit);
        
        // 创建高亮器并设置初始缩放因子
        highlighter = new FontSizeHighlighter(textEdit, 1.0);
        
        // 添加一些有格式的文本作为测试
        textEdit.append("这是普通文本");
        
        QTextCursor cursor = textEdit.textCursor();
        QTextCharFormat boldFormat = new QTextCharFormat();
        boldFormat.setFontWeight(QFont.Weight.Bold.value());
        boldFormat.setFontPointSize(20);
        cursor.insertText("这是粗体文本", boldFormat);
        
        QTextCharFormat colorFormat = new QTextCharFormat();
        colorFormat.setForeground(new QBrush(new QColor(Qt.GlobalColor.red)));
        cursor.insertText("这是红色文本", colorFormat);
        
        // 添加缩放按钮
        QToolBar toolBar = addToolBar("Zoom");
        QAction zoomIn = toolBar.addAction("Zoom In");
        QAction zoomOut = toolBar.addAction("Zoom Out");
        QAction resetZoom = toolBar.addAction("Reset Zoom");
        
        zoomIn.triggered.connect(this, "zoomIn()");
        zoomOut.triggered.connect(this, "zoomOut()");
        resetZoom.triggered.connect(this, "resetZoom()");
    }

    private void zoomIn() {
        highlighter.setScaleFactor(highlighter.scaleFactor() * 1.1);
    }

    private void zoomOut() {
        highlighter.setScaleFactor(highlighter.scaleFactor() / 1.1);
    }

    private void resetZoom() {
        highlighter.setScaleFactor(1.0);
    }

    public static void main(String[] args) {
        QApplication.initialize(args);
        MainWindow mainWindow = new MainWindow();
        mainWindow.show();
        QApplication.exec();
    }
}