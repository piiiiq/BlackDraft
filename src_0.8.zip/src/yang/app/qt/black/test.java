package yang.app.qt.black;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.github.eb4j.mdict.MDException;
import io.github.eb4j.mdict.MDictDictionary;
import io.qt.core.QObject;
import io.qt.core.Qt.WidgetAttribute;
import io.qt.gui.QFont;
import io.qt.gui.QTextDocument;
import io.qt.widgets.QAction;
import io.qt.widgets.QApplication;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QWidget;
import yang.demo.allPurpose.algorithm;

public class test {
	static void converBooks(String dirpath,String dictpath) {
		File file = new File(dirpath);
		if(file.isDirectory()) {
			File[] files = file.listFiles();
			String s = "E:\\download\\coca\\60000-short.txt_去重.txt_变形.txt";
			if(dictpath != null) s = dictpath;
			String text = io.readTextFile(new File(s), "utf-8");
			File outdir = new File(dirpath+File.separator+"new");
			if(!outdir.exists()) outdir.mkdir();
			int i = 1;
			for(File f:files) {
				if(f.isDirectory()) continue;
				System.out.println("开始转换第"+i+"本书");
				String booktext = io.readTextFile(f, "utf-8");
				ArrayList<String> allLine = cheakDocument.getAllLine(text);
				for(String line:allLine) {
					String[] sub = cheakDocument.subString(line, ",");
					if(sub[0].length() != line.length()) {
						if(sub[0].indexOf("-") != -1) {
							String reline = sub[0].replace("-", " ");
							booktext = booktext.replaceAll("(?i)"+reline, sub[0]);
						}
					}
					
				}
				
				io.writeTextFile(new File(outdir.getPath()+File.separator+f.getName()), booktext, "utf-8");
				i++;
			}
		}
	}
	public static String getCleanWord1(String word){
        StringBuilder sb = new StringBuilder(word.length());
        for(int i=0;i<word.length();i++){
            char c = word.charAt(i);
            if(c >= 97 && c <= 122) sb.append(c);
            else if(c >= 65 && c <= 90) sb.append(c);
            else if(c == 45) sb.append(c);
        }
        return sb.toString();
	}
	public static String getCleanWord2(String word) {
		int start = -1,end = -1;
      if(start == -1)
          for(int i=0;i<word.length();i++) {
              char c = word.charAt(i);
              if(c >= 97 && c <= 122) {
                  start = i;
                  break;
              }
              else if(c >= 65 && c <= 90) {
                  start = i;
                  break;
              }
          }
      if(end == -1)
          for(int i=word.length()-1;i>=0;i--) {
              char c = word.charAt(i);
              if(c >= 97 && c <= 122) {
                  end = i;
                  break;
              }
              else if(c >= 65 && c <= 90) {
                  end = i;
                  break;
              }
          }
      if(start != -1 && end != -1)
      return word.substring(start, end+1).toLowerCase();
      else return word.toLowerCase();
	}
	public static String getCleanWord(String word){
    
        String word_ = word;
        if(word_.length() > 1){
            char c_ = word_.charAt(0);
            if(c_ == '“' || c_ == '‘' || c_ == '"' || c_ == '\'' || c_ == '-' || c_ == ':'){
                word_ = word_.substring(1,word_.length());
            }
        }
        if(word_.length() > 1){
            char c1 = word_.charAt(word_.length()-2);
            if(c1 == '.' || c1 == ',' || c1 == '?' || c1 == '!' ||  c1 == '”'|| c1 == '\''|| c1 == ':' || c1 == ';'|| c1 == '-'){
                return word_.substring(0,word_.length()-2);
            }else{
                char c = word_.charAt(word_.length()-1);
                if(c == '.' || c == ',' || c == '?' || c == '!' || c == '’'|| c == '”'||c == '\'' || c == ':' || c == ';'|| c == '-'){
                    return word_.substring(0,word_.length()-1);
                }
            }
        }

        return word_;
    }
	public static void findBooksWord(String bookdir) {
		File dir = new File(bookdir);
		if(!dir.exists() || !dir.isDirectory()) {
			return;
		}
		String s = "E:\\download\\coca\\60000-short.txt_去重.txt";
		String dict = io.readTextFile(new File(s), "utf-8");
		ArrayList<String> dictWords = cheakDocument.getAllLine(dict);
		HashSet<String> dictwords = new HashSet<>();
		HashSet<String> newwords = new HashSet<>();
		for(String word:dictWords) {
			dictwords.add(getCleanWord2(word));
//			String[] sub = cheakDocument.subString(word, ",");
//			if(sub[0].length() != word.length()) {
//				dictwords.add(sub[0]);
//			}
		}
		File[] files = dir.listFiles();
		int bookindex = 1;
		for(File file:files) {
			if(file.isDirectory())continue;
			System.out.println("正在提取第"+bookindex+"本书中的生词");
			String text = io.readTextFile(file, "utf-8");
			HashSet<String> words = getEnglishWords(text);
			for(String w:words) {
				if(!dictwords.contains(w)) {
					newwords.add(w);
				}
			}
			bookindex++;
		}
		StringBuffer sb = new StringBuffer();
		for(String w:newwords) {
			String cleanWord2 = getCleanWord2(w);
			if(cleanWord2.length() > 1 && cleanWord2.indexOf(" ") == -1 && cleanWord2.indexOf("\n") == -1 && cleanWord2.indexOf("\r") == -1)
				sb.append(w+"\n");
		}
		io.writeTextFile(new File(bookdir+"newWord.txt"), sb.toString(), "utf-8");
	}
	static HashSet<String> getEnglishWords(String text) {
		int start=0,end = 0;
		HashSet<String> words = new HashSet<>();
		for(int i=0;i<text.length();i++) {
			char c = text.charAt(i);
			if(c == ' ' || c == '\n') {
				start = end;
				end = i;
				words.add(getCleanWord2(text.substring(start, end)));
			}else if(i==text.length()-1) {
				start = end;
				end = i;
				words.add(getCleanWord2(text.substring(start, end+1)));
			}
		}
		return words;
	}
	
	

	public static void main(String[] args) throws FileNotFoundException, IOException{
		File f = new File("I:\\UserData\\desktop\\a.txt");
		String text = io.readTextFile(f, "utf-8");
		QTextDocument td = new QTextDocument(text);
		QTextDocument tdd = new QTextDocument(td.toHtml());
		System.out.println(tdd.toPlainText());
		
//		converBooks("E:\\download\\coca\\英文书", null);
		
//		String str = "books is good\n\rand you are fine.";
//		ArrayList<String> words = getEnglishWords(str);
//		
//		for(String word:words)
//		System.out.println(getCleanWord2(word));
		
//		findBooksWord("E:\\download\\coca\\英文书");
//		algorithm.getContextFromText("E:\\download\\coca\\英文书newWord.txt", "utf-8", 0);
//		System.out.println(text);
		
//		File file = new File("E:\\download\\coca\\从书中扫描到的新单词的-释义.txt");
//		String text = io.readTextFile(file, "utf-8");
//		ArrayList<String> allLine = cheakDocument.getAllLine(text);
//		StringBuffer sb = new StringBuffer();
//		for(String line:allLine) {
//			if(line.endsWith("->")) {
//				sb.append(line.replace("->", "")+"\n");
//			}
//		}
//		io.writeTextFile(new File(file.toString()+"new.txt"), sb.toString(), "utf-8");
		
		
//		Path dictionaryPath = Paths.get("E:\\download\\coca\\简明英汉字典增强版-去音标.mdx");
//		try {
//			MDictDictionary dictionary = MDictDictionary.loadDictionary(dictionaryPath.toString());
//			
//			
//			for (Map.Entry<String, String> entry: dictionary.readArticlesPredictive("happ")) {
//			    System.out.println( entry.getKey()+" "+ entry.getValue());
//			}
//			int read = System.in.read();
//			
//		} catch (MDException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
//		languageTool.init("chinese-china");
//		String fs = languageTool.getString(68);
//		fs = fs.replace("\\n", "\n");
//		int indexOf = fs.indexOf("\n参数2");
//		System.out.println(indexOf+"\n"+fs);
		
//		System.out.println(HardWareUtils.getCPUSerial()+"\n"+HardWareUtils.getMotherboardSN()+"\n"+HardWareUtils.getMotherboardSN());
//		String[] s = new String[]{"D:\\test\\eclipseWorkspace\\test\\src\\yang\\app\\qt\\black\\Ui_settings.java"};
//		try {
//			Stringtest.main(s);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		String ss = "LOVED THEM TOO;";
//		String s = "FOR JESSICA, WHO LOVES STORIES,FOR ANNE, WHO ";
//		System.out.println(s.length()+" "+s.getBytes().length);
//		
//		
//		String calibrePath = "D:\\Apps\\Unpack\\Calibre\\Calibre Portable\\Calibre\\ebook-convert.exe";
//		File fileword = new File("E:\\download\\coca\\COCA20000.txt1_words");
//		String wordlist = io.readTextFile(fileword, "utf-8");
//		File file = new File("E:\\download\\mobi\\1.mobi");
//		
//		MobiReader reader = new MobiReader();
//		try {
//			MobiDocument doc = reader.read(file);
//			byte[] rawTextContent = doc.getRAWTextContent();
//			System.out.println(rawTextContent.length);
//			String text = MobiByteOffsetFinder.findWordPositionsInRawBytes(rawTextContent, wordlist);
//			io.writeTextFile(new File(file.toString()+"_pos.txt"), text, "utf-8");
//			
////			String words = io.readTextFile(fileword, "utf-8");
////			ArrayList<String> allLine = cheakDocument.getAllLine(words);
////			for(String line:allLine) {
////				byte[] bytes = line.getBytes(StandardCharsets.US_ASCII);
////				
////			}
//			
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
		
		
//		try {
//            CalibreHtmlExtractor extractor = new CalibreHtmlExtractor(calibrePath);
//           
//            System.out.println("开始处理...");
//            System.out.println("Calibre 路径: " + calibrePath);
//            System.out.println("Mobi 文件: " + file.toString());
//            
//            String positions = extractor.findWordPositions(file.toString(), wordlist);
//            
////            System.out.println("找到的词汇位置:");
////            System.out.println(positions);
//            io.writeTextFile(new File(file.toString()+"_wordpos.txt"), positions, "utf-8");
//            
//        } catch (Exception e) {
//            System.err.println("处理过程中出错: " + e.getMessage());
//            e.printStackTrace();
//        }
		
//		CalibreHtmlExtractor.main(new String[] {"D:\\Apps\\Unpack\\Calibre\\Calibre Portable\\Calibre\\ebook-convert.exe", "E:\\download\\mobi\\1.mobi"});
		
//		System.out.println(644501-626005-1);
//		QTextCharFormat tcf = new QTextCharFormat();
//		QTextCharFormat tcf1 = new QTextCharFormat();
//		tcf1.setAnchor(true);
//		String u = "https://img.guangsuimage.com/cover/a833745cd3fec33ab9cf5735c8b9ae36.jpg";
//		byte[] bs = yangIO.getDataFormHttpsURL(u, null);
//		System.out.println();
//		testQT(args,null);
//		System.out.println(cheakDocument.getFileExtensionName("hello.1"));
//		QBrush br = new QBrush();
//		styleInfo si1 = new styleInfo();
//		styleInfo si2 = new styleInfo();
//
//		System.out.println(tcf.equals(tcf1));
//		testQT(args);
		
//		File in = new File("E:\\download\\coca\\60000-short.txt_去重.txt");
//		String text = io.readTextFile(in, "utf-8");
//		ArrayList<String> allLine = cheakDocument.getAllLine(text);
//		WordFormsGenerator tool = WordFormsGenerator.getInstance();
//		StringBuffer sb = new StringBuffer();
//		for(String line:allLine) {
//			sb.append(line+"\n");
//			String[] subString = cheakDocument.subString(line, ",");
//			
//			if(subString[0].length() != line.length() && subString[0].indexOf("-") == -1) {
//				String[] wordForms = tool.getWordForms(subString[0]);
//				for(String w:wordForms) {
//					String[] sub = cheakDocument.subString(w, ",");
//					if(sub[0].length() != w.length()) {
//						sb.append(sub[0]+","+subString[1]+"\n");
//					}
//				}
//			}
//		}
//		
//		io.writeTextFile(new File(in.toPath()+"_变形.txt"), sb.toString(), "utf-8");
		
//		
//		File dir = new File("");

	}
	
	
	public static void testQT(String[] args) {
		QApplication init = QApplication.initialize(args);
//		QTextEdit te = new QTextEdit();
//		String html = io.readTextFile(new File("C:\\Users\\Administrator\\Desktop\\test.html"), "utf-8");
//		te.setHtml(html);
//		te.show();
		QWidget w = new QWidget();
		w.setFont(new QFont("微软雅黑",26));
		QBoxLayout forText = new QBoxLayout(QBoxLayout.Direction.TopToBottom);
		w.setLayout(forText);
		QTextEdit te = new QTextEdit();
		
//		var o = new QObject() {
//			void test() {
//				new bRunnable(100,true,false,false,true) {
//					
//					@Override
//					public void run() {
//						QTextCursor tc = te.textCursor();
//						if(tc.hasSelection()) {
//							int start = tc.selectionStart(),end = tc.selectionEnd();
//							QTextCursor tcstart = new QTextCursor(tc);
//							tcstart.setPosition(start);
//						}
//					}
//				};
//				
//			}
//		};
//		te.selectionChanged.connect(o, "test()");
//		te.cursorPositionChanged.connect(o, "test()");
		Highlighter highlighter = new Highlighter(te);
//		te.setUndoRedoEnabled(false);
//		bUndo bUndo = new bUndo(te);
		String html = io.readTextFile(new File("G:\\Users\\Administrator\\Desktop\\test1.html"), "utf-8");
//		String html = io.readTextFile(new File("C:\\Users\\Administrator\\Desktop\\test.html"), "utf-8");
//		String html = io.readBlackFileByLine(new File("C:\\Users\\Administrator\\Desktop\\test\\Files\\19.black"));
		te.setHtml(html);
		
		
		
//		te.setFrameShape(Shape.NoFrame);
//		
//		QTextCursor tc = te.textCursor();
//		bUndo.donotAddCommand = true;
//		tc.beginEditBlock();
//		tc.insertText("这是测试段落1 This paragraph1 for test\n");
//		tc.insertText("这是测试段落2 This paragraph2 for test\n");
//		tc.insertText("这是测试段落3 This paragraph3 for test\n");
//		tc.select(SelectionType.Document);
//		QTextCharFormat cf = tc.charFormat();
////		cf.setFontPointSize(25);
//		tc.setCharFormat(cf);
//		QTextBlockFormat bf = tc.blockFormat();
//		bf.setTextIndent(50);
//		tc.setBlockFormat(bf);
////		te.undo();
////		te.redo();
//		tc.endEditBlock();
		
		
//		tc.joinPreviousEditBlock();
//		te.undo();
//		tc.select(SelectionType.Document);
//		tc.insertText("te");
//		tc.endEditBlock();
		
		
//		bUndo.donotAddCommand = false;
//		String s = "C:\\Users\\Administrator\\Desktop\\test.html";
//		File file = new File(s);
//		String html = io.readTextFile(file, "utf-8");
//		System.out.println(html);
//		tc.insertHtml(html);
		
		new setTextStyles(te,forText);
		forText.addWidget(te);
		w.show();
		w.setGeometry(0, 40, 400, 500);
		te.setAttribute(WidgetAttribute.WA_DeleteOnClose);
		
		QPushButton but = new QPushButton(w);
		but.setGeometry(10, 10, 50, 20);
		but.setText("close text");
		but.show();
		but.pressed.connect(te, "close()");
		
		
//		QTextDocument doc = te.document();
//		QTextBlock tb = doc.findBlockByNumber(1);
//		System.out.println(tb.text());
//		QTextBlockFormat bff = tb.blockFormat();
//		bff.setLineHeight(150, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value());
//		QTextCursor tcc = new QTextCursor(tb);
//		tcc.setBlockFormat(bff);
//		QAction action = new QAction();
//		action.setShortcut("ctrl+=");
//		action.triggered.connect(bUndo,"undo()");
//		te.addAction(action);
//		QAction action1 = new QAction();
//		action1.setShortcut("ctrl+-");
//		action1.triggered.connect(bUndo, "redo()");
//		te.addAction(action1);

		QAction action2 = new QAction();
		action2.setShortcut("ctrl+/");
		action2.triggered.connect(new QObject() {
			void test() {
//				System.out.println("test");
//				highlighter.zoomvalue = 10;
//				highlighter.rangeChanged();
				te.close();
				te.dispose();
			}
		}, "test()");
		te.addAction(action2);
		
		QApplication.exec();
		QApplication.shutdown();
	}
}
class testText extends QTextEdit{
	
}
