package yang.app.qt.black;

import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.widgets.QAction;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QUndoCommand;
import io.qt.widgets.QUndoStack;

public class bUndo {
	private QUndoStack us;
	private QTextDocument doc;
	private QTextEdit text;
	private undoData undoData;
	static boolean donotAddCommand = false;
	
	bUndo(QTextEdit text){
		this.text = text;
		doc = text.document();
		doc.contentsChange.connect(this, "contentsChange(int,int,int)");
		doc.contentsChanged.connect(this, "contentsChanged()");
		text.cursorPositionChanged.connect(this, "cursorPositionChanged()");
		text.selectionChanged.connect(this, "cursorPositionChanged()");
		
		QAction a0 = new QAction();
		text.addAction(a0);
		a0.setShortcut("ctrl+/");
		a0.triggered.connect(this, "a0()");
		
		us = new QUndoStack(doc);
		us.setActive(true);
	}
	void undo() {
		us.undo();
	}
	void redo() {
		us.redo();
	}
	void a0(){
//		text.clear();
		if(undoData != null)
		System.out.println("curosrposchanged: "+undoData.start +" "+ undoData.end+" "+undoData.text);
	}
	void cursorPositionChanged() {
		if(donotAddCommand) return;
		QTextCursor tc = text.textCursor();
		if(!tc.hasSelection()) {
			tc.movePosition(MoveOperation.PreviousCharacter, MoveMode.KeepAnchor);
		}
		undoData = new undoData(tc.selectionStart(), tc.selectionEnd(),tc.selectedText(), tc.selection().toHtml());
	}
	void contentsChange(int pos,int removed,int added) {
		if(donotAddCommand) return;
		String remove = "";
		String add = "";
		undoData removedata = null;
		undoData addeddata = null;
		if(undoData != null && removed > 0) {
			remove = undoData.start+" "+undoData.end+" 删除了："+undoData.text;
			removedata = undoData;
		}
		if(added > 0) {
			QTextCursor tc = text.textCursor();
			int start = pos;
			int end = pos+added;
//			if(undoData != null) {
//				if(undoData.start >= start && undoData.end <= end) {
//					 start = pos+1;
//				}
//			}
			tc.setPosition(start);
			tc.setPosition(end, MoveMode.KeepAnchor);
			addeddata = new undoData(start, end, tc.selectedText(), tc.selection().toHtml());
			add = tc.selectionStart()+" "+tc.selectionEnd()+" 添加了："+tc.selectedText();
		}
		System.out.println(remove+" "+add);
		
		undoCommand uc = new undoCommand(text,removedata, addeddata);
		uc.donotRedoUndo = true;
		us.push(uc);
		uc.donotRedoUndo = false;
		
		undoData = null;
	}
	void contentsChanged() {

	}
}
class undoData{
	int start=-1,end=-1;
	String context = null;
	static String text = null;
	public undoData(int start,int end,String text,String context) {
		this.start = start;
		this.end = end;
		this.text = text;
		this.context = context;
	}
}
class undoCommand extends QUndoCommand{
	undoData removedata;
	undoData addeddata;
	boolean donotRedoUndo;
	static QTextEdit text;
	public undoCommand(QTextEdit text,undoData removed,undoData added) {
		this.text = text;
		removedata = removed;
		addeddata = added;
	}
	@Override
	public void redo() {
		// TODO Auto-generated method stub
		super.redo();
		if(donotRedoUndo) return;
		System.out.println("redo");
		bUndo.donotAddCommand = true;
		QTextCursor tc = text.textCursor();
		tc.beginEditBlock();
		if(removedata != null) {
			tc.setPosition(removedata.start);
			tc.setPosition(removedata.end, MoveMode.KeepAnchor);
			tc.deleteChar();
		}
		if(addeddata != null) {
			tc.setPosition(addeddata.start);
			tc.setPosition(addeddata.end, MoveMode.KeepAnchor);
			tc.insertHtml(addeddata.context);
		}

		tc.endEditBlock();
		text.setTextCursor(tc);
		text.ensureCursorVisible();
		bUndo.donotAddCommand = false;
	}
	@Override
	public void undo() {
		// TODO Auto-generated method stub
		super.undo();
		if(donotRedoUndo) return;
		System.out.println("undo");
		bUndo.donotAddCommand = true;
		QTextCursor tc = text.textCursor();
		tc.beginEditBlock();
		if(addeddata != null) {
			tc.setPosition(addeddata.start);
			tc.setPosition(addeddata.end, MoveMode.KeepAnchor);
			tc.deleteChar();
		}
		if(removedata != null) {
			tc.setPosition(removedata.start);
			tc.setPosition(removedata.end, MoveMode.KeepAnchor);
			tc.insertHtml(removedata.context);
		}
		
		tc.endEditBlock();
		text.setTextCursor(tc);
		text.ensureCursorVisible();
		bUndo.donotAddCommand = false;
	}
}