package yang.app.qt.black;

import java.io.File;
import java.util.ArrayList;

import io.qt.core.QLocale;

public class languageTool {
	private static ArrayList<String> allLine = new ArrayList<String>();
	public static void init(String languageName){
		File file = new File("."+File.separator+"Languages"+File.separator+languageName);
		//如果找不到指定的语言文件，则使用简体中文
		if(!file.exists()) file = new File("."+File.separator+"Languages"+File.separator+"简体中文-中国-zh_CN");
		String text = io.readTextFile(file, "utf-8");
		int subStart = -1;
		for(int i=0;i<text.length();i++) {
			String line = null;
			char charAt = text.charAt(i);
			if(charAt == ' ') {
				//判断空格前面是否是数字
				if(i > 0) {
					int lastIndexOf = text.lastIndexOf('\n', i);
					String substring = null;
					if(lastIndexOf != -1) {
						substring = text.substring(lastIndexOf+1,i);
						if(substring != null && cheakDocument.isAllNumber(substring)) {
							if(subStart != -1) {
								line = text.substring(subStart, lastIndexOf);
								allLine.add(line);
							}
							subStart = lastIndexOf+1;
						}
					}else {
						substring = text.substring(0,i);
						if(substring != null && cheakDocument.isAllNumber(substring)) {
							subStart = 0;
						}

					}
				}
			}
		}
		allLine.add(text.substring(subStart, text.length()));

	}
	/**查找并返回给定序号的文本
	 * 如果没有查找到文本，返回null
	 * @param number
	 * @return
	 */
	public static String getString(int number) {
		if(allLine.size() == 0) {
			String lang = black.getStringValueFromSettings(appInfo.uiLang, "0");
			if(lang.equals("0")) {
				QLocale system = QLocale.system();
				String name = system.name();
				System.out.println("操作系统的语言-地区为: "+ name);
				String[] uiLanguages = bAction.getUiLanguages(false);
				for(String l:uiLanguages) {
					TextRegion sub = cheakDocument.subStringReverse(l, l.length(), "-");
					if(sub != null) {
						if(sub.text.equals(name)) {
							lang = l;
							break;
						}
					}
				}
				//没有匹配到与当前系统的语言-地区相同的语言文件，则忽略地区，只对语言进行匹配
				if(lang.equals("0")) {
					System.out.println("尚未匹配到与操作系统的语言-地区相一致的语言文件，将只匹配操作系统的语言，忽略操作系统的地区");
					String[] language = cheakDocument.subString(name, "_");
					System.out.println("操作系统的语言为: "+ language[0]);

					for(String l:uiLanguages) {
						TextRegion sub = cheakDocument.subStringReverse(l, l.length(), "-");
						if(sub != null) {
							if(sub.text.equals(language[0])) {
								lang = l;
								break;
							}
						}
					}
				}
			}
			
			//如果既没有查找到与操作系统的语言-地区或仅语言匹配的语言文件，则使用英文语言
			if(lang.equals("0")) lang = "English-en";
			
			init(lang);
		}
		for(String str:allLine) {
			String[] subString = cheakDocument.subString(str, " ");
			if(!subString[1].isEmpty() && subString[0].equals(String.valueOf(number))) {
				String s = subString[1].replace("\\n", "\n");
				s = s.replace("\\t", "\t");
				return s;
			}
		}
		System.out.println("未查找到该编号所对应的语言文件："+number);
		return null;
	}
	/**
	 * 如果没有查找到给定序号的文本，返回null；如果查找到的给定序号的文本没有包含给定的替换参数，则返回原始文本，否则返回替换参数后的文本
	 * @param number
	 * @param args1
	 * @return
	 */
	public static String getString(int number,Object args1) {
		String str = getString(number);
		if(str != null) {
			str = str.replace("$1", args1.toString());
		}
		return str;
	}
	public static String getString(int number,Object args1,Object args2) {
		String str = getString(number, args1);
		if(str != null) str = str.replace("$2", args2.toString());
		return str;
	}
	public static String getString(int number,Object args1,Object args2,Object args3) {
		String str = getString(number,args1,args2);
		if(str != null) return str.replace("$3", args3.toString());
		return str;
	}
	public static String getString(int number,Object args1,Object args2,Object args3,Object args4) {
		String str = getString(number,args1,args2,args3);
		if(str != null) return str.replace("$4", args4.toString());
		return str;
	}
}
