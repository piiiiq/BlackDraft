package yang.app.qt.black;

import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.Qt.CursorShape;
import io.qt.core.Qt.FocusPolicy;
import io.qt.core.Qt.GlobalColor;
import io.qt.gui.QColor;
import io.qt.gui.QCursor;
import io.qt.gui.QFont;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QPaintEvent;
import io.qt.gui.QPainter;
import io.qt.gui.QPalette;
import io.qt.gui.QPalette.ColorRole;
import io.qt.widgets.QApplication;
import io.qt.widgets.QLabel;

public class getKey extends QLabel{
	int keycode;
	String modifierKey;
	String keyText = "";
	String tip = languageTool.getString(1386);
	public getKey() {
		setFocusPolicy(FocusPolicy.StrongFocus);
		setAutoFillBackground(true);
		clearKey();
		installEventFilter(this);
		setContentsMargins(5, 5, 5, 5);
		QFont font = font();
		font.setPointSize(10);
		setFont(font);
	}
	@Override
	protected void paintEvent(QPaintEvent arg__1) {
		// TODO Auto-generated method stub
		QPainter p = new QPainter(this);
		p.begin(this);
		if(hasFocus()) {
			p.setPen(new QColor(GlobalColor.black));
			p.drawRect(contentsRect());
		}
		p.end();
		super.paintEvent(arg__1);
	}
	/**
	 * 返回是否输入了有效的按键
	 * 遗下类型被判断为无效：
	 * 1没有输入任何按键；
	 * 2输入的按键只包含修饰键
	 * @return
	 */
	public boolean isHasKey() {
		if(text() == null || text().isEmpty() || text().equals(tip) || keyboard.onlyHasModifier(text()))return false;
		else return true;
	}
	public void clearKey() {
		QPalette p = palette();
		p.setColor(ColorRole.WindowText, new QColor(GlobalColor.darkCyan));
		p.setColor(backgroundRole(), new QColor(GlobalColor.white));
		setPalette(p);
		super.clear();
		setText(tip);
	}
	@Override
	public boolean eventFilter(QObject watched, QEvent event) {
		// TODO Auto-generated method stub
		if(event.type() == QEvent.Type.KeyPress) {
			QKeyEvent k = (QKeyEvent) event;
			modifierKey = keyboard.getModifierKeyName(k);
			keyText = keyboard.getKeyName(k);
			keycode = k.key();
			setText(keyText);
			QPalette p = palette();
			p.setColor(ColorRole.WindowText, new QColor(GlobalColor.black));
			setPalette(p);
			return true;
		}
//		else if(event.type() == QEvent.Type.HoverEnter) {
//			if(QApplication.overrideCursor() == null)QApplication.setOverrideCursor(new QCursor(CursorShape.IBeamCursor));
//		}else if(event.type() == QEvent.Type.HoverLeave) {
//			if(QApplication.overrideCursor() != null)QApplication.restoreOverrideCursor();
//		}
		return super.eventFilter(watched, event);
	}
}
