package yang.app.qt.black;

import java.util.List;

import io.qt.core.QPoint;
import io.qt.core.QRect;
import io.qt.core.QTimer;
import io.qt.gui.QSyntaxHighlighter;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextFormat;
import io.qt.gui.QTextLayout;
import io.qt.widgets.QTextEdit;

public class FontSizeHighlighter extends QSyntaxHighlighter {
    private QTextEdit textEdit;
    private double scaleFactor;
    private QTimer updateTimer = new QTimer();

    public FontSizeHighlighter(QTextEdit parent, double scaleFactor) {
        super(parent.document());
        this.textEdit = parent;
        this.scaleFactor = scaleFactor;

        // 连接滚动信号以在滚动时更新高亮
        parent.verticalScrollBar().valueChanged.connect(this, "scheduleHighlightUpdate()");
        parent.horizontalScrollBar().valueChanged.connect(this, "scheduleHighlightUpdate()");

        // 使用定时器来合并频繁的更新请求
        updateTimer.setSingleShot(true);
        updateTimer.setInterval(50);
        updateTimer.timeout.connect(this, "rehighlightVisibleArea()");
    }

    public void setScaleFactor(double factor) {
        if (Math.abs(scaleFactor - factor) < 0.001) {
            return;
        }
        
        scaleFactor = factor;
        scheduleHighlightUpdate();
    }

    public double scaleFactor() {
        return scaleFactor;
    }

    @Override
    protected void highlightBlock(String text) {
        // 获取当前块的所有字符格式范围
        QTextBlock block = currentBlock();
        QTextBlockFormat blockFormat = block.blockFormat();
        List<QTextLayout.FormatRange> formatRanges = block.textFormats();

        // 如果没有特定格式范围，为整个块创建一个默认格式
        if (formatRanges.isEmpty()) {
            QTextCharFormat format = new QTextCharFormat();
            format.setFont(textEdit.font());
            format.setProperty(QTextFormat.Property.FontSizeAdjustment.value(), scaleFactor);
            setFormat(0, text.length(), format);
        } else {
            // 为每个格式范围调整字号
            for (QTextLayout.FormatRange range : formatRanges) {
                QTextCharFormat newFormat = range.format();
                // 保留原有字体属性，只调整字号
                double originalSize = newFormat.font().pointSizeF();
                if (originalSize <= 0) {
                    originalSize = textEdit.font().pointSizeF();
                }
                newFormat.setFontPointSize(originalSize * scaleFactor);
                setFormat(range.start(), range.length(), newFormat);
            }
        }
    }

    private void scheduleHighlightUpdate() {
        updateTimer.start();
    }

    private void rehighlightVisibleArea() {
        // 获取可见区域的文本块范围
        QTextCursor cursor = new QTextCursor(textEdit.document());
        QRect viewportRect = textEdit.viewport().rect();
        
        // 获取第一个可见块
        cursor.setPosition(textEdit.cursorForPosition(new QPoint(0, 0)).position());
        int firstVisibleBlock = cursor.blockNumber();
        
        // 获取最后一个可见块
        cursor.setPosition(textEdit.cursorForPosition(new QPoint(0, viewportRect.height())).position());
        int lastVisibleBlock = cursor.blockNumber();
        
        // 扩展一些块作为缓冲区
        firstVisibleBlock = Math.max(0, firstVisibleBlock - 5);
        lastVisibleBlock = Math.min(document().blockCount() - 1, lastVisibleBlock + 5);
        
        // 仅重新高亮可见区域
        QTextBlock block = document().findBlockByNumber(firstVisibleBlock);
        while (block.isValid() && block.blockNumber() <= lastVisibleBlock) {
            rehighlightBlock(block);
            block = block.next();
        }
    }
}