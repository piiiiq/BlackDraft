package yang.app.qt.black;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import io.qt.core.Qt.FindChildOption;
import io.qt.widgets.QAction;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QSizePolicy.Policy;
import io.qt.widgets.QSpacerItem;
import io.qt.widgets.QTreeWidget;
import io.qt.widgets.QTreeWidgetItem;
import io.qt.widgets.QWidget;

public class setKeys extends QWidget{
	private getKey getKey;
	keyboard kb;
	private QTreeWidget tree;
	private QLineEdit serach;
	private QPushButton serachButton;
	black b;
	private QPushButton resetKey;
	String resetButtonText = languageTool.getString(309);
	private QPushButton removeKey;
	private QPushButton addNewKey;
	int spaceItemWidth = 25,spaceItemHeight = 10;
	public setKeys(keyboard kb,black b) {
		this.kb = kb;
		this.b = b;
		QBoxLayout bl = uiTool.getBoxLayout(0);
		setLayout(bl);
		tree = new QTreeWidget(this);
		tree.itemSelectionChanged.connect(this, "selectionChanged()");
		ArrayList<String> al = new ArrayList<String>();
		al.add(languageTool.getString(310));
		al.add(languageTool.getString(311));
		al.add(languageTool.getString(312));
		al.add(languageTool.getString(313));
		tree.setHeaderLabels(al);
		
		QBoxLayout tree_layout = uiTool.getBoxLayout(0);
		bl.addLayout(tree_layout);
		serach = new QLineEdit(this);
		serach.setPlaceholderText(languageTool.getString(314));
		serach.textChanged.connect(this, "textChanged()");
		
		QBoxLayout serach_layout = uiTool.getBoxLayout(2);
		tree_layout.addLayout(serach_layout);
		serach_layout.addWidget(serach);
		serachButton = uiTool.getQPushButton(languageTool.getString(315), this, "listKeyData()");
		serach_layout.addWidget(serachButton);
		tree_layout.addWidget(tree);
		QBoxLayout setKey = uiTool.getBoxLayout(2);
		bl.addLayout(setKey);
		getKey = new getKey();
		setKey.addWidget(getKey);
		setKey.addSpacerItem(new QSpacerItem(spaceItemWidth, spaceItemHeight));
		
		QPushButton ok = uiTool.getQPushButton(languageTool.getString(316), this, "ok()");
		setKey.addWidget(ok);
		resetKey = uiTool.getQPushButton(resetButtonText, this, "resetKey()");
		setKey.addWidget(resetKey);
		resetKey.setEnabled(false);
		setKey.addSpacerItem(new QSpacerItem(spaceItemWidth, spaceItemHeight));

		
		addNewKey = uiTool.getQPushButton(languageTool.getString(317), this, "addNewKey()");
		addNewKey.setEnabled(false);
		setKey.addWidget(addNewKey);
		removeKey = uiTool.getQPushButton(languageTool.getString(318), this, "removeKey()");
		setKey.addWidget(removeKey);
		removeKey.setEnabled(false);
		
		setKey.addSpacerItem(new QSpacerItem(spaceItemWidth, spaceItemHeight));

		QPushButton keyToInputText = uiTool.getQPushButton(languageTool.getString(319), this, "addKeyToInputText()");
		setKey.addWidget(keyToInputText);

		
		
		listKeyData();
	}

	public void addNewKey() {
		QTreeWidgetItem item = tree.selectedItems().get(0);
		keyLink data = (keyLink) item.data(0, 9);
		if(!getKey.isHasKey() || getKey.keyText.equals(data.getKeyText())) {
			b.getMessageBox(languageTool.getString(320), languageTool.getString(321));
			getKey.clearKey();
			return;
		}
		if(b.ba.keyboard.isHasKey(getKey.keyText, data.selectionText))return;
		
		
		if(data.keytype == 0) {
			key k = null;
			if(data.k == null) k = (key) data;
			else k = data.k;
			keyLink keyLink = new keyLink(getKey.modifierKey,getKey.keycode,data.context,data.type,k,data.selectionText);
			b.ba.keyboard.addKey(-1, keyLink);
			QTreeWidgetItem twi = new QTreeWidgetItem(tree);
			twi.setText(0, b.ba.keyboard.keys.size()+keyLink.index+"");
			twi.setText(1, keyLink.getAllText(false));
			twi.setText(2, keyLink.getKeyText(keyLink.defaultKey, keyLink.defaultKeycode));
			twi.setText(3, keyLink.info);
			twi.setData(0, 9, keyLink);
			tree.addTopLevelItem(twi);
			tree.scrollToItem(twi);
			b.ba.keyboard.saveAppKeyData();
			b.getMessageBox(languageTool.getString(322), languageTool.getString(323,keyLink.info,keyLink.getKeyText()));
			getKey.clearKey();
		}else if(data.keytype == 1) {
			key k = null;
			if(data.k == null) k = (key) data;
			else k = data.k;
			keyLink keyLink = new keyLink(getKey.modifierKey,getKey.keycode,data.context,data.type,k,data.selectionText);
			keyLink.keytype = 1;
			b.ba.keyboard.addKey(-1, keyLink);
			QTreeWidgetItem twi = new QTreeWidgetItem(tree);
			twi.setText(0, b.ba.keyboard.keys.size()+keyLink.index+"");
			twi.setText(1, keyLink.getAllText(false));
			twi.setText(2, keyLink.getKeyText(keyLink.defaultKey, keyLink.defaultKeycode));
			String info = languageTool.getString(324,keyLink.info);
			twi.setText(3, info);
			twi.setData(0, 9, keyLink);
			tree.addTopLevelItem(twi);
			tree.scrollToItem(twi);
			b.ba.keyboard.saveProjectKeyData(black.des_doc);
			b.getMessageBox(languageTool.getString(322), languageTool.getString(323,info,keyLink.getKeyText()));
			getKey.clearKey();
		}else if(data.keytype == 5) {
			key k = null;
			if(data.k == null) k = (key) data;
			else k = data.k;
			keyLink keyLink = new keyLink(getKey.modifierKey,getKey.keycode,data.context,data.type,k,data.selectionText);
			keyLink.keytype = 5;
			b.ba.keyboard.addKey(-1, keyLink);
			QTreeWidgetItem twi = new QTreeWidgetItem(tree);
			twi.setText(0, b.ba.keyboard.keys.size()+keyLink.index+"");
			twi.setText(1, keyLink.getAllText(false));
			twi.setText(2, keyLink.getKeyText(keyLink.defaultKey, keyLink.defaultKeycode));
			String info = languageTool.getString(325,keyLink.info);
			twi.setText(3, info);
			twi.setData(0, 9, keyLink);
			tree.addTopLevelItem(twi);
			tree.scrollToItem(twi);
			b.ba.keyboard.saveAppKeyData();
			b.getMessageBox(languageTool.getString(322), languageTool.getString(323,info,keyLink.getKeyText()));
			getKey.clearKey();
		}

		
		
	}
	public void removeKey() {
		List<QTreeWidgetItem> items = tree.selectedItems();
		if(items.size() > 0) {
			QTreeWidgetItem item = items.get(0);
			keyLink data = (keyLink) item.data(0, 9);
			//必须在修改元素之前将其从hashmap中删除，元素修改后因为hashcode发生变化，会导致无法从hashmap中删除
			keyLink remove = b.ba.keyboard.keys_user.remove(data.index);
			int context = remove.context;
			//需要先将context置为-1，才能删除ui中的快捷键文本
			remove.context = -1;
			b.ba.keyboard.setUIKeyText(remove, "");
			remove.context = context;
			if(remove != null) {
				//如果删除的是非程序内置快捷键的定义，则将定义复制到已经存在的第一个引用中（将查找到的第一个引用转变成定义），然后再删除定义
				if(data.keytype != 0) {
					if(data.k == null) {
						Iterator<keyLink> it = b.ba.keyboard.keys_user.values().iterator();
						keyLink kk = null;
						while(it.hasNext()) {
							keyLink next = it.next();
							if(data.equals(next.k)) {
								kk = next;
								next.context = -1;
								it.remove();
								break;
							}
						}
						if(kk != null) {
							data.setKey(kk.key, kk.keycode);
							//下面的语句会导致data context变成-1
//							data.context = kk.context;
							data.defaultKey = kk.defaultKey;
							data.defaultKeycode = kk.defaultKeycode;
							b.ba.keyboard.addKey(kk.index, data);
						}
					}
				}
				int type = data.keytype;
				tree.takeTopLevelItem(tree.indexOfTopLevelItem(item));
				if(type != 1)
					b.ba.keyboard.saveAppKeyData();
				else
					b.ba.keyboard.saveProjectKeyData(black.des_doc);
				b.getMessageBox(languageTool.getString(326), languageTool.getString(327,item.text(1)));
			}else b.getMessageBox(languageTool.getString(326), languageTool.getString(328));
			
			
			
		}
	}
	public void addKeyToInputText() {
		if(!getKey.isHasKey()) {
			b.getMessageBox(languageTool.getString(329), languageTool.getString(330));
			getKey.clearKey();
			return;
		}
		if(b.ba.keyboard.isHasKey(getKey.keyText, false))return;

		InputDialog id = new InputDialog(this,languageTool.getString(331),languageTool.getString(332),false,false,"") {
			
			@Override
			void whenOkButtonPressed() {
				// TODO Auto-generated method stub
				if(copyLineText().isEmpty()) {
					b.getMessageBox(languageTool.getString(329), languageTool.getString(333));
				}else {
					if(!serach.text().isEmpty()){
						serach.clear();
						
					}
					Collection<keyLink> values = b.ba.keyboard.keys.values();
					Iterator<keyLink> it = values.iterator();
					while(it.hasNext()) {
						keyLink next = it.next();
						if(next.keytype == 1) {
							if(next.info.equals(copyLineText())) {
								b.getMessageBox(languageTool.getString(334), languageTool.getString(335,next.index));
								close();
								return;
							}
						}
					}
					keyLink customInputText = addKeys.customInputText(-1,b.ba.keyboard, getKey.modifierKey, getKey.keycode, copyLineText());
					QTreeWidgetItem twi = new QTreeWidgetItem(tree);
					twi.setText(0, b.ba.keyboard.keys.size()+customInputText.index+"");
					twi.setText(1, customInputText.getAllText(false));
					twi.setText(2, customInputText.getAllText(true));
					twi.setText(3, languageTool.getString(336,customInputText.info));
					twi.setData(0, 9, customInputText);
					tree.addTopLevelItem(twi);
					tree.scrollToItem(twi);
					getKey.clearKey();
					b.ba.keyboard.saveProjectKeyData(black.des_doc);
					b.getMessageBox(languageTool.getString(329), languageTool.getString(337,copyLineText(),getKey.keyText));
					close();
				}
			}
			
			@Override
			void whenClose() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			void whenCannelButtonPressed() {
				// TODO Auto-generated method stub
			}
		};
		id.setMessageText(languageTool.getString(338,getKey.keyText));
		id.show();
	}
	public void selectionChanged() {
		getKey.clearKey();
		List<QTreeWidgetItem> items = tree.selectedItems();
		if(items.size() > 0) {
			QTreeWidgetItem it = items.get(0);
			keyLink data = (keyLink) it.data(0, 9);
			if(!data.key.equals(data.defaultKey) || data.keycode != data.defaultKeycode) {
				resetKey.setText(resetButtonText+data.getKeyText(data.defaultKey, data.defaultKeycode));
				resetKey.setEnabled(true);
			}else {
				resetKey.setText(resetButtonText);
				resetKey.setEnabled(false);
			}
			if(data.keytype != 0 || data.k != null) {
				removeKey.setEnabled(true);
			}else removeKey.setEnabled(false);
			addNewKey.setEnabled(true);
			
		}else {
			resetKey.setText(resetButtonText);
			resetKey.setEnabled(false);
			removeKey.setEnabled(false);
			addNewKey.setEnabled(false);
		}
	}
	public void resetKey() {
		setKey(true);
	}
	public void listKeyData() {
		Set<Entry<Integer, keyLink>> entrySet = kb.keys.entrySet();
		Set<Entry<Integer, keyLink>> entrySet_user = kb.keys_user.entrySet();
		tree.clear();
		
		Iterator<Entry<Integer, keyLink>> it = entrySet.iterator();
		Iterator<Entry<Integer, keyLink>> it_user = entrySet_user.iterator();
		
		if(serach.text().isEmpty()) {
			while(it.hasNext()) {
				Entry<Integer, keyLink> next = it.next();
				QTreeWidgetItem twi = new QTreeWidgetItem(tree);
				twi.setText(0, next.getKey()+"");
				keyLink value = next.getValue();
				twi.setText(1, value.getAllText(false));
				twi.setText(2, value.getAllText(true));
				if(next.getValue().keytype != 1)
					twi.setText(3, value.info);
				else twi.setText(3, languageTool.getString(339,value.info));
				twi.setData(0, 9, value);
				tree.addTopLevelItem(twi);
			}
			int index = b.ba.keyboard.getNextIndex(b.ba.keyboard.keys);
			while(it_user.hasNext()) {
				Entry<Integer, keyLink> next = it_user.next();
				QTreeWidgetItem twi = new QTreeWidgetItem(tree);
				twi.setText(0, index+next.getKey()+"");
				keyLink value = next.getValue();
				twi.setText(1, value.getAllText(false));
				twi.setText(2, value.getAllText(true));
				if(next.getValue().keytype  == 0)
					twi.setText(3, value.info);
				else if(next.getValue().keytype  == 1)
					twi.setText(3, languageTool.getString(339,value.info));
				else if(next.getValue().keytype  == 5)
					twi.setText(3, languageTool.getString(340,value.info));
				twi.setData(0, 9, value);
				tree.addTopLevelItem(twi);
			}
		}else {
			while(it.hasNext()) {
				Entry<Integer, keyLink> next = it.next();
				keyLink value = next.getValue();
				if(value.getAllText(false).indexOf(serach.text()) != -1 
						|| value.info.indexOf(serach.text()) != -1
						|| next.getKey().toString().indexOf(serach.text()) != -1
						|| value.getAllText(true).indexOf(serach.text()) != -1) {
					QTreeWidgetItem twi = new QTreeWidgetItem(tree);
					twi.setText(0, next.getKey()+"");
					twi.setText(1, value.getAllText(false));
					twi.setText(2, value.getAllText(true));
					if(next.getValue().keytype != 1)
						twi.setText(3, value.info);
					else twi.setText(3, languageTool.getString(339,value.info));
					twi.setData(0, 9, value);
					tree.addTopLevelItem(twi);
				}
				
			}
			int index = b.ba.keyboard.getNextIndex(b.ba.keyboard.keys);

			while(it_user.hasNext()) {
				Entry<Integer, keyLink> next = it_user.next();
				keyLink value = next.getValue();
				if(value.getAllText(false).indexOf(serach.text()) != -1 
						|| value.info.indexOf(serach.text()) != -1
						|| next.getKey().toString().indexOf(serach.text()) != -1
						|| value.getAllText(true).indexOf(serach.text()) != -1) {
					QTreeWidgetItem twi = new QTreeWidgetItem(tree);
					twi.setText(0, index+next.getKey()+"");
					twi.setText(1, value.getAllText(false));
					twi.setText(2, value.getAllText(true));
					if(next.getValue().keytype  == 0)
						twi.setText(3, value.info);
					else if(next.getValue().keytype  == 1)
						twi.setText(3, languageTool.getString(339,value.info));
					else if(next.getValue().keytype  == 5)
						twi.setText(3, languageTool.getString(340,value.info));
					twi.setData(0, 9, value);
					tree.addTopLevelItem(twi);
				}
				
			}
		}
		
	
	}
	public void textChanged() {
		listKeyData();
	}
	public void ok() {
		setKey(false);
	}
	
	public void setKey(boolean isRest) {
		List<QTreeWidgetItem> selectedItems = tree.selectedItems();
		if(selectedItems.size() == 0) {
			b.getMessageBox(languageTool.getString(341),languageTool.getString(342));
			return;
		}
		QTreeWidgetItem twi = selectedItems.get(0);
		keyLink data = (keyLink) twi.data(0, 9);
		String key1 = null;
		if(isRest) key1 = data.getKeyText(data.defaultKey, data.defaultKeycode);
		else {
			if(!getKey.isHasKey() || getKey.keyText.equals(data.getKeyText())) {
				b.getMessageBox(languageTool.getString(341), languageTool.getString(343));
				getKey.clearKey();
				return;
			}
			key1 = getKey.keyText;
		}

		if(isRest) {
			if(!data.defaultKey.isEmpty() || data.defaultKeycode != -1)
			if(b.ba.keyboard.isHasKey(data.getKeyText(data.defaultKey, data.defaultKeycode), data.selectionText))return;
			String keyText = data.getKeyText();
			data.setKey(data.defaultKey, data.defaultKeycode);
			twi.setText(1, data.getAllText(true));
			if(data.keytype != 1)
				b.ba.keyboard.saveAppKeyData();
			else
				b.ba.keyboard.saveProjectKeyData(black.des_doc);
			b.getMessageBox(languageTool.getString(341), languageTool.getString(344,data.info,data.getKeyText()));
			getKey.clearKey();
			resetKey.setText(resetButtonText);
			resetKey.setEnabled(false);
			b.ba.keyboard.setUIKeyText(data,keyText);
		}else {
			if(b.ba.keyboard.isHasKey(getKey.keyText, data.selectionText))return;
			String keyText = data.getKeyText();
			data.setKey(getKey.modifierKey, getKey.keycode);
			twi.setText(1, data.getAllText(false));
			if(data.keytype != 1)
				b.ba.keyboard.saveAppKeyData();
			else
				b.ba.keyboard.saveProjectKeyData(black.des_doc);
			b.getMessageBox(languageTool.getString(341), languageTool.getString(345,data.info,getKey.keyText));
			getKey.clearKey();
			resetKey.setText(resetButtonText+data.getKeyText(data.defaultKey, data.defaultKeycode));
			if(!b.ba.keyboard.keyTextCompare(getKey.keyText, data.getKeyText(data.defaultKey, data.defaultKeycode)))
				resetKey.setEnabled(true);
			else resetKey.setEnabled(false);
			b.ba.keyboard.setUIKeyText(data,keyText);

		}
		
	}
	
}
