package yang.app.qt.black;

import static yang.app.qt.black.black.text;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import io.qt.core.QByteArray;
import io.qt.core.QEvent;
import io.qt.core.QEvent.Type;
import io.qt.core.QList;
import io.qt.core.QObject;
import io.qt.core.QPoint;
import io.qt.core.QPropertyAnimation;
import io.qt.core.QRect;
import io.qt.core.QRectF;
import io.qt.core.QTimer;
import io.qt.core.QUrl;
import io.qt.core.Qt;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.KeyboardModifier;
import io.qt.core.Qt.KeyboardModifiers;
import io.qt.core.Qt.PenStyle;
import io.qt.core.Qt.WindowType;
import io.qt.widgets.QApplication;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QDialog;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QFont.SpacingType;
import io.qt.gui.QImage;
import io.qt.widgets.QFrame;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QKeySequence;
import io.qt.widgets.QLabel;
import io.qt.widgets.QMenu;
import io.qt.widgets.QProgressBar;
import io.qt.gui.QPainter;
import io.qt.gui.QPalette;
import io.qt.gui.QPen;
import io.qt.widgets.QStyleFactory;
import io.qt.gui.QTextBlock;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.gui.QTextDocument;
import io.qt.widgets.QTextEdit;
import io.qt.widgets.QTreeWidget;
import io.qt.gui.QTextListFormat;
import io.qt.widgets.QTreeWidgetItem;
import io.qt.widgets.QWidget;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QTextEdit.ExtraSelection;
import io.qt.widgets.QAction;
import yang.app.qt.black.appInfo.fontSize;
import yang.demo.allPurpose.debug;
import yang.demo.allPurpose.fileTool;
import yang.demo.allPurpose.httpGet;
import yang.demo.allPurpose.time;

public class blacktext extends QObject {
	bTextEdit text;
	Qt.KeyboardModifiers km = new Qt.KeyboardModifiers(
			new Qt.KeyboardModifier[] { Qt.KeyboardModifier.ControlModifier });
	black b;
	int pos = 0;
	int lastpos = -1;
	int charCountAtToday = -1;
	QTextCursor currentFindCursor;
	boolean doNotScroll;
	boolean doNotSetStyle;
	QLabel timeMessage;
	int lastposFor;
	private int blockNumber;
	private int lastBlockNumber;
	static int typeModeValue = 2;
	float posAtLocationF;
	ArrayList<QTextEdit.ExtraSelection> extraSelection;
	QTreeWidgetItem keywordListFile;
	fileInfo fileInfo;
	int vScrollBarMaxValue;
	long lastposTime;
	long posTime;
	/**
	 * 用来指示3个修饰键是否被按下
	 */
	boolean shiftKeyIsPressed;
	boolean controlKeyIsPressed;
	boolean altKeyIsPressed;
	/**
	 * 滚动条真实的长度
	 */
	int trueMax;
	private long lastScrollTime;

	public blacktext(bTextEdit text, black black) {
		this.text = text;
		fileInfo = black.infoOfCurrentEditing;
//		text.verticalScrollBar().setStyle(new QCleanlooksStyle());
//		text.horizontalScrollBar().setStyle(new QCleanlooksStyle());
		currentFindCursor = text.textCursor();
		this.b = black;
		
		typeModeValue = b.getIntValueFromSettings(appInfo.typeModeValue, "2");
		text.setFrameStyle(QFrame.Shape.NoFrame.value());

		text.textChanged.connect(this, "textchanged()");
		
		text.verticalScrollBar().rangeChanged.connect(this, "r(int,int)");
		
		text.installEventFilter(this);
		text.textChanged.connect(black, "documentTextChanged()");
		text.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);
		text.customContextMenuRequested.connect(this, "addMenu(QPoint)");

		text.setEnabled(false);
		text.cursorPositionChanged.connect(this, "cursorPosChanged()");

		text.selectionChanged.connect(b, "selectionChanged()");
		text.verticalScrollBar().valueChanged.connect(this, "v(int)");
	}

	void v(int v) {
		if(text == null)return;
		b.ba.updateLockTime();
		text.updateCaret(2);
		b.update();
	}
	/**
	 * 增加滚动条的最大值，以便于能够使用打字机卷动功能
	 * @param v
	 * @param v2
	 */
	void r(int v, int v2) {
		if(!text.isVisible())return;
		if(b.isLoadFile)return;
		text.verticalScrollBar().rangeChanged.disconnect(this);

		trueMax = v2;
		if (typeModeValue == 1)
			return;
		int h = text.viewport().rect().height() - this.text.viewport().rect().height() / typeModeValue;
		if (this.text.verticalScrollBar().maximum() == 0) {
			if (this.text.cursorRect().y() >= h) {
				this.text.verticalScrollBar().setMaximum(h);
			}
		} else {
			this.text.verticalScrollBar().setRange(v, v2 + h);
		}
		text.verticalScrollBar().rangeChanged.connect(this, "r(int,int)");
	}

	void m(int m) {
		System.out.println("move: " + m);
	}	

	void moveCaret() {
		QTimer t = new QTimer(this.b);
		t.startTimer(1);
	}
	
	
	void cursorPosChanged() {
		if (this.b.isLoadFile) {
			return;
		}
		if(b.setTextStyles != null)
			b.setTextStyles.cursorPositionChanged();

		text.ensureCursorVisible();

		b.ba.typerMode(b);
		if(!b.noPageLine) b.update();
		
		
		
		b.activeTime = System.currentTimeMillis();
		b.monitorOff = false;
		
		lastposTime = posTime;
		posTime = System.currentTimeMillis();
		long t = posTime-lastposTime;
		if(text.preeditStringPos == -1 && t < 50) {
//			b.debugPrint("光标移动时间间隔"+t+"ms");
			text.caretMoveWithNoAnmiation = true;
		}else text.caretMoveWithNoAnmiation = false;
		
		
		this.lastpos = this.pos;
		QTextCursor tc = this.text.textCursor();
		
		this.pos = tc.position();
		this.lastBlockNumber = this.blockNumber;
		this.blockNumber = tc.blockNumber();
		float posF = pos;
		float charCountF = text.charCountOfDoc();
		posAtLocationF = (posF / charCountF * 100F);
		int posAtLocation = (int) posAtLocationF;
		b.caretPos.setText(pos + "(" + posAtLocation + "%)");
		b.caretPos.show();
		
	
		b.setMarkAndStyle();

		
		
		if(text.preeditStringPos == -1)
		if ((this.b.keywords != null) && (this.b.keywords.isVisible()) && (!this.b.doNotHideKeywordsDialog)) {
			this.b.keywords.hide();
		}
	}

	public void addMenu(QPoint point) {
		if(appInfo.miniMode.equals("1"))return;
		QMenu qm = new QMenu(this.text);
		QFont font = qm.font();
		font.setPointSize(b.ba.getUIFontSize(fontSize.menu));
		qm.setFont(font);
		
		qm.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose);
		
		QAction newFile = new QAction(languageTool.getString(1356));
		newFile.setParent(qm);
		QMenu newFileMenu = new QMenu();
		newFile.setMenu(newFileMenu);

		b.ba.addMenuTo(newFileMenu, languageTool.getString(1357)+b.ba.keyboard.getKeyTextOfSameAppAction(129), "",b.ba,"addFileByEditorMenu_NullFileName()");
		b.ba.addMenuTo(newFileMenu, languageTool.getString(1358)+b.ba.keyboard.getKeyTextOfSameAppAction(78), "",b.ba,"addFileByEditorMenu_NameByDate()");
		
		//需要再次为两个新建文件菜单项设置字号，不知为何不会自动通过parent继承字号
		b.ba.setFontSizeForQObject(newFileMenu, qm.font().pointSize());

		qm.addAction(newFile);

		qm.addSeparator();
		
		QAction undo = b.b.ba.addMenuTo(qm, languageTool.getString(1359)+b.ba.keyboard.getKeyTextOfSameAppAction(23), "", text, "undo()");
		b.b.ba.addMenuTo(qm, languageTool.getString(1360)+b.ba.keyboard.getKeyTextOfSameAppAction(24), "", text, "redo()");
		
		qm.addSeparator();

		QAction copy = new QAction(qm);
		copy.setText(languageTool.getString(1361)+b.ba.keyboard.getKeyTextOfSameAppAction(17));
		copy.triggered.connect(b, "copyText()");
		QAction cut = new QAction(qm);
		cut.setText(languageTool.getString(1362)+b.ba.keyboard.getKeyTextOfSameAppAction(18));
		cut.triggered.connect(b, "cutText()");

		QAction paste = new QAction(qm);
		paste.setText(languageTool.getString(1468)+b.ba.keyboard.getKeyTextOfSameAppAction(342));
		paste.triggered.connect(this.b.ba, "pasteWithFormat()");
		
		QAction pasteWithoutFormat = new QAction(qm);
		pasteWithoutFormat.setText(languageTool.getString(1363)+b.ba.keyboard.getKeyTextOfSameAppAction(19));
		pasteWithoutFormat.triggered.connect(this.b, "pasteWithCurrentFormat()");
		QAction selectAll = new QAction(qm);
		selectAll.setText(languageTool.getString(1364)+b.ba.keyboard.getKeyTextOfSameAppAction(20));
		selectAll.triggered.connect(b.ba, "selectAll()");

		
		qm.addAction(cut);
		qm.addAction(copy);
		qm.addAction(paste);
		qm.addAction(pasteWithoutFormat);
		qm.addSeparator();
		qm.addAction(selectAll);
		qm.addSeparator();

		QAction setTextAsTitle = new QAction(qm);
		setTextAsTitle.setText(languageTool.getString(1365)+b.ba.keyboard.getKeyTextOfSameAppAction(130));
		setTextAsTitle.triggered.connect(this.b, "setFileTitleAsSelectedText()");
		qm.addAction(setTextAsTitle);
		
		QAction findInCurrentDoc = new QAction(qm);
		findInCurrentDoc.setText(languageTool.getString(1366)+b.ba.keyboard.getKeyTextOfSameAppAction(1));
		findInCurrentDoc.triggered.connect(b.ba, "findInCurrentDoc()");
		qm.addAction(findInCurrentDoc);
		
		QAction findInAll = new QAction(qm);
		findInAll.setText(languageTool.getString(1367)+b.ba.keyboard.getKeyTextOfSameAppAction(3));
		findInAll.triggered.connect(b.ba, "findInAllFiles()");
		qm.addAction(findInAll);
		if (this.text.textCursor().selectedText().length() == 0) {
			setTextAsTitle.setEnabled(false);
			findInCurrentDoc.setEnabled(false);
			findInAll.setEnabled(false);
		}
		QAction findInGoldenDict = new QAction(qm);
		findInGoldenDict.setText(languageTool.getString(1368)+b.ba.keyboard.getKeyTextOfSameAppAction(52));
		findInGoldenDict.triggered.connect(this.b, "findInGoldenDict()");
		qm.addAction(findInGoldenDict);

		QAction isSetTitleStyle = new QAction(qm);
		isSetTitleStyle.setCheckable(true);
		if (this.b.infoOfCurrentEditing.isKeyWordsList) {
			isSetTitleStyle.setEnabled(false);
		} else if (this.b.infoOfCurrentEditing.setTitleStyle) {
			isSetTitleStyle.setChecked(true);
		} else {
			isSetTitleStyle.setChecked(false);
		}
		QAction h = new QAction(qm);
		h.setCheckable(true);
		if (this.b.infoOfCurrentEditing.isKeyWordsList) {
			h.setEnabled(false);
		} else if (this.b.infoOfCurrentEditing.showMark) {
			h.setChecked(true);
		} else {
			h.setChecked(false);
		}
		h.setText(languageTool.getString(1369)+b.ba.keyboard.getKeyTextOfSameAppAction(131));
		h.triggered.connect(this.b, "setMarkBackground()");
		qm.addAction(h);

		qm.addSeparator();
		QAction resetDocFormat = new QAction(qm);
		resetDocFormat.setText(languageTool.getString(1370)+b.ba.keyboard.getKeyTextOfSameAppAction(132));
		resetDocFormat.triggered.connect(this.b, "resetDocumentFormat()");
		qm.addAction(resetDocFormat);

		QAction resetDocTextLayout = new QAction(qm);
		resetDocTextLayout.setText(languageTool.getString(1371)+b.ba.keyboard.getKeyTextOfSameAppAction(133));
		resetDocTextLayout.triggered.connect(this.b, "resetTextStringLayout()");
		qm.addAction(resetDocTextLayout);
		qm.addSeparator();

		QAction showInExplorer = new QAction(qm);
		showInExplorer.setText(languageTool.getString(1372)+b.ba.keyboard.getKeyTextOfSameAppAction(134));
		showInExplorer.triggered.connect(b, "showInExplorer()");
		qm.addAction(showInExplorer);

		
		if (this.b.infoOfCurrentEditing.editPoints != null) {
			QAction clearWalkList = new QAction(qm);
			clearWalkList.setText(languageTool.getString(1373,this.b.infoOfCurrentEditing.editPoints.size())+b.ba.keyboard.getKeyTextOfSameAppAction(135));
			clearWalkList.triggered.connect(this.b, "clearWalkList()");
			qm.addAction(clearWalkList);
		}
		
		qm.addAction(this.b.ui.commit);
		qm.addAction(this.b.ui.commitAndPush);

		qm.addSeparator();

		QAction openfile = new QAction(qm);
		openfile.setText(languageTool.getString(1375));
		Menu openfileMenu = this.b.listMenuWithTreeWidget(null, "openFileByMenu(QAction)", true);
		openfileMenu.setStyleSheet(this.b.styleSheet());
		openfile.setMenu(openfileMenu);
		qm.addAction(openfile);
		qm.addSeparator();
		
		
		if (black.writingView > 0) {
			QAction act = b.ba.addMenuTo(qm, languageTool.getString(1376)+b.ba.keyboard.getKeyTextOfSameAppAction(70), "", b, "setLightOrDark()");
			qm.insertAction(undo, act);
			if(b.ba.checkBingPicIsEnable()) {
				QAction showBingPicInfo = b.ba.addMenuTo(qm, languageTool.getString(1377)+b.ba.keyboard.getKeyTextOfSameAppAction(136).replace("\t", "/"), "", b.ba, "showBingPicInfo()");
				qm.insertAction(undo, showBingPicInfo);
				QAction disableBingPic = b.ba.addMenuTo(qm, languageTool.getString(1378)+b.ba.keyboard.getKeyTextOfSameAppAction(137), "", b.ba, "setUseBingPic()");
				qm.insertAction(undo, disableBingPic);
			}else if(b.ba.checkIsUsePic()) {
				QAction nextPic = b.ba.addMenuTo(qm, languageTool.getString(1379)+b.ba.keyboard.getKeyTextOfSameAppAction(29), "", b.ba, "changeBackgroundImage()");
				qm.insertAction(undo, nextPic);
				QAction useBingPic = b.ba.addMenuTo(qm, languageTool.getString(1380)+b.ba.keyboard.getKeyTextOfSameAppAction(137), "", b.ba, "setUseBingPic()");
				qm.insertAction(undo, useBingPic);
				QAction disablePic = b.ba.addMenuTo(qm, languageTool.getString(1381)+b.ba.keyboard.getKeyTextOfSameAppAction(138), "", b.ba, "setUsePic()");
				qm.insertAction(undo, disablePic);
			}else {
				QAction usePic = b.ba.addMenuTo(qm, languageTool.getString(1382)+b.ba.keyboard.getKeyTextOfSameAppAction(138), "", b.ba, "setUsePic()");
				qm.insertAction(undo, usePic);
			}
			
			qm.insertSeparator(undo);
			
			QAction a = new QAction(languageTool.getString(1383)+b.ba.keyboard.getKeyTextOfSameAppAction(21), this.text);
			a.triggered.connect(this.b, "exitWritingView()");
			a.setShortcut("ESC");
			qm.addAction(a);

			QAction exit = new QAction(languageTool.getString(1384)+b.ba.keyboard.getKeyTextOfSameAppAction(22), this.text);
			exit.setShortcut("shift+esc");
			exit.triggered.connect(this.b, "exit()");
			qm.addAction(exit);

			qm.addSeparator();
			QAction charcount = new QAction(qm);
			String selectedText = this.text.textCursor().selectedText();
			if (selectedText.length() > 0) {
				charcount.setText(languageTool.getString(1385,selectedText.length() + "/" + this.text.document().characterCount())+b.ba.keyboard.getKeyTextOfSameAppAction(93));
			} else {
				charcount.setText(languageTool.getString(1385,String.valueOf(this.text.document().characterCount()))+b.ba.keyboard.getKeyTextOfSameAppAction(93));
			}
			charcount.triggered.connect(this.b, "showCharCountBox()");
			qm.addAction(charcount);
		}
		qm.popup(this.text.mapToGlobal(point));
		if (this.b.keywords != null) {
			this.b.keywords.scrollBarOfTreeHideing = false;
		}
	}

	void actionForSetTitleStyle(Boolean bool) {
		this.b.infoOfCurrentEditing.setTitleStyle = (!this.b.infoOfCurrentEditing.setTitleStyle);
		new bRunnable(0, true, true, true, true) {
			public void run() {
				blacktext.this.b.btext.resetEditor();
			}
		};
	}

	

	boolean keywordsIsShowing() {
		if ((this.b.keywords != null) && (this.b.keywords.isVisible())) {
			return true;
		}
		return false;
	}

	public boolean eventFilter(QObject o, QEvent e) {
		if ((o.equals(this.text)) && (e.type() == QEvent.Type.KeyPress)) {
			if(text.isReadOnly())return true;
			QKeyEvent keypress = (QKeyEvent) e;
			if(keypress.key() == Qt.Key.Key_Shift.value())
				shiftKeyIsPressed = true;
			else if(keypress.key() == Qt.Key.Key_Control.value())
				controlKeyIsPressed = true;
			else if(keypress.key() == Qt.Key.Key_Alt.value())
				altKeyIsPressed = true;	
			return b.ba.keyboard.checkKey(keypress,0);
			

		}else if(o.equals(this.text) && e.type() == QEvent.Type.KeyRelease) {
			QKeyEvent key = (QKeyEvent) e;
			if(key.key() == Qt.Key.Key_Shift.value())
				shiftKeyIsPressed = false;
			else if(key.key() == Qt.Key.Key_Control.value())
				controlKeyIsPressed = false;
			else if(key.key() == Qt.Key.Key_Alt.value())
				altKeyIsPressed = false;
		}
		else if ((o.equals(this.text)) && (e.type() == QEvent.Type.FocusIn)) {
			this.b.tree.clearSelection();
			if(b.TreeWidgetItemOfCurrentEditing != null)
				this.b.TreeWidgetItemOfCurrentEditing.setSelected(true);
		}
		return false;
	}

	public void a3() {
		int h = this.text.viewport().rect().height() / 2;
		if (this.text.verticalScrollBar().maximum() == 0) {
			if (this.text.cursorRect().y() >= h) {
				this.text.verticalScrollBar().setMaximum(h);
			}
		}
	}

	public void textchanged() {
		vScrollBarMaxValue = text.verticalScrollBar().maximum();
		scroll();
		this.b.lastInputTime_long = time.getCurrentTime_long();
	}

	public void scroll() {
		if (this.doNotScroll || typeModeValue == 1 || b.isLoadFile || text.preeditStringPos != -1 || text.inputing) {
			return;
		}
//		if(text.textCursor().atStart() || text.textCursor().atEnd())return;
		QTextBlockFormat tbf = this.text.textCursor().blockFormat();
		int i = (int) (tbf.lineHeight() - tbf.topMargin() - tbf.bottomMargin()
				- (this.text.font().weight() - text.highlighter.zoomvalue) / typeModeValue);
		if (this.text.cursorRect().y() >= this.text.viewport().rect().height() / typeModeValue) {
			int h = this.text.cursorRect().y() - this.text.viewport().rect().height() / typeModeValue;
			int newtop = this.text.verticalScrollBar().value() + h - i;
//			this.text.verticalScrollBar().setValue(newtop);
			scrollWithAnimation(newtop);
		} else {
			int h = this.text.viewport().rect().height() / typeModeValue - this.text.cursorRect().y();
			int newtop = this.text.verticalScrollBar().value() - h - i;
//			this.text.verticalScrollBar().setValue(newtop);
			scrollWithAnimation(newtop);
		}
	}
	void scrollWithAnimation(int endValue) {
		Long last = System.currentTimeMillis()-lastScrollTime;
		int animationTime = b.getAnimationTime();
		if(last < b.getAnimationTime()) animationTime = 0;
		int value = text.verticalScrollBar().value();
		b.setAnimation(text.verticalScrollBar(), "value", value, endValue, animationTime);
		lastScrollTime = System.currentTimeMillis();
	}
	public void addList() {
		QTextListFormat listformat = new QTextListFormat();
		listformat.setStyle(QTextListFormat.Style.ListDecimal);
		this.text.textCursor().insertList(listformat);
	}



//	void applyEditorColor() {
//		QPalette background = this.text.palette();
//
//		QPalette qPalette = this.text.palette();
//		this.text.setPalette(qPalette);
//		if (!this.b.getBooleanValueFromSettings(appInfo.focusMode, "false")) {
//			QColor bc = null;
//			QColor fc = null;
//			int whatColor = b.getIntValueFromSettings(appInfo.editorColor, "0");
//			if (whatColor < 2) {
//				bc = b.withoutBlueColor(new QColor(Qt.GlobalColor.white), b.withoutBuleValue);
//				fc = b.withoutBlueColor(new QColor(Qt.GlobalColor.black), b.withoutBuleValue);
//			} else {
//				bc = new QColor(51, 51, 51);
//				fc = new QColor(238, 238, 238);
//			}
//
//			background.setColor(QPalette.ColorRole.Base, bc);
//			background.setColor(QPalette.ColorRole.Text, fc);
//			this.text.setPalette(background);
////			QPalette pb = this.b.palette();
////			pb.setColor(QPalette.ColorRole.Window, bc);
////			pb.setColor(QPalette.ColorRole.WindowText, fc);
////			this.b.setPalette(pb);
//		}
//		this.text.verticalScrollBar().setStyleSheet("");
//		this.text.horizontalScrollBar().setStyleSheet("");
//	}

	void J() {
		this.b.bInsertText(this.text, "“", -1, false);
	}

	void K() {
		this.b.bInsertText(this.text, "”", -1, false);
	}

	

	
	

	String findNext(String style) {
		List<String> keys = QStyleFactory.keys();
		for (int i = 0; i < keys.size(); i++) {
			String string = ((String) keys.get(i)).toLowerCase();
			if (style.equals(string)) {
				if (i + 1 < keys.size()) {
					return (String) keys.get(i + 1);
				}
				return (String) keys.get(0);
			}
		}
		return null;
	}

	void ttt() {
		String objectName = QApplication.style().objectName();
		String lowerCase = objectName.toLowerCase();
		String findNext = findNext(lowerCase);
		if (findNext != null) {
			QApplication.setStyle(findNext);
		}
	}

	void testtts() {
		this.text.hide();
	}

	void moveUp() {
		QKeyEvent key = new QKeyEvent(Type.KeyPress, Qt.Key.Key_Up.value(),
				new KeyboardModifiers(Qt.KeyboardModifier.NoModifier));
		QApplication.postEvent(text, key);

	}

	void moveDown() {
		QKeyEvent key = new QKeyEvent(Type.KeyPress, Qt.Key.Key_Down.value(),
				new KeyboardModifiers(Qt.KeyboardModifier.NoModifier));
		QApplication.postEvent(text, key);
	}

	void moveLeft() {
		QKeyEvent key = new QKeyEvent(Type.KeyPress, Qt.Key.Key_Left.value(),
				new KeyboardModifiers(Qt.KeyboardModifier.NoModifier));
		QApplication.postEvent(text, key);

	}

	void moveRight() {
		QKeyEvent key = new QKeyEvent(Type.KeyPress, Qt.Key.Key_Right.value(),
				new KeyboardModifiers(Qt.KeyboardModifier.NoModifier));
		QApplication.postEvent(text, key);
	}

	void t3() {
		b.getMessageBox("", "");
	}
	
	public void resetEditor() {
		String content = black.text.toPlainText();
		dataForOpenedFile openedfile = this.b.findInOpenedFiles(this.b.infoOfCurrentEditing.fileName);
		QTreeWidgetItem treeWidgetItemOfCurrentEditing = this.b.TreeWidgetItemOfCurrentEditing;
		this.b.changedFileOfCurrentEdit();
		openedfile.editor.text.dispose();
		openedfile.editor.text = null;
		openedfile.editor = null;
		openedfile.content = content;
		
		this.b.openFileByTreeItem(treeWidgetItemOfCurrentEditing);
	}

//	public void addShortcut(QObject o, QKeySequence key, String mothedname) {
//		QAction a = new QAction(this.text);
//		a.setShortcut(key);
//		a.triggered.connect(o, mothedname);
//		this.text.addAction(a);
//	}
	
	

	
}
