package yang.app.qt.black;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobiByteOffsetFinder {

    /**
     * 在原始Mobi HTML字节数组中查找词汇位置
     * @param htmlBytes 原始HTML字节数组（包含所有标签、转义字符等）
     * @param wordList 要查找的词汇列表，每行一个词
     * @return 每行包含"词汇,字节偏移量"的字符串
     */
    public static String findWordPositionsInRawBytes(byte[] htmlBytes, String wordList) {
        // 解析要查找的词汇列表
        Set<String> targetWords = new HashSet<>();
        String[] lines = wordList.split("\\r?\\n");
        for (String line : lines) {
            String word = line.trim();
            if (!word.isEmpty()) {
                targetWords.add(word.toLowerCase());
            }
        }

        if (targetWords.isEmpty()) {
            return "";
        }

        List<String> results = new ArrayList<>();
        String fullHtml = new String(htmlBytes, StandardCharsets.UTF_8);
        
        try {
            // 1. 首先在body标签内搜索（这是WordDumb的做法）
            Pattern bodyPattern = Pattern.compile(
                "<body[^>]*>(.*?)</body>", 
                Pattern.DOTALL | Pattern.CASE_INSENSITIVE
            );
            
            Matcher bodyMatcher = bodyPattern.matcher(fullHtml);
            
            while (bodyMatcher.find()) {
                int bodyStart = bodyMatcher.start(1); // body内容开始位置（字符偏移）
                String bodyContent = bodyMatcher.group(1);
                
                // 2. 在body内容中查找文本节点
                processBodyContent(bodyContent, bodyStart, htmlBytes, targetWords, results);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
        
        return String.join("\n", results);
    }

    /**
     * 处理body内容，查找文本节点中的词汇
     */
    private static void processBodyContent(String bodyContent, int bodyStartOffset, 
                                         byte[] htmlBytes, Set<String> targetWords, 
                                         List<String> results) {
        // 匹配文本节点（位于>和<之间的内容）
        Pattern textPattern = Pattern.compile(">([^<]+)<");
        Matcher textMatcher = textPattern.matcher(bodyContent);
        
        while (textMatcher.find()) {
            String textNode = textMatcher.group(1); // 文本内容（可能包含HTML转义）
            int textStartInBody = textMatcher.start(1); // 在body中的字符偏移
            
            // 计算在完整HTML中的字符偏移
            int textStartInFullHtml = bodyStartOffset + textStartInBody;
            
            // 处理文本节点中的词汇
            processTextNode(textNode, textStartInFullHtml, htmlBytes, targetWords, results);
        }
    }

    /**
     * 处理单个文本节点，查找其中的词汇
     */
    private static void processTextNode(String textNode, int textStartOffset, 
                                      byte[] htmlBytes, Set<String> targetWords, 
                                      List<String> results) {
        // 处理HTML转义字符（但保持原始字节计算）
        String unescapedText = unescapeHtml(textNode);
        
        // 简单的分词（按空格分割）
        String[] words = unescapedText.split("\\s+");
        int currentCharPosition = 0;
        
        for (String word : words) {
            if (word.isEmpty()) continue;
            
            String cleanWord = cleanWord(word);
            if (cleanWord.isEmpty()) continue;
            
            // 检查是否是目标词汇
            if (targetWords.contains(cleanWord.toLowerCase())) {
                // 找到词汇在未转义文本中的位置
                int wordPosInText = unescapedText.indexOf(word, currentCharPosition);
                if (wordPosInText == -1) {
                    currentCharPosition += word.length() + 1;
                    continue;
                }
                
                // 计算在完整HTML中的字符位置
                int wordCharOffset = textStartOffset + wordPosInText;
                
                // 关键步骤：计算字节偏移量
                int byteOffset = calculateByteOffset(htmlBytes, wordCharOffset, word);
                
                if (byteOffset != -1) {
                    results.add(cleanWord + "," + byteOffset);
                }
            }
            
            currentCharPosition += word.length() + 1;
        }
    }

    /**
     * 计算词汇的精确字节偏移量
     */
    private static int calculateByteOffset(byte[] htmlBytes, int charOffset, String word) {
        try {
            // 方法1：直接计算前charOffset个字符的字节长度
            // 这是最准确的方法，与WordDumb保持一致
            String prefix = new String(htmlBytes, 0, charOffset, StandardCharsets.UTF_8);
            return prefix.getBytes(StandardCharsets.UTF_8).length;
            
        } catch (Exception e) {
            // 方法2：备选方案 - 逐字符计算
            return calculateOffsetByChars(htmlBytes, charOffset);
        }
    }

    /**
     * 备选方法：通过逐字符计算字节偏移量
     */
    private static int calculateOffsetByChars(byte[] htmlBytes, int charOffset) {
        int byteCount = 0;
        int charCount = 0;
        int index = 0;
        
        while (charCount < charOffset && index < htmlBytes.length) {
            // 解码UTF-8字符
            int charLength = getUtf8CharLength(htmlBytes, index);
            byteCount += charLength;
            charCount++;
            index += charLength;
        }
        
        return byteCount;
    }

    /**
     * 获取UTF-8字符的字节长度
     */
    private static int getUtf8CharLength(byte[] bytes, int start) {
        byte firstByte = bytes[start];
        if ((firstByte & 0x80) == 0) {
            return 1; // ASCII字符
        } else if ((firstByte & 0xE0) == 0xC0) {
            return 2; // 2字节UTF-8
        } else if ((firstByte & 0xF0) == 0xE0) {
            return 3; // 3字节UTF-8
        } else if ((firstByte & 0xF8) == 0xF0) {
            return 4; // 4字节UTF-8
        }
        return 1; // 默认
    }

    /**
     * 清理词汇（移除标点符号）
     */
    private static String cleanWord(String word) {
        return word.replaceAll("^[^\\w]+|[^\\w]+$", "").toLowerCase();
    }

    /**
     * 处理HTML转义字符
     */
    private static String unescapeHtml(String text) {
        return text.replace("&amp;", "&")
                  .replace("&lt;", "<")
                  .replace("&gt;", ">")
                  .replace("&quot;", "\"")
                  .replace("&apos;", "'")
                  .replace("&nbsp;", " ")
                  .replace("&#160;", " ")
                  .replace("&#xA0;", " ");
    }

    /**
     * 测试方法
     */
    public static void main(String[] args) {
        // 示例：模拟原始HTML字节数组
        String sampleHtml = "<html><body><p>This is a test with important words.</p></body></html>";
        byte[] htmlBytes = sampleHtml.getBytes(StandardCharsets.UTF_8);
        
        String wordList = "test\nwords\nimportant";
        
        String result = findWordPositionsInRawBytes(htmlBytes, wordList);
        System.out.println("Found positions:");
        System.out.println(result);
    }
}