package yang.app.qt.black;

public class bKey {
	public bKey(String name,int type,String key) {
		
	}
}
