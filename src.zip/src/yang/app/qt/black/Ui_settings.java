package yang.app.qt.black;

import java.util.ArrayList;

import io.qt.QUiForm;
import io.qt.core.QCoreApplication;
import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.core.Qt;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.CursorShape;
import io.qt.core.Qt.LayoutDirection;
import io.qt.core.Qt.Orientation;
import io.qt.core.QtMsgType;
import io.qt.widgets.QApplication;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QCheckBox;
import io.qt.widgets.QComboBox;
import io.qt.gui.QCursor;
import io.qt.widgets.QDialog;
import io.qt.widgets.QFontComboBox;
import io.qt.widgets.QGroupBox;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QLineEdit.EchoMode;
import io.qt.widgets.QMessageBox;
import io.qt.widgets.QMessageBox.Icon;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QRadioButton;
import io.qt.widgets.QSlider;
import io.qt.widgets.QSlider.TickPosition;
import io.qt.widgets.QSpinBox;
import io.qt.widgets.QTabWidget;
import io.qt.widgets.QTabWidget.TabPosition;
import io.qt.widgets.QTabWidget.TabShape;
import io.qt.widgets.QWidget;

public class Ui_settings
  implements QUiForm<QDialog>
{
  public QTabWidget taps;
  public QWidget first_tap;
  public QGroupBox groupBox_9;
  public QCheckBox topKeywords;
  public QSpinBox topKeywordsCount;
  public QCheckBox onlyAPart;
  public QWidget editorsettings_tap;
  public QGroupBox groupBox;
  public QFontComboBox fontComboBox;
  public QLabel label;
  public QLabel label_7;
  public QSpinBox fontsize;
  public QGroupBox groupBox_2;
  public QLabel label_3;
  public QLabel label_4;
  public QLabel label_5;
  public QSpinBox firstline;
  public QSpinBox paragraphspace;
  public QSpinBox linespace;
  public QGroupBox groupBox_3;
  public QLabel label_6;
  public QSpinBox textCursorWidth;
  public QComboBox zoom;
  public QLabel label_2;
  public QSpinBox documentmargin;
  public QLabel label_8;
  public QWidget writingview_tap;
  public QGroupBox groupBox_4;
  public QSlider textWidth;
  public QGroupBox groupBox_6;
  public QWidget savesettings_tap;
  public QGroupBox groupBox_7;
  public QCheckBox savecheckBox;
  public QLabel savelable;
  public QSpinBox savetime;
  public QGroupBox groupBox_8;
  public QCheckBox savegitinfo;
  public QPushButton gitstartwork;
  public QLabel label_11;
  public QLineEdit gitpassword;
  public QLabel label_10;
  public QLineEdit gitusername;
  public QLabel label_9;
  public QLineEdit githost;
  public QCheckBox boldFont;
  public QCheckBox italicFont;
  
  black b;
 ArrayList<Object> al_commandToUI;
 QGroupBox groupBox2;
 QBoxLayout boxLayout_groupBox2;
 QRadioButton left_Text;
 QRadioButton center_Text;
 QRadioButton right_Text;
  public void setupUi(QDialog settings)
  {
	this.b = ((settings)settings).b;
    settings.setObjectName("settings");
    QBoxLayout layout = new QBoxLayout(Direction.TopToBottom);
    settings.setLayout(layout);
    
    this.taps = new QTabWidget(settings);
    this.taps.setObjectName("taps");
    this.taps.setEnabled(true);
    this.taps.setCursor(new QCursor(Qt.CursorShape.ArrowCursor));
    this.taps.setTabPosition(QTabWidget.TabPosition.North);
    this.taps.setTabShape(QTabWidget.TabShape.Rounded);
    this.taps.setDocumentMode(false);
    layout.addWidget(taps);
    
    this.first_tap = new QWidget();
    this.first_tap.setObjectName("first_tap");
    
    QBoxLayout layout_tap1 = new QBoxLayout(Direction.TopToBottom);
    first_tap.setLayout(layout_tap1);
    
    this.groupBox_9 = new QGroupBox(this.first_tap);
    this.groupBox_9.setObjectName("groupBox_9");
    layout_tap1.addWidget(groupBox_9);
    
    QBoxLayout layout_group9 = new QBoxLayout(Direction.TopToBottom);
    
    groupBox_9.setLayout(layout_group9);
    
    this.topKeywords = new QCheckBox(this.groupBox_9);
    this.topKeywords.setObjectName("topKeywords");
    layout_group9.addWidget(topKeywords);
    
    this.topKeywordsCount = new QSpinBox(this.groupBox_9);
    this.topKeywordsCount.setObjectName("topKeywordsCount");
    this.topKeywordsCount.setFrame(true);
    layout_group9.addWidget(topKeywordsCount);
    
    this.onlyAPart = new QCheckBox(this.groupBox_9);
    this.onlyAPart.setObjectName("onlyAPart");
    layout_group9.addWidget(onlyAPart);
    
    this.taps.addTab(this.first_tap, QCoreApplication.translate("settings", "关键词列表", null));
    
    QBoxLayout layout_tab2 = uiTool.getBoxLayout(0);
    
    
    this.editorsettings_tap = new QWidget();
    this.editorsettings_tap.setObjectName("editorsettings_tap");
    
    editorsettings_tap.setLayout(layout_tab2);
    
    this.groupBox = new QGroupBox(this.editorsettings_tap);
    this.groupBox.setObjectName("groupBox");
    layout_tab2.addWidget(groupBox);
    
    QBoxLayout layout_groupbox = uiTool.getBoxLayout(2);
    groupBox.setLayout(layout_groupbox);
    
    this.label = new QLabel(this.groupBox);
    this.label.setObjectName("label");
    this.label.setAlignment( Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupbox.addWidget(label);
    
    this.fontComboBox = new QFontComboBox(this.groupBox);
    this.fontComboBox.setObjectName("fontComboBox");
    layout_groupbox.addWidget(fontComboBox);
    
    groupBox2 = uiTool.getGroupBox(editorsettings_tap, "文本对齐方式");
    boxLayout_groupBox2 = uiTool.getBoxLayout(2);
    groupBox2.setLayout(boxLayout_groupBox2);
    
    left_Text = uiTool.insertQRadioButton(boxLayout_groupBox2, "左对齐");
    center_Text = uiTool.insertQRadioButton(boxLayout_groupBox2, "居中对齐");
    right_Text = uiTool.insertQRadioButton(boxLayout_groupBox2, "右对齐");


    boldFont = uiTool.insertCheckBox(layout_groupbox, "粗体",appInfo.boldFont,"false",b,"setBold()");
    italicFont = uiTool.insertCheckBox(layout_groupbox, "斜体",appInfo.italicFont,"false",b,"setItalic()");

    
    this.label_7 = new QLabel(this.groupBox);
    this.label_7.setObjectName("label_7");
    this.label_7.setLayoutDirection(Qt.LayoutDirection.LeftToRight);
    this.label_7.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupbox.addWidget(label_7);
    
    
    this.fontsize = new QSpinBox(this.groupBox);
    this.fontsize.setObjectName("fontsize");
    layout_groupbox.addWidget(fontsize);
    
    QBoxLayout layout_groupBox_2 = uiTool.getBoxLayout(2);
    
    this.groupBox_2 = new QGroupBox(this.editorsettings_tap);
    this.groupBox_2.setObjectName("groupBox_2");
    groupBox_2.setLayout(layout_groupBox_2);
    layout_tab2.addWidget(groupBox_2);
    
    this.label_3 = new QLabel(this.groupBox_2);
    this.label_3.setObjectName("label_3");
    this.label_3.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_2.addWidget(label_3);
    
    this.linespace = new QSpinBox(this.groupBox_2);
    this.linespace.setObjectName("linespace");
    
    layout_groupBox_2.addWidget(linespace);
    
    this.label_4 = new QLabel(this.groupBox_2);
    this.label_4.setObjectName("label_4");
    this.label_4.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_2.addWidget(label_4);
    
    this.paragraphspace = new QSpinBox(this.groupBox_2);
    this.paragraphspace.setObjectName("paragraphspace");
    layout_groupBox_2.addWidget(paragraphspace);
    
    this.label_5 = new QLabel(this.groupBox_2);
    this.label_5.setObjectName("label_5");
    this.label_5.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_2.addWidget(label_5);
    
    this.firstline = new QSpinBox(this.groupBox_2);
    this.firstline.setObjectName("firstline");
    layout_groupBox_2.addWidget(firstline);
  
    this.groupBox_3 = new QGroupBox(this.editorsettings_tap);
    this.groupBox_3.setObjectName("groupBox_3");
    layout_tab2.addWidget(groupBox_3);
    
    QBoxLayout layout_groupBox_3 = uiTool.getBoxLayout(2);
    groupBox_3.setLayout(layout_groupBox_3);

    
    this.label_6 = new QLabel(this.groupBox_3);
    this.label_6.setObjectName("label_6");
    this.label_6.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_3.addWidget(label_6);
    
    this.textCursorWidth = new QSpinBox(this.groupBox_3);
    this.textCursorWidth.setObjectName("textCursorWidth");
    this.textCursorWidth.setMinimum(1);
    layout_groupBox_3.addWidget(textCursorWidth);
    
    this.label_2 = new QLabel(this.groupBox_3);
    this.label_2.setObjectName("label_2");
    this.label_2.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_3.addWidget(label_2);
    
    this.zoom = new QComboBox(this.groupBox_3);
    this.zoom.setObjectName("zoom");
    layout_groupBox_3.addWidget(zoom);
    
    this.label_8 = new QLabel(this.groupBox_3);
    this.label_8.setObjectName("label_8");
    this.label_8.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_3.addWidget(label_8);
    
    this.documentmargin = new QSpinBox(this.groupBox_3);
    this.documentmargin.setObjectName("documentmargin");
    this.documentmargin.setMinimum(1);
    layout_groupBox_3.addWidget(documentmargin);
    
    this.taps.addTab(this.editorsettings_tap, QCoreApplication.translate("settings", "编辑器", null));
    
    QBoxLayout layoutTap_Writingview = uiTool.getBoxLayout(0);
    QBoxLayout layout_Tap_writingview_1 = uiTool.getBoxLayout(2);
    layoutTap_Writingview.addLayout(layout_Tap_writingview_1);
    
    this.writingview_tap = new QWidget();
    this.writingview_tap.setObjectName("writingview_tap");
    writingview_tap.setLayout(layoutTap_Writingview);
    
    
    this.groupBox_4 = new QGroupBox(this.writingview_tap);
    this.groupBox_4.setObjectName("groupBox_4");
    
    QBoxLayout layout_groupBox_4 = uiTool.getBoxLayout(0);    
    groupBox_4.setLayout(layout_groupBox_4);
    
    
   
    layout_Tap_writingview_1.addWidget(groupBox_4);
    
    this.textWidth = new QSlider(this.groupBox_4);
    this.textWidth.setObjectName("textWidth");
    this.textWidth.setTracking(true);
    this.textWidth.setOrientation(Qt.Orientation.Horizontal);
    this.textWidth.setTickPosition(QSlider.TickPosition.NoTicks);
    layout_groupBox_4.addWidget(textWidth);
    
    
    this.groupBox_6 = new QGroupBox(this.writingview_tap);
    this.groupBox_6.setObjectName("groupBox_6");
    
    QBoxLayout layout_groupBox_6 = uiTool.getBoxLayout(2);
    groupBox_6.setLayout(layout_groupBox_6);
    
    layout_Tap_writingview_1.addWidget(groupBox_6);
    
    uiTool.insertCheckBox(layout_groupBox_6, "隐藏任务栏", appInfo.fullScreen, "true", b.ba, "setFullScreen()");
    
    
    
    
    QBoxLayout layout_save_tap = uiTool.getBoxLayout(0);
    this.taps.addTab(this.writingview_tap, QCoreApplication.translate("settings", "写作视图", null));
    this.savesettings_tap = new QWidget();
    this.savesettings_tap.setObjectName("savesettings_tap");
    savesettings_tap.setLayout(layout_save_tap);
    
    QBoxLayout layout_groupBox_7 = uiTool.getBoxLayout(2);
    
    this.groupBox_7 = new QGroupBox(this.savesettings_tap);
    this.groupBox_7.setObjectName("groupBox_7");
    groupBox_7.setLayout(layout_groupBox_7);
    layout_save_tap.addWidget(groupBox_7);

    
    this.savecheckBox = new QCheckBox(this.groupBox_7);
    this.savecheckBox.setObjectName("savecheckBox");
    layout_groupBox_7.addWidget(savecheckBox);
    
    this.savelable = new QLabel(this.groupBox_7);
    this.savelable.setObjectName("savelable");
    this.savelable.setAlignment(Qt.AlignmentFlag.AlignRight, Qt.AlignmentFlag.AlignVCenter);
    layout_groupBox_7.addWidget(savelable);
    
    this.savetime = new QSpinBox(this.groupBox_7);
    this.savetime.setObjectName("savetime");
    this.savetime.setMinimum(1);
    this.savetime.setMaximum(3600);
    layout_groupBox_7.addWidget(savetime);
    
    this.groupBox_8 = new QGroupBox(this.savesettings_tap);
    this.groupBox_8.setObjectName("groupBox_8");
    layout_save_tap.addWidget(groupBox_8);
    
    QBoxLayout layout_groupBox_8 = uiTool.getBoxLayout(0);
    groupBox_8.setLayout(layout_groupBox_8);
    
    QBoxLayout layout_groupBox_8_1 = uiTool.getBoxLayout(2);
    layout_groupBox_8.addLayout(layout_groupBox_8_1);
    
    this.label_9 = new QLabel(this.groupBox_8);
    this.label_9.setObjectName("label_9");
    layout_groupBox_8_1.addWidget(label_9);
    
    this.githost = new QLineEdit(this.groupBox_8);
    this.githost.setObjectName("githost");
    layout_groupBox_8_1.addWidget(githost);

    QBoxLayout layout_groupBox_8_2 = uiTool.getBoxLayout(2);
    layout_groupBox_8.addLayout(layout_groupBox_8_2);
    
    this.label_10 = new QLabel(this.groupBox_8);
    this.label_10.setObjectName("label_10");
    layout_groupBox_8_2.addWidget(label_10);
    
    this.gitusername = new QLineEdit(this.groupBox_8);
    this.gitusername.setObjectName("gitusername");
    layout_groupBox_8_2.addWidget(gitusername);
    
    QBoxLayout layout_groupBox_8_3 = uiTool.getBoxLayout(2);
    layout_groupBox_8.addLayout(layout_groupBox_8_3);
    
    this.label_11 = new QLabel(this.groupBox_8);
    this.label_11.setObjectName("label_11");
    layout_groupBox_8_3.addWidget(label_11);
    
    this.gitpassword = new QLineEdit(this.groupBox_8);
    this.gitpassword.setObjectName("gitpassword");
    this.gitpassword.setEchoMode(QLineEdit.EchoMode.Password);
    layout_groupBox_8_3.addWidget(gitpassword);
    
    QBoxLayout layout_groupBox_8_4 = uiTool.getBoxLayout(2);
    layout_groupBox_8.addLayout(layout_groupBox_8_4);
    
    this.savegitinfo = new QCheckBox(this.groupBox_8);
    this.savegitinfo.setObjectName("savegitinfo");
    layout_groupBox_8_4.addWidget(savegitinfo);
    
    this.gitstartwork = new QPushButton(this.groupBox_8);
    this.gitstartwork.setObjectName("gitstartwork");
    layout_groupBox_8_4.addWidget(gitstartwork);
    
    
    
    
    this.taps.addTab(this.savesettings_tap, QCoreApplication.translate("settings", "保存选项", null));
    retranslateUi(settings);
    
    b.ba.customSettings(this);
    
    this.taps.setCurrentIndex(2);
    
  }
 

  void retranslateUi(QDialog settings)
  {
    settings.setWindowTitle(QCoreApplication.translate("settings", "Dialog", null));
    this.groupBox_9.setTitle(QCoreApplication.translate("settings", "关键词预测", null));
    this.topKeywords.setToolTip(QCoreApplication.translate("settings", "勾选此项能够显著提升关键词列表框的显示速度（在编辑长文档且定义了大量关键词时效果明显）", null));
    this.topKeywords.setText(QCoreApplication.translate("settings", "置顶的关键词达到此数量时停止预测：", null));
    this.onlyAPart.setToolTip(QCoreApplication.translate("settings", "勾选此项可加快文档内容分析及预测速度", null));
    this.onlyAPart.setText(QCoreApplication.translate("settings", "预测时仅分析文档中的部分文本，而非整个文档", null));
    this.taps.setTabText(this.taps.indexOf(this.first_tap), QCoreApplication.translate("settings", "关键词列表", null));
    this.groupBox.setTitle(QCoreApplication.translate("settings", "字体与字号", null));
    this.label.setText(QCoreApplication.translate("settings", "默认字体：", null));
    this.label_7.setText(QCoreApplication.translate("settings", "字号：", null));
    this.groupBox_2.setTitle(QCoreApplication.translate("settings", "段落", null));
    this.label_3.setText(QCoreApplication.translate("settings", "行距：", null));
    this.label_4.setText(QCoreApplication.translate("settings", "段落间距：", null));
    this.label_5.setText(QCoreApplication.translate("settings", "首行缩进：", null));
    this.groupBox_3.setTitle(QCoreApplication.translate("settings", "其他", null));
    this.label_6.setText(QCoreApplication.translate("settings", "插入符宽度：", null));
    this.label_2.setText(QCoreApplication.translate("settings", "缩放值：", null));
    this.label_8.setText(QCoreApplication.translate("settings", "页边距：", null));
    this.taps.setTabText(this.taps.indexOf(this.editorsettings_tap), QCoreApplication.translate("settings", "编辑器", null));
    this.groupBox_4.setTitle(QCoreApplication.translate("settings", "编辑器宽度", null));
    this.groupBox_6.setTitle(QCoreApplication.translate("settings", "视图模式", null));
    this.taps.setTabText(this.taps.indexOf(this.writingview_tap), QCoreApplication.translate("settings", "写作视图", null));
    this.groupBox_7.setTitle(QCoreApplication.translate("settings", "自动保存", null));
    this.savecheckBox.setText(QCoreApplication.translate("settings", "启用自动保存", null));
    this.savelable.setText(QCoreApplication.translate("settings", "文档更改超过此时间后自动保存(秒)：", null));
    this.groupBox_8.setTitle(QCoreApplication.translate("settings", "备份项目到Git远程仓库", null));
    this.savegitinfo.setText(QCoreApplication.translate("settings", "记住凭据", null));
    this.gitstartwork.setText(QCoreApplication.translate("settings", "连接仓库并上传项目", null));
    this.label_11.setText(QCoreApplication.translate("settings", "密码：", null));
    this.label_10.setText(QCoreApplication.translate("settings", "用户名：", null));
    this.label_9.setText(QCoreApplication.translate("settings", "仓库地址(https)：", null));
    this.taps.setTabText(this.taps.indexOf(this.savesettings_tap), QCoreApplication.translate("settings", "保存选项", null));
  }
}
