package yang.app.qt.black;


import java.util.ArrayList;

import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QCheckBox;
import io.qt.widgets.QGroupBox;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLayout;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QRadioButton;
import io.qt.widgets.QSpinBox;
import io.qt.widgets.QTabWidget;
import io.qt.widgets.QWidget;

public class uiTool {
	/**
	 * 
	 * @param direction 0:topToTottom 1:bottomToTop 2:leftToRigth 3:rightToLeft default:TopToBottom
	 * @return
	 */
	public static QBoxLayout getBoxLayout(int direction) {
		
		switch(direction) {
		case 0:
			return new QBoxLayout(Direction.TopToBottom);
		case 1:
			return new QBoxLayout(Direction.BottomToTop);
		case 2:
			return new QBoxLayout(Direction.LeftToRight);
		case 3:			
			return new QBoxLayout(Direction.RightToLeft);
			
			default: return new QBoxLayout(Direction.TopToBottom);
		}
	}
	/**
	 * 在tap控件里添加一个新页面，并为该页面设定一个BoxLayout
	 * @param parent
	 * @param title
	 * @return
	 */
	public static QWidget addNewTap(QTabWidget parent,String title) {
		QWidget wid = new QWidget(parent);
		parent.addTab(wid, title);
		QBoxLayout layout = getBoxLayout(0);
		layout.setParent(wid);
		wid.setLayout(layout);
		return wid;
	}
	/**
	 * 得到一个groupBox，并将其加入parent的layout中
	 * @param parent
	 * @param title
	 * @return
	 */
	public static QGroupBox getGroupBox(QWidget parent,String title) {
		QGroupBox gb = new QGroupBox(parent);
		gb.setTitle(title);
		parent.layout().addWidget(gb);
		return gb;
	}
	/**
	 * 插入一个boxlayout
	 * @param layout
	 * @param direction同getBoxLayout方法
	 * @return 生成的boxlayout
	 */
	public static QBoxLayout insertBoxLayout(QBoxLayout layout,int direction) {
		QBoxLayout boxLayout = getBoxLayout(direction);
		boxLayout.setParent(layout.parentWidget());
		layout.addLayout(boxLayout);
		return boxLayout;
	}
	/**
	 * 在给定的布局对象中插入一个带文本提示标签的数字选择框，插入的方向取决于布局对象的默认插入方向
	 * @param layout
	 * @param tip
	 * @return
	 */
	public static QSpinBox insertSpinBox(QLayout layout,String tip) {
		QLabel tipLabel = new QLabel(tip);
		tipLabel.setParent(layout.parentWidget());
		QSpinBox sp = new QSpinBox(layout.parentWidget()) {
			@Override
		public boolean eventFilter(QObject watched, QEvent event) {
			// TODO Auto-generated method stub
			if(event.type() == QEvent.Type.EnabledChange) {
				tipLabel.setEnabled(isEnabled());
			}
				
			return super.eventFilter(watched, event);
		}};
		sp.installEventFilter(sp);
		layout.addWidget(tipLabel);
		layout.addWidget(sp);
		
		return sp;
	}
	
	public static QSpinBox insertSpinBox(QLayout layout,String tip,int minvalue,int maxvalue,String key,String defaultValue,Object receiver,String method) {
		QSpinBox sp = insertSpinBox(layout, tip);
		sp.setParent(layout.parentWidget());
		sp.setMinimum(minvalue);
		sp.setMaximum(maxvalue);
		sp.textChanged.connect(receiver, method);
		sp.setObjectName(key);
		if(black.settings != null && key!=null) {
			int v = black.getIntValueFromSettings(key, defaultValue);
			sp.setValue(v);
		}
		return sp;
	}
	public static QRadioButton insertQRadioButton(QLayout layout,String text) {
		QRadioButton pb = new QRadioButton();
		pb.setParent(layout.parentWidget());
		pb.setText(text);
		layout.addWidget(pb);
		return pb;
	}
	
	public static QCheckBox insertCheckBox(QLayout layout,String boxText) {
		QCheckBox cb = new QCheckBox(layout.parentWidget());
		cb.setText(boxText);
		layout.addWidget(cb);
		return cb;
	}
	/**
	 *	在给定的布局对象中插入一个带文本提示的勾选框，插入的方向取决于布局对象的默认插入方向。
	 *	该方法可以自动关联被勾选框被触发后调用的方法，且勾选框显示时会自动根据给定的settings中的键值获取初始状态
	 *	通常情况下，只需要本方法即可完成勾选框所有常用属性的设定
	 * @param layout 布局对象
	 * @param boxText 显示的提示文本
	 * @param key 该勾选框初始状态位于settings对象中的键值（该键关联的值为布尔值）,为null时不设定初始值
	 * @param defaultValue上个键参数默认的值（如果在settings对象找不到关联的值，则使用该值）
	 * @param receiver勾选框被触发后信号的接受对象
	 * @param method被触发后调用的方法
	 * @return
	 */
	public static QCheckBox insertCheckBox(QLayout layout,String boxText,String key,String defaultValue,Object receiver,String method) {
		QCheckBox cb = insertCheckBox(layout, boxText);
		cb.setObjectName(key);
		cb.setParent(layout.parentWidget());
		cb.clicked.connect(receiver,method);
		if(black.settings != null && key!=null) {
			boolean v = black.getBooleanValueFromSettings(key, defaultValue);
			cb.setChecked(v);
		}
		return cb;
	}
	
	public static QPushButton getQPushButton(String buttonText,Object receiver,String method) {
		QPushButton pb = new QPushButton();
		pb.setText(buttonText);
		pb.clicked.connect(receiver, method);
	
		return pb;
	}
	public static void insertQWedget(QTabWidget tw,String tabName,ArrayList<QWidget> ls,int col,int row) {
		
		int i = 0;
		QBoxLayout layout = null;
		QBoxLayout boxLayout = null;
		int r = 0;
		int index = 1;
		for(QWidget w:ls) {
			black.debugPrint("r: "+r+ "  i: "+i +" index: "+index);
			
			if(r == 0 && i == 0) {
				QWidget wid = new QWidget(tw);
				boxLayout = getBoxLayout(0);
				wid.setLayout(boxLayout);
				tw.addTab(wid, tabName+index);
				index++;
			}
			if(i == 0) {
				layout = getBoxLayout(2);
				boxLayout.addLayout(layout);
			}
			layout.addWidget(w);
			i++;
			if(i>=col-1) {
				i=0;
				r++;
			}
			
			if(r>row) {
				r=0;
			}
			
		}
	}
}

