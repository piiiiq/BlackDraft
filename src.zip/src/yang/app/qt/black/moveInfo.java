package yang.app.qt.black;

class moveInfo
{
  int cursorpos;
  String filename;
  
  public moveInfo(int cursorpos, String filename)
  {
    this.cursorpos = cursorpos;
    this.filename = filename;
  }
}
