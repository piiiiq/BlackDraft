package yang.app.qt.black;

import io.qt.widgets.QPushButton;


public abstract class commandToUI{
	QPushButton pb;
	String comd;
	boolean noArgs;

	public commandToUI(String buttonText,String command,boolean noArgs) {
		pb = uiTool.getQPushButton(buttonText, this, "action()");
		this.comd = command;
		this.noArgs = noArgs;
	}
	
	abstract void action();
}