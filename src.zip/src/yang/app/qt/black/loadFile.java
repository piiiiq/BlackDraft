package yang.app.qt.black;

import java.io.File;

class loadFile {
	String text;
	String showName;
	int part;
	int start;
	black b;
	int plusValue;
	File file;
	boolean isSaved;
	boolean opened;
	long a;

	public loadFile(black b, String str, String showname, int part, File file, boolean isSaved, long a,
			boolean opened) {
		this.b = b;
		this.text = str;
		this.showName = showname;
		this.part = part;
		this.file = file;
		this.isSaved = isSaved;
		this.a = a;
		this.opened = opened;
		if (part == 0) {
			this.plusValue = 50000;
		} else {
			this.plusValue = part;
		}
		run();
	}

	public void run() {
		new Thread(new Runnable() {
			
			public void run() {
				//在加载文档前让QTextEdit组件显示出来，能获得最快的加载速度
//				black.uiRun(b, new Runnable() {
//					public void run() {
//						b.showAllWidget();
//						b.show();
//					}
//				});

				loadDocument(text);
			}
		}).start();
	}

	public void loadDocument(String text) {
		// 设定每次向QTextEdit追加的字符串数量，该数值会影响加载文档的性能
		int splitCount = 30000;
		int textLen = text.length();
		int start = 0;
		int end = 0;
		while (true) {
			String str = null;
			end = start + splitCount;
			boolean isBreak = false;
			if (end < textLen) {
				str = text.substring(start, end);
				start = end;
			} else {
				str = text.substring(start, textLen);
				end = textLen;
				isBreak = true;
			}

			int c = end;
			String s = str;
			boolean isB = isBreak;
			black.uiRun(b, new Runnable() {
				public void run() {
					loadFile.this.b.setProgressBarValue(c, loadFile.this.text.length(), loadFile.this.showName + "\n");
					loadFile.this.b.btext.text.append(s);
					if (isB) {
						loadFile.this.b.whenLoadFileDone(loadFile.this.file, loadFile.this.isSaved, loadFile.this.a,
								loadFile.this.showName, loadFile.this.opened);
						b.btext.vScrollBarMaxValue = b.text.verticalScrollBar().maximum();
					}

				}
			});

			if (isBreak)
				return;
		}
	}

}
