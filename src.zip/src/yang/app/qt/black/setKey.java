package yang.app.qt.black;

import java.util.ArrayList;

public class setKey {
	ArrayList<bKey> al = new ArrayList<bKey>();
	public setKey() {
		
	}
	public void addKey(bKey key) {
		al.add(key);
	}
}
