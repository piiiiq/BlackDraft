package yang.app.qt.black;

import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.Qt;
import io.qt.widgets.QAction;
import io.qt.widgets.QBoxLayout;
import io.qt.gui.QCloseEvent;
import io.qt.gui.QKeyEvent;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QToolButton;
import io.qt.widgets.QWidget;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QLineEdit.EchoMode;
import io.qt.widgets.QDialog;

public abstract class InputDialog extends QDialog{
	private QLineEdit line;
	private QToolButton button_ok;
	private QToolButton button_can;
	boolean noHide;
			/**
			 * 按下ESC不退出
			 */
	boolean noESC;
	/**
	 * 此开关打开时，按下取消按钮和关闭按钮和alt+f4不会关闭窗口，如果需要关闭窗口，需先将此开关置于false
	 */
	boolean noClose;
	private QLabel label;
	private Runnable run_show;
	private Runnable run_Window_DeActivate;
	private Runnable run_textChanged;
	private Runnable run_Window_Activate;

	/**
	 * 初始化后需要调用exec方法显示,点击确定返回1，点击取消返回0
	 * 输入框也可以用来显示能够复制的信息，显示信息时应设置成只读模式
	 * 如果想要点击按钮后不自动关闭对话框，请将noHide开关设为true
	 * 此类所有的setRunable开头的方法均为按需实现，需要再实现
	 * value方法获取输入值
	 * @param title
	 * @param lineEditKeyName
	 */
	public InputDialog(QWidget parent,String title,String lineEditKeyName,boolean passwordMode,boolean onlyReadMode,String InputLineValue) {
		super(parent);
//		black.speakText(lineEditKeyName, -1);

		setWindowTitle(title);
		QBoxLayout topBox = new QBoxLayout(Direction.TopToBottom);
		setLayout(topBox);
		QBoxLayout box = new QBoxLayout(Direction.RightToLeft);
		
		topBox.insertLayout(0, box);
		QBoxLayout buttons = new QBoxLayout(Direction.LeftToRight);
		buttons.setContentsMargins(0, 10, 0, 0);
		topBox.insertLayout(1, buttons, 0);
		button_ok = new QToolButton();
		button_ok.setText("确定");
		button_ok.clicked.connect(this,"ok()");
		buttons.addWidget(button_ok);
		button_can = new QToolButton();
		button_can.clicked.connect(this,"can()");
		button_can.setText("取消");
		buttons.addWidget(button_can);
		buttons.setAlignment(new Qt.Alignment(Qt.AlignmentFlag.AlignRight));
		line = new QLineEdit(this);
		if(InputLineValue != null) line.setText(InputLineValue);
		line.setReadOnly(onlyReadMode);
		line.setFocus();
		if(passwordMode)
		line.setEchoMode(EchoMode.Password);
		line.installEventFilter(this);
//		QAction enter_action = new QAction(line);
//		enter_action.setShortcut("enter");
//		enter_action.triggered.connect(this,"enter()");
//		line.addAction(enter_action);
		box.addWidget(line);
		label = new QLabel();
		label.setText(lineEditKeyName);
		box.addWidget(label);
		adjustSize();
		
	}
	abstract void whenOkButtonPressed();
	abstract void whenCannelButtonPressed();
	void setKeyText(String text) {
		label.setText(text);
	}
	void setLineText(String text) {
		line.setText(text);
	}
	void setOkButtonName(String name) {
		button_ok.setText(name);
	}
	void setCannelButtonName(String name) {
		button_can.setText(name);
	}
	String copyLineText() {
		line.selectAll();
		line.copy();
		return line.text();
	}
	void ok() {
		whenOkButtonPressed();
		if(noHide)return;
		if(!line.text().isEmpty())
		done(1);
	}
	void can() {
		whenCannelButtonPressed();
		if(noHide)return;
		done(0);
	}
	public String value() {
		return line.text();
	}
	@Override
	protected void closeEvent(QCloseEvent arg__1) {
		// TODO Auto-generated method stub
		if(noClose)
			arg__1.ignore();
//		
//		super.closeEvent(arg__1);
	}
	public boolean eventFilter(QObject arg__1, QEvent arg__2) {
		// TODO Auto-generated method stub
		if(arg__2.type()==QEvent.Type.KeyPress) {
			QKeyEvent key = (QKeyEvent) arg__2;
//			System.out.println(key.key()+" "+Qt.Key.Key_Enter.value());
			if(key.key() == Qt.Key.Key_Escape.value()) {
				if(noESC)
				return true;
			}
			else if(key.key() == 16777220) {
				ok();
				return true;
			}
		}else if(arg__2.type() == QEvent.Type.Hide) {
			whenClose();
			if(noHide) return true;
		}else if(arg__2.type() == QEvent.Type.Show) {
			if(getRunableAtShow() != null)getRunableAtShow().run();
//			if(parentWidget() != null) {
//				setGeometry(parentWidget().width()/2-width()/2, parentWidget().height()/2-height()/2, width(), height());
//			}
			line.setFocus();
		}else if(arg__2.type() == QEvent.Type.WindowActivate) {
			if(getRunableAtWindowActivate() != null) getRunableAtWindowActivate().run();
			line.setFocus();
			
		}else if(arg__2.type() == QEvent.Type.WindowDeactivate) {
			if(getRunableAtWindowDeActivate() != null) getRunableAtWindowDeActivate().run();
		}
		return super.eventFilter(arg__1, arg__2);
	}
	/**
	 * 设定一个在对话框显示后调用的run对象
	 * @param run
	 */
	public void setRunableAtShow(Runnable run) {
		this.run_show = run;
	}
	public Runnable getRunableAtShow() {
		return run_show;
	}
	public void setRunableAtWindowDeActivate(Runnable run) {
		run_Window_DeActivate = run;
	}
	public Runnable getRunableAtWindowDeActivate() {
		return run_Window_DeActivate;
	}
	public void setRunableAtWindowActivate(Runnable run) {
		run_Window_Activate = run;
	}
	public Runnable getRunableAtWindowActivate() {
		return run_Window_Activate;
	}
	public Runnable getRunableAtTextChanged() {
		return run_textChanged;
	}
	public void setRunableAtTextChanged(Runnable run) {
		run_textChanged = run;
		line.textChanged.connect(run_textChanged, "run()");
	}
	public void closeThis() {
		noHide = false;
		close();
	}
	abstract void whenClose();
}
