package yang.app.qt.black;

class isRight
{
  boolean isright;
  Object value;
  
  public isRight(boolean isright, Object value)
  {
    this.isright = isright;
    this.value = value;
  }
}
