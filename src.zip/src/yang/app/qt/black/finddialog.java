package yang.app.qt.black;


import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.QRegExp;
import io.qt.core.Qt;
import io.qt.gui.QKeyEvent;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveMode;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextDocument.FindFlag;
import io.qt.gui.QTextDocument.FindFlags;
import io.qt.widgets.QApplication;
import io.qt.widgets.QDialog;
import io.qt.widgets.QMessageBox;
import io.qt.widgets.QWidget;
/**
 * 替换按钮和查找并替换按钮按下后，如果没有替换文本则给出提示框
 * @author Administrator
 *
 */
public class finddialog extends QDialog {
	Ui_finddialog ui = new Ui_finddialog();
	black b;
	boolean onlyShowHistoryOfBlackCommands;
	FindFlags findFlags = new FindFlags();
	private int findIn;
	
	QTextDocument doc;
	

	public static void main(String[] args) {
		QApplication.initialize(args);

		finddialog testfinddialog = new finddialog();
		testfinddialog.show();

		QApplication.exec();
	}

	public finddialog() {
		this.ui.setupUi(this);
//		setFont(new QFont("微软雅黑", 10));

		this.ui.findText.insertItem(0, "hello");
		this.ui.findText.insertItem(2, "test");

		this.ui.findText.setFocus();
		this.ui.findText.lineEdit().selectAll();
//		this.ui.findText.currentIndexChanged.connect(this.ui.findText.lineEdit(), "selectAll()");
//		QApplication.connect(ui.findText, "currentIndexChanged", ui.findText.lineEdit(),"selectAll()");
	}

	public finddialog(QWidget parent) {
		super(parent);
		this.b = ((black) parent);

		this.ui.setupUi(this);
		if (b.text.isReadOnly()) {
			ui.replace.setEnabled(false);
			ui.replace_find.setEnabled(false);
			ui.replaceall.setEnabled(false);
		}
		setWindowTitle("查找/替换");
		this.ui.next.pressed.connect(this, "next()");
		this.ui.previous.pressed.connect(this, "previous()");
//		setFont(new QFont("微软雅黑", 10));
		this.ui.findText.editTextChanged.connect(this, "findStrChanged(String)");

		this.ui.findText.setFocus();
		this.ui.findText.lineEdit().setPlaceholderText("键入搜索文本");

		this.ui.findText.lineEdit().selectAll();
//		this.ui.findText.currentIndexChanged.connect(this.ui.findText.lineEdit(), "selectAll()");
		QApplication.connect(ui.findText, "currentIndexChanged(int)", ui.findText.lineEdit(),"selectAll()");

		this.ui.findText.installEventFilter(this);
		if (this.ui.findText.currentText().isEmpty()) {
			this.ui.next.setEnabled(false);
			this.ui.previous.setEnabled(false);
			this.ui.replace_find.setEnabled(false);
			this.ui.replaceall.setEnabled(false);
			this.ui.replace.setEnabled(false);
		}
		this.ui.document.setChecked(true);
		this.ui.replaceall.clicked.connect(this, "replaceAll()");
		this.ui.replace_find.clicked.connect(this, "replaceAndFind()");
		this.ui.replace.clicked.connect(this, "replace()");
		ui.case_2.clicked.connect(this, "caseS(boolean)");
		ui.case_2.setChecked(true);
		installEventFilter(this);
		b.btext.currentFindCursor = b.btext.text.textCursor();
		ui.document.setChecked(true);
		ui.document.clicked.connect(this,"findInDoc(boolean)");
		ui.files.clicked.connect(this,"findInFiles(boolean)");
		findFlags.clear(FindFlag.FindCaseSensitively);
		
	}
	void findInDoc(boolean b) {
		if(b)
		findIn = 0;
		ui.next.setDisabled(false);
		ui.previous.setDisabled(false);
		ui.replace_find.setDisabled(false);
		ui.replace.setDisabled(false);
	}
	void findInFiles(boolean b){
		if(b) {
			findIn = 1;
			ui.next.setDisabled(true);
			ui.previous.setDisabled(true);
			ui.replace_find.setDisabled(true);
			ui.replace.setDisabled(true);
		}
	}
	/**
	 * 区分大小写开关
	 * @param b
	 */
	void caseS(boolean b) {
		if(!b)
		findFlags.set(FindFlag.FindCaseSensitively);
		else findFlags.clear(FindFlag.FindCaseSensitively);
	}
	

	void replace() {
		boolean done = false;
		String findText = getFindText();
		if (!findText.isEmpty()) {
			String selectedText = b.btext.currentFindCursor.selectedText();
			if(!selectedText.isEmpty()) {
				b.btext.currentFindCursor.insertText(this.ui.replace_str.text());
				done = true;
			}
			
		}
		
		if(!done) b.getMessageBox("查找/替换", "没有替换任何文本");
	}
	/**
	 * 该方法先尝试替换一次，如果替换不成功，则执行一次查找，然后再次尝试替换，不管替换是否成功，最后再查找一次
	 */
	boolean replaceAndFind() {
		boolean done = false;
		String findText = getFindText();
		if (!findText.isEmpty()) {
			//先尝试替换一次
			if(b.btext.currentFindCursor != null && b.btext.currentFindCursor.hasSelection()) {
				this.b.btext.currentFindCursor.insertText(this.ui.replace_str.text());
				done = true;
				//如果上面的替换操作不成功，则尝试再查找一次
			}else {
				if(!findFlags.isSet(FindFlag.FindBackward))
					next();
				else previous();
			}
			//尝试再次替换
			if(b.btext.currentFindCursor != null && b.btext.currentFindCursor.hasSelection()) {
				this.b.btext.currentFindCursor.insertText(this.ui.replace_str.text());
				done = true;
			}
			//再次查找
			if(!findFlags.isSet(FindFlag.FindBackward))
				next();
			else previous();
		}
		
		if(!done) b.getMessageBox("查找/替换", "没有替换任何文本");
		return done;
	}

	void findStrChanged(String str) {
		if (str.isEmpty()) {
			this.ui.next.setEnabled(false);
			this.ui.previous.setEnabled(false);
			this.ui.replace_find.setEnabled(false);
			this.ui.replaceall.setEnabled(false);
			this.ui.replace.setEnabled(false);
		} else {
			this.ui.next.setEnabled(true);
			this.ui.previous.setEnabled(true);
			if (b.text.isReadOnly())
				return;

			this.ui.replace_find.setEnabled(true);
			this.ui.replaceall.setEnabled(true);
			this.ui.replace.setEnabled(true);
		}
	}

	public boolean eventFilter(QObject o, QEvent e) {
		if ((o.equals(this.ui.findText)) && (e.type() == QEvent.Type.KeyPress)) {
			QKeyEvent keypress = (QKeyEvent) e;
			if (keypress.key() == Qt.Key.Key_Return.value()) {
				String findText = getFindText();
				if (findText.indexOf(appInfo.blackCommand) != 0) {
					next();
				} else {
					this.b.execCommand(findText);
				}
				return true;
			}
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.Show)) {
			if (!this.onlyShowHistoryOfBlackCommands) {
				for (int i = this.b.findHistory.size() - 1; i >= 0; i--) {
					this.ui.findText.insertItem(this.b.findHistory.size() - 1 - i, (String) this.b.findHistory.get(i));
				}
				String selectedText = b.text.textCursor().selectedText();
				if (!selectedText.isEmpty()) {
//        	ui.findText.insertItem(0, selectedText);
					ui.findText.setEditText(selectedText);
					ui.findText.lineEdit().selectAll();
				}
			} else {
				for (int i = this.b.findHistory.size() - 1; i >= 0; i--) {
					if (((String) this.b.findHistory.get(i)).indexOf(appInfo.blackCommand) == 0) {
						this.ui.findText.insertItem(this.b.findHistory.size() - 1 - i,
								(String) this.b.findHistory.get(i));
					}
				}
			}
		} else if ((o.equals(this)) && (e.type() == QEvent.Type.Hide)) {
			this.b.finddialog = null;
		}else if((o.equals(this)) && (e.type() == QEvent.Type.WindowDeactivate)) {
		}
		return false;
	}

	String getFindText() {
		String text = this.ui.findText.currentText();
		if (!text.isEmpty()) {
			this.b.addToFindHistory(text);
		}
		return text;
	}
	/**此方法是负责查找搜索选项并执行搜索的方法
	 * 不管是向上还是向下搜索最终都会调用此方法
	 * 返回的光标是black.text可以直接使用的光标
	 * 如果没有查找到结果，返回TextCursor pos为-1
	 * @return
	 */
	QTextCursor findnext() {
//		System.out.println("start: "+b.btext.currentFindCursor.position());
		String findstr = getFindText();
		if(findstr.isEmpty())return null;
		//检查是否选择了全字匹配
		int currentIndex = this.ui.findOptions.currentIndex();
		if(currentIndex == 1) {
			findFlags.set(FindFlag.FindWholeWords);
		}else findFlags.clear(FindFlag.FindWholeWords);
		
		//检查是否启用了高级查找选项
		boolean hasText = false,onStart = false,onEnd = false;
		if(currentIndex == 2) hasText = true;
		else if(currentIndex == 3)onStart = true;
		else if(currentIndex == 4)onEnd = true;
		
		if(doc == null) {
			if(b.btext != null)
				doc = this.b.btext.text.document();
		}
		QTextCursor find = null;
		int findPos = 0;
		//向后查找
		if(!findFlags.isSet(FindFlag.FindBackward)) {
			if(b.btext.currentFindCursor.hasSelection()) findPos = b.btext.currentFindCursor.selectionEnd();
			else findPos = b.btext.currentFindCursor.position();
		//向前查找
		}else {
			if(b.btext.currentFindCursor.hasSelection()) findPos = b.btext.currentFindCursor.selectionStart();
			else findPos = b.btext.currentFindCursor.position();
		}
		//执行普通查找，不用正则表达式
		if(!hasText && !onStart && !onEnd)
			find = doc.find(findstr, findPos,findFlags);
		//开启了高级选项后，使用正则表达式查找
		else {
			QRegExp regEx = null;
			if(hasText)	regEx = new QRegExp("^.*"+findstr+".*$");
			else if(onStart) regEx = new QRegExp("^"+findstr+".*$");
			else if(onEnd) regEx = new QRegExp("^.*"+findstr+"$");
			find = doc.find(regEx, findPos,findFlags);
		}
				
		return find;
	}
	/**
	 * 设定findFlags
	 * 然后交给findnext方法去具体执行搜索
	 * 此方法负责处理findnext搜索后返回结果并给出提示
	 */
	void next() {
		findFlags.clear(FindFlag.FindBackward);
		QTextCursor findnext = findnext();
		if (findnext.position() != -1) {
			this.b.btext.text.setTextCursor(findnext);
			this.b.btext.currentFindCursor = findnext;
		} else{
			int messageBoxWithYesNO = b.getMessageBoxWithYesNO("查找", "没有查找到结果，是否再次从文档开头查找", "是", "否", QMessageBox.Icon.Question, 1);
			if(messageBoxWithYesNO == 1) {
				this.b.btext.currentFindCursor.setPosition(0);
				next();
			}
		}
	}
	/**
	 * 设定findFlags
	 * 然后交给findnext方法去具体执行搜索
	 * 此方法负责处理findnext搜索后返回结果并给出提示
	 */
	void previous() {
		findFlags.set(FindFlag.FindBackward);
		QTextCursor findpre = findnext();
		b.debugPrint("find: "+findpre.position());
		if (findpre.position() != -1) {
			this.b.btext.text.setTextCursor(findpre);
			this.b.btext.currentFindCursor = findpre;
		} else {
			int messageBoxWithYesNO = b.getMessageBoxWithYesNO("查找", "没有查找到结果，是否再次从结尾开始查找", "是", "否", QMessageBox.Icon.Question, 1);
			if(messageBoxWithYesNO == 1) {
				b.btext.currentFindCursor.movePosition(MoveOperation.End);
				previous();
			}
		}
	}

	void replaceAll() {
		String findText = getFindText();
		if (!findText.isEmpty()) {
			if(findIn == 0) {
				b.ba.replaceAll_doc(this, false);
			}
			else
				b.ba.replaceAll_files(this);

			
		}
	}
}
