package yang.app.qt.black;

public class black_super1 extends QTmud {

}
