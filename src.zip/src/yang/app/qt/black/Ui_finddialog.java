package yang.app.qt.black;

import io.qt.QUiForm;
import io.qt.core.QCoreApplication;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.widgets.QBoxLayout;
import io.qt.widgets.QBoxLayout.Direction;
import io.qt.widgets.QCheckBox;
import io.qt.widgets.QComboBox;
import io.qt.widgets.QDialog;
import io.qt.widgets.QGroupBox;
import io.qt.widgets.QLabel;
import io.qt.widgets.QLineEdit;
import io.qt.widgets.QPushButton;
import io.qt.widgets.QRadioButton;
import io.qt.widgets.QSizePolicy;
import io.qt.widgets.QSizePolicy.Policy;

public class Ui_finddialog
  implements QUiForm<QDialog>
{
  public QLabel label;
  public QLineEdit replace_str;
  public QLabel label_2;
  public QGroupBox groupBox_3;
  public QCheckBox case_2;
  public QComboBox findOptions;
  public QPushButton next;
  public QPushButton previous;
  public QPushButton replace_find;
  public QPushButton replace;
  public QPushButton replaceall;
  public QGroupBox groupBox_4;
  public QRadioButton document;
  public QRadioButton files;
  public QComboBox findText;
  
  public void setupUi(QDialog finddialog)
  {
    finddialog.setObjectName("finddialog");
//    finddialog.resize(new QSize(493, 174).expandedTo(finddialog.minimumSizeHint()));
    finddialog.setSizePolicy(Policy.Expanding, Policy.Expanding);
    QBoxLayout boxlayout = new QBoxLayout(Direction.TopToBottom);
    finddialog.setLayout(boxlayout);
    
    QBoxLayout l1 = new QBoxLayout(Direction.LeftToRight);
    
    this.label = new QLabel(finddialog);
    this.label.setObjectName("label");
    l1.addWidget(label);
    
    this.findText = new QComboBox(finddialog);
    this.findText.setObjectName("findText");
    this.findText.setEditable(true);

    l1.addWidget(findText,100);
    
    this.next = new QPushButton(finddialog);
    this.next.setObjectName("next");
    l1.addWidget(next);
    
    boxlayout.addLayout(l1);
    
    QBoxLayout l2 = new QBoxLayout(Direction.LeftToRight);

    this.label_2 = new QLabel(finddialog);
    this.label_2.setObjectName("label_2");
    l2.addWidget(label_2);
    
    this.replace_str = new QLineEdit(finddialog);
    this.replace_str.setObjectName("replace_str");
    
    l2.addWidget(replace_str);
    
    this.previous = new QPushButton(finddialog);
    this.previous.setObjectName("previous");
    this.previous.setGeometry(new QRect(390, 40, 91, 24));
    l2.addWidget(previous);
    boxlayout.addLayout(l2);
    
    QBoxLayout l3 = new QBoxLayout(Direction.LeftToRight);
    
    this.groupBox_4 = new QGroupBox(finddialog);
    this.groupBox_4.setObjectName("groupBox_4");
    l3.addWidget(groupBox_4);
    
    QBoxLayout lgb = new QBoxLayout(Direction.TopToBottom);
    groupBox_4.setLayout(lgb);
    
    this.files = new QRadioButton(this.groupBox_4);
    this.files.setObjectName("selectionText");
    lgb.addWidget(files);
    
    this.document = new QRadioButton(this.groupBox_4);
    this.document.setObjectName("document");
    lgb.addWidget(document);
    
    boxlayout.addLayout(l3);
    
    this.groupBox_3 = new QGroupBox(finddialog);
    this.groupBox_3.setObjectName("groupBox_3");
    
    l3.addWidget(groupBox_3);
    QBoxLayout lgb1 = new QBoxLayout(Direction.TopToBottom);
    groupBox_3.setLayout(lgb1);
    
    this.case_2 = new QCheckBox(this.groupBox_3);
    this.case_2.setObjectName("case_2");
    lgb1.addWidget(case_2);
   
    this.findOptions = new QComboBox(this.groupBox_3);
    this.findOptions.setObjectName("findOptions");
    lgb1.addWidget(findOptions);
    
    QBoxLayout bl = new QBoxLayout(Direction.TopToBottom);
    
    this.replace = new QPushButton(finddialog);
    this.replace.setObjectName("replace");
    this.replace.setEnabled(true);
    bl.addWidget(replace);
    
    this.replace_find = new QPushButton(finddialog);
    this.replace_find.setObjectName("replace_find");
    this.replace_find.setEnabled(true);
    bl.addWidget(replace_find);
    
    this.replaceall = new QPushButton(finddialog);
    this.replaceall.setObjectName("replaceall");
    bl.addWidget(replaceall);
    
    l3.addLayout(bl);

   
    retranslateUi(finddialog);
    
//    finddialog.connectSlotsByName();
  }
  
  void retranslateUi(QDialog finddialog)
  {
    finddialog.setWindowTitle(QCoreApplication.translate("finddialog", "Dialog", null));
    this.label.setText(QCoreApplication.translate("finddialog", "查找:", null));
    this.label_2.setText(QCoreApplication.translate("finddialog", "替换:", null));
    this.groupBox_3.setTitle(QCoreApplication.translate("finddialog", "查找选项", null));
    this.case_2.setText(QCoreApplication.translate("finddialog", "忽略大小写", null));
    this.findOptions.clear();
    this.findOptions.addItem(QCoreApplication.translate("finddialog", "不使用", null));
    this.findOptions.addItem(QCoreApplication.translate("finddialog", "全字匹配", null));
    this.findOptions.addItem(QCoreApplication.translate("finddialog", "包含此文本的段落", null));
    this.findOptions.addItem(QCoreApplication.translate("finddialog", "以此文本开始的段落", null));
    this.findOptions.addItem(QCoreApplication.translate("finddialog", "以此文本结束的段落", null));
    this.next.setText(QCoreApplication.translate("finddialog", "下一个", null));
    this.previous.setText(QCoreApplication.translate("finddialog", "前一个", null));
    this.replace_find.setText(QCoreApplication.translate("finddialog", "替换并查找", null));
    this.replace.setText(QCoreApplication.translate("finddialog", "替换", null));
    this.replaceall.setText(QCoreApplication.translate("finddialog", "替换全部", null));
    this.groupBox_4.setTitle(QCoreApplication.translate("finddialog", "替换区域", null));
    this.document.setText(QCoreApplication.translate("finddialog", "当前文档", null));
    this.files.setText(QCoreApplication.translate("finddialog", "当前文件集", null));
  }
}
