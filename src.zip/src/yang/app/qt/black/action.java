package yang.app.qt.black;

abstract class action
{
  public abstract void action();
}
