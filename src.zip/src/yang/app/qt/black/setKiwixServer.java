package yang.app.qt.black;

class setKiwixServer {}
