package yang.app.qt.black;

import java.util.ArrayList;

import io.qt.core.QEvent;
import io.qt.core.QObject;
import io.qt.core.QRect;
import io.qt.core.QSize;
import io.qt.core.Qt;
import io.qt.core.Qt.Alignment;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.core.Qt.ItemFlag;
import io.qt.core.Qt.ScrollBarPolicy;
import io.qt.core.Qt.WindowType;
import io.qt.gui.QBrush;
import io.qt.gui.QColor;
import io.qt.gui.QFont;
import io.qt.gui.QKeyEvent;
import io.qt.widgets.QApplication;
import io.qt.widgets.QDialog;
import io.qt.widgets.QFrame;
import io.qt.widgets.QHBoxLayout;
import io.qt.widgets.QHeaderView.ResizeMode;
import io.qt.widgets.QSizePolicy;
import io.qt.widgets.QSizePolicy.Policy;
import io.qt.widgets.QTableWidget;
import io.qt.widgets.QTableWidgetItem;
import io.qt.widgets.QToolButton;
import io.qt.widgets.QVBoxLayout;
import io.qt.widgets.QWidget;

public class bTableBox extends QDialog{
	QTableWidget tw;
	/**
	 * 得到一个基本的表格内容提示框，
	 * @param parent 
	 * @param col表格最大的列数（纵向）
	 * @param data包含表格所有文本内容的list数组，内容将会根据给定的列数进行换行显示
	 * @param setStyle是否设定样式，默认不设定样式。如果是true，提示框会为内容设定样式，例如设置背景色，第一列的文本将会以粗体显示
	 * @param hideScrollBar 是否隐藏滚动条，展示少量数据时不需要显示滚动条；隐藏滚动条时也会禁止调整表格窗口大小
	 */
	public bTableBox(QWidget parent,int col,ArrayList<String> data,boolean setStyle,boolean hideScrollBar) {
		super(parent);
		setWindowFlag(WindowType.WindowCloseButtonHint);
		tw = new QTableWidget(data.size()/col,col);
		tw.setFrameStyle(QFrame.Shape.NoFrame.value());
		tw.horizontalHeader().hide();
		tw.verticalHeader().hide();
		tw.verticalHeader().setSectionResizeMode(ResizeMode.ResizeToContents);
		tw.horizontalHeader().setSectionResizeMode(ResizeMode.ResizeToContents);
		
		if(hideScrollBar) {
			tw.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
			tw.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAlwaysOff);
			//隐藏滚动条时也会禁止调整表格窗口大小
//			setSizePolicy(new QSizePolicy(Policy.Fixed, Policy.Fixed));
		}
		
		int row_current = 0;
		int col_current = 0;
		for(int i=0;i<data.size();i++) {
			String d = data.get(i);
			
			QTableWidgetItem item = new QTableWidgetItem(d);
			if(setStyle) {
				if(col_current == 0) {
					QFont font = item.font();
					font.setBold(true);
					item.setFont(font);
//					item.setBackground(new QBrush(new QColor(Qt.GlobalColor.cyan)));
					item.setTextAlignment(AlignmentFlag.AlignVCenter.value()|AlignmentFlag.AlignRight.value());
				}else {
					QFont font = item.font();
					font.setItalic(true);
					item.setFont(font);
//					item.setBackground(new QBrush(new QColor(Qt.GlobalColor.cyan)));
					item.setTextAlignment(AlignmentFlag.AlignVCenter.value()|AlignmentFlag.AlignLeft.value());


				}
			}
//			tw.setRowHeight(row_current, 5);
			item.setFlags(ItemFlag.ItemIsEnabled);
			tw.setItem(row_current, col_current, item);
			col_current++;
			
			if(col_current == col) {
				col_current = 0;
				row_current++;
			}
		}
		tw.setSizeAdjustPolicy(QTableWidget.SizeAdjustPolicy.AdjustToContents);
		
		QVBoxLayout qvBoxLayout = new QVBoxLayout(this);
		qvBoxLayout.setContentsMargins(0, 0, 0, 0);
		qvBoxLayout.setAlignment(AlignmentFlag.AlignHCenter);
		qvBoxLayout.addWidget(tw);
		QHBoxLayout qhBoxLayout = new QHBoxLayout();
		qhBoxLayout.setContentsMargins(0, 10, 10, 10);
		QToolButton ok = new QToolButton(this);
		ok.setText("Ok");
		ok.clicked.connect(this, "ok()");
		qhBoxLayout.addWidget(ok, 0, AlignmentFlag.AlignRight);
		qvBoxLayout.addItem(qhBoxLayout);
		setLayout(qvBoxLayout);
		tw.adjustSize();
//		setSizePolicy(Policy.Preferred, Policy.Preferred);
		QRect geometry = QApplication.desktop().geometry();
		adjustSize();
		QSize sizeHint = sizeHint();
		if(sizeHint.width() <= geometry.width() && sizeHint.height() <= geometry.height())
			setFixedSize(sizeHint.width(), sizeHint.height()+1);
		ok.setFocus();
		installEventFilter(this);
	}
	void ok() {
		close();
	}
	@Override
	public boolean eventFilter(QObject arg__1, QEvent arg__2) {
		// TODO Auto-generated method stub
		if(arg__2.type()==QEvent.Type.KeyPress) {
			QKeyEvent k = (QKeyEvent) arg__2;
			System.out.println(k.key());
			if(k.key() == 16777220) {
				close();
				return true;
			}
		}else if(arg__2.type() == QEvent.Type.Resize) {
			QSize minimumSizeHint = tw.sizeHint();
			if(tw.size().width() < minimumSizeHint.width() || tw.size().height() < minimumSizeHint.height()) {
				tw.setHorizontalScrollBarPolicy(ScrollBarPolicy.ScrollBarAsNeeded);
				tw.setVerticalScrollBarPolicy(ScrollBarPolicy.ScrollBarAsNeeded);
			}
		}
		return super.eventFilter(arg__1, arg__2);
	}

}
