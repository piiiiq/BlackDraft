package yang.app.qt.black;

import java.util.ArrayList;
/**
 * 此类定义black中的全部动作
 * @author Administrator
 *
 */
public class actions {
	ArrayList<action> al = new ArrayList<action>();
	public actions(black b) {
		addActon(new action() {
			
			@Override
			void action() {
				// TODO Auto-generated method stub
				
			}
		});
	}
	public void addActon(action a){
		al.add(a);
	}
}
abstract class action{

	private String name;
	private int type;
	private String key;
	private String info;

	public action(String name,int type,String key,String info) {
		this.name = name;
		this.type = type;
		this.key = key;
		this.info = info;
	}
	abstract void action() ;
}