package yang.app.qt.black;

import java.io.File;
import java.util.ArrayList;

import io.qt.core.QTimer;
import io.qt.core.Qt.AlignmentFlag;
import io.qt.gui.QFont;
import io.qt.gui.QTextBlockFormat;
import io.qt.gui.QTextCharFormat;
import io.qt.gui.QTextCursor;
import io.qt.gui.QTextCursor.MoveOperation;
import io.qt.gui.QTextCursor.SelectionType;
import io.qt.gui.QTextDocument;
import io.qt.gui.QTextOption;
import io.qt.widgets.QApplication;
import io.qt.widgets.QDateTimeEdit.Section;
import io.qt.widgets.QTextEdit;


public class test {
	
	static void t(String text,Runnable run) {
		int splitCount = 7;
		int textLen = text.length();
		int start = 0;
		int end = 0;
		
		while(true) {
			String str = null;
			end = start+splitCount;
			boolean isBreak = false;
			if(end < textLen) {
				str = text.substring(start, end);
				start = end;
			}else {
				str = text.substring(start, textLen);
				isBreak = true;
			}
			if(run != null)
				run.run();
			if(isBreak)return;
		}
	}
	public static void main(String[] args) throws Exception {
		String s = "helloworld";
//		t(s,null);
		t(s,new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println(str);
			}
		});
		
		
//		testQT(args);
		
	}

	public static void testQT(String[] args) {
		
		QApplication.initialize(args);
	
		QTextEdit te = new QTextEdit();
		te.setGeometry(100, 100, 600, 600);
		te.show();
		File file = new File("C:\\Users\\Administrator\\Desktop\\刚果惊魂.txt");
		long t0 = System.currentTimeMillis();
		String text = io.readTextFile(file, "gbk");
		long t1 = System.currentTimeMillis();
		long t = t1-t0;
		System.out.println("read file time: "+t+"ms");
		
		long t2 = System.currentTimeMillis();
//		QTimer qtimer = new QTimer();
//		qtimer.timeout.connect(te, "");
		te.zoomIn(10);
		
		QTextCursor tc = te.textCursor();
		tc.select(SelectionType.Document);
		QTextBlockFormat bf = tc.blockFormat();
		bf.setLineHeight(30, 4);
		bf.setAlignment(AlignmentFlag.AlignCenter);
		QTextCharFormat cf = bf.toCharFormat();

		tc.setBlockFormat(bf);
		tc.setCharFormat(cf);
//		te.setTextCursor(tc);
		
		ArrayList<String> allLine = cheakDocument.getAllLine(text);
		int i = 0;
		for(String s:allLine) {
//			QTextDocument doc = te.document();
			te.append(s);
//			te.setPlainText(text);
			if(i == 0) {
				
				te.moveCursor(MoveOperation.Start);
			}
			
			
			i++;
		}
		
		
		
		
	
		QFont ff = te.font();
		System.out.println(ff.pointSize());

		long t3 = System.currentTimeMillis();
		long f = t3-t2;
		System.out.println("show file time: "+f+"ms");
//		QTextDocument doc = te.document();
//		QTextCursor ttc = new QTextCursor(doc);
//		ttc.movePosition(MoveOperation.End);
//		ttc.select(SelectionType.BlockUnderCursor);
//		
//		te.setTextCursor(ttc);
		QApplication.exec();
		QApplication.shutdown();
	}

	
}