package yang.app.qt.black;

class hasinfo
{
  boolean ishas;
  int index;
  
  public hasinfo(boolean ishas, int index)
  {
    this.ishas = ishas;
    this.index = index;
  }
}
