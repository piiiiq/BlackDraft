package yang.demo.allPurpose;

public class setIndex{
	String s;
	int v;
	public setIndex(String s,int v) {
		this.s = s;
		this.v = v;
	}
}