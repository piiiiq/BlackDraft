package yang.demo.allPurpose;
/**
 * 此类写了一些通用算法
 */
import java.util.ArrayList;
import java.util.Iterator;

public class algorithm {

	/**
	 * 对set数组中的setIndex对象进行排序
	 * setIndex数组中装有setIndex对象，对象v值大的，排在返回的数组的上面
	 * @param set
	 * @return返回的数组只包含排序后的setIndex对象的s值，也就是其包含的字符串
	 */
	public static ArrayList<String> setIndex(ArrayList<setIndex> set) {
		ArrayList<String> s = new ArrayList<>();
		ArrayList<setIndex> sett = set;

		while(sett.size() != 0) {
			int i=0;
			int index = 0;
			String text = null;
			for(int a=0;a<sett.size();a++) {
				setIndex setIndex = sett.get(a);
				if(setIndex.v > i) {
					i=setIndex.v;
					text = setIndex.s;
					index = a;
				}
			}
			s.add(text);
			sett.remove(index);
		}
		return s;
		
	}
	/**
	 * 返回a中有多少字符被b包含
	 * @param a
	 * @param b
	 * @return
	 */
	public static int valueBySame(String a,String b) {
		int same = 0;
		for(int i=0;i<a.length();i++) {
			char charAt = a.charAt(i);
			if(b.indexOf(charAt)!=-1) {
				same++;
			}
		}
		return same;
	}
	
}
