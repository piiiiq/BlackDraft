package yang.demo.allPurpose;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import yang.app.qt.black.black;

public class yangIO implements Serializable {
	static final long serialVersionUID = 42L;
	FileReader fr;
	FileWriter fw;
	BufferedReader br;
	BufferedWriter bw;

	public String readLineFromFile(File file) {
		try {
			if (this.fr == null) {
				this.fr = new FileReader(file);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		if (this.br == null) {
			this.br = new BufferedReader(this.fr);
		}
		try {
			String str;
			if ((str = this.br.readLine()) != null) {
				return str;
			}
			this.br.close();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int writeStringToFile(File file, String str) {
		try {
			if (this.fw == null) {
				this.fw = new FileWriter(file);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (this.bw == null) {
			this.bw = new BufferedWriter(this.fw);
		}
		try {
			this.bw.write(str);
			this.bw.close();
			return 1;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}
	/**
	 * 获取给定的url指向的数据到byte数组
	 * 此方法配合此类的其他的方法，可下载远程数据到文件或内存
	 * @param u
	 * @return
	 */
	public static byte[] getFileFromURL(String u) {
		byte[] bytes = null;
		try {
			URL url = new URL(u);
			URLConnection oc = url.openConnection();
			oc.setConnectTimeout(5000);
			oc.setReadTimeout(5000);
			DataInputStream dataInputStream = new DataInputStream(oc.getInputStream());
			bytes = dataInputStream.readAllBytes();
			dataInputStream.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if(e.getClass().getName().equals("java.net.SocketTimeoutException")) {
					black.p("连接url("+u+")超时");
			}else if(e.getClass().getName().equals("java.net.UnknownHostException")) {
				black.p("网络连接出错：未知主机错误");
			}else {
				e.printStackTrace();

			}
		}
			
		
		
		return bytes;
	}
	/**
	 * 将给定的字节数组内的数据保存到文件中
	 * @param b
	 * @param file
	 * @return 写入是否成功
	 */
	public static boolean writeFileFromBytes(byte[] b,String file) {
		File f = new File(file);
		boolean isOk = true;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(f);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			isOk = false;
			e1.printStackTrace();
		}
		DataOutputStream dos = new DataOutputStream(fos);
		try {
			dos.write(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		try {
			dos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		try {
			dos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isOk = false;
			e.printStackTrace();
		}
		return isOk;
	}
}
