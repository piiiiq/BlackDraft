package yang.demo.allPurpose;

public class MDict {}
